package su.spyme.license;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Verifies the server's Ed25519 signature with an embedded {@code kid → publicKey}
 * map (native JDK, no BouncyCastle). This is the anti-fake-server core: without
 * the server's private key, no one can forge a VALID a genuine SDK will accept.
 */
final class ResponseVerifier {

    private final Map<Integer, PublicKey> keys;

    private ResponseVerifier(Map<Integer, PublicKey> keys) {
        this.keys = keys;
    }

    /** @param keysByKid kid → base64 X.509 public key (as produced by the server's Ed25519Keys). */
    static ResponseVerifier fromBase64(Map<Integer, String> keysByKid) {
        Map<Integer, PublicKey> parsed = new HashMap<>();
        for (Map.Entry<Integer, String> e : keysByKid.entrySet()) {
            parsed.put(e.getKey(), publicFromBase64(e.getValue()));
        }
        return new ResponseVerifier(parsed);
    }

    boolean verify(SignedResponse response) {
        PublicKey key = keys.get(response.kid());
        if (key == null) {
            return false;
        }
        try {
            byte[] canonical = CanonicalPayload.bytes(
                    response.kid(),
                    response.licenseKeyId(),
                    response.productId(),
                    response.verdict(),
                    response.ttl(),
                    response.nonce(),
                    response.issuedAt(),
                    response.hwidHash());
            Signature sig = Signature.getInstance("Ed25519");
            sig.initVerify(key);
            sig.update(canonical);
            return sig.verify(Base64.getDecoder().decode(response.sig()));
        } catch (Exception e) {
            return false;
        }
    }

    private static PublicKey publicFromBase64(String b64) {
        try {
            byte[] der = Base64.getDecoder().decode(b64);
            return KeyFactory.getInstance("Ed25519").generatePublic(new X509EncodedKeySpec(der));
        } catch (Exception e) {
            throw new IllegalArgumentException("invalid Ed25519 public key", e);
        }
    }
}
