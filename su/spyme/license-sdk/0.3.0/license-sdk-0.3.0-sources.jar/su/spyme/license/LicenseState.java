package su.spyme.license;

/**
 * Outcome of a license check.
 *
 * <ul>
 *   <li>{@link #VALID} — the server returned VALID and the signature verified.</li>
 *   <li>{@link #INVALID} — the server returned a rejection (revoked/expired/limit/…),
 *       signature verified. The plugin should degrade.</li>
 *   <li>{@link #GRACE} — the server was unreachable but a valid, HWID-bound,
 *       in-window cached VALID exists. Keep running.</li>
 *   <li>{@link #NO_KEY} — no license key was configured.</li>
 *   <li>{@link #ERROR} — server unreachable with no usable cache, or a response
 *       failed verification (bad signature / wrong HWID / replay). Treat as invalid.</li>
 * </ul>
 */
public enum LicenseState {
    VALID,
    INVALID,
    GRACE,
    NO_KEY,
    ERROR;

    /** True when the plugin is allowed to run (a live VALID or an in-window GRACE). */
    public boolean isUsable() {
        return this == VALID || this == GRACE;
    }
}
