package su.spyme.license;

import java.util.Map;

/**
 * Parsed license-service response. Holds the raw JSON too, so the grace cache
 * can persist and later re-verify the exact signed bytes.
 */
final class SignedResponse {

    private final int kid;
    private final String verdict;
    private final long ttl;
    private final String nonce;
    private final String hwidHash;
    private final long issuedAt;
    private final long licenseKeyId;
    private final long productId;
    private final String message;
    private final String sig;
    private final String raw;

    private SignedResponse(int kid, String verdict, long ttl, String nonce, String hwidHash,
                           long issuedAt, long licenseKeyId, long productId, String message, String sig, String raw) {
        this.kid = kid;
        this.verdict = verdict;
        this.ttl = ttl;
        this.nonce = nonce;
        this.hwidHash = hwidHash;
        this.issuedAt = issuedAt;
        this.licenseKeyId = licenseKeyId;
        this.productId = productId;
        this.message = message;
        this.sig = sig;
        this.raw = raw;
    }

    static SignedResponse parse(String json) {
        Map<String, String> m = Json.parseFlatObject(json);
        return new SignedResponse(
                asInt(m, "kid"),
                req(m, "verdict"),
                asLong(m, "ttl"),
                req(m, "nonce"),
                req(m, "hwid_hash"),
                asLong(m, "issued_at"),
                asLong(m, "license_key_id"),
                asLong(m, "product_id"),
                m.get("message"),
                req(m, "sig"),
                json);
    }

    int kid() { return kid; }
    String verdict() { return verdict; }
    long ttl() { return ttl; }
    String nonce() { return nonce; }
    String hwidHash() { return hwidHash; }
    long issuedAt() { return issuedAt; }
    long licenseKeyId() { return licenseKeyId; }
    long productId() { return productId; }
    String message() { return message; }
    String sig() { return sig; }
    String raw() { return raw; }

    boolean isValidVerdict() {
        return "VALID".equals(verdict);
    }

    private static String req(Map<String, String> m, String key) {
        String v = m.get(key);
        if (v == null) {
            throw new IllegalArgumentException("missing field: " + key);
        }
        return v;
    }

    private static int asInt(Map<String, String> m, String key) {
        return Integer.parseInt(req(m, key).trim());
    }

    private static long asLong(Map<String, String> m, String key) {
        return Long.parseLong(req(m, key).trim());
    }
}
