package su.spyme.license;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Tiny JSON helper — just enough for this SDK's flat request/response shapes, so
 * the artifact stays dependency-free. Not a general JSON library: it parses a
 * single flat object (no nested objects/arrays).
 */
final class Json {

    private Json() {
    }

    /** Escapes a string's contents for embedding between quotes (no surrounding quotes). */
    static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '"' -> sb.append("\\\"");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    /**
     * Parses a flat JSON object into key → value. String values are unescaped;
     * numbers/booleans are kept as their text; JSON null maps to Java null.
     *
     * @throws IllegalArgumentException on malformed input.
     */
    static Map<String, String> parseFlatObject(String json) {
        Map<String, String> out = new LinkedHashMap<>();
        int i = skipWs(json, 0);
        i = expect(json, i, '{');
        i = skipWs(json, i);
        if (at(json, i) == '}') {
            return out;
        }
        while (true) {
            i = skipWs(json, i);
            StringBuilder key = new StringBuilder();
            i = readString(json, i, key);
            i = skipWs(json, i);
            i = expect(json, i, ':');
            i = skipWs(json, i);
            String value;
            char c = at(json, i);
            if (c == '"') {
                StringBuilder sb = new StringBuilder();
                i = readString(json, i, sb);
                value = sb.toString();
            } else if (json.startsWith("null", i)) {
                value = null;
                i += 4;
            } else if (json.startsWith("true", i)) {
                value = "true";
                i += 4;
            } else if (json.startsWith("false", i)) {
                value = "false";
                i += 5;
            } else {
                int start = i;
                while (i < json.length() && "-+.eE0123456789".indexOf(json.charAt(i)) >= 0) {
                    i++;
                }
                if (i == start) {
                    throw new IllegalArgumentException("unexpected value at " + i);
                }
                value = json.substring(start, i);
            }
            out.put(key.toString(), value);
            i = skipWs(json, i);
            char sep = at(json, i);
            if (sep == ',') {
                i++;
            } else if (sep == '}') {
                break;
            } else {
                throw new IllegalArgumentException("expected ',' or '}' at " + i);
            }
        }
        return out;
    }

    private static int readString(String s, int i, StringBuilder into) {
        i = expect(s, i, '"');
        while (i < s.length()) {
            char c = s.charAt(i++);
            if (c == '"') {
                return i;
            }
            if (c == '\\') {
                char e = s.charAt(i++);
                switch (e) {
                    case '"' -> into.append('"');
                    case '\\' -> into.append('\\');
                    case '/' -> into.append('/');
                    case 'n' -> into.append('\n');
                    case 'r' -> into.append('\r');
                    case 't' -> into.append('\t');
                    case 'b' -> into.append('\b');
                    case 'f' -> into.append('\f');
                    case 'u' -> {
                        into.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                    }
                    default -> throw new IllegalArgumentException("bad escape \\" + e);
                }
            } else {
                into.append(c);
            }
        }
        throw new IllegalArgumentException("unterminated string");
    }

    private static int skipWs(String s, int i) {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    private static int expect(String s, int i, char c) {
        if (at(s, i) != c) {
            throw new IllegalArgumentException("expected '" + c + "' at " + i);
        }
        return i + 1;
    }

    private static char at(String s, int i) {
        if (i >= s.length()) {
            throw new IllegalArgumentException("unexpected end of input");
        }
        return s.charAt(i);
    }
}
