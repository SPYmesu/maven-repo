package su.spyme.license;

import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Enumeration;
import java.util.HexFormat;

/**
 * Pure-JDK hardware fingerprint (zero dependencies). Only the SHA-256 of the
 * fingerprint ever leaves the machine — the raw values stay local.
 *
 * Sources, most stable first: the OS machine-id (stable across restarts, incl.
 * inside a container), the primary MAC, and os.arch/os.name. Inside a
 * Pterodactyl/Docker container the machine-id anchors identity; if a container
 * is recreated with a fresh id that just reads as a new instance — the server's
 * stale-activation release reclaims the old slot, so churn never wrongly trips
 * the activation limit.
 *
 * ponytail: machine-id + MAC + arch is a deliberately simple fingerprint; the
 * exact field set can be tuned per host if Pterodactyl stability demands it
 * (docs/license-system-plan.md §17), but this is stable for the common case.
 */
final class Hwid {

    private static volatile String cached;

    private Hwid() {
    }

    /** SHA-256 hex of the local fingerprint. Computed once, then cached. */
    static String compute() {
        String c = cached;
        if (c != null) {
            return c;
        }
        StringBuilder raw = new StringBuilder(96);
        String machineId = readMachineId();
        if (machineId != null && !machineId.isBlank()) {
            raw.append("mid=").append(machineId.trim()).append(';');
        }
        String mac = primaryMac();
        if (mac != null) {
            raw.append("mac=").append(mac).append(';');
        }
        if (machineId == null && mac == null) {
            // Last resort so the fingerprint is never empty.
            raw.append("host=").append(hostname()).append(';');
        }
        raw.append("arch=").append(System.getProperty("os.arch", "")).append(';');
        raw.append("os=").append(System.getProperty("os.name", "")).append(';');

        c = sha256Hex(raw.toString());
        cached = c;
        return c;
    }

    private static String readMachineId() {
        for (String p : new String[]{"/etc/machine-id", "/var/lib/dbus/machine-id"}) {
            try {
                Path path = Path.of(p);
                if (Files.isReadable(path)) {
                    return Files.readString(path, StandardCharsets.UTF_8);
                }
            } catch (Exception ignored) {
                // try the next candidate
            }
        }
        // Windows fallback: the machine name is stable enough as a component.
        String computerName = System.getenv("COMPUTERNAME");
        return computerName != null ? "win:" + computerName : null;
    }

    private static String primaryMac() {
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (ni.isLoopback() || ni.isVirtual() || !ni.isUp()) {
                    continue;
                }
                byte[] mac = ni.getHardwareAddress();
                if (mac != null && mac.length > 0) {
                    return HexFormat.of().formatHex(mac);
                }
            }
        } catch (Exception ignored) {
            // no usable interface
        }
        return null;
    }

    private static String hostname() {
        try {
            return java.net.InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }
}
