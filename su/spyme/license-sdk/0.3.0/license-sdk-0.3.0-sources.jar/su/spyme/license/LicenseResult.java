package su.spyme.license;

/**
 * Immutable result of {@link LicenseGuard#check()}: the {@link LicenseState}
 * plus the server verdict string (e.g. {@code "REVOKED"}) and a human message
 * when present.
 */
public final class LicenseResult {

    private final LicenseState state;
    private final String verdict;
    private final String message;

    public LicenseResult(LicenseState state, String verdict, String message) {
        this.state = state;
        this.verdict = verdict;
        this.message = message;
    }

    public LicenseState state() {
        return state;
    }

    /** Server verdict ({@code VALID}, {@code REVOKED}, …), or null when there was no verified response. */
    public String verdict() {
        return verdict;
    }

    public String message() {
        return message;
    }

    public boolean isUsable() {
        return state.isUsable();
    }

    @Override
    public String toString() {
        return "LicenseResult{" + state + (verdict != null ? ", verdict=" + verdict : "") + "}";
    }
}
