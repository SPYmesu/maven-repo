package su.spyme.license;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Public entry point plugin developers embed (§10). Typical use in {@code onEnable}:
 *
 * <pre>{@code
 * LicenseGuard.init(LicenseConfig.builder()
 *     .key(getConfig().getString("license-key"))
 *     .productId(42)
 *     .endpoint("https://l.moonstudio.space/api/v1/license")
 *     .publicKeys(Map.of(1, "<base64 ed25519 pub>"))
 *     .cacheDir(getDataFolder().toPath())
 *     .pluginVersion(getDescription().getVersion())
 *     .build());
 * LicenseGuard.require(); // throws LicenseException → plugin disabled if not licensed
 * LicenseGuard.onStateChange(r -> { if (!r.isUsable()) disableFeatures(); });
 * }</pre>
 *
 * After the first {@link #check()}/{@link #require()} a daemon heartbeat thread
 * re-validates on the configured interval and fires {@link #onStateChange}
 * listeners on a change — this is how a runtime revoke reaches the plugin.
 *
 * Note: any client-side check inside a jar can ultimately be stripped by a
 * determined reverser (see the honest threat model, §1). The unforgeable parts
 * live on the server (signed verdicts, activation limits) and in the per-download
 * watermark; this guard raises the cost and wires the plugin into that system.
 */
public final class LicenseGuard {

    private static volatile LicenseGuard instance;

    private final LicenseConfig config;
    private final LicenseClient client;
    private final List<Consumer<LicenseResult>> listeners = new CopyOnWriteArrayList<>();
    private volatile LicenseResult current;
    private volatile ScheduledExecutorService heartbeat;

    private LicenseGuard(LicenseConfig config, LicenseClient client) {
        this.config = config;
        this.client = client;
    }

    /** Initializes the guard with the production HTTP transport. Call once, early. */
    public static synchronized void init(LicenseConfig config) {
        install(config, new LicenseClient(config, LicenseClient.httpTransport(config.httpTimeout())));
    }

    /** Test/advanced hook: initialize with a custom transport. */
    static synchronized void install(LicenseConfig config, LicenseClient client) {
        shutdown();
        instance = new LicenseGuard(config, client);
    }

    /** Blocking validation. Starts the heartbeat on first call. */
    public static LicenseResult check() {
        return required().doCheck();
    }

    /**
     * {@link #check()} then throw {@link LicenseException} if not usable. Let it
     * propagate out of {@code onEnable} to have the platform disable the plugin.
     */
    public static void require() {
        LicenseResult result = check();
        if (!result.isUsable()) {
            throw new LicenseException(result);
        }
    }

    /** Cheap soft gate around premium features — reflects the last known state (no network call). */
    public static boolean isValid() {
        LicenseGuard g = instance;
        return g != null && g.current != null && g.current.isUsable();
    }

    /** The last known result, or null before the first {@link #check()}. */
    public static LicenseResult current() {
        LicenseGuard g = instance;
        return g != null ? g.current : null;
    }

    /** Registers a listener fired whenever the state changes (e.g. a runtime revoke). */
    public static void onStateChange(Consumer<LicenseResult> listener) {
        required().listeners.add(listener);
    }

    /** Stops the heartbeat thread. Safe to call multiple times. */
    public static synchronized void shutdown() {
        LicenseGuard g = instance;
        if (g != null && g.heartbeat != null) {
            g.heartbeat.shutdownNow();
            g.heartbeat = null;
        }
    }

    private LicenseResult doCheck() {
        LicenseResult result = client.validate();
        setState(result);
        startHeartbeat();
        return result;
    }

    private void setState(LicenseResult result) {
        LicenseResult previous = current;
        current = result;
        if (previous == null || previous.state() != result.state()) {
            for (Consumer<LicenseResult> listener : listeners) {
                try {
                    listener.accept(result);
                } catch (Throwable ignored) {
                    // a listener must never break the guard
                }
            }
        }
    }

    private synchronized void startHeartbeat() {
        if (heartbeat != null) {
            return;
        }
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "spyme-license-heartbeat");
            thread.setDaemon(true);
            return thread;
        });
        long seconds = Math.max(60, config.heartbeatInterval().toSeconds());
        scheduler.scheduleAtFixedRate(() -> {
            try {
                setState(client.heartbeat());
            } catch (Throwable ignored) {
                // never let a heartbeat error kill the scheduler
            }
        }, seconds, seconds, TimeUnit.SECONDS);
        heartbeat = scheduler;
    }

    private static LicenseGuard required() {
        LicenseGuard g = instance;
        if (g == null) {
            throw new IllegalStateException("LicenseGuard.init(...) must be called first");
        }
        return g;
    }
}
