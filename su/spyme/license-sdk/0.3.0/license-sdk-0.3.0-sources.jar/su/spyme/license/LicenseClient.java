package su.spyme.license;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;

/**
 * The verification engine (§5, §10): builds the request, calls the server,
 * verifies the signed response, and falls back to the HWID-bound offline-grace
 * cache when the server is unreachable.
 *
 * The {@link Transport} seam keeps all this logic unit-testable without a live
 * server — production uses {@link #httpTransport}.
 */
final class LicenseClient {

    /** Pluggable HTTP layer: return the response body, or throw on any transport failure. */
    interface Transport {
        String send(String url, String body) throws Exception;
    }

    private final LicenseConfig config;
    private final ResponseVerifier verifier;
    private final GraceCache cache;
    private final Transport transport;
    private final String hwid;
    private final SecureRandom random = new SecureRandom();

    LicenseClient(LicenseConfig config, Transport transport) {
        this.config = config;
        this.verifier = ResponseVerifier.fromBase64(config.publicKeys());
        this.cache = new GraceCache(config.cacheDir(), config.productId());
        this.transport = transport;
        this.hwid = Hwid.compute();
    }

    LicenseResult validate() {
        return call("/validate");
    }

    LicenseResult heartbeat() {
        return call("/heartbeat");
    }

    private LicenseResult call(String path) {
        if (!config.hasKey()) {
            return new LicenseResult(LicenseState.NO_KEY, null, "No license key configured");
        }
        String nonce = newNonce();
        String body = buildRequest(nonce, Instant.now().getEpochSecond());

        String responseJson;
        try {
            responseJson = transport.send(config.endpoint() + path, body);
        } catch (Exception networkError) {
            return fromGrace(); // server unreachable → try the offline cache
        }

        SignedResponse resp;
        try {
            resp = SignedResponse.parse(responseJson);
        } catch (Exception malformed) {
            return new LicenseResult(LicenseState.ERROR, null, "Malformed server response");
        }

        // Order matters: signature first (defeats fake server), then freshness + HWID binding.
        if (!verifier.verify(resp)) {
            return new LicenseResult(LicenseState.ERROR, null, "Signature verification failed");
        }
        if (!nonce.equals(resp.nonce())) {
            return new LicenseResult(LicenseState.ERROR, null, "Nonce mismatch (possible replay)");
        }
        if (!hwid.equals(resp.hwidHash())) {
            return new LicenseResult(LicenseState.ERROR, null, "Response bound to a different machine");
        }

        if (resp.isValidVerdict()) {
            cache.store(resp.raw());
            return new LicenseResult(LicenseState.VALID, "VALID", resp.message());
        }
        // A verified rejection must not silently fall back to a stale VALID cache.
        cache.clear();
        return new LicenseResult(LicenseState.INVALID, resp.verdict(), resp.message());
    }

    private LicenseResult fromGrace() {
        String raw = cache.read();
        if (raw == null) {
            return new LicenseResult(LicenseState.ERROR, null, "Server unreachable and no cached license");
        }
        SignedResponse resp;
        try {
            resp = SignedResponse.parse(raw);
        } catch (Exception e) {
            return new LicenseResult(LicenseState.ERROR, null, "Corrupt license cache");
        }
        long now = Instant.now().getEpochSecond();
        if (!verifier.verify(resp)) {
            return new LicenseResult(LicenseState.ERROR, null, "Cached license failed verification");
        }
        if (!resp.isValidVerdict()) {
            return new LicenseResult(LicenseState.ERROR, null, "Cached license is not VALID");
        }
        if (!hwid.equals(resp.hwidHash())) {
            return new LicenseResult(LicenseState.ERROR, null, "Cached license bound to another machine");
        }
        // Clock-tamper: a wall-clock rolled back before issue can't be trusted to bound the grace window.
        if (now < resp.issuedAt()) {
            return new LicenseResult(LicenseState.ERROR, null, "System clock rolled back — cache rejected");
        }
        long graceEnd = resp.issuedAt() + config.graceWindow().toSeconds();
        if (now >= graceEnd) {
            return new LicenseResult(LicenseState.ERROR, null, "Offline grace window expired");
        }
        return new LicenseResult(LicenseState.GRACE, "VALID", "Offline grace (server unreachable)");
    }

    private String buildRequest(String nonce, long ts) {
        StringBuilder sb = new StringBuilder(176);
        sb.append('{');
        sb.append("\"key\":\"").append(Json.escape(config.key())).append("\",");
        sb.append("\"hwid\":\"").append(hwid).append("\",");
        sb.append("\"product_id\":").append(config.productId()).append(',');
        if (config.pluginVersion() != null) {
            sb.append("\"plugin_ver\":\"").append(Json.escape(config.pluginVersion())).append("\",");
        }
        sb.append("\"nonce\":\"").append(Json.escape(nonce)).append("\",");
        sb.append("\"ts\":").append(ts);
        sb.append('}');
        return sb.toString();
    }

    private String newNonce() {
        byte[] b = new byte[12];
        random.nextBytes(b);
        return Base64.getEncoder().encodeToString(b);
    }

    /** Production transport over {@link HttpClient}. Non-2xx (incl. 429) throws → grace fallback. */
    static Transport httpTransport(Duration timeout) {
        HttpClient http = HttpClient.newBuilder().connectTimeout(timeout).build();
        return (url, body) -> {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                    .timeout(timeout)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            int code = response.statusCode();
            if (code / 100 != 2) {
                throw new IOException("license-service returned HTTP " + code);
            }
            return response.body();
        };
    }
}
