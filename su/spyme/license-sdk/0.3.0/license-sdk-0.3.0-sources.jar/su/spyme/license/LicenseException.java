package su.spyme.license;

/**
 * Thrown by {@link LicenseGuard#require()} when the license is not usable. A
 * plugin can let it propagate out of {@code onEnable} (the platform then
 * disables the plugin) or catch it to degrade gracefully.
 */
public final class LicenseException extends RuntimeException {

    private final transient LicenseResult result;

    public LicenseException(LicenseResult result) {
        super("License not usable: " + result.state()
                + (result.verdict() != null ? " (" + result.verdict() + ")" : "")
                + (result.message() != null ? " — " + result.message() : ""));
        this.result = result;
    }

    public LicenseResult result() {
        return result;
    }
}
