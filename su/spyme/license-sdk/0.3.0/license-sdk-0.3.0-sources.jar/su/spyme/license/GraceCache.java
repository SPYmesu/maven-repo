package su.spyme.license;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Persists the last verified VALID response so the plugin survives our downtime
 * (offline grace, §5.3). Stores the raw signed JSON verbatim — it is re-verified
 * (signature + HWID + grace window + clock) on read, so a tampered file is
 * rejected. All IO is best-effort: a failure to read/write degrades to "no
 * cache", never crashes the plugin.
 */
final class GraceCache {

    private final Path file;

    GraceCache(Path cacheDir, long productId) {
        this.file = cacheDir.resolve("lic-" + productId + ".lic");
    }

    void store(String rawJson) {
        try {
            Path parent = file.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(file, rawJson, StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            // Read-only FS / permissions — grace simply won't be available.
        }
    }

    String read() {
        try {
            return Files.isReadable(file) ? Files.readString(file, StandardCharsets.UTF_8) : null;
        } catch (Exception e) {
            return null;
        }
    }

    void clear() {
        try {
            Files.deleteIfExists(file);
        } catch (Exception ignored) {
            // best-effort
        }
    }
}
