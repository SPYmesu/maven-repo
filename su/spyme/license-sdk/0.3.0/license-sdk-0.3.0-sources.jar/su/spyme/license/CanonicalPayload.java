package su.spyme.license;

import java.nio.charset.StandardCharsets;

/**
 * Byte-for-byte reproduction of the server's signed payload
 * ({@code su.spyme.marketplace.licensing.LicenseSignedPayload.canonicalBytes}).
 * The two MUST stay identical — a golden test on each side pins the exact bytes.
 *
 * Canonical form: a JSON object with keys in ascending name order, no
 * insignificant whitespace, minimal string escaping.
 */
final class CanonicalPayload {

    private CanonicalPayload() {
    }

    static byte[] bytes(
            int kid,
            long licenseKeyId,
            long productId,
            String verdict,
            long ttl,
            String nonce,
            long issuedAt,
            String hwidHash) {
        StringBuilder sb = new StringBuilder(160);
        sb.append('{');
        field(sb, "hwid_hash", hwidHash).append(',');
        number(sb, "issued_at", issuedAt).append(',');
        number(sb, "kid", kid).append(',');
        number(sb, "license_key_id", licenseKeyId).append(',');
        field(sb, "nonce", nonce).append(',');
        number(sb, "product_id", productId).append(',');
        number(sb, "ttl", ttl).append(',');
        field(sb, "verdict", verdict);
        sb.append('}');
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static StringBuilder field(StringBuilder sb, String key, String value) {
        sb.append('"').append(key).append("\":\"");
        escape(sb, value);
        return sb.append('"');
    }

    private static StringBuilder number(StringBuilder sb, String key, long value) {
        return sb.append('"').append(key).append("\":").append(value);
    }

    private static void escape(StringBuilder sb, String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '"' -> sb.append("\\\"");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
    }
}
