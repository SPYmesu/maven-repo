package su.spyme.license;

import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;

/**
 * Immutable SDK configuration. Build with {@link Builder}. The plugin reads the
 * {@code key} from its own config (e.g. {@code config.yml: license-key}); the
 * server {@code endpoint} and {@code publicKeys} are baked into the plugin by
 * the developer.
 */
public final class LicenseConfig {

    private final String key;
    private final long productId;
    private final String endpoint;
    private final Map<Integer, String> publicKeys;
    private final String pluginVersion;
    private final Path cacheDir;
    private final Duration graceWindow;
    private final Duration heartbeatInterval;
    private final Duration httpTimeout;

    private LicenseConfig(Builder b) {
        this.key = b.key;
        this.productId = b.productId;
        this.endpoint = stripTrailingSlash(b.endpoint);
        this.publicKeys = Map.copyOf(b.publicKeys);
        this.pluginVersion = b.pluginVersion;
        this.cacheDir = b.cacheDir != null ? b.cacheDir : Path.of(".");
        this.graceWindow = b.graceWindow;
        this.heartbeatInterval = b.heartbeatInterval;
        this.httpTimeout = b.httpTimeout;
    }

    public String key() { return key; }
    public long productId() { return productId; }
    public String endpoint() { return endpoint; }
    public Map<Integer, String> publicKeys() { return publicKeys; }
    public String pluginVersion() { return pluginVersion; }
    public Path cacheDir() { return cacheDir; }
    public Duration graceWindow() { return graceWindow; }
    public Duration heartbeatInterval() { return heartbeatInterval; }
    public Duration httpTimeout() { return httpTimeout; }

    public boolean hasKey() {
        return key != null && !key.isBlank();
    }

    public static Builder builder() {
        return new Builder();
    }

    private static String stripTrailingSlash(String s) {
        return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
    }

    public static final class Builder {
        private String key;
        private long productId;
        private String endpoint;
        private Map<Integer, String> publicKeys;
        private String pluginVersion;
        private Path cacheDir;
        private Duration graceWindow = Duration.ofHours(48);
        private Duration heartbeatInterval = Duration.ofMinutes(30);
        private Duration httpTimeout = Duration.ofSeconds(10);

        /** The license key the server admin pasted into the plugin config. May be null/blank (→ NO_KEY). */
        public Builder key(String key) { this.key = key; return this; }

        public Builder productId(long productId) { this.productId = productId; return this; }

        /** Base URL, e.g. {@code https://l.moonstudio.space/api/v1/license}. */
        public Builder endpoint(String endpoint) { this.endpoint = endpoint; return this; }

        /** kid → base64 X.509 Ed25519 public key. Baked into the plugin at build time. */
        public Builder publicKeys(Map<Integer, String> publicKeys) { this.publicKeys = publicKeys; return this; }

        public Builder pluginVersion(String v) { this.pluginVersion = v; return this; }

        /** Where the offline-grace {@code .lic} cache is written (e.g. the plugin data folder). */
        public Builder cacheDir(Path dir) { this.cacheDir = dir; return this; }

        public Builder graceWindow(Duration d) { this.graceWindow = d; return this; }

        public Builder heartbeatInterval(Duration d) { this.heartbeatInterval = d; return this; }

        public Builder httpTimeout(Duration d) { this.httpTimeout = d; return this; }

        public LicenseConfig build() {
            if (endpoint == null || endpoint.isBlank()) {
                throw new IllegalArgumentException("endpoint is required");
            }
            if (productId <= 0) {
                throw new IllegalArgumentException("productId is required");
            }
            if (publicKeys == null || publicKeys.isEmpty()) {
                throw new IllegalArgumentException("at least one public key is required");
            }
            return new LicenseConfig(this);
        }
    }
}
