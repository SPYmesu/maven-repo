-- V036 — multi-vendor module.
--
-- vendors            — registered vendors (status PENDING/ACTIVE/SUSPENDED/REJECTED).
-- vendor_users       — m:n bridge (vendor_id, user_id) с role (OWNER/MANAGER/STAFF).
-- vendor_invitations — outside-email invite codes для onboarding via email + claim.

CREATE TABLE vendors (
    id              BIGSERIAL    PRIMARY KEY,
    slug            VARCHAR(64)  NOT NULL UNIQUE,
    display_name    TEXT         NOT NULL,
    contact_email   TEXT         NOT NULL,
    contact_phone   VARCHAR(32)  NULL,
    description     TEXT         NULL,
    logo_url        TEXT         NULL,
    banner_url      TEXT         NULL,
    status          VARCHAR(16)  NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING','ACTIVE','SUSPENDED','REJECTED')),
    suspended_reason TEXT        NULL,
    onboarded_at    TIMESTAMP    NULL,
    suspended_at    TIMESTAMP    NULL,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX vendors_status_idx ON vendors (status);

CREATE TRIGGER vendors_set_updated_at_trigger
BEFORE UPDATE ON vendors
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE vendor_users (
    vendor_id    BIGINT       NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    user_id      BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role         VARCHAR(16)  NOT NULL DEFAULT 'STAFF'
        CHECK (role IN ('OWNER','MANAGER','STAFF')),
    invited_by   BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    invited_at   TIMESTAMP    NULL,
    accepted_at  TIMESTAMP    NULL,
    PRIMARY KEY (vendor_id, user_id)
);

CREATE INDEX vendor_users_user_idx ON vendor_users (user_id);

CREATE TABLE vendor_invitations (
    id                    BIGSERIAL    PRIMARY KEY,
    vendor_id             BIGINT       NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    email                 TEXT         NOT NULL,
    code                  VARCHAR(64)  NOT NULL UNIQUE,
    role                  VARCHAR(16)  NOT NULL DEFAULT 'STAFF'
        CHECK (role IN ('OWNER','MANAGER','STAFF')),
    invited_by            BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    invited_at            TIMESTAMP    NOT NULL DEFAULT NOW(),
    expires_at            TIMESTAMP    NOT NULL,
    accepted_at           TIMESTAMP    NULL,
    accepted_by_user_id   BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX vendor_invitations_email_idx ON vendor_invitations (email)
    WHERE accepted_at IS NULL;
CREATE INDEX vendor_invitations_active_idx ON vendor_invitations (vendor_id, expires_at)
    WHERE accepted_at IS NULL;
