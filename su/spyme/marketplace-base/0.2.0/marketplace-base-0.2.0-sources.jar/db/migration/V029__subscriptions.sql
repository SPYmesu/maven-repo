-- V029 — subscriptions module.
--
-- Time-bounded access for subscription-style products (digital plugins
-- on moonstudio, premium tiers, recurring physical goods).
--
-- Lifecycle: ACTIVE -> EXPIRED (cron sweep) или ACTIVE -> CANCELLED (user/manager).
-- Auto-renew = TRUE: cron создаёт следующий order на expires_at - N days
-- (post-launch feature; в 0.2.0 — manual extend).
-- order_id NULL разрешён — host-seeded subscriptions без linked order.

CREATE TABLE subscriptions (
    id                    BIGSERIAL    PRIMARY KEY,
    user_id               BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id            BIGINT       NOT NULL REFERENCES products(id),
    order_id              BIGINT       NULL REFERENCES orders(id) ON DELETE SET NULL,
    period                VARCHAR(16)  NOT NULL CHECK (period IN ('month','quarter','year')),
    started_at            TIMESTAMP    NOT NULL DEFAULT NOW(),
    expires_at            TIMESTAMP    NOT NULL,
    cancelled_at          TIMESTAMP    NULL,
    cancelled_by_user_id  BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    status                VARCHAR(16)  NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE','EXPIRED','CANCELLED')),
    auto_renew            BOOLEAN      NOT NULL DEFAULT FALSE,
    notified_expiring_at  TIMESTAMP    NULL,
    notified_expired_at   TIMESTAMP    NULL,
    created_at            TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX subscriptions_user_status_idx
    ON subscriptions (user_id, status);
CREATE INDEX subscriptions_product_status_idx
    ON subscriptions (product_id, status);
CREATE INDEX subscriptions_expires_active_idx
    ON subscriptions (expires_at)
    WHERE status = 'ACTIVE';

CREATE TRIGGER subscriptions_set_updated_at_trigger
BEFORE UPDATE ON subscriptions
FOR EACH ROW EXECUTE FUNCTION set_updated_at();
