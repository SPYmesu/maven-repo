-- V034 — tax module.
--
-- tax_rules — настраиваемые правила налога с географией + scoping.
--   country/region — NULL означает «applies везде» (с приоритетом над
--                    более общими правилами через priority field).
--   product_kind   — NULL означает применимо ко всем kinds. Иначе DIGITAL/PHYSICAL.
--   category_id    — NULL означает все категории. FK to categories(id).
--   rate_bp        — basis points: 2000 = 20%. 100 bp = 1%.
--   inclusive      — TRUE: цена товара уже включает этот налог
--                    (EU VAT pattern); FALSE: добавляется сверху (US sales tax).
--   priority       — больше = applies first. Default 100.

CREATE TABLE tax_rules (
    id              BIGSERIAL    PRIMARY KEY,
    name            TEXT         NOT NULL,
    country         VARCHAR(2)   NULL,
    region          TEXT         NULL,
    product_kind    VARCHAR(16)  NULL
        CHECK (product_kind IS NULL OR product_kind IN ('PHYSICAL','DIGITAL','MIXED')),
    category_id     BIGINT       NULL REFERENCES categories(id) ON DELETE CASCADE,
    rate_bp         INTEGER      NOT NULL CHECK (rate_bp >= 0 AND rate_bp <= 100000),
    inclusive       BOOLEAN      NOT NULL DEFAULT FALSE,
    priority        INTEGER      NOT NULL DEFAULT 100,
    valid_from      TIMESTAMP    NOT NULL DEFAULT NOW(),
    valid_until     TIMESTAMP    NULL,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX tax_rules_active_country_idx ON tax_rules (country, region)
    WHERE is_active = TRUE;
CREATE INDEX tax_rules_category_idx ON tax_rules (category_id)
    WHERE category_id IS NOT NULL;
CREATE INDEX tax_rules_priority_idx ON tax_rules (priority DESC, id ASC)
    WHERE is_active = TRUE;

CREATE TRIGGER tax_rules_set_updated_at_trigger
BEFORE UPDATE ON tax_rules
FOR EACH ROW EXECUTE FUNCTION set_updated_at();
