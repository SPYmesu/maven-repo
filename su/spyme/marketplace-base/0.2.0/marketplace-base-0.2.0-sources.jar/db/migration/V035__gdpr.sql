-- V035 — GDPR deletion module (Б3 twin-layer).
--
-- gdpr_deletion_requests — workflow PENDING → APPROVED → EXECUTED
--                          (или PENDING → REJECTED).
-- gdpr_legal_archive     — encrypted snapshot of personal data, retained
--                          для legal/regulatory покрытия после operational scrub.
--                          Access — LEGAL_OFFICER role + 2FA (host's policy).

CREATE TABLE gdpr_deletion_requests (
    id              BIGSERIAL    PRIMARY KEY,
    user_id         BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status          VARCHAR(16)  NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING','APPROVED','REJECTED','EXECUTED')),
    requested_at    TIMESTAMP    NOT NULL DEFAULT NOW(),
    reason          TEXT         NULL,
    reviewed_at     TIMESTAMP    NULL,
    reviewed_by     BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    review_notes    TEXT         NULL,
    executed_at     TIMESTAMP    NULL,
    UNIQUE (user_id, status)
        DEFERRABLE INITIALLY DEFERRED  -- позволяет re-request после REJECTED
);

CREATE INDEX gdpr_deletion_requests_status_idx ON gdpr_deletion_requests (status, requested_at)
    WHERE status = 'PENDING' OR status = 'APPROVED';

CREATE TABLE gdpr_legal_archive (
    id                   BIGSERIAL  PRIMARY KEY,
    user_id              BIGINT     NOT NULL,
    deletion_request_id  BIGINT     NULL REFERENCES gdpr_deletion_requests(id) ON DELETE SET NULL,
    encrypted_payload    BYTEA      NOT NULL,
    encryption_alg       VARCHAR(32) NOT NULL DEFAULT 'AES-256-GCM',
    archived_at          TIMESTAMP  NOT NULL DEFAULT NOW(),
    retention_until      TIMESTAMP  NULL
);

CREATE INDEX gdpr_legal_archive_user_idx ON gdpr_legal_archive (user_id);
CREATE INDEX gdpr_legal_archive_retention_idx ON gdpr_legal_archive (retention_until)
    WHERE retention_until IS NOT NULL;
