-- V033 — promotions module.
--
-- promocodes              — codes с discount_type (PERCENT/FIXED), TTL,
--                           usage limits, scope для host's policy.
-- promocode_redemptions   — каждое использование code'а одним order'ом.
--                           UNIQUE(promocode, order) — один code раз/order.

CREATE TABLE promocodes (
    id                  BIGSERIAL    PRIMARY KEY,
    code                VARCHAR(64)  NOT NULL UNIQUE,
    description         TEXT         NULL,
    discount_type       VARCHAR(16)  NOT NULL
        CHECK (discount_type IN ('PERCENT','FIXED')),
    discount_value      BIGINT       NOT NULL CHECK (discount_value > 0),
    currency            CHAR(3)      NULL,
    valid_from          TIMESTAMP    NOT NULL DEFAULT NOW(),
    valid_until         TIMESTAMP    NULL,
    usage_limit         INTEGER      NULL CHECK (usage_limit IS NULL OR usage_limit > 0),
    used_count          INTEGER      NOT NULL DEFAULT 0 CHECK (used_count >= 0),
    min_order_amount    BIGINT       NULL CHECK (min_order_amount IS NULL OR min_order_amount >= 0),
    max_discount_amount BIGINT       NULL CHECK (max_discount_amount IS NULL OR max_discount_amount >= 0),
    per_user_limit      INTEGER      NULL CHECK (per_user_limit IS NULL OR per_user_limit > 0),
    scope               VARCHAR(32)  NOT NULL DEFAULT 'ALL_PRODUCTS'
        CHECK (scope IN ('ALL_PRODUCTS','CATEGORY','PRODUCT','USER')),
    scope_target_id     BIGINT       NULL,
    is_active           BOOLEAN      NOT NULL DEFAULT TRUE,
    created_by          BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at          TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP    NOT NULL DEFAULT NOW(),
    -- Currency обязательна для FIXED, бессмысленна для PERCENT.
    CONSTRAINT promocodes_currency_for_fixed CHECK (
        (discount_type = 'FIXED' AND currency IS NOT NULL) OR
        (discount_type = 'PERCENT' AND currency IS NULL)
    ),
    -- PERCENT discount_value should be 1..100.
    CONSTRAINT promocodes_percent_range CHECK (
        discount_type <> 'PERCENT' OR (discount_value BETWEEN 1 AND 100)
    )
);

CREATE INDEX promocodes_active_until_idx ON promocodes (valid_until)
    WHERE is_active = TRUE;
CREATE INDEX promocodes_scope_target_idx ON promocodes (scope, scope_target_id)
    WHERE scope_target_id IS NOT NULL;

CREATE TRIGGER promocodes_set_updated_at_trigger
BEFORE UPDATE ON promocodes
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE promocode_redemptions (
    id                       BIGSERIAL  PRIMARY KEY,
    promocode_id             BIGINT     NOT NULL REFERENCES promocodes(id) ON DELETE CASCADE,
    user_id                  BIGINT     NULL REFERENCES users(id) ON DELETE SET NULL,
    order_id                 BIGINT     NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    discount_applied_amount  BIGINT     NOT NULL CHECK (discount_applied_amount >= 0),
    currency                 CHAR(3)    NOT NULL,
    redeemed_at              TIMESTAMP  NOT NULL DEFAULT NOW(),
    UNIQUE (promocode_id, order_id)
);

CREATE INDEX promocode_redemptions_user_idx ON promocode_redemptions (user_id)
    WHERE user_id IS NOT NULL;
CREATE INDEX promocode_redemptions_order_idx ON promocode_redemptions (order_id);
