-- V030 — digital-delivery module.
--
-- product_versions  — downloadable artefacts (file_url+file_size+
--                     changelog) per product release. Lifecycle:
--                     PENDING_REVIEW -> APPROVED (cron approve) or
--                     PENDING_REVIEW -> REJECTED. published_at NULL
--                     until APPROVED.
-- downloads         — каждое успешное скачивание. (user_id, product_id,
--                     version_id, downloaded_at). Powers analytics +
--                     digital DELIVERED transition (order_items.delivered_at).

CREATE TABLE product_versions (
    id                BIGSERIAL    PRIMARY KEY,
    product_id        BIGINT       NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    version           TEXT         NOT NULL,
    title             TEXT         NULL,
    changelog_format  VARCHAR(16)  NOT NULL CHECK (changelog_format IN ('markdown','html')),
    changelog_content TEXT         NOT NULL,
    file_url          TEXT         NULL,
    file_size_bytes   BIGINT       NULL CHECK (file_size_bytes IS NULL OR file_size_bytes > 0),
    download_count    INTEGER      NOT NULL DEFAULT 0,
    status            VARCHAR(32)  NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (status IN ('PENDING_REVIEW','APPROVED','REJECTED')),
    rejection_reason  TEXT         NULL,
    reviewed_by       BIGINT       NULL REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at       TIMESTAMP    NULL,
    submitted_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    published_at      TIMESTAMP    NULL,
    UNIQUE (product_id, version)
);

CREATE INDEX product_versions_product_status_idx
    ON product_versions (product_id, status);
CREATE INDEX product_versions_pending_idx
    ON product_versions (submitted_at)
    WHERE status = 'PENDING_REVIEW';

CREATE TABLE downloads (
    id            BIGSERIAL  PRIMARY KEY,
    user_id       BIGINT     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id    BIGINT     NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    version_id    BIGINT     NOT NULL REFERENCES product_versions(id) ON DELETE CASCADE,
    downloaded_at TIMESTAMP  NOT NULL DEFAULT NOW(),
    -- ip и user-agent для аналитики опускаются — host добавит side-table если нужно.
    UNIQUE (user_id, product_id, version_id, downloaded_at)
);

CREATE INDEX downloads_user_product_idx ON downloads (user_id, product_id);
CREATE INDEX downloads_product_idx ON downloads (product_id, downloaded_at DESC);
