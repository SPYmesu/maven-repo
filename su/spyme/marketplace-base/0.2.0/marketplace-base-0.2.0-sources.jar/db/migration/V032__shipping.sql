-- V032 — shipping module.
--
-- shipping_addresses — addresses пользователей (один user может иметь
--                      несколько — home, office, pickup-point).
-- carriers           — registered providers (boxberry, cdek, pochta-rossii, ...).
-- shipments          — конкретная отправка по order. Может быть несколько
--                      shipments на один order (split shipment).
-- shipment_items     — какие OrderItem'ы в этой shipment.

CREATE TABLE shipping_addresses (
    id              BIGSERIAL    PRIMARY KEY,
    user_id         BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label           TEXT         NULL,
    recipient_name  TEXT         NOT NULL,
    phone           VARCHAR(32)  NULL,
    country         VARCHAR(2)   NOT NULL,
    city            TEXT         NOT NULL,
    region          TEXT         NULL,
    postal_code     VARCHAR(20)  NULL,
    street          TEXT         NOT NULL,
    building        TEXT         NULL,
    apartment       TEXT         NULL,
    notes           TEXT         NULL,
    is_default      BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX shipping_addresses_user_idx ON shipping_addresses (user_id);

CREATE TRIGGER shipping_addresses_set_updated_at_trigger
BEFORE UPDATE ON shipping_addresses
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE carriers (
    id          BIGSERIAL    PRIMARY KEY,
    code        VARCHAR(64)  NOT NULL UNIQUE,
    name        TEXT         NOT NULL,
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
    config      JSONB        NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TRIGGER carriers_set_updated_at_trigger
BEFORE UPDATE ON carriers
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE shipments (
    id              BIGSERIAL    PRIMARY KEY,
    order_id        BIGINT       NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    carrier_id      BIGINT       NULL REFERENCES carriers(id) ON DELETE SET NULL,
    address_id      BIGINT       NULL REFERENCES shipping_addresses(id) ON DELETE SET NULL,
    tracking_number TEXT         NULL,
    status          VARCHAR(32)  NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING','LABEL_CREATED','PICKED_UP','IN_TRANSIT','OUT_FOR_DELIVERY','DELIVERED','RETURNED','LOST')),
    shipped_at      TIMESTAMP    NULL,
    delivered_at    TIMESTAMP    NULL,
    cost_amount     BIGINT       NULL,
    cost_currency   CHAR(3)      NULL,
    notes           TEXT         NULL,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX shipments_order_idx ON shipments (order_id);
CREATE INDEX shipments_tracking_idx ON shipments (tracking_number)
    WHERE tracking_number IS NOT NULL;

CREATE TRIGGER shipments_set_updated_at_trigger
BEFORE UPDATE ON shipments
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE shipment_items (
    shipment_id   BIGINT   NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    order_item_id BIGINT   NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
    quantity      INTEGER  NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (shipment_id, order_item_id)
);
