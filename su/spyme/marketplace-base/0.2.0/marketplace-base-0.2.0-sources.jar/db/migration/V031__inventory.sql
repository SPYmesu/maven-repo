-- V031 — inventory module.
--
-- warehouses     — физические склады (id, code, name, address, is_active).
-- stock_levels   — текущий on_hand quantity на (warehouse, product, variant).
-- stock_reservations — TTL holds для cart/checkout flow. Cron sweeps expired.

CREATE TABLE warehouses (
    id          BIGSERIAL    PRIMARY KEY,
    code        VARCHAR(64)  NOT NULL UNIQUE,
    name        TEXT         NOT NULL,
    address     TEXT         NULL,
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TRIGGER warehouses_set_updated_at_trigger
BEFORE UPDATE ON warehouses
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE stock_levels (
    id              BIGSERIAL  PRIMARY KEY,
    warehouse_id    BIGINT     NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    product_id      BIGINT     NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id      BIGINT     NULL REFERENCES product_variants(id) ON DELETE CASCADE,
    on_hand         INTEGER    NOT NULL DEFAULT 0 CHECK (on_hand >= 0),
    reserved        INTEGER    NOT NULL DEFAULT 0 CHECK (reserved >= 0),
    updated_at      TIMESTAMP  NOT NULL DEFAULT NOW()
);

-- Unique-per-(warehouse, product, variant) — variant_id NULL обработан
-- через COALESCE в expression-index. Два partial-index: variant=NULL
-- и variant=not-null — clean PostgreSQL pattern.
CREATE UNIQUE INDEX stock_levels_unique_with_variant_idx
    ON stock_levels (warehouse_id, product_id, variant_id)
    WHERE variant_id IS NOT NULL;
CREATE UNIQUE INDEX stock_levels_unique_no_variant_idx
    ON stock_levels (warehouse_id, product_id)
    WHERE variant_id IS NULL;

CREATE INDEX stock_levels_product_idx ON stock_levels (product_id);

CREATE TRIGGER stock_levels_set_updated_at_trigger
BEFORE UPDATE ON stock_levels
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE stock_reservations (
    id              BIGSERIAL  PRIMARY KEY,
    warehouse_id    BIGINT     NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    product_id      BIGINT     NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id      BIGINT     NULL REFERENCES product_variants(id) ON DELETE CASCADE,
    quantity        INTEGER    NOT NULL CHECK (quantity > 0),
    order_id        BIGINT     NULL REFERENCES orders(id) ON DELETE CASCADE,
    cart_token      TEXT       NULL,
    expires_at      TIMESTAMP  NOT NULL,
    released_at     TIMESTAMP  NULL,
    fulfilled_at    TIMESTAMP  NULL,
    created_at      TIMESTAMP  NOT NULL DEFAULT NOW()
);

CREATE INDEX stock_reservations_expires_active_idx
    ON stock_reservations (expires_at)
    WHERE released_at IS NULL AND fulfilled_at IS NULL;
CREATE INDEX stock_reservations_order_idx
    ON stock_reservations (order_id)
    WHERE order_id IS NOT NULL;
