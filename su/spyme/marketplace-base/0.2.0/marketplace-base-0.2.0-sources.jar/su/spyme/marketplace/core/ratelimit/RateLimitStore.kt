package su.spyme.marketplace.core.ratelimit

import java.time.Duration
import java.time.Instant

/**
 * Sliding-window rate-limit store. Hosts/plugins call [tryAcquire] перед
 * processing-ом privileged request; if limit exceeded, return 429.
 *
 * Default impl is [CaffeineRateLimitStore] (in-memory, no cross-instance
 * coordination). Host overrides via ConflictRegistry если нужен Redis-backed
 * store для multi-instance deployment.
 *
 * Window semantics:
 *   - permits — how many requests in the window are allowed.
 *   - window — Duration of the rolling window (e.g. 60s).
 *   - tryAcquire('key', N, W, now) — returns [Decision] containing whether
 *     the request fits AND when the next slot becomes available.
 *
 * "Sliding" means каждый request stamped with timestamp; we drop stamps
 * older than `now - window` before counting. This is more permissive than
 * fixed-window but more expensive (need to keep per-stamp timestamps).
 */
interface RateLimitStore {

    fun tryAcquire(
        key: String,
        permits: Int,
        window: Duration,
        now: Instant = Instant.now(),
    ): Decision

    /** Drops all state for [key]. */
    fun reset(key: String)

    /** Cron sweep: removes empty / expired buckets. */
    fun cleanup(now: Instant = Instant.now())

    data class Decision(
        val allowed: Boolean,
        val remaining: Int,
        val resetAt: Instant,
    )
}
