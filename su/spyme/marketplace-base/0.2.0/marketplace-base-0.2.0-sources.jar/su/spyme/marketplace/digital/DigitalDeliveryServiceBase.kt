package su.spyme.marketplace.digital

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant

/**
 * Digital-delivery module: product versions + downloads.
 *
 * Vendor submits a version, moderator approves -> APPROVED + publishedAt
 * set. Users with access (free product OR PAID order) trigger
 * [registerDownload] which inserts a row + increments download_count.
 *
 * Access guard NOT enforced here — host service decides who may download
 * (e.g. ProductsService.canDownload(user, product, version)). Lib just
 * persists the event.
 */
open class DigitalDeliveryServiceBase(protected val mainDb: Database) {

    open fun createVersion(
        productId: Long,
        version: String,
        title: String? = null,
        changelogFormat: String = "markdown",
        changelogContent: String = "",
        fileUrl: String? = null,
        fileSizeBytes: Long? = null,
    ): ProductVersion = transaction(mainDb) {
        val id = BaseProductVersionsTable.insert {
            it[BaseProductVersionsTable.productId] = productId
            it[BaseProductVersionsTable.version] = version
            it[BaseProductVersionsTable.title] = title
            it[BaseProductVersionsTable.changelogFormat] = changelogFormat
            it[BaseProductVersionsTable.changelogContent] = changelogContent
            it[BaseProductVersionsTable.fileUrl] = fileUrl
            it[BaseProductVersionsTable.fileSizeBytes] = fileSizeBytes
        } get BaseProductVersionsTable.id
        loadVersionById(id)!!
    }

    open fun approveVersion(id: Long, reviewedBy: Long?, now: Instant = Instant.now()): ProductVersion {
        transaction(mainDb) {
            BaseProductVersionsTable.update({
                (BaseProductVersionsTable.id eq id) and
                    (BaseProductVersionsTable.status eq ProductVersionStatus.PENDING_REVIEW.name)
            }) {
                it[BaseProductVersionsTable.status] = ProductVersionStatus.APPROVED.name
                it[BaseProductVersionsTable.reviewedBy] = reviewedBy
                it[BaseProductVersionsTable.reviewedAt] = now
                it[BaseProductVersionsTable.publishedAt] = now
                it[BaseProductVersionsTable.rejectionReason] = null
            }
        }
        return loadVersionById(id) ?: error("version $id missing after approve")
    }

    open fun rejectVersion(id: Long, reviewedBy: Long?, reason: String?, now: Instant = Instant.now()): ProductVersion {
        transaction(mainDb) {
            BaseProductVersionsTable.update({
                (BaseProductVersionsTable.id eq id) and
                    (BaseProductVersionsTable.status eq ProductVersionStatus.PENDING_REVIEW.name)
            }) {
                it[BaseProductVersionsTable.status] = ProductVersionStatus.REJECTED.name
                it[BaseProductVersionsTable.reviewedBy] = reviewedBy
                it[BaseProductVersionsTable.reviewedAt] = now
                it[BaseProductVersionsTable.rejectionReason] = reason
            }
        }
        return loadVersionById(id) ?: error("version $id missing after reject")
    }

    open fun loadVersionById(id: Long): ProductVersion? = transaction(mainDb) {
        BaseProductVersionsTable.selectAll()
            .where { BaseProductVersionsTable.id eq id }
            .firstOrNull()?.let(ProductVersion::fromRow)
    }

    open fun listVersionsForProduct(productId: Long, onlyApproved: Boolean = true): List<ProductVersion> =
        transaction(mainDb) {
            val query = BaseProductVersionsTable.selectAll()
                .where {
                    val base = BaseProductVersionsTable.productId eq productId
                    if (onlyApproved) {
                        base and (BaseProductVersionsTable.status eq ProductVersionStatus.APPROVED.name)
                    } else base
                }
                .orderBy(BaseProductVersionsTable.publishedAt to SortOrder.DESC_NULLS_LAST,
                         BaseProductVersionsTable.id to SortOrder.DESC)
            query.map(ProductVersion::fromRow)
        }

    /**
     * Latest APPROVED version по publishedAt DESC. Used by digital-delivery
     * access guard когда product не имеет fixed-version subscription.
     */
    open fun currentVersionFor(productId: Long): ProductVersion? =
        listVersionsForProduct(productId, onlyApproved = true).firstOrNull()

    /**
     * Records a download event + atomically increments download_count on
     * the version row. Caller (host service) is responsible for access
     * check before calling this.
     */
    open fun registerDownload(userId: Long, productId: Long, versionId: Long, now: Instant = Instant.now()): Download =
        transaction(mainDb) {
            val downloadId = BaseDownloadsTable.insert {
                it[BaseDownloadsTable.userId] = userId
                it[BaseDownloadsTable.productId] = productId
                it[BaseDownloadsTable.versionId] = versionId
                it[BaseDownloadsTable.downloadedAt] = now
            } get BaseDownloadsTable.id

            BaseProductVersionsTable.update({ BaseProductVersionsTable.id eq versionId }) {
                with(SqlExpressionBuilder) {
                    it.update(BaseProductVersionsTable.downloadCount,
                        BaseProductVersionsTable.downloadCount + 1)
                }
            }

            BaseDownloadsTable.selectAll()
                .where { BaseDownloadsTable.id eq downloadId }
                .single().let(Download::fromRow)
        }

    open fun hasUserDownloaded(userId: Long, productId: Long): Boolean = transaction(mainDb) {
        BaseDownloadsTable.selectAll()
            .where {
                (BaseDownloadsTable.userId eq userId) and
                    (BaseDownloadsTable.productId eq productId)
            }
            .limit(1)
            .empty().not()
    }
}
