package su.spyme.marketplace.tax

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * Tax module: единая table tax_rules с priority-based fan-out.
 *
 * Rule matching: для (country, region?, productKind, categoryId) рули matches
 * если geo+kind+category satisfies (NULL = wildcard) AND is_active AND now between
 * valid_from..valid_until.
 *
 * Inclusive vs exclusive:
 *   - inclusive=FALSE (default): tax_amount = price × rate_bp / 10000 (US sales tax).
 *   - inclusive=TRUE: tax уже в цене; extracted_tax = price × rate_bp / (10000 + rate_bp) (EU VAT).
 *
 * basis points: 2000 = 20%, 1850 = 18.5%, 0 = exempt.
 */
object BaseTaxRulesTable : Table("tax_rules") {
    val id: Column<Long> = long("id").autoIncrement()
    val name: Column<String> = text("name")
    val country: Column<String?> = varchar("country", 2).nullable()
    val region: Column<String?> = text("region").nullable()
    val productKind: Column<String?> = varchar("product_kind", 16).nullable()
    val categoryId: Column<Long?> = long("category_id").nullable()
    val rateBp: Column<Int> = integer("rate_bp")
    val inclusive: Column<Boolean> = bool("inclusive").default(false)
    val priority: Column<Int> = integer("priority").default(100)
    val validFrom: Column<Instant> = timestamp("valid_from").defaultExpression(NowExpression)
    val validUntil: Column<Instant?> = timestamp("valid_until").nullable()
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

data class TaxRule(
    val id: Long,
    val name: String,
    val country: String?,
    val region: String?,
    val productKind: String?,
    val categoryId: Long?,
    val rateBp: Int,
    val inclusive: Boolean,
    val priority: Int,
    val validFrom: Instant,
    val validUntil: Instant?,
    val isActive: Boolean,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    fun isLive(now: Instant = Instant.now()): Boolean =
        isActive &&
            !now.isBefore(validFrom) &&
            (validUntil == null || now.isBefore(validUntil))

    fun matches(country: String?, region: String?, productKind: String?, categoryId: Long?): Boolean {
        // NULL in rule = wildcard. Non-null must match.
        if (this.country != null && this.country != country) return false
        if (this.region != null && this.region != region) return false
        if (this.productKind != null && this.productKind != productKind) return false
        if (this.categoryId != null && this.categoryId != categoryId) return false
        return true
    }
}

/**
 * Input для расчёта налога: одна строка order/cart.
 */
data class TaxableLine(
    val productKind: String,
    val categoryId: Long?,
    val unitPrice: Money,
    val quantity: Int,
) {
    val lineSubtotal: Money
        get() = Money(amount = unitPrice.amount * quantity, currency = unitPrice.currency)
}

/**
 * Налог на одну линию order'а — applied rules + breakdown.
 */
data class LineTax(
    val line: TaxableLine,
    val appliedRules: List<AppliedTax>,
    val totalTax: Money,
)

data class AppliedTax(
    val ruleId: Long,
    val ruleName: String,
    val rateBp: Int,
    val inclusive: Boolean,
    val amount: Money,
)

/**
 * Aggregated per-order tax breakdown.
 */
data class OrderTaxBreakdown(
    val lineTaxes: List<LineTax>,
    val totalTax: Money,
) {
    val totalTaxByRule: Map<Long, Money>
        get() = lineTaxes.flatMap { it.appliedRules }
            .groupBy { it.ruleId }
            .mapValues { entry ->
                val first = entry.value.first().amount
                Money(
                    amount = entry.value.sumOf { it.amount.amount },
                    currency = first.currency,
                )
            }
}
