package su.spyme.marketplace.shipping

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * Shipping service: addresses + carriers + shipments + items.
 *
 * Address lifecycle:
 *   - User creates one or more addresses; one is is_default=TRUE.
 *   - setDefaultAddress flips current default and bumps the new one в одной
 *     транзакции — guarantees never two default-true одновременно для same user.
 *
 * Shipment lifecycle:
 *   - createShipment → status=PENDING.
 *   - Carrier API webhook / admin updates progressShipment(LABEL_CREATED → ... → DELIVERED).
 *   - shippedAt stamped on PICKED_UP/IN_TRANSIT, deliveredAt on DELIVERED.
 *
 * Carrier config (JSONB) — не маппится в Exposed singleton. Host читает
 * через raw SQL если нужно (boxberry/cdek API ключи лежат там).
 */
open class ShippingServiceBase(protected val mainDb: Database) {

    // -------- Addresses --------

    open fun createAddress(
        userId: Long,
        recipientName: String,
        country: String,
        city: String,
        street: String,
        label: String? = null,
        phone: String? = null,
        region: String? = null,
        postalCode: String? = null,
        building: String? = null,
        apartment: String? = null,
        notes: String? = null,
        makeDefault: Boolean = false,
    ): ShippingAddress = transaction(mainDb) {
        if (makeDefault) {
            BaseShippingAddressesTable.update({ BaseShippingAddressesTable.userId eq userId }) {
                it[BaseShippingAddressesTable.isDefault] = false
            }
        }
        val id = BaseShippingAddressesTable.insert {
            it[BaseShippingAddressesTable.userId] = userId
            it[BaseShippingAddressesTable.label] = label
            it[BaseShippingAddressesTable.recipientName] = recipientName
            it[BaseShippingAddressesTable.phone] = phone
            it[BaseShippingAddressesTable.country] = country
            it[BaseShippingAddressesTable.city] = city
            it[BaseShippingAddressesTable.region] = region
            it[BaseShippingAddressesTable.postalCode] = postalCode
            it[BaseShippingAddressesTable.street] = street
            it[BaseShippingAddressesTable.building] = building
            it[BaseShippingAddressesTable.apartment] = apartment
            it[BaseShippingAddressesTable.notes] = notes
            it[BaseShippingAddressesTable.isDefault] = makeDefault
        } get BaseShippingAddressesTable.id
        loadAddressById(id)!!
    }

    open fun loadAddressById(id: Long): ShippingAddress? = transaction(mainDb) {
        BaseShippingAddressesTable.selectAll()
            .where { BaseShippingAddressesTable.id eq id }
            .firstOrNull()?.let(::addressFromRow)
    }

    open fun listAddressesForUser(userId: Long): List<ShippingAddress> = transaction(mainDb) {
        BaseShippingAddressesTable.selectAll()
            .where { BaseShippingAddressesTable.userId eq userId }
            .orderBy(
                BaseShippingAddressesTable.isDefault to SortOrder.DESC,
                BaseShippingAddressesTable.createdAt to SortOrder.ASC,
            )
            .map(::addressFromRow)
    }

    /**
     * Atomically clears prior default-flag for [userId], sets [addressId] as
     * default. Returns true если address принадлежит пользователю и updated.
     */
    open fun setDefaultAddress(userId: Long, addressId: Long): Boolean = transaction(mainDb) {
        val target = loadAddressById(addressId) ?: return@transaction false
        if (target.userId != userId) return@transaction false
        BaseShippingAddressesTable.update({ BaseShippingAddressesTable.userId eq userId }) {
            it[BaseShippingAddressesTable.isDefault] = false
        }
        BaseShippingAddressesTable.update({ BaseShippingAddressesTable.id eq addressId }) {
            it[BaseShippingAddressesTable.isDefault] = true
        }
        true
    }

    open fun deleteAddress(addressId: Long): Boolean = transaction(mainDb) {
        BaseShippingAddressesTable.deleteWhere { BaseShippingAddressesTable.id eq addressId } > 0
    }

    // -------- Carriers --------

    open fun createCarrier(code: String, name: String): Carrier = transaction(mainDb) {
        val id = BaseCarriersTable.insert {
            it[BaseCarriersTable.code] = code
            it[BaseCarriersTable.name] = name
        } get BaseCarriersTable.id
        loadCarrierById(id)!!
    }

    open fun loadCarrierById(id: Long): Carrier? = transaction(mainDb) {
        BaseCarriersTable.selectAll()
            .where { BaseCarriersTable.id eq id }
            .firstOrNull()?.let(::carrierFromRow)
    }

    open fun loadCarrierByCode(code: String): Carrier? = transaction(mainDb) {
        BaseCarriersTable.selectAll()
            .where { BaseCarriersTable.code eq code }
            .firstOrNull()?.let(::carrierFromRow)
    }

    open fun listActiveCarriers(): List<Carrier> = transaction(mainDb) {
        BaseCarriersTable.selectAll()
            .where { BaseCarriersTable.isActive eq true }
            .orderBy(BaseCarriersTable.code)
            .map(::carrierFromRow)
    }

    open fun deactivateCarrier(carrierId: Long): Boolean = transaction(mainDb) {
        BaseCarriersTable.update({ BaseCarriersTable.id eq carrierId }) {
            it[BaseCarriersTable.isActive] = false
        } > 0
    }

    // -------- Shipments --------

    open fun createShipment(
        orderId: Long,
        carrierId: Long? = null,
        addressId: Long? = null,
        trackingNumber: String? = null,
        cost: Money? = null,
        notes: String? = null,
    ): Shipment = transaction(mainDb) {
        val id = BaseShipmentsTable.insert {
            it[BaseShipmentsTable.orderId] = orderId
            it[BaseShipmentsTable.carrierId] = carrierId
            it[BaseShipmentsTable.addressId] = addressId
            it[BaseShipmentsTable.trackingNumber] = trackingNumber
            it[BaseShipmentsTable.costAmount] = cost?.amount
            it[BaseShipmentsTable.costCurrency] = cost?.currency
            it[BaseShipmentsTable.notes] = notes
        } get BaseShipmentsTable.id
        loadShipmentById(id)!!
    }

    open fun loadShipmentById(id: Long): Shipment? = transaction(mainDb) {
        BaseShipmentsTable.selectAll()
            .where { BaseShipmentsTable.id eq id }
            .firstOrNull()?.let(::shipmentFromRow)
    }

    open fun listShipmentsForOrder(orderId: Long): List<Shipment> = transaction(mainDb) {
        BaseShipmentsTable.selectAll()
            .where { BaseShipmentsTable.orderId eq orderId }
            .orderBy(BaseShipmentsTable.createdAt to SortOrder.ASC)
            .map(::shipmentFromRow)
    }

    /**
     * Updates shipment status. Stamps shippedAt on first transition into
     * any "in motion" status (PICKED_UP/IN_TRANSIT/OUT_FOR_DELIVERY) and
     * deliveredAt when reaching DELIVERED. Idempotent — повторный setStatus
     * на same status не сдвинет timestamps.
     */
    open fun updateShipmentStatus(
        shipmentId: Long,
        newStatus: ShipmentStatus,
        now: Instant = Instant.now(),
    ): Boolean = transaction(mainDb) {
        val current = loadShipmentById(shipmentId) ?: return@transaction false
        if (current.status == newStatus) return@transaction true
        BaseShipmentsTable.update({ BaseShipmentsTable.id eq shipmentId }) {
            it[BaseShipmentsTable.status] = newStatus.name
            if (current.shippedAt == null && isInMotion(newStatus)) {
                it[BaseShipmentsTable.shippedAt] = now
            }
            if (newStatus == ShipmentStatus.DELIVERED && current.deliveredAt == null) {
                it[BaseShipmentsTable.deliveredAt] = now
            }
        }
        true
    }

    open fun attachTrackingNumber(shipmentId: Long, trackingNumber: String): Boolean =
        transaction(mainDb) {
            BaseShipmentsTable.update({ BaseShipmentsTable.id eq shipmentId }) {
                it[BaseShipmentsTable.trackingNumber] = trackingNumber
            } > 0
        }

    // -------- Shipment items --------

    /**
     * Adds an order_item to the shipment. Idempotent — upsert overwrites
     * quantity if (shipment, order_item) pair уже существует.
     */
    open fun addShipmentItem(shipmentId: Long, orderItemId: Long, quantity: Int) {
        require(quantity > 0)
        transaction(mainDb) {
            BaseShipmentItemsTable.upsert {
                it[BaseShipmentItemsTable.shipmentId] = shipmentId
                it[BaseShipmentItemsTable.orderItemId] = orderItemId
                it[BaseShipmentItemsTable.quantity] = quantity
            }
        }
    }

    open fun listItemsForShipment(shipmentId: Long): List<ShipmentItem> = transaction(mainDb) {
        BaseShipmentItemsTable.selectAll()
            .where { BaseShipmentItemsTable.shipmentId eq shipmentId }
            .map {
                ShipmentItem(
                    shipmentId = it[BaseShipmentItemsTable.shipmentId],
                    orderItemId = it[BaseShipmentItemsTable.orderItemId],
                    quantity = it[BaseShipmentItemsTable.quantity],
                )
            }
    }

    // -------- helpers --------

    private fun isInMotion(s: ShipmentStatus) = s in setOf(
        ShipmentStatus.PICKED_UP,
        ShipmentStatus.IN_TRANSIT,
        ShipmentStatus.OUT_FOR_DELIVERY,
        ShipmentStatus.DELIVERED,
    )

    private fun addressFromRow(r: org.jetbrains.exposed.sql.ResultRow) = ShippingAddress(
        id = r[BaseShippingAddressesTable.id],
        userId = r[BaseShippingAddressesTable.userId],
        label = r[BaseShippingAddressesTable.label],
        recipientName = r[BaseShippingAddressesTable.recipientName],
        phone = r[BaseShippingAddressesTable.phone],
        country = r[BaseShippingAddressesTable.country],
        city = r[BaseShippingAddressesTable.city],
        region = r[BaseShippingAddressesTable.region],
        postalCode = r[BaseShippingAddressesTable.postalCode],
        street = r[BaseShippingAddressesTable.street],
        building = r[BaseShippingAddressesTable.building],
        apartment = r[BaseShippingAddressesTable.apartment],
        notes = r[BaseShippingAddressesTable.notes],
        isDefault = r[BaseShippingAddressesTable.isDefault],
        createdAt = r[BaseShippingAddressesTable.createdAt],
        updatedAt = r[BaseShippingAddressesTable.updatedAt],
    )

    private fun carrierFromRow(r: org.jetbrains.exposed.sql.ResultRow) = Carrier(
        id = r[BaseCarriersTable.id],
        code = r[BaseCarriersTable.code],
        name = r[BaseCarriersTable.name],
        isActive = r[BaseCarriersTable.isActive],
        createdAt = r[BaseCarriersTable.createdAt],
        updatedAt = r[BaseCarriersTable.updatedAt],
    )

    private fun shipmentFromRow(r: org.jetbrains.exposed.sql.ResultRow) = Shipment(
        id = r[BaseShipmentsTable.id],
        orderId = r[BaseShipmentsTable.orderId],
        carrierId = r[BaseShipmentsTable.carrierId],
        addressId = r[BaseShipmentsTable.addressId],
        trackingNumber = r[BaseShipmentsTable.trackingNumber],
        status = ShipmentStatus.parse(r[BaseShipmentsTable.status]),
        shippedAt = r[BaseShipmentsTable.shippedAt],
        deliveredAt = r[BaseShipmentsTable.deliveredAt],
        costAmount = r[BaseShipmentsTable.costAmount],
        costCurrency = r[BaseShipmentsTable.costCurrency],
        notes = r[BaseShipmentsTable.notes],
        createdAt = r[BaseShipmentsTable.createdAt],
        updatedAt = r[BaseShipmentsTable.updatedAt],
    )
}

data class ShipmentItem(
    val shipmentId: Long,
    val orderItemId: Long,
    val quantity: Int,
)
