package su.spyme.marketplace.gdpr

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * GDPR module: twin-layer deletion (Б3).
 *
 * Lifecycle:
 *   1. User (или admin from user's behalf) creates deletion request
 *      → status PENDING.
 *   2. LEGAL_OFFICER reviews + approves → status APPROVED.
 *      Альтернативно reject → REJECTED.
 *   3. Worker / admin runs executeApprovedRequest:
 *      - Operational scrub via registered DeletionScrubbers
 *        (anonymize username/email, drop sessions, etc.).
 *      - Encrypted snapshot saved to gdpr_legal_archive (AES-256-GCM).
 *      - status → EXECUTED.
 */
enum class DeletionStatus {
    PENDING, APPROVED, REJECTED, EXECUTED;
    companion object {
        fun parse(s: String) = entries.firstOrNull { it.name == s }
            ?: throw IllegalArgumentException("Unknown DeletionStatus: $s")
    }
}

object BaseDeletionRequestsTable : Table("gdpr_deletion_requests") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val requestedAt: Column<Instant> = timestamp("requested_at").defaultExpression(NowExpression)
    val reason: Column<String?> = text("reason").nullable()
    val reviewedAt: Column<Instant?> = timestamp("reviewed_at").nullable()
    val reviewedBy: Column<Long?> = long("reviewed_by").nullable()
    val reviewNotes: Column<String?> = text("review_notes").nullable()
    val executedAt: Column<Instant?> = timestamp("executed_at").nullable()

    override val primaryKey = PrimaryKey(id)
}

object BaseLegalArchiveTable : Table("gdpr_legal_archive") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val deletionRequestId: Column<Long?> = long("deletion_request_id").nullable()
    val encryptedPayload: Column<ByteArray> = binary("encrypted_payload")
    val encryptionAlg: Column<String> = varchar("encryption_alg", 32).default("AES-256-GCM")
    val archivedAt: Column<Instant> = timestamp("archived_at").defaultExpression(NowExpression)
    val retentionUntil: Column<Instant?> = timestamp("retention_until").nullable()

    override val primaryKey = PrimaryKey(id)
}

data class DeletionRequest(
    val id: Long,
    val userId: Long,
    val status: DeletionStatus,
    val requestedAt: Instant,
    val reason: String?,
    val reviewedAt: Instant?,
    val reviewedBy: Long?,
    val reviewNotes: String?,
    val executedAt: Instant?,
)

data class LegalArchiveEntry(
    val id: Long,
    val userId: Long,
    val deletionRequestId: Long?,
    val encryptedPayload: ByteArray,
    val encryptionAlg: String,
    val archivedAt: Instant,
    val retentionUntil: Instant?,
)
