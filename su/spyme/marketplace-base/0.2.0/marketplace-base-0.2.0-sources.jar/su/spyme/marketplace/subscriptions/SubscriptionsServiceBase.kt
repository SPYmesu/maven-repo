package su.spyme.marketplace.subscriptions

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant
import java.time.temporal.ChronoUnit

/**
 * Time-bounded subscription management.
 *
 * Host-bootstrap pattern:
 *   1. Register an [su.spyme.marketplace.commerce.orders.OrderTransitionListener]
 *      that detects PAID transitions on subscription products and calls
 *      [createOrExtend]. (Lib doesn't know which products are subscription
 *      candidates — host decides via product attributes or a host-side
 *      registry.)
 *   2. Schedule [expireStale] as a daily cron job (idempotent).
 *
 * Host-pattern: extend by overriding [computeExpiresAt] if subscription
 * durations should follow calendar months / business days / etc.
 */
open class SubscriptionsServiceBase(protected val mainDb: Database) {

    /**
     * Default duration calculator: 30 / 90 / 365 days from [startedAt].
     * Hosts that want true calendar months can override.
     */
    open fun computeExpiresAt(period: SubscriptionPeriod, startedAt: Instant): Instant {
        val days = when (period) {
            SubscriptionPeriod.MONTH -> 30L
            SubscriptionPeriod.QUARTER -> 90L
            SubscriptionPeriod.YEAR -> 365L
        }
        return startedAt.plus(days, ChronoUnit.DAYS)
    }

    /**
     * Either creates a new ACTIVE subscription for (user, product) or
     * extends the existing ACTIVE one by `period.duration`.
     *
     * Used by an OrderTransitionListener on order PAID.
     */
    open fun createOrExtend(
        userId: Long,
        productId: Long,
        period: SubscriptionPeriod,
        orderId: Long? = null,
        autoRenew: Boolean = false,
        now: Instant = Instant.now(),
    ): Subscription = transaction(mainDb) {
        val active = BaseSubscriptionsTable.selectAll()
            .where {
                (BaseSubscriptionsTable.userId eq userId) and
                    (BaseSubscriptionsTable.productId eq productId) and
                    (BaseSubscriptionsTable.status eq SubscriptionStatus.ACTIVE.name)
            }
            .singleOrNull()

        if (active != null) {
            val current = Subscription.fromRow(active)
            val base = if (current.expiresAt.isAfter(now)) current.expiresAt else now
            val newExpires = computeExpiresAt(period, base)
            BaseSubscriptionsTable.update({ BaseSubscriptionsTable.id eq current.id }) {
                it[BaseSubscriptionsTable.expiresAt] = newExpires
                it[BaseSubscriptionsTable.orderId] = orderId ?: current.orderId
                it[BaseSubscriptionsTable.autoRenew] = autoRenew || current.autoRenew
                it[BaseSubscriptionsTable.notifiedExpiringAt] = null
                it[BaseSubscriptionsTable.notifiedExpiredAt] = null
            }
            return@transaction loadById(current.id)!!
        }

        val newId = BaseSubscriptionsTable.insert {
            it[BaseSubscriptionsTable.userId] = userId
            it[BaseSubscriptionsTable.productId] = productId
            it[BaseSubscriptionsTable.orderId] = orderId
            it[BaseSubscriptionsTable.period] = period.code
            it[BaseSubscriptionsTable.startedAt] = now
            it[BaseSubscriptionsTable.expiresAt] = computeExpiresAt(period, now)
            it[BaseSubscriptionsTable.autoRenew] = autoRenew
        } get BaseSubscriptionsTable.id

        loadById(newId)!!
    }

    open fun cancel(id: Long, byUserId: Long?, now: Instant = Instant.now()): Boolean =
        transaction(mainDb) {
            BaseSubscriptionsTable.update({
                (BaseSubscriptionsTable.id eq id) and
                    (BaseSubscriptionsTable.status eq SubscriptionStatus.ACTIVE.name)
            }) {
                it[BaseSubscriptionsTable.status] = SubscriptionStatus.CANCELLED.name
                it[BaseSubscriptionsTable.cancelledAt] = now
                it[BaseSubscriptionsTable.cancelledByUserId] = byUserId
            } > 0
        }

    open fun loadById(id: Long): Subscription? = transaction(mainDb) {
        BaseSubscriptionsTable.selectAll()
            .where { BaseSubscriptionsTable.id eq id }
            .firstOrNull()?.let(Subscription::fromRow)
    }

    open fun findActiveForUserProduct(userId: Long, productId: Long): Subscription? =
        transaction(mainDb) {
            BaseSubscriptionsTable.selectAll()
                .where {
                    (BaseSubscriptionsTable.userId eq userId) and
                        (BaseSubscriptionsTable.productId eq productId) and
                        (BaseSubscriptionsTable.status eq SubscriptionStatus.ACTIVE.name)
                }
                .firstOrNull()?.let(Subscription::fromRow)
        }

    open fun listForUser(userId: Long): List<Subscription> = transaction(mainDb) {
        BaseSubscriptionsTable.selectAll()
            .where { BaseSubscriptionsTable.userId eq userId }
            .orderBy(BaseSubscriptionsTable.expiresAt to SortOrder.DESC)
            .map(Subscription::fromRow)
    }

    /**
     * Marks ACTIVE subscriptions past expires_at as EXPIRED + stamps
     * notified_expired_at = NOW. Returns the number of rows transitioned.
     * Idempotent — call once a day from cron.
     */
    open fun expireStale(now: Instant = Instant.now()): Int = transaction(mainDb) {
        BaseSubscriptionsTable.update({
            (BaseSubscriptionsTable.status eq SubscriptionStatus.ACTIVE.name) and
                (BaseSubscriptionsTable.expiresAt less now)
        }) {
            it[BaseSubscriptionsTable.status] = SubscriptionStatus.EXPIRED.name
            it[BaseSubscriptionsTable.notifiedExpiredAt] = now
        }
    }

    /**
     * Marks ACTIVE subscriptions whose expires_at falls in
     * (now, now + windowDays] and whose notified_expiring_at is NULL.
     * Returns the IDs that just got marked — host typically dispatches
     * notifications based on this list.
     */
    open fun markExpiringSoon(windowDays: Long = 7, now: Instant = Instant.now()): List<Long> =
        transaction(mainDb) {
            val deadline = now.plus(windowDays, ChronoUnit.DAYS)
            val candidates = BaseSubscriptionsTable.selectAll()
                .where {
                    (BaseSubscriptionsTable.status eq SubscriptionStatus.ACTIVE.name) and
                        (BaseSubscriptionsTable.expiresAt greater now) and
                        (BaseSubscriptionsTable.expiresAt lessEq deadline) and
                        (BaseSubscriptionsTable.notifiedExpiringAt.isNull())
                }
                .map { it[BaseSubscriptionsTable.id] }

            if (candidates.isNotEmpty()) {
                BaseSubscriptionsTable.update({ BaseSubscriptionsTable.id inList candidates }) {
                    it[BaseSubscriptionsTable.notifiedExpiringAt] = now
                }
            }
            candidates
        }
}
