package su.spyme.marketplace.promotions

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * Promotions service: promocode validation + atomic redeem.
 *
 * Validation rules (in order):
 *   1. Code exists.
 *   2. Code is live (active + within valid_from..valid_until + under usage_limit).
 *   3. min_order_amount satisfied (if set).
 *   4. per_user_limit satisfied (если set; считает existing redemptions
 *      for (promocode, user)).
 *   5. Currency consistency: для FIXED — code's currency должна match order's
 *      currency. PERCENT — universally compatible.
 *
 * Scope-target enforcement (CATEGORY/PRODUCT/USER) — host's job. This service
 * carries the data but не делает scope-checking сам, потому что ему пришлось
 * бы знать структуру order's items.
 *
 * Redeem атомарно:
 *   - Проверяет validateForUser inside same transaction.
 *   - Inserts row в promocode_redemptions (UNIQUE(promocode, order) предотвращает
 *     double-apply на same order).
 *   - Bumps used_count += 1.
 */
open class PromotionsServiceBase(protected val mainDb: Database) {

    open fun createPromocode(
        code: String,
        discountType: DiscountType,
        discountValue: Long,
        currency: String? = null,
        description: String? = null,
        validFrom: Instant = Instant.now(),
        validUntil: Instant? = null,
        usageLimit: Int? = null,
        minOrderAmount: Long? = null,
        maxDiscountAmount: Long? = null,
        perUserLimit: Int? = null,
        scope: PromocodeScope = PromocodeScope.ALL_PRODUCTS,
        scopeTargetId: Long? = null,
        createdBy: Long? = null,
    ): Promocode {
        // Pre-validation matches DB CHECK constraints — fail fast in app code.
        when (discountType) {
            DiscountType.PERCENT -> {
                require(discountValue in 1L..100L) { "PERCENT discount must be 1..100, got $discountValue" }
                require(currency == null) { "PERCENT discount must have null currency" }
            }
            DiscountType.FIXED -> {
                require(discountValue > 0) { "FIXED discount must be > 0" }
                require(!currency.isNullOrBlank()) { "FIXED discount requires currency" }
            }
        }
        return transaction(mainDb) {
            val id = BasePromocodesTable.insert {
                it[BasePromocodesTable.code] = code
                it[BasePromocodesTable.description] = description
                it[BasePromocodesTable.discountType] = discountType.name
                it[BasePromocodesTable.discountValue] = discountValue
                it[BasePromocodesTable.currency] = currency
                it[BasePromocodesTable.validFrom] = validFrom
                it[BasePromocodesTable.validUntil] = validUntil
                it[BasePromocodesTable.usageLimit] = usageLimit
                it[BasePromocodesTable.minOrderAmount] = minOrderAmount
                it[BasePromocodesTable.maxDiscountAmount] = maxDiscountAmount
                it[BasePromocodesTable.perUserLimit] = perUserLimit
                it[BasePromocodesTable.scope] = scope.name
                it[BasePromocodesTable.scopeTargetId] = scopeTargetId
                it[BasePromocodesTable.createdBy] = createdBy
            } get BasePromocodesTable.id
            loadById(id)!!
        }
    }

    open fun loadById(id: Long): Promocode? = transaction(mainDb) {
        BasePromocodesTable.selectAll()
            .where { BasePromocodesTable.id eq id }
            .firstOrNull()?.let(::fromRow)
    }

    open fun loadByCode(code: String): Promocode? = transaction(mainDb) {
        BasePromocodesTable.selectAll()
            .where { BasePromocodesTable.code eq code }
            .firstOrNull()?.let(::fromRow)
    }

    /**
     * Validates a code для given user + order subtotal. Returns sealed
     * result: [Valid] с computed discount amount, или [Invalid] с reason.
     *
     * Discount calc:
     *   - PERCENT: orderSubtotal × percent / 100, capped by max_discount_amount.
     *   - FIXED: discount_value (capped by orderSubtotal so we never overshoot
     *     to negative total).
     */
    open fun validateForUser(
        code: String,
        userId: Long?,
        orderSubtotal: Money,
        now: Instant = Instant.now(),
    ): ValidationResult = transaction(mainDb) {
        val pc = loadByCode(code) ?: return@transaction ValidationResult.Invalid(InvalidReason.NOT_FOUND)
        if (!pc.isLive(now)) return@transaction ValidationResult.Invalid(InvalidReason.EXPIRED_OR_DISABLED)
        if (pc.discountType == DiscountType.FIXED && pc.currency != orderSubtotal.currency) {
            return@transaction ValidationResult.Invalid(InvalidReason.CURRENCY_MISMATCH)
        }
        if (pc.minOrderAmount != null && orderSubtotal.amount < pc.minOrderAmount) {
            return@transaction ValidationResult.Invalid(InvalidReason.MIN_ORDER_NOT_MET)
        }
        if (pc.perUserLimit != null && userId != null) {
            val used = BasePromocodeRedemptionsTable.selectAll()
                .where {
                    (BasePromocodeRedemptionsTable.promocodeId eq pc.id) and
                        (BasePromocodeRedemptionsTable.userId eq userId)
                }
                .count()
            if (used >= pc.perUserLimit) {
                return@transaction ValidationResult.Invalid(InvalidReason.USER_LIMIT_EXCEEDED)
            }
        }
        val discount = computeDiscount(pc, orderSubtotal)
        ValidationResult.Valid(promocode = pc, discount = discount)
    }

    /**
     * Atomically redeems code for [orderId]: validates inside the same tx,
     * inserts redemption row, bumps used_count. UNIQUE(promo, order) предотвращает
     * double-apply (insert конфликтует если уже redeemed на этот order).
     *
     * Returns Valid с PromocodeRedemption, или Invalid с reason.
     */
    open fun redeem(
        code: String,
        userId: Long?,
        orderId: Long,
        orderSubtotal: Money,
        now: Instant = Instant.now(),
    ): RedeemResult = transaction(mainDb) {
        when (val v = validateForUser(code, userId, orderSubtotal, now)) {
            is ValidationResult.Invalid -> RedeemResult.Invalid(v.reason)
            is ValidationResult.Valid -> {
                val pc = v.promocode
                // Re-check (FOR UPDATE? — for simple-case Postgres serializable not
                // required since UNIQUE catches double-redeem). Insert + bump.
                val rid = try {
                    BasePromocodeRedemptionsTable.insert {
                        it[BasePromocodeRedemptionsTable.promocodeId] = pc.id
                        it[BasePromocodeRedemptionsTable.userId] = userId
                        it[BasePromocodeRedemptionsTable.orderId] = orderId
                        it[BasePromocodeRedemptionsTable.discountAppliedAmount] = v.discount.amount
                        it[BasePromocodeRedemptionsTable.currency] = v.discount.currency
                        it[BasePromocodeRedemptionsTable.redeemedAt] = now
                    } get BasePromocodeRedemptionsTable.id
                } catch (e: org.jetbrains.exposed.exceptions.ExposedSQLException) {
                    return@transaction RedeemResult.Invalid(InvalidReason.ALREADY_REDEEMED_FOR_ORDER)
                }
                BasePromocodesTable.update({ BasePromocodesTable.id eq pc.id }) {
                    with(SqlExpressionBuilder) {
                        it.update(BasePromocodesTable.usedCount, BasePromocodesTable.usedCount + 1)
                    }
                }
                RedeemResult.Redeemed(
                    redemption = PromocodeRedemption(
                        id = rid,
                        promocodeId = pc.id,
                        userId = userId,
                        orderId = orderId,
                        discountAppliedAmount = v.discount.amount,
                        currency = v.discount.currency,
                        redeemedAt = now,
                    ),
                    discount = v.discount,
                )
            }
        }
    }

    open fun deactivate(promocodeId: Long): Boolean = transaction(mainDb) {
        BasePromocodesTable.update({ BasePromocodesTable.id eq promocodeId }) {
            it[BasePromocodesTable.isActive] = false
        } > 0
    }

    open fun listRedemptionsForUser(userId: Long): List<PromocodeRedemption> = transaction(mainDb) {
        BasePromocodeRedemptionsTable.selectAll()
            .where { BasePromocodeRedemptionsTable.userId eq userId }
            .map { redemptionFromRow(it) }
    }

    open fun listRedemptionsForOrder(orderId: Long): List<PromocodeRedemption> = transaction(mainDb) {
        BasePromocodeRedemptionsTable.selectAll()
            .where { BasePromocodeRedemptionsTable.orderId eq orderId }
            .map { redemptionFromRow(it) }
    }

    // ---------- Sealed result types ----------

    sealed class ValidationResult {
        data class Valid(val promocode: Promocode, val discount: Money) : ValidationResult()
        data class Invalid(val reason: InvalidReason) : ValidationResult()
    }

    sealed class RedeemResult {
        data class Redeemed(val redemption: PromocodeRedemption, val discount: Money) : RedeemResult()
        data class Invalid(val reason: InvalidReason) : RedeemResult()
    }

    enum class InvalidReason {
        NOT_FOUND, EXPIRED_OR_DISABLED, CURRENCY_MISMATCH,
        MIN_ORDER_NOT_MET, USER_LIMIT_EXCEEDED, ALREADY_REDEEMED_FOR_ORDER,
    }

    // ---------- helpers ----------

    private fun computeDiscount(pc: Promocode, orderSubtotal: Money): Money = when (pc.discountType) {
        DiscountType.PERCENT -> {
            val raw = (orderSubtotal.amount * pc.discountValue) / 100
            val capped = if (pc.maxDiscountAmount != null) minOf(raw, pc.maxDiscountAmount) else raw
            Money(amount = minOf(capped, orderSubtotal.amount), currency = orderSubtotal.currency)
        }
        DiscountType.FIXED -> {
            // pc.currency guaranteed not-null at this point (DB CHECK + validate).
            Money(amount = minOf(pc.discountValue, orderSubtotal.amount), currency = pc.currency!!)
        }
    }

    private fun fromRow(r: org.jetbrains.exposed.sql.ResultRow) = Promocode(
        id = r[BasePromocodesTable.id],
        code = r[BasePromocodesTable.code],
        description = r[BasePromocodesTable.description],
        discountType = DiscountType.parse(r[BasePromocodesTable.discountType]),
        discountValue = r[BasePromocodesTable.discountValue],
        currency = r[BasePromocodesTable.currency],
        validFrom = r[BasePromocodesTable.validFrom],
        validUntil = r[BasePromocodesTable.validUntil],
        usageLimit = r[BasePromocodesTable.usageLimit],
        usedCount = r[BasePromocodesTable.usedCount],
        minOrderAmount = r[BasePromocodesTable.minOrderAmount],
        maxDiscountAmount = r[BasePromocodesTable.maxDiscountAmount],
        perUserLimit = r[BasePromocodesTable.perUserLimit],
        scope = PromocodeScope.parse(r[BasePromocodesTable.scope]),
        scopeTargetId = r[BasePromocodesTable.scopeTargetId],
        isActive = r[BasePromocodesTable.isActive],
        createdBy = r[BasePromocodesTable.createdBy],
        createdAt = r[BasePromocodesTable.createdAt],
        updatedAt = r[BasePromocodesTable.updatedAt],
    )

    private fun redemptionFromRow(r: org.jetbrains.exposed.sql.ResultRow) = PromocodeRedemption(
        id = r[BasePromocodeRedemptionsTable.id],
        promocodeId = r[BasePromocodeRedemptionsTable.promocodeId],
        userId = r[BasePromocodeRedemptionsTable.userId],
        orderId = r[BasePromocodeRedemptionsTable.orderId],
        discountAppliedAmount = r[BasePromocodeRedemptionsTable.discountAppliedAmount],
        currency = r[BasePromocodeRedemptionsTable.currency],
        redeemedAt = r[BasePromocodeRedemptionsTable.redeemedAt],
    )
}
