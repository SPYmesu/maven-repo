package su.spyme.marketplace.inventory

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Inventory module: warehouses + stock_levels + stock_reservations.
 *
 * Stock model: каждый (warehouse, product, variant) — это одна строка
 * с on_hand (физический остаток) и reserved (зарезервирован в активных
 * cart/order). Available = on_hand - reserved.
 *
 * Reservations имеют TTL — cron sweep'ит expired holds и возвращает
 * inventory.
 */

object BaseWarehousesTable : Table("warehouses") {
    val id: Column<Long> = long("id").autoIncrement()
    val code: Column<String> = varchar("code", 64).uniqueIndex()
    val name: Column<String> = text("name")
    val address: Column<String?> = text("address").nullable()
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseStockLevelsTable : Table("stock_levels") {
    val id: Column<Long> = long("id").autoIncrement()
    val warehouseId: Column<Long> = long("warehouse_id")
    val productId: Column<Long> = long("product_id")
    val variantId: Column<Long?> = long("variant_id").nullable()
    val onHand: Column<Int> = integer("on_hand").default(0)
    val reserved: Column<Int> = integer("reserved").default(0)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
    // Unique-per-(warehouse, product, variant) обеспечивается двумя
    // partial-index'ами в V031 SQL (variant=NULL / variant=not-null).
    // Service-слой делает lookup через rowMatch() helper.
}

object BaseStockReservationsTable : Table("stock_reservations") {
    val id: Column<Long> = long("id").autoIncrement()
    val warehouseId: Column<Long> = long("warehouse_id")
    val productId: Column<Long> = long("product_id")
    val variantId: Column<Long?> = long("variant_id").nullable()
    val quantity: Column<Int> = integer("quantity")
    val orderId: Column<Long?> = long("order_id").nullable()
    val cartToken: Column<String?> = text("cart_token").nullable()
    val expiresAt: Column<Instant> = timestamp("expires_at")
    val releasedAt: Column<Instant?> = timestamp("released_at").nullable()
    val fulfilledAt: Column<Instant?> = timestamp("fulfilled_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

data class Warehouse(
    val id: Long, val code: String, val name: String,
    val address: String?, val isActive: Boolean,
    val createdAt: Instant, val updatedAt: Instant,
)

data class StockLevel(
    val warehouseId: Long, val productId: Long, val variantId: Long?,
    val onHand: Int, val reserved: Int,
) {
    val available: Int get() = (onHand - reserved).coerceAtLeast(0)
}

data class StockReservation(
    val id: Long, val warehouseId: Long, val productId: Long, val variantId: Long?,
    val quantity: Int, val orderId: Long?, val cartToken: String?,
    val expiresAt: Instant, val releasedAt: Instant?, val fulfilledAt: Instant?,
    val createdAt: Instant,
) {
    val isActive: Boolean
        get() = releasedAt == null && fulfilledAt == null && expiresAt.isAfter(Instant.now())
}
