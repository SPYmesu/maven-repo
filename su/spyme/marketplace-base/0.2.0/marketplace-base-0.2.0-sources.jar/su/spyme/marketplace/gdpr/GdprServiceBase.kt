package su.spyme.marketplace.gdpr

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.or
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.auth.SecretEncryption
import su.spyme.marketplace.users.BaseUsersTable
import java.time.Instant

/**
 * Scrubber для одной зоны данных — host's tables (например, BookmarksScrubber,
 * NotesScrubber). Чёрный ящик: получает userId, возвращает JSON snapshot
 * полей, которые он скраббит, плюс мутирует/удаляет их в same transaction.
 *
 * Built-in [UserRowScrubber] anonymizes users table (username, email, phone).
 */
interface DeletionScrubber {
    val name: String

    /**
     * @return JSON snapshot of data that was scrubbed (for legal_archive
     *         encrypted payload). Empty object {} means "nothing to scrub
     *         for this user".
     */
    fun scrub(userId: Long, mainDb: Database): JsonObject
}

/**
 * GDPR-deletion service: lifecycle PENDING → APPROVED → EXECUTED.
 *
 * Twin-layer (Б3):
 *   - operational scrub via registered [DeletionScrubber]s.
 *   - encrypted legal_archive entry retains personal data for regulatory
 *     legal retention period (host's policy via retentionUntil).
 *
 * Execution is atomic per-request: все scrubbers + archive insert + status
 * flip happen in one transaction. Failure rolls back entire request.
 */
open class GdprServiceBase(
    protected val mainDb: Database,
    protected val encryption: SecretEncryption,
) {

    private val scrubbers: MutableList<DeletionScrubber> = mutableListOf()

    /**
     * Registers a scrubber. Host calls during bootstrap phase 1 (Registration).
     * Idempotent — повторная regist с same name заменяет предыдущий.
     */
    fun registerScrubber(scrubber: DeletionScrubber) {
        scrubbers.removeAll { it.name == scrubber.name }
        scrubbers += scrubber
    }

    fun registeredScrubberNames(): List<String> = scrubbers.map { it.name }

    open fun requestDeletion(userId: Long, reason: String? = null): DeletionRequest = transaction(mainDb) {
        val id = BaseDeletionRequestsTable.insert {
            it[BaseDeletionRequestsTable.userId] = userId
            it[BaseDeletionRequestsTable.reason] = reason
        } get BaseDeletionRequestsTable.id
        loadById(id)!!
    }

    open fun loadById(id: Long): DeletionRequest? = transaction(mainDb) {
        BaseDeletionRequestsTable.selectAll()
            .where { BaseDeletionRequestsTable.id eq id }
            .firstOrNull()?.let(::fromRow)
    }

    open fun listPending(): List<DeletionRequest> = transaction(mainDb) {
        BaseDeletionRequestsTable.selectAll()
            .where { BaseDeletionRequestsTable.status eq DeletionStatus.PENDING.name }
            .orderBy(BaseDeletionRequestsTable.requestedAt to SortOrder.ASC)
            .map(::fromRow)
    }

    open fun listApproved(): List<DeletionRequest> = transaction(mainDb) {
        BaseDeletionRequestsTable.selectAll()
            .where { BaseDeletionRequestsTable.status eq DeletionStatus.APPROVED.name }
            .orderBy(BaseDeletionRequestsTable.reviewedAt to SortOrder.ASC)
            .map(::fromRow)
    }

    /**
     * Approves PENDING request. Returns updated row или null если status
     * не PENDING (already approved/rejected/executed).
     */
    open fun approve(
        requestId: Long, reviewedBy: Long, notes: String? = null, now: Instant = Instant.now(),
    ): DeletionRequest? = transaction(mainDb) {
        val updated = BaseDeletionRequestsTable.update({
            (BaseDeletionRequestsTable.id eq requestId) and
                (BaseDeletionRequestsTable.status eq DeletionStatus.PENDING.name)
        }) {
            it[BaseDeletionRequestsTable.status] = DeletionStatus.APPROVED.name
            it[BaseDeletionRequestsTable.reviewedAt] = now
            it[BaseDeletionRequestsTable.reviewedBy] = reviewedBy
            it[BaseDeletionRequestsTable.reviewNotes] = notes
        }
        if (updated == 0) null else loadById(requestId)
    }

    open fun reject(
        requestId: Long, reviewedBy: Long, notes: String? = null, now: Instant = Instant.now(),
    ): DeletionRequest? = transaction(mainDb) {
        val updated = BaseDeletionRequestsTable.update({
            (BaseDeletionRequestsTable.id eq requestId) and
                (BaseDeletionRequestsTable.status eq DeletionStatus.PENDING.name)
        }) {
            it[BaseDeletionRequestsTable.status] = DeletionStatus.REJECTED.name
            it[BaseDeletionRequestsTable.reviewedAt] = now
            it[BaseDeletionRequestsTable.reviewedBy] = reviewedBy
            it[BaseDeletionRequestsTable.reviewNotes] = notes
        }
        if (updated == 0) null else loadById(requestId)
    }

    /**
     * Executes approved request: runs scrubbers, archives snapshot, marks EXECUTED.
     *
     * @throws IllegalStateException если request не APPROVED.
     */
    open fun executeApprovedRequest(
        requestId: Long,
        retentionUntil: Instant? = null,
        now: Instant = Instant.now(),
    ): ExecutionResult = transaction(mainDb) {
        val req = loadById(requestId)
            ?: throw IllegalStateException("Deletion request $requestId not found")
        check(req.status == DeletionStatus.APPROVED) {
            "Deletion request $requestId must be APPROVED, was ${req.status}"
        }

        // 1. Run all registered scrubbers — collect snapshots.
        val perScrubber: MutableMap<String, JsonElement> = mutableMapOf()
        for (s in scrubbers) {
            perScrubber[s.name] = s.scrub(req.userId, mainDb)
        }
        // Combined snapshot.
        val combined = JsonObject(perScrubber)

        // 2. Encrypt + persist to legal_archive.
        val encrypted = encryption.encryptString(combined.toString())
        val archiveId = BaseLegalArchiveTable.insert {
            it[BaseLegalArchiveTable.userId] = req.userId
            it[BaseLegalArchiveTable.deletionRequestId] = req.id
            it[BaseLegalArchiveTable.encryptedPayload] = encrypted
            it[BaseLegalArchiveTable.retentionUntil] = retentionUntil
        } get BaseLegalArchiveTable.id

        // 3. Mark request EXECUTED.
        BaseDeletionRequestsTable.update({ BaseDeletionRequestsTable.id eq requestId }) {
            it[BaseDeletionRequestsTable.status] = DeletionStatus.EXECUTED.name
            it[BaseDeletionRequestsTable.executedAt] = now
        }

        ExecutionResult(
            requestId = requestId,
            archiveId = archiveId,
            scrubberNames = scrubbers.map { it.name },
        )
    }

    /**
     * Returns archive entries for user. Body is encrypted — call
     * [decryptArchive] для unwrap.
     */
    open fun listArchiveForUser(userId: Long): List<LegalArchiveEntry> = transaction(mainDb) {
        BaseLegalArchiveTable.selectAll()
            .where { BaseLegalArchiveTable.userId eq userId }
            .orderBy(BaseLegalArchiveTable.archivedAt to SortOrder.ASC)
            .map(::archiveFromRow)
    }

    /**
     * Decrypts archive payload back to JSON. Call gated by LEGAL_OFFICER
     * role + 2FA in host's route.
     */
    open fun decryptArchive(entry: LegalArchiveEntry): String =
        encryption.decryptString(entry.encryptedPayload)

    // ---------- helpers ----------

    private fun fromRow(r: org.jetbrains.exposed.sql.ResultRow) = DeletionRequest(
        id = r[BaseDeletionRequestsTable.id],
        userId = r[BaseDeletionRequestsTable.userId],
        status = DeletionStatus.parse(r[BaseDeletionRequestsTable.status]),
        requestedAt = r[BaseDeletionRequestsTable.requestedAt],
        reason = r[BaseDeletionRequestsTable.reason],
        reviewedAt = r[BaseDeletionRequestsTable.reviewedAt],
        reviewedBy = r[BaseDeletionRequestsTable.reviewedBy],
        reviewNotes = r[BaseDeletionRequestsTable.reviewNotes],
        executedAt = r[BaseDeletionRequestsTable.executedAt],
    )

    private fun archiveFromRow(r: org.jetbrains.exposed.sql.ResultRow) = LegalArchiveEntry(
        id = r[BaseLegalArchiveTable.id],
        userId = r[BaseLegalArchiveTable.userId],
        deletionRequestId = r[BaseLegalArchiveTable.deletionRequestId],
        encryptedPayload = r[BaseLegalArchiveTable.encryptedPayload],
        encryptionAlg = r[BaseLegalArchiveTable.encryptionAlg],
        archivedAt = r[BaseLegalArchiveTable.archivedAt],
        retentionUntil = r[BaseLegalArchiveTable.retentionUntil],
    )
}

data class ExecutionResult(
    val requestId: Long,
    val archiveId: Long,
    val scrubberNames: List<String>,
)

/**
 * Built-in scrubber для users table: snapshots username/email/phone, then
 * anonymizes them + bumps jwt_version to invalidate sessions + stamps deleted_at.
 */
class UserRowScrubber : DeletionScrubber {
    override val name = "users"

    override fun scrub(userId: Long, mainDb: Database): JsonObject =
        org.jetbrains.exposed.sql.transactions.transaction(mainDb) {
            val row = BaseUsersTable.selectAll()
                .where { BaseUsersTable.id eq userId }
                .firstOrNull()
                ?: return@transaction JsonObject(emptyMap())
            val snapshot = buildJsonObject {
                put("username", JsonPrimitive(row[BaseUsersTable.username]))
                put("email", JsonPrimitive(row[BaseUsersTable.email]))
                put("phone", JsonPrimitive(row[BaseUsersTable.phone]))
                put("locale", JsonPrimitive(row[BaseUsersTable.locale]))
                put("timezone", JsonPrimitive(row[BaseUsersTable.timezone]))
            }
            BaseUsersTable.update({ BaseUsersTable.id eq userId }) {
                it[BaseUsersTable.username] = "__deleted_${userId}__"
                it[BaseUsersTable.email] = "deleted+${userId}@anonymous.local"
                it[BaseUsersTable.phone] = null
                it[BaseUsersTable.emailVerifiedAt] = null
                it[BaseUsersTable.phoneVerifiedAt] = null
                it[BaseUsersTable.timezone] = null
                it[BaseUsersTable.deletedAt] = Instant.now()
                with(SqlExpressionBuilder) {
                    it.update(BaseUsersTable.jwtVersion, BaseUsersTable.jwtVersion + 1)
                }
            }
            snapshot
        }
}
