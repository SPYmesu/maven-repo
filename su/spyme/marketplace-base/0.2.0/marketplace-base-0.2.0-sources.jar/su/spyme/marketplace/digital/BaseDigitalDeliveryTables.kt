package su.spyme.marketplace.digital

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Moderation outcome for a [ProductVersion]. Mirrors V030 CHECK alphabet.
 */
enum class ProductVersionStatus {
    PENDING_REVIEW, APPROVED, REJECTED;

    companion object {
        fun parse(value: String): ProductVersionStatus =
            entries.firstOrNull { it.name == value }
                ?: throw IllegalArgumentException("Unknown ProductVersionStatus: '$value'")
    }
}

object BaseProductVersionsTable : Table("product_versions") {
    val id: Column<Long> = long("id").autoIncrement()
    val productId: Column<Long> = long("product_id")
    val version: Column<String> = text("version")
    val title: Column<String?> = text("title").nullable()
    val changelogFormat: Column<String> = varchar("changelog_format", 16)
    val changelogContent: Column<String> = text("changelog_content")
    val fileUrl: Column<String?> = text("file_url").nullable()
    val fileSizeBytes: Column<Long?> = long("file_size_bytes").nullable()
    val downloadCount: Column<Int> = integer("download_count").default(0)
    val status: Column<String> = varchar("status", 32).default("PENDING_REVIEW")
    val rejectionReason: Column<String?> = text("rejection_reason").nullable()
    val reviewedBy: Column<Long?> = long("reviewed_by").nullable()
    val reviewedAt: Column<Instant?> = timestamp("reviewed_at").nullable()
    val submittedAt: Column<Instant> = timestamp("submitted_at").defaultExpression(NowExpression)
    val publishedAt: Column<Instant?> = timestamp("published_at").nullable()

    override val primaryKey = PrimaryKey(id)
}

object BaseDownloadsTable : Table("downloads") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val productId: Column<Long> = long("product_id")
    val versionId: Column<Long> = long("version_id")
    val downloadedAt: Column<Instant> = timestamp("downloaded_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

data class ProductVersion(
    val id: Long,
    val productId: Long,
    val version: String,
    val title: String?,
    val changelogFormat: String,
    val changelogContent: String,
    val fileUrl: String?,
    val fileSizeBytes: Long?,
    val downloadCount: Int,
    val status: ProductVersionStatus,
    val rejectionReason: String?,
    val reviewedBy: Long?,
    val reviewedAt: Instant?,
    val submittedAt: Instant,
    val publishedAt: Instant?,
) {
    val isPublic: Boolean get() = status == ProductVersionStatus.APPROVED

    companion object {
        fun fromRow(row: ResultRow): ProductVersion = ProductVersion(
            id = row[BaseProductVersionsTable.id],
            productId = row[BaseProductVersionsTable.productId],
            version = row[BaseProductVersionsTable.version],
            title = row[BaseProductVersionsTable.title],
            changelogFormat = row[BaseProductVersionsTable.changelogFormat],
            changelogContent = row[BaseProductVersionsTable.changelogContent],
            fileUrl = row[BaseProductVersionsTable.fileUrl],
            fileSizeBytes = row[BaseProductVersionsTable.fileSizeBytes],
            downloadCount = row[BaseProductVersionsTable.downloadCount],
            status = ProductVersionStatus.parse(row[BaseProductVersionsTable.status]),
            rejectionReason = row[BaseProductVersionsTable.rejectionReason],
            reviewedBy = row[BaseProductVersionsTable.reviewedBy],
            reviewedAt = row[BaseProductVersionsTable.reviewedAt],
            submittedAt = row[BaseProductVersionsTable.submittedAt],
            publishedAt = row[BaseProductVersionsTable.publishedAt],
        )
    }
}

data class Download(
    val id: Long,
    val userId: Long,
    val productId: Long,
    val versionId: Long,
    val downloadedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): Download = Download(
            id = row[BaseDownloadsTable.id],
            userId = row[BaseDownloadsTable.userId],
            productId = row[BaseDownloadsTable.productId],
            versionId = row[BaseDownloadsTable.versionId],
            downloadedAt = row[BaseDownloadsTable.downloadedAt],
        )
    }
}
