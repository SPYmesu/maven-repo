package su.spyme.marketplace.promotions

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Promotions module: promocodes + promocode_redemptions.
 *
 * Discount kinds:
 *   - PERCENT: 1..100 (capped optionally by max_discount_amount).
 *   - FIXED: discount_value in cents of [currency].
 *
 * Scope tells host's policy WHERE the code applies (ALL_PRODUCTS, CATEGORY,
 * PRODUCT, USER) — base service не enforces scope-target match (host's job).
 */
enum class DiscountType { PERCENT, FIXED;
    companion object {
        fun parse(s: String): DiscountType = entries.firstOrNull { it.name == s }
            ?: throw IllegalArgumentException("Unknown DiscountType: '$s'")
    }
}

enum class PromocodeScope { ALL_PRODUCTS, CATEGORY, PRODUCT, USER;
    companion object {
        fun parse(s: String): PromocodeScope = entries.firstOrNull { it.name == s }
            ?: throw IllegalArgumentException("Unknown PromocodeScope: '$s'")
    }
}

object BasePromocodesTable : Table("promocodes") {
    val id: Column<Long> = long("id").autoIncrement()
    val code: Column<String> = varchar("code", 64).uniqueIndex()
    val description: Column<String?> = text("description").nullable()
    val discountType: Column<String> = varchar("discount_type", 16)
    val discountValue: Column<Long> = long("discount_value")
    val currency: Column<String?> = varchar("currency", 3).nullable()
    val validFrom: Column<Instant> = timestamp("valid_from").defaultExpression(NowExpression)
    val validUntil: Column<Instant?> = timestamp("valid_until").nullable()
    val usageLimit: Column<Int?> = integer("usage_limit").nullable()
    val usedCount: Column<Int> = integer("used_count").default(0)
    val minOrderAmount: Column<Long?> = long("min_order_amount").nullable()
    val maxDiscountAmount: Column<Long?> = long("max_discount_amount").nullable()
    val perUserLimit: Column<Int?> = integer("per_user_limit").nullable()
    val scope: Column<String> = varchar("scope", 32).default("ALL_PRODUCTS")
    val scopeTargetId: Column<Long?> = long("scope_target_id").nullable()
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdBy: Column<Long?> = long("created_by").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BasePromocodeRedemptionsTable : Table("promocode_redemptions") {
    val id: Column<Long> = long("id").autoIncrement()
    val promocodeId: Column<Long> = long("promocode_id")
    val userId: Column<Long?> = long("user_id").nullable()
    val orderId: Column<Long> = long("order_id")
    val discountAppliedAmount: Column<Long> = long("discount_applied_amount")
    val currency: Column<String> = varchar("currency", 3)
    val redeemedAt: Column<Instant> = timestamp("redeemed_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
    init { uniqueIndex("promocode_redemptions_promo_order_unique", promocodeId, orderId) }
}

data class Promocode(
    val id: Long,
    val code: String,
    val description: String?,
    val discountType: DiscountType,
    val discountValue: Long,
    val currency: String?,
    val validFrom: Instant,
    val validUntil: Instant?,
    val usageLimit: Int?,
    val usedCount: Int,
    val minOrderAmount: Long?,
    val maxDiscountAmount: Long?,
    val perUserLimit: Int?,
    val scope: PromocodeScope,
    val scopeTargetId: Long?,
    val isActive: Boolean,
    val createdBy: Long?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    fun isLive(now: Instant = Instant.now()): Boolean =
        isActive &&
            !now.isBefore(validFrom) &&
            (validUntil == null || now.isBefore(validUntil)) &&
            (usageLimit == null || usedCount < usageLimit)
}

data class PromocodeRedemption(
    val id: Long,
    val promocodeId: Long,
    val userId: Long?,
    val orderId: Long,
    val discountAppliedAmount: Long,
    val currency: String,
    val redeemedAt: Instant,
)
