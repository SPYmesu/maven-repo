package su.spyme.marketplace.tax

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * Tax computation service.
 *
 * Workflow:
 *   - Host registers tax rules at startup OR runtime (admin UI).
 *   - At checkout, [computeForOrder] called с jurisdiction (country, region?)
 *     и list[TaxableLine]. Returns OrderTaxBreakdown с per-line + per-rule
 *     aggregation.
 *   - Rules matching same line are stacked by priority — highest priority first.
 *
 * Inclusive vs exclusive:
 *   - Exclusive (default): tax = subtotal × rate / 10000.
 *   - Inclusive (EU VAT): tax = subtotal × rate / (10000 + rate). Subtotal остаётся
 *     prefilled (без bumping order total).
 *
 * No persistence в этом service-слое для applied tax — это responsibility
 * order/payment слоёв (snapshot в order'е).
 */
open class TaxServiceBase(protected val mainDb: Database) {

    open fun createRule(
        name: String,
        rateBp: Int,
        country: String? = null,
        region: String? = null,
        productKind: String? = null,
        categoryId: Long? = null,
        inclusive: Boolean = false,
        priority: Int = 100,
        validFrom: Instant = Instant.now(),
        validUntil: Instant? = null,
    ): TaxRule {
        require(rateBp in 0..100_000) { "rateBp must be 0..100000 (= 0..1000%)" }
        if (productKind != null) {
            require(productKind in setOf("PHYSICAL", "DIGITAL", "MIXED")) {
                "productKind must be PHYSICAL/DIGITAL/MIXED or null"
            }
        }
        return transaction(mainDb) {
            val id = BaseTaxRulesTable.insert {
                it[BaseTaxRulesTable.name] = name
                it[BaseTaxRulesTable.country] = country
                it[BaseTaxRulesTable.region] = region
                it[BaseTaxRulesTable.productKind] = productKind
                it[BaseTaxRulesTable.categoryId] = categoryId
                it[BaseTaxRulesTable.rateBp] = rateBp
                it[BaseTaxRulesTable.inclusive] = inclusive
                it[BaseTaxRulesTable.priority] = priority
                it[BaseTaxRulesTable.validFrom] = validFrom
                it[BaseTaxRulesTable.validUntil] = validUntil
            } get BaseTaxRulesTable.id
            loadById(id)!!
        }
    }

    open fun loadById(id: Long): TaxRule? = transaction(mainDb) {
        BaseTaxRulesTable.selectAll()
            .where { BaseTaxRulesTable.id eq id }
            .firstOrNull()?.let(::fromRow)
    }

    /**
     * Returns all active rules sorted by priority DESC. Host may cache the
     * list (rules меняются редко).
     */
    open fun listActiveRules(now: Instant = Instant.now()): List<TaxRule> = transaction(mainDb) {
        BaseTaxRulesTable.selectAll()
            .where { BaseTaxRulesTable.isActive eq true }
            .orderBy(
                BaseTaxRulesTable.priority to SortOrder.DESC,
                BaseTaxRulesTable.id to SortOrder.ASC,
            )
            .map(::fromRow)
            .filter { it.isLive(now) }
    }

    open fun deactivate(ruleId: Long): Boolean = transaction(mainDb) {
        BaseTaxRulesTable.update({ BaseTaxRulesTable.id eq ruleId }) {
            it[BaseTaxRulesTable.isActive] = false
        } > 0
    }

    /**
     * Computes tax для одной line. Применяет все matching rules по priority
     * order. Each rule contributes a separate [AppliedTax]; total summed.
     */
    open fun computeForLine(
        line: TaxableLine,
        country: String?,
        region: String? = null,
        rules: List<TaxRule>,
    ): LineTax {
        val applicable = rules.filter { it.matches(country, region, line.productKind, line.categoryId) }
        val applied = applicable.map { rule ->
            val taxAmount = applyRate(line.lineSubtotal.amount, rule.rateBp, rule.inclusive)
            AppliedTax(
                ruleId = rule.id,
                ruleName = rule.name,
                rateBp = rule.rateBp,
                inclusive = rule.inclusive,
                amount = Money(amount = taxAmount, currency = line.unitPrice.currency),
            )
        }
        val total = Money(
            amount = applied.sumOf { it.amount.amount },
            currency = line.unitPrice.currency,
        )
        return LineTax(line = line, appliedRules = applied, totalTax = total)
    }

    /**
     * Computes tax breakdown для order — applies все matching rules to each line.
     */
    open fun computeForOrder(
        lines: List<TaxableLine>,
        country: String?,
        region: String? = null,
        now: Instant = Instant.now(),
    ): OrderTaxBreakdown {
        require(lines.isNotEmpty()) { "at least one taxable line required" }
        val currency = lines.first().unitPrice.currency
        require(lines.all { it.unitPrice.currency == currency }) {
            "all lines must share single currency"
        }
        val rules = listActiveRules(now)
        val lineTaxes = lines.map { computeForLine(it, country, region, rules) }
        val total = Money(
            amount = lineTaxes.sumOf { it.totalTax.amount },
            currency = currency,
        )
        return OrderTaxBreakdown(lineTaxes = lineTaxes, totalTax = total)
    }

    // ---------- helpers ----------

    /**
     * Calculates tax-cents для subtotal at rate basis points.
     *   - Exclusive: subtotal × rate / 10000.
     *   - Inclusive: subtotal × rate / (10000 + rate). Bankers rounding round-half-to-even
     *     не used — простой floor (HALF_UP при необходимости в host'е).
     */
    private fun applyRate(subtotalCents: Long, rateBp: Int, inclusive: Boolean): Long {
        if (rateBp == 0) return 0
        return if (inclusive) {
            (subtotalCents * rateBp) / (10_000L + rateBp)
        } else {
            (subtotalCents * rateBp) / 10_000L
        }
    }

    private fun fromRow(r: org.jetbrains.exposed.sql.ResultRow) = TaxRule(
        id = r[BaseTaxRulesTable.id],
        name = r[BaseTaxRulesTable.name],
        country = r[BaseTaxRulesTable.country],
        region = r[BaseTaxRulesTable.region],
        productKind = r[BaseTaxRulesTable.productKind],
        categoryId = r[BaseTaxRulesTable.categoryId],
        rateBp = r[BaseTaxRulesTable.rateBp],
        inclusive = r[BaseTaxRulesTable.inclusive],
        priority = r[BaseTaxRulesTable.priority],
        validFrom = r[BaseTaxRulesTable.validFrom],
        validUntil = r[BaseTaxRulesTable.validUntil],
        isActive = r[BaseTaxRulesTable.isActive],
        createdAt = r[BaseTaxRulesTable.createdAt],
        updatedAt = r[BaseTaxRulesTable.updatedAt],
    )
}
