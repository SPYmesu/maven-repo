package su.spyme.marketplace.inventory

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant

/**
 * Inventory service: warehouses + stock + reservations с TTL.
 *
 * Bootstrap pattern:
 *   - Host регистрирует один-более warehouses.
 *   - Cart/checkout flow вызывает reserveStock() с cart_token + TTL.
 *   - Order PAID transition вызывает fulfillReservation(orderId).
 *   - Cron releaseExpiredReservations() гонится раз в минуту.
 */
open class InventoryServiceBase(protected val mainDb: Database) {

    open fun createWarehouse(code: String, name: String, address: String? = null): Warehouse =
        transaction(mainDb) {
            val id = BaseWarehousesTable.insert {
                it[BaseWarehousesTable.code] = code
                it[BaseWarehousesTable.name] = name
                it[BaseWarehousesTable.address] = address
            } get BaseWarehousesTable.id
            loadWarehouseById(id)!!
        }

    open fun loadWarehouseById(id: Long): Warehouse? = transaction(mainDb) {
        BaseWarehousesTable.selectAll()
            .where { BaseWarehousesTable.id eq id }
            .firstOrNull()?.let {
                Warehouse(
                    id = it[BaseWarehousesTable.id],
                    code = it[BaseWarehousesTable.code],
                    name = it[BaseWarehousesTable.name],
                    address = it[BaseWarehousesTable.address],
                    isActive = it[BaseWarehousesTable.isActive],
                    createdAt = it[BaseWarehousesTable.createdAt],
                    updatedAt = it[BaseWarehousesTable.updatedAt],
                )
            }
    }

    /**
     * Sets on_hand для (warehouse, product, variant) — upsert. Used by
     * vendor-initiated stock updates и initial seeding.
     */
    open fun setOnHand(warehouseId: Long, productId: Long, variantId: Long?, onHand: Int) {
        require(onHand >= 0) { "onHand must be >= 0" }
        transaction(mainDb) {
            val existing = findStock(warehouseId, productId, variantId)
            if (existing != null) {
                BaseStockLevelsTable.update({
                    rowMatch(warehouseId, productId, variantId)
                }) {
                    it[BaseStockLevelsTable.onHand] = onHand
                }
            } else {
                BaseStockLevelsTable.insert {
                    it[BaseStockLevelsTable.warehouseId] = warehouseId
                    it[BaseStockLevelsTable.productId] = productId
                    it[BaseStockLevelsTable.variantId] = variantId
                    it[BaseStockLevelsTable.onHand] = onHand
                }
            }
        }
    }

    open fun findStock(warehouseId: Long, productId: Long, variantId: Long?): StockLevel? =
        transaction(mainDb) {
            BaseStockLevelsTable.selectAll()
                .where { rowMatch(warehouseId, productId, variantId) }
                .firstOrNull()?.let {
                    StockLevel(
                        warehouseId = it[BaseStockLevelsTable.warehouseId],
                        productId = it[BaseStockLevelsTable.productId],
                        variantId = it[BaseStockLevelsTable.variantId],
                        onHand = it[BaseStockLevelsTable.onHand],
                        reserved = it[BaseStockLevelsTable.reserved],
                    )
                }
        }

    /**
     * Атомарный hold inventory: bump reserved += quantity и insert
     * stock_reservation row. Возвращает null если available < quantity.
     */
    open fun reserveStock(
        warehouseId: Long, productId: Long, variantId: Long?, quantity: Int,
        ttlSeconds: Long, cartToken: String? = null, orderId: Long? = null,
        now: Instant = Instant.now(),
    ): StockReservation? {
        require(quantity > 0)
        return transaction(mainDb) {
            val stock = findStock(warehouseId, productId, variantId) ?: return@transaction null
            if (stock.available < quantity) return@transaction null

            BaseStockLevelsTable.update({ rowMatch(warehouseId, productId, variantId) }) {
                with(SqlExpressionBuilder) {
                    it.update(BaseStockLevelsTable.reserved, BaseStockLevelsTable.reserved + quantity)
                }
            }
            val expiresAt = now.plusSeconds(ttlSeconds)
            val id = BaseStockReservationsTable.insert {
                it[BaseStockReservationsTable.warehouseId] = warehouseId
                it[BaseStockReservationsTable.productId] = productId
                it[BaseStockReservationsTable.variantId] = variantId
                it[BaseStockReservationsTable.quantity] = quantity
                it[BaseStockReservationsTable.cartToken] = cartToken
                it[BaseStockReservationsTable.orderId] = orderId
                it[BaseStockReservationsTable.expiresAt] = expiresAt
            } get BaseStockReservationsTable.id
            loadReservationById(id)!!
        }
    }

    /**
     * Order PAID: списываем on_hand на quantity, чистим reserved (товар
     * уехал к покупателю). Marks reservation fulfilled_at.
     */
    open fun fulfillReservation(reservationId: Long, now: Instant = Instant.now()): Boolean =
        transaction(mainDb) {
            val r = loadReservationById(reservationId) ?: return@transaction false
            if (r.releasedAt != null || r.fulfilledAt != null) return@transaction false
            BaseStockLevelsTable.update({ rowMatch(r.warehouseId, r.productId, r.variantId) }) {
                with(SqlExpressionBuilder) {
                    it.update(BaseStockLevelsTable.onHand, BaseStockLevelsTable.onHand - r.quantity)
                    it.update(BaseStockLevelsTable.reserved, BaseStockLevelsTable.reserved - r.quantity)
                }
            }
            BaseStockReservationsTable.update({ BaseStockReservationsTable.id eq reservationId }) {
                it[BaseStockReservationsTable.fulfilledAt] = now
            }
            true
        }

    /**
     * Освобождает hold (cart abandoned / order cancelled): reserved -=
     * quantity. Stamps released_at. Refuses if reservation already
     * fulfilled или released. Expired-but-untouched holds — фair game
     * (cron sweep relies on this).
     */
    open fun releaseReservation(reservationId: Long, now: Instant = Instant.now()): Boolean =
        transaction(mainDb) {
            val r = loadReservationById(reservationId) ?: return@transaction false
            if (r.releasedAt != null || r.fulfilledAt != null) return@transaction false
            BaseStockLevelsTable.update({ rowMatch(r.warehouseId, r.productId, r.variantId) }) {
                with(SqlExpressionBuilder) {
                    it.update(BaseStockLevelsTable.reserved, BaseStockLevelsTable.reserved - r.quantity)
                }
            }
            BaseStockReservationsTable.update({ BaseStockReservationsTable.id eq reservationId }) {
                it[BaseStockReservationsTable.releasedAt] = now
            }
            true
        }

    /** Cron: releases all expired holds. Returns count freed. */
    open fun releaseExpiredReservations(now: Instant = Instant.now()): Int = transaction(mainDb) {
        val expired = BaseStockReservationsTable.selectAll()
            .where {
                (BaseStockReservationsTable.expiresAt less now) and
                    BaseStockReservationsTable.releasedAt.isNull() and
                    BaseStockReservationsTable.fulfilledAt.isNull()
            }
            .toList()
        var freed = 0
        for (row in expired) {
            val rid = row[BaseStockReservationsTable.id]
            if (releaseReservation(rid, now)) freed++
        }
        freed
    }

    open fun loadReservationById(id: Long): StockReservation? = transaction(mainDb) {
        BaseStockReservationsTable.selectAll()
            .where { BaseStockReservationsTable.id eq id }
            .firstOrNull()?.let {
                StockReservation(
                    id = it[BaseStockReservationsTable.id],
                    warehouseId = it[BaseStockReservationsTable.warehouseId],
                    productId = it[BaseStockReservationsTable.productId],
                    variantId = it[BaseStockReservationsTable.variantId],
                    quantity = it[BaseStockReservationsTable.quantity],
                    orderId = it[BaseStockReservationsTable.orderId],
                    cartToken = it[BaseStockReservationsTable.cartToken],
                    expiresAt = it[BaseStockReservationsTable.expiresAt],
                    releasedAt = it[BaseStockReservationsTable.releasedAt],
                    fulfilledAt = it[BaseStockReservationsTable.fulfilledAt],
                    createdAt = it[BaseStockReservationsTable.createdAt],
                )
            }
    }

    private fun rowMatch(warehouseId: Long, productId: Long, variantId: Long?) =
        with(SqlExpressionBuilder) {
            val base = (BaseStockLevelsTable.warehouseId eq warehouseId) and
                (BaseStockLevelsTable.productId eq productId)
            if (variantId == null) base and BaseStockLevelsTable.variantId.isNull()
            else base and (BaseStockLevelsTable.variantId eq variantId)
        }
}
