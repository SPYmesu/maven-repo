package su.spyme.marketplace.subscriptions

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Billing period for [Subscription]. Mirrors the V029 CHECK alphabet.
 *
 * Lib doesn't enforce a fixed-duration mapping (a host might define
 * `quarter` as 90 days vs 3 calendar months); the duration calculation
 * is up to [SubscriptionsServiceBase.computeExpiresAt].
 */
enum class SubscriptionPeriod {
    MONTH, QUARTER, YEAR;

    val code: String get() = name.lowercase()

    companion object {
        fun parse(value: String): SubscriptionPeriod =
            entries.firstOrNull { it.code == value.lowercase() }
                ?: throw IllegalArgumentException("Unknown SubscriptionPeriod: '$value'")
    }
}

/**
 * Lifecycle status. ACTIVE -> EXPIRED (cron sweep) or ACTIVE -> CANCELLED.
 */
enum class SubscriptionStatus {
    ACTIVE, EXPIRED, CANCELLED;

    companion object {
        fun parse(value: String): SubscriptionStatus =
            entries.firstOrNull { it.name == value }
                ?: throw IllegalArgumentException("Unknown SubscriptionStatus: '$value'")
    }
}

/**
 * Time-bounded access to a subscription-style product.
 *
 * A row is created when an order containing a subscription product
 * transitions to PAID (see [SubscriptionsServiceBase.createOnOrderPaid]
 * called from an OrderTransitionListener registered by the host).
 *
 * Sub-second precision on timestamps mirrors lib convention; hosts
 * that need finer billing windows may add their own columns through
 * side-tables.
 */
object BaseSubscriptionsTable : Table("subscriptions") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val productId: Column<Long> = long("product_id")
    val orderId: Column<Long?> = long("order_id").nullable()
    val period: Column<String> = varchar("period", 16)
    val startedAt: Column<Instant> = timestamp("started_at").defaultExpression(NowExpression)
    val expiresAt: Column<Instant> = timestamp("expires_at")
    val cancelledAt: Column<Instant?> = timestamp("cancelled_at").nullable()
    val cancelledByUserId: Column<Long?> = long("cancelled_by_user_id").nullable()
    val status: Column<String> = varchar("status", 16).default("ACTIVE")
    val autoRenew: Column<Boolean> = bool("auto_renew").default(false)
    val notifiedExpiringAt: Column<Instant?> = timestamp("notified_expiring_at").nullable()
    val notifiedExpiredAt: Column<Instant?> = timestamp("notified_expired_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

data class Subscription(
    val id: Long,
    val userId: Long,
    val productId: Long,
    val orderId: Long?,
    val period: SubscriptionPeriod,
    val startedAt: Instant,
    val expiresAt: Instant,
    val cancelledAt: Instant?,
    val cancelledByUserId: Long?,
    val status: SubscriptionStatus,
    val autoRenew: Boolean,
    val notifiedExpiringAt: Instant?,
    val notifiedExpiredAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isActive: Boolean get() = status == SubscriptionStatus.ACTIVE && expiresAt.isAfter(Instant.now())
    val isExpired: Boolean get() = expiresAt.isBefore(Instant.now()) || status == SubscriptionStatus.EXPIRED

    companion object {
        fun fromRow(row: ResultRow): Subscription = Subscription(
            id = row[BaseSubscriptionsTable.id],
            userId = row[BaseSubscriptionsTable.userId],
            productId = row[BaseSubscriptionsTable.productId],
            orderId = row[BaseSubscriptionsTable.orderId],
            period = SubscriptionPeriod.parse(row[BaseSubscriptionsTable.period]),
            startedAt = row[BaseSubscriptionsTable.startedAt],
            expiresAt = row[BaseSubscriptionsTable.expiresAt],
            cancelledAt = row[BaseSubscriptionsTable.cancelledAt],
            cancelledByUserId = row[BaseSubscriptionsTable.cancelledByUserId],
            status = SubscriptionStatus.parse(row[BaseSubscriptionsTable.status]),
            autoRenew = row[BaseSubscriptionsTable.autoRenew],
            notifiedExpiringAt = row[BaseSubscriptionsTable.notifiedExpiringAt],
            notifiedExpiredAt = row[BaseSubscriptionsTable.notifiedExpiredAt],
            createdAt = row[BaseSubscriptionsTable.createdAt],
            updatedAt = row[BaseSubscriptionsTable.updatedAt],
        )
    }
}
