package su.spyme.marketplace.core.ratelimit

import java.time.Duration

/**
 * Pre-canned rate limit profiles for common External API patterns.
 *
 * Host applies через `apiKeysScopeRateLimit(profile)` middleware (host wires
 * Ktor route plugin since lib не depends on ktor-server-core directly here).
 */
object RateLimits {

    /**
     * 1000 requests per minute. Sane default для user-scoped API keys.
     */
    val USER_API_DEFAULT = Profile(permits = 1000, window = Duration.ofMinutes(1))

    /**
     * Vendor-scoped writes: more burst tolerance (sync price/stock dumps).
     */
    val VENDOR_API_BURST = Profile(permits = 5000, window = Duration.ofMinutes(1))

    /**
     * Webhook delivery callbacks — outbound from this server, used когда we
     * throttle our own webhook fan-out per-endpoint.
     */
    val WEBHOOK_OUTBOUND = Profile(permits = 100, window = Duration.ofSeconds(10))

    /**
     * Public unauthenticated reads — strict.
     */
    val PUBLIC_READ_STRICT = Profile(permits = 60, window = Duration.ofMinutes(1))

    data class Profile(val permits: Int, val window: Duration)
}
