package su.spyme.marketplace.core.ratelimit

import com.github.benmanes.caffeine.cache.Caffeine
import java.time.Duration
import java.time.Instant
import java.util.ArrayDeque
import java.util.Deque
import java.util.concurrent.TimeUnit

/**
 * In-memory sliding-window rate limit store. Каждый key gets [Deque] of
 * Instant timestamps; stale ones evicted on each [tryAcquire].
 *
 * Caffeine cache eviction: per-key bucket auto-removed after 1 hour of
 * inactivity (covers slowest sliding-window edge case).
 *
 * Concurrency: per-bucket lock via [synchronized] on the Deque. No global
 * lock — separate keys progress concurrently. Acceptable for tens of thousands
 * of distinct keys at moderate QPS.
 *
 * Caveats:
 *   - Single-instance only. For multi-instance, host swaps in Redis-backed
 *     impl via ConflictRegistry.
 *   - Memory: O(permits) per active key. Bounded by Caffeine maxSize (default
 *     100k keys).
 */
class CaffeineRateLimitStore(
    maxKeys: Long = 100_000L,
) : RateLimitStore {

    private val buckets = Caffeine.newBuilder()
        .maximumSize(maxKeys)
        .expireAfterAccess(1, TimeUnit.HOURS)
        .build<String, Deque<Instant>>()

    override fun tryAcquire(
        key: String, permits: Int, window: Duration, now: Instant,
    ): RateLimitStore.Decision {
        require(permits > 0) { "permits must be > 0" }
        require(!window.isZero && !window.isNegative) { "window must be positive" }
        val bucket = buckets.get(key) { ArrayDeque(permits + 1) }!!
        synchronized(bucket) {
            val cutoff = now.minus(window)
            while (bucket.isNotEmpty() && bucket.peekFirst()!!.isBefore(cutoff)) {
                bucket.pollFirst()
            }
            if (bucket.size < permits) {
                bucket.addLast(now)
                val remaining = permits - bucket.size
                val resetAt = bucket.peekFirst()!!.plus(window)
                return RateLimitStore.Decision(allowed = true, remaining = remaining, resetAt = resetAt)
            } else {
                // Earliest stamp's window-end = когда первый слот освободится.
                val resetAt = bucket.peekFirst()!!.plus(window)
                return RateLimitStore.Decision(allowed = false, remaining = 0, resetAt = resetAt)
            }
        }
    }

    override fun reset(key: String) {
        buckets.invalidate(key)
    }

    override fun cleanup(now: Instant) {
        buckets.cleanUp()
    }
}
