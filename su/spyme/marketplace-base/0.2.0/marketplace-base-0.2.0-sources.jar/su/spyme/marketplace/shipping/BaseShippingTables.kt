package su.spyme.marketplace.shipping

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Shipping module: addresses + carriers + shipments + shipment_items.
 *
 * Status alphabet matches V032 CHECK.
 */
enum class ShipmentStatus {
    PENDING, LABEL_CREATED, PICKED_UP, IN_TRANSIT, OUT_FOR_DELIVERY,
    DELIVERED, RETURNED, LOST;

    companion object {
        fun parse(value: String): ShipmentStatus =
            entries.firstOrNull { it.name == value }
                ?: throw IllegalArgumentException("Unknown ShipmentStatus: '$value'")
    }
}

object BaseShippingAddressesTable : Table("shipping_addresses") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val label: Column<String?> = text("label").nullable()
    val recipientName: Column<String> = text("recipient_name")
    val phone: Column<String?> = varchar("phone", 32).nullable()
    val country: Column<String> = varchar("country", 2)
    val city: Column<String> = text("city")
    val region: Column<String?> = text("region").nullable()
    val postalCode: Column<String?> = varchar("postal_code", 20).nullable()
    val street: Column<String> = text("street")
    val building: Column<String?> = text("building").nullable()
    val apartment: Column<String?> = text("apartment").nullable()
    val notes: Column<String?> = text("notes").nullable()
    val isDefault: Column<Boolean> = bool("is_default").default(false)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseCarriersTable : Table("carriers") {
    val id: Column<Long> = long("id").autoIncrement()
    val code: Column<String> = varchar("code", 64).uniqueIndex()
    val name: Column<String> = text("name")
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseShipmentsTable : Table("shipments") {
    val id: Column<Long> = long("id").autoIncrement()
    val orderId: Column<Long> = long("order_id")
    val carrierId: Column<Long?> = long("carrier_id").nullable()
    val addressId: Column<Long?> = long("address_id").nullable()
    val trackingNumber: Column<String?> = text("tracking_number").nullable()
    val status: Column<String> = varchar("status", 32).default("PENDING")
    val shippedAt: Column<Instant?> = timestamp("shipped_at").nullable()
    val deliveredAt: Column<Instant?> = timestamp("delivered_at").nullable()
    val costAmount: Column<Long?> = long("cost_amount").nullable()
    val costCurrency: Column<String?> = varchar("cost_currency", 3).nullable()
    val notes: Column<String?> = text("notes").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseShipmentItemsTable : Table("shipment_items") {
    val shipmentId: Column<Long> = long("shipment_id")
    val orderItemId: Column<Long> = long("order_item_id")
    val quantity: Column<Int> = integer("quantity")

    override val primaryKey = PrimaryKey(shipmentId, orderItemId)
}

data class ShippingAddress(
    val id: Long, val userId: Long, val label: String?, val recipientName: String,
    val phone: String?, val country: String, val city: String, val region: String?,
    val postalCode: String?, val street: String, val building: String?, val apartment: String?,
    val notes: String?, val isDefault: Boolean,
    val createdAt: Instant, val updatedAt: Instant,
)

data class Carrier(
    val id: Long, val code: String, val name: String, val isActive: Boolean,
    val createdAt: Instant, val updatedAt: Instant,
)

data class Shipment(
    val id: Long, val orderId: Long, val carrierId: Long?, val addressId: Long?,
    val trackingNumber: String?, val status: ShipmentStatus,
    val shippedAt: Instant?, val deliveredAt: Instant?,
    val costAmount: Long?, val costCurrency: String?, val notes: String?,
    val createdAt: Instant, val updatedAt: Instant,
)
