package su.spyme.marketplace.apikeys

import su.spyme.marketplace.core.auth.KeyEncoding
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.HexFormat

/**
 * Plaintext API-key format and parsing helpers per V4 of the
 * architecture plan: `mp_<env>_<scope>_<entropy24>_<checksum8>`
 * Stripe-style.
 *
 * - `env` ∈ {live, test}.
 * - `scope` ∈ {user, vendor, admin}.
 * - `entropy24` is 24 chars of base62 (~144 bits of randomness).
 * - `checksum8` is HMAC-SHA256(format_secret, "<env>_<scope>_<entropy24>")
 *   truncated to 8 chars of base62.
 *
 * The checksum makes a malformed key cheap to reject without a DB
 * hit. The format secret stops external scripts from generating
 * valid-looking keys without it.
 */
object ApiKeyFormat {

    private const val PREFIX = "mp"
    private const val ENTROPY_LEN = 24
    private const val CHECKSUM_LEN = 8

    private val FORMAT_REGEX = Regex(
        "^${PREFIX}_(live|test)_(user|vendor|admin)_([A-Za-z0-9]{$ENTROPY_LEN})_([A-Za-z0-9]{$CHECKSUM_LEN})$"
    )

    /**
     * Generates a fresh plaintext key. Caller is responsible for the
     * SQL-side bookkeeping (hashing the entropy + storing the prefix).
     *
     * @param formatSecret The HMAC secret pinned in
     *        `MARKETPLACE_API_KEY_FORMAT_SECRET`. Never rotates.
     */
    fun generate(env: ApiKeyEnv, scope: ApiKeyScopeType, formatSecret: String): GeneratedKey {
        val entropy = KeyEncoding.randomBase62(ENTROPY_LEN)
        val body = "${env.code}_${scope.code}_$entropy"
        val checksum = checksumOf(body, formatSecret)
        val plain = "${PREFIX}_${body}_$checksum"
        return GeneratedKey(
            plaintext = plain,
            entropy = entropy,
            checksum = checksum,
            prefix = visiblePrefix(plain),
            env = env,
            scope = scope,
        )
    }

    /** Parses a plaintext key without DB lookup; null on malformed input. */
    fun parse(raw: String, formatSecret: String): ParsedKey? {
        val match = FORMAT_REGEX.matchEntire(raw) ?: return null
        val (envCode, scopeCode, entropy, checksum) = match.destructured
        val expected = checksumOf("${envCode}_${scopeCode}_$entropy", formatSecret)
        if (!KeyEncoding.constantTimeEquals(expected, checksum)) return null
        return ParsedKey(
            env = ApiKeyEnv.parse(envCode),
            scope = ApiKeyScopeType.parse(scopeCode),
            entropy = entropy,
            checksum = checksum,
            plaintext = raw,
        )
    }

    /**
     * Computes the SQL-stored hash from the entropy and a per-key salt.
     * SHA-256 is fine here — the entropy already has 144 bits of
     * randomness, so brute-force is infeasible regardless of bcrypt-
     * style work factors. Keeping it cheap matters: every external API
     * request hashes the key.
     */
    fun keyHash(entropy: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        md.update(entropy.toByteArray(Charsets.UTF_8))
        return HexFormat.of().formatHex(md.digest())
    }

    /** Random 16-byte salt used in [keyHash]. */
    fun randomSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    /**
     * Visible portion shown in admin UI:
     * `mp_live_user_aBcD12***IjKl_********` — env+scope kept, first
     * 6 + last 4 of entropy, asterisks for the rest, checksum masked.
     */
    fun visiblePrefix(plaintext: String): String {
        val match = FORMAT_REGEX.matchEntire(plaintext) ?: return plaintext.take(16)
        val (envCode, scopeCode, entropy, _) = match.destructured
        val head = entropy.take(6)
        val tail = entropy.takeLast(4)
        return "${PREFIX}_${envCode}_${scopeCode}_${head}***${tail}_********"
    }

    /** Masks a key suitable for log output. */
    fun maskForLogging(plaintext: String): String = visiblePrefix(plaintext)

    private fun checksumOf(body: String, formatSecret: String): String =
        KeyEncoding.checksum(body, formatSecret, CHECKSUM_LEN)

    data class GeneratedKey(
        val plaintext: String,
        val entropy: String,
        val checksum: String,
        val prefix: String,
        val env: ApiKeyEnv,
        val scope: ApiKeyScopeType,
    )

    data class ParsedKey(
        val env: ApiKeyEnv,
        val scope: ApiKeyScopeType,
        val entropy: String,
        val checksum: String,
        val plaintext: String,
    )
}

enum class ApiKeyEnv(val code: String) {
    LIVE("live"),
    TEST("test");

    companion object {
        fun parse(code: String): ApiKeyEnv = entries.firstOrNull { it.code == code }
            ?: throw IllegalArgumentException("Unknown ApiKeyEnv: '$code'")
    }
}

enum class ApiKeyScopeType(val code: String) {
    USER("user"),
    VENDOR("vendor"),
    ADMIN("admin");

    companion object {
        fun parse(code: String): ApiKeyScopeType = entries.firstOrNull { it.code == code }
            ?: throw IllegalArgumentException("Unknown ApiKeyScopeType: '$code'")
    }
}
