package su.spyme.marketplace.core.auth

import java.math.BigInteger
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Shared primitives for Stripe-style plaintext key formats
 * (`ApiKeyFormat`, the licensing module's `LicenseKeyFormat`): base62
 * entropy, a truncated HMAC checksum, and constant-time comparison.
 */
object KeyEncoding {

    private val BASE62_ALPHABET: CharArray =
        ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789").toCharArray()
    private val BASE = BigInteger.valueOf(62)
    private val rng = SecureRandom()

    /** [length] base62 chars from a CSPRNG (~5.95 bits each). */
    fun randomBase62(length: Int): String =
        String(CharArray(length) { BASE62_ALPHABET[rng.nextInt(BASE62_ALPHABET.size)] })

    /** Big-endian unsigned base62 encoding of [bytes]. */
    fun base62Encode(bytes: ByteArray): String {
        var n = BigInteger(1, bytes)
        if (n.signum() == 0) return BASE62_ALPHABET[0].toString()
        val sb = StringBuilder()
        while (n.signum() > 0) {
            val (q, r) = n.divideAndRemainder(BASE)
            sb.append(BASE62_ALPHABET[r.toInt()])
            n = q
        }
        return sb.reverse().toString()
    }

    /** Raw HMAC-SHA256 of [message] under [secret] (both UTF-8). */
    fun hmacSha256(secret: String, message: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(message.toByteArray(Charsets.UTF_8))
    }

    /** HMAC-SHA256([secret], [body]) as base62, truncated to [length] chars. */
    fun checksum(body: String, secret: String, length: Int): String =
        base62Encode(hmacSha256(secret, body)).take(length)

    /** Constant-time string equality so verification doesn't leak via timing. */
    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
}
