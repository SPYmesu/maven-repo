package su.spyme.marketplace.core.database

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Expression
import org.jetbrains.exposed.sql.QueryBuilder
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.VarCharColumnType
import java.time.Instant

/**
 * `CITEXT NOT NULL` column. CITEXT extension is enabled in V001. Binds
 * parameters as a `PGobject` with type=citext so PostgreSQL keeps the
 * case-insensitive collation on both sides of the comparison; if we
 * sent plain VARCHAR the resolver falls back to text and CITEXT loses
 * its meaning.
 */
fun Table.citext(name: String): Column<String> =
    registerColumn(name, CitextColumnType())

private class CitextColumnType : org.jetbrains.exposed.sql.ColumnType<String>() {
    override fun sqlType(): String = "CITEXT"

    override fun valueFromDB(value: Any): String = value.toString()

    override fun notNullValueToDB(value: String): Any =
        org.postgresql.util.PGobject().apply {
            type = "citext"
            this.value = value
        }

    override fun setParameter(
        stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi,
        index: Int,
        value: Any?,
    ) {
        if (value == null) {
            stmt.setNull(index, this)
            return
        }
        val obj = when (value) {
            is org.postgresql.util.PGobject -> value
            else -> org.postgresql.util.PGobject().apply {
                type = "citext"
                this.value = value.toString()
            }
        }
        stmt[index] = obj
    }
}

/**
 * `VARCHAR(elementSize)[] NOT NULL DEFAULT ARRAY[]::VARCHAR[]` column
 * (the DDL lives in the migrations). Kotlin side is List<String>; a thin
 * alias over Exposed's built-in `array()` column, so `anyFrom(column)`
 * and friends work on it.
 */
fun Table.stringArray(name: String, elementSize: Int): Column<List<String>> =
    array(name, VarCharColumnType(elementSize))

/**
 * `INET NOT NULL` column on the SQL side, String on Kotlin side. Stored
 * as e.g. "192.168.0.1" or "2001:db8::1" — the driver converts to/from
 * the PG INET wire format. Use `null` via `.nullable()` extension.
 */
fun Table.inet(name: String): Column<String> =
    registerColumn(name, InetColumnType())

private class InetColumnType : org.jetbrains.exposed.sql.ColumnType<String>() {
    override fun sqlType(): String = "INET"

    override fun valueFromDB(value: Any): String = value.toString()

    override fun notNullValueToDB(value: String): Any = value

    override fun setParameter(stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi, index: Int, value: Any?) {
        if (value == null) {
            stmt.setNull(index, this)
            return
        }
        val obj = org.postgresql.util.PGobject().apply {
            type = "inet"
            this.value = value.toString()
        }
        stmt[index] = obj
    }
}

/**
 * `NOW()` expression for `defaultExpression()` on TIMESTAMP columns.
 */
object NowExpression : Expression<Instant>() {
    override fun toQueryBuilder(queryBuilder: QueryBuilder) {
        queryBuilder.append("NOW()")
    }
}
