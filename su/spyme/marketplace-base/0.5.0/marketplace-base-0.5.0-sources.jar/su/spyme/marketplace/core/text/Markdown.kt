package su.spyme.marketplace.core.text

import com.vladsch.flexmark.ext.autolink.AutolinkExtension
import com.vladsch.flexmark.ext.gfm.strikethrough.StrikethroughExtension
import com.vladsch.flexmark.ext.gfm.tasklist.TaskListExtension
import com.vladsch.flexmark.ext.tables.TablesExtension
import com.vladsch.flexmark.html.HtmlRenderer
import com.vladsch.flexmark.parser.Parser
import com.vladsch.flexmark.util.data.MutableDataSet
import org.jsoup.Jsoup
import org.jsoup.safety.Safelist

/**
 * Markdown → safe HTML for user-authored content (product descriptions,
 * changelogs). GFM-ish: tables, autolinks, ~~strikethrough~~, task lists;
 * a single newline renders as `<br />`.
 *
 * Output of [render] is always passed through [Jsoup.clean] with
 * [defaultSafelist] — scripts, event handlers and `javascript:` URLs are
 * stripped, so it may be inserted into a page as raw HTML.
 *
 * Hosts with their own syntax (e.g. callout blocks) pre/post-process around
 * [toHtml] and sanitize with an extended [defaultSafelist].
 *
 * Thread-safe: the parser and renderer are immutable after construction.
 */
object Markdown {

    private val options = MutableDataSet().apply {
        set(
            Parser.EXTENSIONS, listOf(
                TablesExtension.create(),
                AutolinkExtension.create(),
                StrikethroughExtension.create(),
                TaskListExtension.create(),
            )
        )
        set(HtmlRenderer.SOFT_BREAK, "<br />\n")
    }

    private val parser: Parser = Parser.builder(options).build()
    private val renderer: HtmlRenderer = HtmlRenderer.builder(options).build()

    /** Markdown → sanitized HTML; empty string for null/empty input. */
    fun render(source: String?): String =
        if (source.isNullOrEmpty()) "" else sanitize(toHtml(source))

    /** Markdown → raw, UNSANITIZED HTML. Always [sanitize] before output. */
    fun toHtml(source: String): String = renderer.render(parser.parse(source))

    /** Cleans [html] against [safelist] (defaults to [defaultSafelist]). */
    fun sanitize(html: String, safelist: Safelist = defaultSafelist()): String =
        Jsoup.clean(html, "", safelist)

    /**
     * A fresh, mutable safelist covering everything [toHtml] emits:
     * `Safelist.relaxed()` + strikethrough, task-list checkboxes, link
     * rel/target, lazy images; URL schemes http/https/mailto (links) and
     * http/https/data (images). Relative links are kept.
     */
    fun defaultSafelist(): Safelist = Safelist.relaxed()
        .addTags("del", "input")
        .addAttributes("a", "rel", "target", "href")
        .addAttributes("img", "loading")
        .addAttributes("input", "type", "checked", "disabled")
        .addAttributes("li", "class")
        .addProtocols("a", "href", "http", "https", "mailto")
        .addProtocols("img", "src", "http", "https", "data")
        .preserveRelativeLinks(true)
}
