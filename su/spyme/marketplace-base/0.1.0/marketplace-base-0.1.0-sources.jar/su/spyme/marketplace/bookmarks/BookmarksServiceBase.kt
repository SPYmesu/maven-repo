package su.spyme.marketplace.bookmarks

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseBookmarksTable : Table("bookmarks") {
    val userId: Column<Long> = long("user_id")
    val productId: Column<Long> = long("product_id")
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(userId, productId)
}

/** Many-to-many link between users and saved products. */
data class Bookmark(
    val userId: Long,
    val productId: Long,
    val createdAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): Bookmark = Bookmark(
            userId = row[BaseBookmarksTable.userId],
            productId = row[BaseBookmarksTable.productId],
            createdAt = row[BaseBookmarksTable.createdAt],
        )
    }
}

/**
 * Bookmark CRUD. Idempotent operations — adding the same bookmark
 * twice is a no-op; removing a non-existent bookmark returns false
 * without throwing.
 */
open class BookmarksServiceBase(protected val mainDb: Database) {

    /** Adds the bookmark; returns true if a new row was created. */
    open fun add(userId: Long, productId: Long): Boolean = transaction(mainDb) {
        // upsert is the simplest way to honor the composite-PK idempotency
        // — Exposed's primary-key-driven upsert maps cleanly to ON CONFLICT.
        val countBefore = BaseBookmarksTable.selectAll()
            .where { (BaseBookmarksTable.userId eq userId) and (BaseBookmarksTable.productId eq productId) }
            .count()
        BaseBookmarksTable.upsert {
            it[BaseBookmarksTable.userId] = userId
            it[BaseBookmarksTable.productId] = productId
        }
        countBefore == 0L
    }

    /** Removes the bookmark; returns true if a row was actually deleted. */
    open fun remove(userId: Long, productId: Long): Boolean = transaction(mainDb) {
        BaseBookmarksTable.deleteWhere {
            (BaseBookmarksTable.userId eq userId) and (BaseBookmarksTable.productId eq productId)
        } > 0
    }

    /** Convenience flip: adds when absent, removes when present. */
    open fun toggle(userId: Long, productId: Long): Boolean {
        if (add(userId, productId)) return true
        remove(userId, productId)
        return false
    }

    open fun isBookmarked(userId: Long, productId: Long): Boolean = transaction(mainDb) {
        BaseBookmarksTable.selectAll()
            .where { (BaseBookmarksTable.userId eq userId) and (BaseBookmarksTable.productId eq productId) }
            .count() > 0
    }

    open fun listForUser(userId: Long): List<Bookmark> = transaction(mainDb) {
        BaseBookmarksTable.selectAll()
            .where { BaseBookmarksTable.userId eq userId }
            .orderBy(BaseBookmarksTable.createdAt to SortOrder.DESC)
            .map(Bookmark::fromRow)
    }

    open fun countForProduct(productId: Long): Long = transaction(mainDb) {
        BaseBookmarksTable.selectAll()
            .where { BaseBookmarksTable.productId eq productId }
            .count()
    }
}
