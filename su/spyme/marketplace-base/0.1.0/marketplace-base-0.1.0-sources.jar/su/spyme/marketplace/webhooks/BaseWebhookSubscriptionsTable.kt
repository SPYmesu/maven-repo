package su.spyme.marketplace.webhooks

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.database.stringArray
import java.time.Instant
import java.util.UUID

object BaseWebhookSubscriptionsTable : Table("webhook_subscriptions") {
    val id: Column<UUID> = uuid("id")
    val name: Column<String> = varchar("name", 128)
    val targetUrl: Column<String> = varchar("target_url", 2048)
    val eventTypes: Column<List<String>> = stringArray("event_types", 128)
    val secretCurrent: Column<String> = varchar("secret_current", 128)
    val secretPrevious: Column<String?> = varchar("secret_previous", 128).nullable()
    val secretRotatedAt: Column<Instant?> = timestamp("secret_rotated_at").nullable()
    val maxConcurrentDeliveries: Column<Short> = short("max_concurrent_deliveries").default(5)
    val maxPerMinute: Column<Int> = integer("max_per_minute").default(600)
    val coalescingWindowSeconds: Column<Int> = integer("coalescing_window_seconds").default(0)
    val filters: Column<JsonElement?> = jsonb("filters", Json, JsonElement.serializer()).nullable()
    val ownerUserId: Column<Long?> = long("owner_user_id").nullable()
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Outbound webhook subscription. One row per consumer endpoint.
 *
 * @property eventTypes Concrete event codes from
 *           [WebhookEventRegistry], or `["*"]` to opt into every
 *           event. Service validates non-`*` codes against the
 *           registry on write.
 * @property secretCurrent Current HMAC-SHA256 signing secret.
 * @property secretPrevious Previous secret while rotation grace
 *           window is open (Б5: 7 days). Null outside rotation.
 * @property coalescingWindowSeconds 0 disables coalescing; > 0
 *           opts the subscriber into bulk-payload deliveries (per В9).
 */
data class WebhookSubscription(
    val id: UUID,
    val name: String,
    val targetUrl: String,
    val eventTypes: List<String>,
    val secretCurrent: String,
    val secretPrevious: String?,
    val secretRotatedAt: Instant?,
    val maxConcurrentDeliveries: Int,
    val maxPerMinute: Int,
    val coalescingWindowSeconds: Int,
    val filters: JsonElement?,
    val ownerUserId: Long?,
    val isActive: Boolean,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    /** True if this subscription wants [eventCode]. */
    fun matches(eventCode: String): Boolean =
        isActive && (eventTypes.contains("*") || eventTypes.contains(eventCode))

    /** True iff [secretPrevious] is still inside the rotation grace window. */
    fun isPreviousSecretValid(graceSeconds: Long, now: Instant = Instant.now()): Boolean {
        val rotated = secretRotatedAt ?: return false
        return secretPrevious != null && now.epochSecond - rotated.epochSecond < graceSeconds
    }

    companion object {
        fun fromRow(row: ResultRow): WebhookSubscription = WebhookSubscription(
            id = row[BaseWebhookSubscriptionsTable.id],
            name = row[BaseWebhookSubscriptionsTable.name],
            targetUrl = row[BaseWebhookSubscriptionsTable.targetUrl],
            eventTypes = row[BaseWebhookSubscriptionsTable.eventTypes],
            secretCurrent = row[BaseWebhookSubscriptionsTable.secretCurrent],
            secretPrevious = row[BaseWebhookSubscriptionsTable.secretPrevious],
            secretRotatedAt = row[BaseWebhookSubscriptionsTable.secretRotatedAt],
            maxConcurrentDeliveries = row[BaseWebhookSubscriptionsTable.maxConcurrentDeliveries].toInt(),
            maxPerMinute = row[BaseWebhookSubscriptionsTable.maxPerMinute],
            coalescingWindowSeconds = row[BaseWebhookSubscriptionsTable.coalescingWindowSeconds],
            filters = row[BaseWebhookSubscriptionsTable.filters],
            ownerUserId = row[BaseWebhookSubscriptionsTable.ownerUserId],
            isActive = row[BaseWebhookSubscriptionsTable.isActive],
            createdAt = row[BaseWebhookSubscriptionsTable.createdAt],
            updatedAt = row[BaseWebhookSubscriptionsTable.updatedAt],
        )
    }
}
