package su.spyme.marketplace.i18n.yandex

import su.spyme.marketplace.core.i18n.Locale
import su.spyme.marketplace.core.i18n.MachineTranslator
import su.spyme.marketplace.core.i18n.TranslationException

/**
 * Stub for Yandex Cloud Translate API integration.
 *
 * Wire this in production hosts by extending the class and overriding
 * [translate] / [translateBatch] with a real HTTP call. The base class
 * exists so the host can register a typed instance against
 * [su.spyme.marketplace.core.i18n.MachineTranslatorRegistry] without
 * inventing its own translator interface.
 *
 * ## Endpoint
 *  POST `https://translate.api.cloud.yandex.net/translate/v2/translate`
 *
 * ## Auth
 *  `Authorization: Api-Key <apiKey>` (preferred) or `Bearer <iamToken>`.
 *  IAM tokens expire every ~12h — hosts should pick one or the other,
 *  not both.
 *
 * ## Request body (JSON)
 *  ```
 *  {
 *    "folderId": "<folder-id>",       // required for OAuth tokens
 *    "sourceLanguageCode": "en",       // optional → auto-detect
 *    "targetLanguageCode": "ru",
 *    "format": "PLAIN_TEXT",           // or HTML
 *    "texts": ["..."]
 *  }
 *  ```
 *
 * ## Response
 *  ```
 *  { "translations": [{ "text": "..." , "detectedLanguageCode": "en" }] }
 *  ```
 *
 * ## Quota
 *  Yandex Cloud bills per 1M characters per month. Free tier ≈ 1M /mo
 *  for new accounts. Surface quota errors as
 *  [TranslationException.QuotaExceeded].
 *
 * @property apiKey Yandex Cloud API key. Pass via env var
 *           `MARKETPLACE_YANDEX_TRANSLATE_KEY` and decode at host
 *           bootstrap.
 * @property folderId The Yandex Cloud folder ID owning the API key
 *           (required for IAM auth, optional for API-Key auth).
 * @property endpointUrl Override only for staging environments; the
 *           default points at the production endpoint.
 */
open class YandexMachineTranslator(
    protected val apiKey: String,
    protected val folderId: String? = null,
    protected val endpointUrl: String = "https://translate.api.cloud.yandex.net/translate/v2/translate",
) : MachineTranslator {

    override val providerCode: String = PROVIDER_CODE

    override fun translate(text: String, from: Locale?, to: Locale): String {
        throw TranslationException.Unauthorized(
            "YandexMachineTranslator is a stub. Override translate() in the host with a real HTTP call. " +
                "See KDoc for endpoint contract.",
        )
    }

    companion object {
        const val PROVIDER_CODE = "yandex"
    }
}
