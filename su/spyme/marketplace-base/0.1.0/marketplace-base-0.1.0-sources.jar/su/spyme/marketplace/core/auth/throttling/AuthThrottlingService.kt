package su.spyme.marketplace.core.auth.throttling

import com.github.benmanes.caffeine.cache.Cache
import com.github.benmanes.caffeine.cache.Caffeine
import java.time.Duration
import java.time.Instant
import java.util.ArrayDeque

/**
 * In-memory throttling for credential verification (password, OTP,
 * forgot-password). Tracks failures per identity (e.g. "email:foo@bar")
 * over a sliding hour window; emits progressive delays and triggers a
 * temporary lock once the threshold is exceeded.
 *
 * Thread-safety: each [State] has its own monitor lock — fine because
 * contention per identity is naturally low.
 *
 * Hosting decision: in-memory only for now. Multi-instance deployments
 * lose accuracy — moving to Redis is a one-class swap when needed.
 */
class AuthThrottlingService(
    private val maxFailuresPerHour: Int = 10,
    private val lockDuration: Duration = Duration.ofMinutes(30),
    private val window: Duration = Duration.ofHours(1),
) {

    private val cache: Cache<String, State> = Caffeine.newBuilder()
        .expireAfterAccess(Duration.ofHours(2))
        .maximumSize(100_000)
        .build()

    fun recordFailure(identity: String, now: Instant = Instant.now()): FailureResult {
        val state = cache.get(identity) { State() }
        synchronized(state) {
            evictOld(state, now)
            state.failures.addLast(now)
            val count = state.failures.size
            if (count >= maxFailuresPerHour && state.lockedUntil?.isAfter(now) != true) {
                state.lockedUntil = now.plus(lockDuration)
            }
            return FailureResult(
                delayMs = progressiveDelayMs(count),
                lockedUntil = state.lockedUntil,
                attemptCount = count,
            )
        }
    }

    fun recordSuccess(identity: String) {
        cache.invalidate(identity)
    }

    fun isLocked(identity: String, now: Instant = Instant.now()): Boolean {
        val state = cache.getIfPresent(identity) ?: return false
        synchronized(state) {
            return state.lockedUntil?.isAfter(now) == true
        }
    }

    fun lockedUntil(identity: String): Instant? {
        val state = cache.getIfPresent(identity) ?: return null
        return synchronized(state) { state.lockedUntil }
    }

    /** Test/diagnostic hook — returns the current count after windowing. */
    fun failureCount(identity: String, now: Instant = Instant.now()): Int {
        val state = cache.getIfPresent(identity) ?: return 0
        synchronized(state) {
            evictOld(state, now)
            return state.failures.size
        }
    }

    private fun evictOld(state: State, now: Instant) {
        val cutoff = now.minus(window)
        while (state.failures.isNotEmpty() && state.failures.peekFirst().isBefore(cutoff)) {
            state.failures.pollFirst()
        }
    }

    /** 250ms → 500ms → 1s → 2s → 5s, then 5s steady. */
    private fun progressiveDelayMs(attemptCount: Int): Long = when (attemptCount) {
        1 -> 250
        2 -> 500
        3 -> 1_000
        4 -> 2_000
        else -> 5_000
    }

    data class FailureResult(
        val delayMs: Long,
        val lockedUntil: Instant?,
        val attemptCount: Int,
    ) {
        val isLocked: Boolean get() = lockedUntil != null
    }

    private class State {
        val failures: ArrayDeque<Instant> = ArrayDeque()
        var lockedUntil: Instant? = null
    }
}
