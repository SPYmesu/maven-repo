package su.spyme.marketplace.core

enum class MarketplaceKind {
    DIGITAL,
    PHYSICAL,
    MIXED,
}
