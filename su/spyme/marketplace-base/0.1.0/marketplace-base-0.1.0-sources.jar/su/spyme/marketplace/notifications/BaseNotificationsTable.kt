package su.spyme.marketplace.notifications

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/** SQL row status for an outbox notification. Mirrors V016 CHECK. */
enum class NotificationStatus {
    PENDING, SENT, FAILED;

    companion object {
        fun parse(value: String): NotificationStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown NotificationStatus: '$value'")
    }
}

object BaseNotificationsTable : Table("notifications") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long?> = long("user_id").nullable()
    val kind: Column<String> = varchar("kind", 64)
    val channel: Column<String> = varchar("channel", 32)
    val recipient: Column<String> = varchar("recipient", 255)
    val subject: Column<String?> = text("subject").nullable()
    val body: Column<String> = text("body")
    val payload: Column<JsonElement?> = jsonb("payload", Json, JsonElement.serializer()).nullable()
    val locale: Column<String> = varchar("locale", 8).default("ru")
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val attempts: Column<Short> = short("attempts").default(0)
    val lastError: Column<String?> = text("last_error").nullable()
    val dedupKey: Column<String?> = varchar("dedup_key", 128).nullable()
    val enqueuedAt: Column<Instant> = timestamp("enqueued_at").defaultExpression(NowExpression)
    val sentAt: Column<Instant?> = timestamp("sent_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Persisted notification. The producer-supplied [dedupKey] is what
 * the SQL UNIQUE index keys on for idempotent enqueue.
 */
data class Notification(
    val id: Long,
    val userId: Long?,
    val kind: String,
    val channel: String,
    val recipient: String,
    val subject: String?,
    val body: String,
    val payload: JsonElement?,
    val locale: String,
    val status: NotificationStatus,
    val attempts: Int,
    val lastError: String?,
    val dedupKey: String?,
    val enqueuedAt: Instant,
    val sentAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): Notification = Notification(
            id = row[BaseNotificationsTable.id],
            userId = row[BaseNotificationsTable.userId],
            kind = row[BaseNotificationsTable.kind],
            channel = row[BaseNotificationsTable.channel],
            recipient = row[BaseNotificationsTable.recipient],
            subject = row[BaseNotificationsTable.subject],
            body = row[BaseNotificationsTable.body],
            payload = row[BaseNotificationsTable.payload],
            locale = row[BaseNotificationsTable.locale],
            status = NotificationStatus.parse(row[BaseNotificationsTable.status]),
            attempts = row[BaseNotificationsTable.attempts].toInt(),
            lastError = row[BaseNotificationsTable.lastError],
            dedupKey = row[BaseNotificationsTable.dedupKey],
            enqueuedAt = row[BaseNotificationsTable.enqueuedAt],
            sentAt = row[BaseNotificationsTable.sentAt],
            createdAt = row[BaseNotificationsTable.createdAt],
            updatedAt = row[BaseNotificationsTable.updatedAt],
        )
    }
}
