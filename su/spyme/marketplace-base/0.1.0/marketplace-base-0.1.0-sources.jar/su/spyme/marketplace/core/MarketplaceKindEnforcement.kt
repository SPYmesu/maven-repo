package su.spyme.marketplace.core

object MarketplaceKindEnforcement {

    /**
     * Verifies every module supports the host's marketplace kind. Returns
     * the input list unchanged on success; throws on the first violation
     * with all offenders aggregated for a single readable error.
     */
    fun validate(modules: List<MarketplaceModule>, kind: MarketplaceKind): List<MarketplaceModule> {
        val violations = modules.filterNot { kind in it.supportedKinds }
        if (violations.isNotEmpty()) {
            throw IncompatibleMarketplaceKindException(kind, violations)
        }
        return modules
    }
}

class IncompatibleMarketplaceKindException(
    val kind: MarketplaceKind,
    val violations: List<MarketplaceModule>,
) : RuntimeException(
    buildString {
        append("Marketplace kind=$kind is incompatible with ${violations.size} active module(s): ")
        violations.joinTo(this, separator = ", ") { m ->
            "${m.name} (supports ${m.supportedKinds.joinToString("/")})"
        }
    },
)
