package su.spyme.marketplace.apikeys

import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant
import java.util.UUID

/**
 * Outcome of [ApiKeysService.create] — caller persists the row id and
 * shows [plaintext] to the user **once**. After that the SQL row only
 * carries the hashed verifier.
 */
data class CreatedApiKey(
    val key: ApiKey,
    val plaintext: String,
)

/**
 * Outcome of [ApiKeysService.verify] — fast-rejects on every layer
 * (format, checksum, hash mismatch, revoked, expired) so the caller
 * can map each to a 401/403 with a useful reason.
 */
sealed class ApiKeyVerificationResult {
    data class Valid(val key: ApiKey) : ApiKeyVerificationResult()
    data object Malformed : ApiKeyVerificationResult()
    data object UnknownKey : ApiKeyVerificationResult()
    data object Revoked : ApiKeyVerificationResult()
    data object Expired : ApiKeyVerificationResult()
}

/**
 * SQL-side companion to [ApiKeyFormat]. Generates plaintext keys,
 * stores their hashed verifier, and answers verify() requests on the
 * external-API hot path.
 *
 * @param formatSecret Pinned in `MARKETPLACE_API_KEY_FORMAT_SECRET`
 *        env. Used to compute and validate the checksum embedded in
 *        every key. Never rotates.
 */
open class ApiKeysService(
    protected val mainDb: Database,
    protected val formatSecret: String,
) {

    init {
        require(formatSecret.length >= 32) {
            "formatSecret must be at least 32 chars; the API-key checksum HMAC needs ≥256 bits of key material"
        }
    }

    /**
     * Creates a fresh API key for a USER scope. The plaintext lives
     * inside [CreatedApiKey] — the caller shows it to the human once
     * and never persists it.
     */
    open fun createForUser(
        userId: Long,
        name: String,
        env: ApiKeyEnv = ApiKeyEnv.LIVE,
        rateLimitPerMinute: Int? = null,
        expiresAt: Instant? = null,
        createdByUserId: Long? = null,
        metadata: JsonElement? = null,
    ): CreatedApiKey = create(
        scopeType = ApiKeyScopeType.USER,
        scopeUserId = userId,
        scopeVendorId = null,
        env = env,
        name = name,
        rateLimitPerMinute = rateLimitPerMinute,
        expiresAt = expiresAt,
        createdByUserId = createdByUserId,
        metadata = metadata,
    )

    open fun createForVendor(
        vendorId: Long,
        name: String,
        env: ApiKeyEnv = ApiKeyEnv.LIVE,
        rateLimitPerMinute: Int? = null,
        isUnlimited: Boolean = false,
        expiresAt: Instant? = null,
        createdByUserId: Long? = null,
        metadata: JsonElement? = null,
    ): CreatedApiKey = create(
        scopeType = ApiKeyScopeType.VENDOR,
        scopeUserId = null,
        scopeVendorId = vendorId,
        env = env,
        name = name,
        rateLimitPerMinute = rateLimitPerMinute,
        isUnlimited = isUnlimited,
        expiresAt = expiresAt,
        createdByUserId = createdByUserId,
        metadata = metadata,
    )

    open fun createForAdmin(
        name: String,
        env: ApiKeyEnv = ApiKeyEnv.LIVE,
        isUnlimited: Boolean = false,
        rateLimitPerMinute: Int? = null,
        expiresAt: Instant? = null,
        createdByUserId: Long? = null,
        metadata: JsonElement? = null,
    ): CreatedApiKey = create(
        scopeType = ApiKeyScopeType.ADMIN,
        scopeUserId = null,
        scopeVendorId = null,
        env = env,
        name = name,
        rateLimitPerMinute = rateLimitPerMinute,
        isUnlimited = isUnlimited,
        expiresAt = expiresAt,
        createdByUserId = createdByUserId,
        metadata = metadata,
    )

    /**
     * Verifies a plaintext key. Walks the four reject layers in order
     * and returns a typed result.
     */
    open fun verify(plaintext: String, now: Instant = Instant.now()): ApiKeyVerificationResult {
        val parsed = ApiKeyFormat.parse(plaintext, formatSecret)
            ?: return ApiKeyVerificationResult.Malformed

        // Hash needs the per-key salt — look up by prefix's hashable region.
        // We can't index by entropy alone (hash uses salt); the simplest
        // option is to search all keys with the matching prefix and try
        // the hash. In practice only a single row matches.
        val candidates = transaction(mainDb) {
            BaseApiKeysTable.selectAll()
                .where {
                    (BaseApiKeysTable.env eq parsed.env.code) and
                        (BaseApiKeysTable.scopeType eq parsed.scope.code)
                }
                .map(ApiKey::fromRow)
                .filter { ApiKeyFormat.keyHash(parsed.entropy, it.keySalt) == it.keyHash }
        }
        val match = candidates.firstOrNull() ?: return ApiKeyVerificationResult.UnknownKey
        if (match.isRevoked) return ApiKeyVerificationResult.Revoked
        if (match.isExpired) return ApiKeyVerificationResult.Expired

        // Stamp last_used_at without invalidating any cache or holding a lock.
        transaction(mainDb) {
            BaseApiKeysTable.update({ BaseApiKeysTable.id eq match.id }) {
                it[BaseApiKeysTable.lastUsedAt] = now
            }
        }
        return ApiKeyVerificationResult.Valid(match)
    }

    open fun findById(id: UUID): ApiKey? = transaction(mainDb) {
        BaseApiKeysTable.selectAll()
            .where { BaseApiKeysTable.id eq id }
            .firstOrNull()
            ?.let(ApiKey::fromRow)
    }

    open fun listForUser(userId: Long): List<ApiKey> = transaction(mainDb) {
        BaseApiKeysTable.selectAll()
            .where { BaseApiKeysTable.scopeUserId eq userId }
            .map(ApiKey::fromRow)
    }

    open fun listForVendor(vendorId: Long): List<ApiKey> = transaction(mainDb) {
        BaseApiKeysTable.selectAll()
            .where { BaseApiKeysTable.scopeVendorId eq vendorId }
            .map(ApiKey::fromRow)
    }

    /** Sets revoked_at and (optionally) the user id who pulled the trigger. */
    open fun revoke(id: UUID, byUserId: Long? = null, now: Instant = Instant.now()): Boolean =
        transaction(mainDb) {
            BaseApiKeysTable.update({
                (BaseApiKeysTable.id eq id) and BaseApiKeysTable.revokedAt.isNull()
            }) {
                it[BaseApiKeysTable.revokedAt] = now
                it[BaseApiKeysTable.revokedByUserId] = byUserId
            } > 0
        }

    private fun create(
        scopeType: ApiKeyScopeType,
        scopeUserId: Long?,
        scopeVendorId: Long?,
        env: ApiKeyEnv,
        name: String,
        rateLimitPerMinute: Int? = null,
        isUnlimited: Boolean = false,
        expiresAt: Instant? = null,
        createdByUserId: Long? = null,
        metadata: JsonElement? = null,
    ): CreatedApiKey {
        require(name.isNotBlank()) { "name must not be blank" }

        val generated = ApiKeyFormat.generate(env, scopeType, formatSecret)
        val salt = ApiKeyFormat.randomSalt()
        val hash = ApiKeyFormat.keyHash(generated.entropy, salt)
        val rowId = UUID.randomUUID()

        val key = transaction(mainDb) {
            BaseApiKeysTable.insert {
                it[BaseApiKeysTable.id] = rowId
                it[BaseApiKeysTable.name] = name
                it[BaseApiKeysTable.keyHash] = hash
                it[BaseApiKeysTable.keySalt] = salt
                it[BaseApiKeysTable.keyPrefix] = generated.prefix
                it[BaseApiKeysTable.env] = env.code
                it[BaseApiKeysTable.scopeType] = scopeType.code
                it[BaseApiKeysTable.scopeUserId] = scopeUserId
                it[BaseApiKeysTable.scopeVendorId] = scopeVendorId
                it[BaseApiKeysTable.rateLimitPerMinute] = rateLimitPerMinute
                it[BaseApiKeysTable.isUnlimited] = isUnlimited
                it[BaseApiKeysTable.expiresAt] = expiresAt
                it[BaseApiKeysTable.createdByUserId] = createdByUserId
                it[BaseApiKeysTable.metadata] = metadata
            }
            BaseApiKeysTable.selectAll()
                .where { BaseApiKeysTable.id eq rowId }
                .first()
                .let(ApiKey::fromRow)
        }
        return CreatedApiKey(key = key, plaintext = generated.plaintext)
    }
}
