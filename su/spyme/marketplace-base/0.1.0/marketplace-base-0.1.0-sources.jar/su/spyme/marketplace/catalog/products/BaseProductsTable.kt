package su.spyme.marketplace.catalog.products

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.catalog.categories.BaseCategoriesTable
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseProductsTable : Table("products") {
    val id: Column<Long> = long("id").autoIncrement()
    val vendorId: Column<Long?> = long("vendor_id").nullable()
    val categoryId: Column<Long> = long("category_id").references(BaseCategoriesTable.id)
    val slug: Column<String> = varchar("slug", 96)
    val productKind: Column<String> = varchar("product_kind", 16)
    val status: Column<String> = varchar("status", 16).default("DRAFT")
    val priceAmount: Column<Long> = long("price_amount").default(0)
    val priceCurrency: Column<String> = varchar("price_currency", 3).default("RUB")
    val maxTotalPurchases: Column<Int?> = integer("max_total_purchases").nullable()
    val maxPerUserPurchases: Column<Int?> = integer("max_per_user_purchases").nullable()
    val totalPurchaseCount: Column<Int> = integer("total_purchase_count").default(0)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)
    val publishedAt: Column<Instant?> = timestamp("published_at").nullable()
    val archivedAt: Column<Instant?> = timestamp("archived_at").nullable()

    override val primaryKey = PrimaryKey(id)
}
