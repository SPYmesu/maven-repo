package su.spyme.marketplace.core.bootstrap

import io.ktor.events.EventDefinition
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationStopping
import io.ktor.server.routing.routing
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.BaseConfig
import su.spyme.marketplace.core.MarketplaceBootstrapContext
import su.spyme.marketplace.core.MarketplaceKindEnforcement
import su.spyme.marketplace.core.MarketplaceModule
import su.spyme.marketplace.core.database.Databases
import su.spyme.marketplace.core.database.FlywayRunner

private val log = LoggerFactory.getLogger("MarketplaceBootstrap")

/**
 * Application entry point that wires marketplace-base into a Ktor app.
 *
 * Phases (per Б3 of the architectural plan):
 *   0. Validate — kind compatibility, dependency graph, duplicate names.
 *   1. Registration — open DB pools, run Flyway, call module.bootstrap().
 *   2. Plugins — install Ktor plugins driven by registries (extension hook).
 *   3. Routing — collect module.routes() into one routing block.
 *   4. Cron — call module.startCron() so jobs only start after routing.
 *
 * Pool shutdown is wired to ApplicationStopping so HikariCP can drain
 * connections before the JVM exits.
 */
fun Application.marketplaceModule(
    config: BaseConfig,
    modules: List<MarketplaceModule>,
    pluginsHook: (MarketplaceBootstrapContext) -> Unit = {},
): MarketplaceBootstrapContext {
    log.info(
        "Starting marketplace bootstrap (name='{}', kind={}, env={}, modules={})",
        config.marketplaceName,
        config.marketplaceKind,
        config.environment,
        modules.map { it.name },
    )

    // Phase 0 — validation runs before any side effect (no DB pool, no migrations).
    val ordered = ModuleDependencyGraph.topologicalOrder(modules)
    MarketplaceKindEnforcement.validate(ordered, config.marketplaceKind)

    // Database pools + Flyway migrations on main pool.
    val databases = Databases.open(config.database)
    monitor.subscribe(ApplicationStopping) {
        log.info("Application stopping — closing database pools")
        databases.close()
    }
    FlywayRunner(databases.mainSource, config.environment).migrate()

    val context = MarketplaceBootstrapContext(this, config)
    context.register(databases)

    // Phase 1 — Registration.
    log.info("Phase 1/4: Registration ({} module(s))", ordered.size)
    ordered.forEach { module ->
        log.debug("Bootstrap module: {}", module.name)
        module.bootstrap(context)
    }

    // Phase 2 — Plugins (host-provided hook; later stages add core plugins via modules).
    log.info("Phase 2/4: Plugins")
    pluginsHook(context)

    // Phase 3 — Routing.
    log.info("Phase 3/4: Routing")
    routing {
        ordered.forEach { module ->
            module.routes(this, context)
        }
    }

    // Phase 4 — Cron.
    log.info("Phase 4/4: Cron")
    ordered.forEach { module ->
        module.startCron(context)
    }

    log.info("Marketplace bootstrap complete")
    monitor.raise(MarketplaceReady, context)
    return context
}

/**
 * Raised after [marketplaceModule] finishes all four phases. Hosts can
 * subscribe via `application.monitor.subscribe(MarketplaceReady) { ctx -> ... }`
 * to defer their own initialization until the marketplace is fully wired.
 */
val MarketplaceReady: EventDefinition<MarketplaceBootstrapContext> =
    EventDefinition()
