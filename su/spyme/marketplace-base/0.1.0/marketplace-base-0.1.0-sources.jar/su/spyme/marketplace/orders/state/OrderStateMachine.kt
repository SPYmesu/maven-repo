package su.spyme.marketplace.orders.state

/**
 * One legal transition from [from] to [to]. The transition is only
 * allowed if the proposed actor is in [allowedActors].
 */
data class OrderTransition(
    val from: OrderStatus,
    val to: OrderStatus,
    val allowedActors: Set<TransitionActor>,
)

/**
 * Set of legal transitions for one order kind (physical, digital, …).
 *
 * Hosts pick one machine per [su.spyme.marketplace.core.MarketplaceKind]
 * + per-product-kind variation through [OrderStateMachineRegistry];
 * the [OrdersServiceBase] consults the active machine to validate
 * every status change.
 *
 * @property name Stable identifier surfaced in audit logs and admin
 *           UI ("physical", "digital", "digitalManualConfirm",
 *           "mixed", or a host-defined override).
 */
class OrderStateMachine(
    val name: String,
    val transitions: List<OrderTransition>,
) {
    private val byFrom: Map<OrderStatus, List<OrderTransition>> =
        transitions.groupBy { it.from }

    /** Pure check — does not throw. */
    fun canTransition(from: OrderStatus, to: OrderStatus, actor: TransitionActor): Boolean =
        byFrom[from].orEmpty().any { it.to == to && actor in it.allowedActors }

    /** Throws [IllegalOrderTransitionException] if the transition is not allowed. */
    fun validate(from: OrderStatus, to: OrderStatus, actor: TransitionActor) {
        val match = byFrom[from].orEmpty().firstOrNull { it.to == to }
            ?: throw IllegalOrderTransitionException(
                machine = name, from = from, to = to, actor = actor,
                why = "no $from → $to transition declared",
            )
        if (actor !in match.allowedActors) {
            throw IllegalOrderTransitionException(
                machine = name, from = from, to = to, actor = actor,
                why = "actor $actor is not allowed; allowed: ${match.allowedActors}",
            )
        }
    }

    /** Possible next statuses regardless of actor. Useful for the admin UI. */
    fun nextStates(from: OrderStatus): Set<OrderStatus> =
        byFrom[from].orEmpty().map { it.to }.toSet()

    fun allowedActors(from: OrderStatus, to: OrderStatus): Set<TransitionActor> =
        byFrom[from].orEmpty().firstOrNull { it.to == to }?.allowedActors ?: emptySet()
}

class IllegalOrderTransitionException(
    val machine: String,
    val from: OrderStatus,
    val to: OrderStatus,
    val actor: TransitionActor,
    val why: String,
) : RuntimeException("[$machine] $from → $to by $actor is forbidden: $why")
