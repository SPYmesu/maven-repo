package su.spyme.marketplace.webhooks

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * HMAC-SHA256 webhook signing per Б5 of the architecture plan.
 *
 * Header layout (Stripe-style):
 *   `X-Webhook-Signature: t=<unix_seconds>,v1=<hex>[,v1=<hex_old>]`
 *
 * - `t` is the unix timestamp the signer ran. Receiver rejects
 *   anything older than the tolerance window (5 min default).
 * - `v1` is HMAC-SHA256(secret, "<t>.<body>"); the second `v1` is
 *   present during the 7-day rotation grace window.
 *
 * Receiver verifies: parse t, check |now - t| <= tolerance,
 * recompute HMAC over "<t>.<received_body>", constant-time compare
 * against any of the supplied v1 values.
 */
object WebhookHmacSigner {

    fun signature(timestampSeconds: Long, body: String, secrets: List<String>): String {
        require(secrets.isNotEmpty()) { "at least one secret required" }
        val payload = "$timestampSeconds.$body"
        val parts = secrets.joinToString(",") { "v1=" + hmacHex(it, payload) }
        return "t=$timestampSeconds,$parts"
    }

    /** Convenience overload for the common one-secret case. */
    fun signature(timestampSeconds: Long, body: String, secret: String): String =
        signature(timestampSeconds, body, listOf(secret))

    /** Constant-time verification — accepts any of [validSecrets]. */
    fun verify(
        header: String,
        body: String,
        validSecrets: List<String>,
        toleranceSeconds: Long = 300,
        now: Long = System.currentTimeMillis() / 1000,
    ): Boolean {
        val (t, sigs) = parse(header) ?: return false
        if (kotlin.math.abs(now - t) > toleranceSeconds) return false
        val payload = "$t.$body"
        val expected = validSecrets.map { hmacHex(it, payload) }
        return sigs.any { sig -> expected.any { exp -> constantTimeEquals(sig, exp) } }
    }

    /** Parses `t=<ts>,v1=<hex>[,v1=<hex>]` into (timestamp, list of hex sigs). */
    fun parse(header: String): Pair<Long, List<String>>? {
        var t: Long? = null
        val sigs = mutableListOf<String>()
        for (part in header.split(",")) {
            val trimmed = part.trim()
            val eq = trimmed.indexOf('=')
            if (eq <= 0) return null
            val key = trimmed.substring(0, eq)
            val value = trimmed.substring(eq + 1)
            when (key) {
                "t" -> t = value.toLongOrNull() ?: return null
                "v1" -> sigs += value
            }
        }
        if (t == null || sigs.isEmpty()) return null
        return t to sigs
    }

    private fun hmacHex(secret: String, payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
