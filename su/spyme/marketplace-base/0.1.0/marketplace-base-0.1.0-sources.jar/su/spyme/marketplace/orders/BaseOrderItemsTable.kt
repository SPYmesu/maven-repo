package su.spyme.marketplace.orders

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseOrderItemsTable : Table("order_items") {
    val id: Column<Long> = long("id").autoIncrement()
    val orderId: Column<Long> = long("order_id").references(BaseOrdersTable.id)
    val productId: Column<Long> = long("product_id")
    val variantId: Column<Long?> = long("variant_id").nullable()
    val vendorId: Column<Long?> = long("vendor_id").nullable()
    val quantity: Column<Int> = integer("quantity")
    val unitPriceAmount: Column<Long> = long("unit_price_amount")
    val unitPriceCurrency: Column<String> = varchar("unit_price_currency", 3)
    val lineTotalAmount: Column<Long> = long("line_total_amount")
    val deliveredAt: Column<Instant?> = timestamp("delivered_at").nullable()
    val status: Column<String?> = varchar("status", 16).nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Per-line snapshot of stable presentation data (per В7) — kept in a
 * separate table from [BaseOrderItemsTable] so the operational row
 * stays small and the JSONB blob loads only when the UI asks for the
 * order detail page.
 */
object BaseOrderItemSnapshotsTable : Table("order_item_snapshots") {
    val orderItemId: Column<Long> = long("order_item_id").references(BaseOrderItemsTable.id)
    val snapshotMeta: Column<JsonElement> = jsonb("snapshot_meta", Json, JsonElement.serializer())
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(orderItemId)
}

/**
 * Single line on an [Order]. `delivered_at` flips on for digital lines
 * once the user downloads them; the OrdersService aggregates per-line
 * deliveries into the order-level transition to DELIVERED.
 */
data class OrderItem(
    val id: Long,
    val orderId: Long,
    val productId: Long,
    val variantId: Long?,
    val vendorId: Long?,
    val quantity: Int,
    val unitPrice: Money,
    val lineTotal: Money,
    val deliveredAt: Instant?,
    val status: String?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): OrderItem {
            val currency = row[BaseOrderItemsTable.unitPriceCurrency]
            return OrderItem(
                id = row[BaseOrderItemsTable.id],
                orderId = row[BaseOrderItemsTable.orderId],
                productId = row[BaseOrderItemsTable.productId],
                variantId = row[BaseOrderItemsTable.variantId],
                vendorId = row[BaseOrderItemsTable.vendorId],
                quantity = row[BaseOrderItemsTable.quantity],
                unitPrice = Money(row[BaseOrderItemsTable.unitPriceAmount], currency),
                lineTotal = Money(row[BaseOrderItemsTable.lineTotalAmount], currency),
                deliveredAt = row[BaseOrderItemsTable.deliveredAt],
                status = row[BaseOrderItemsTable.status],
                createdAt = row[BaseOrderItemsTable.createdAt],
                updatedAt = row[BaseOrderItemsTable.updatedAt],
            )
        }
    }
}

/** В7: snapshot at booking time, decoupled from the operational row. */
data class OrderItemSnapshot(
    val orderItemId: Long,
    val snapshotMeta: JsonElement,
    val createdAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): OrderItemSnapshot = OrderItemSnapshot(
            orderItemId = row[BaseOrderItemSnapshotsTable.orderItemId],
            snapshotMeta = row[BaseOrderItemSnapshotsTable.snapshotMeta],
            createdAt = row[BaseOrderItemSnapshotsTable.createdAt],
        )
    }
}
