package su.spyme.marketplace.payments

import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * CRUD around the payments table. Knows nothing about gateways
 * directly — that's [PaymentGateway]'s job; this service is the
 * SQL-layer companion that records every state transition the
 * gateway reports.
 */
open class PaymentsServiceBase(protected val mainDb: Database) {

    /**
     * Creates a payment row in INITIATED status. If a row with the
     * same (provider, idempotencyKey) already exists it is returned
     * unchanged — the partial unique index turns a duplicate POST
     * into a no-op so retried initiate calls never duplicate-charge.
     */
    open fun createInitiated(
        orderId: Long,
        provider: String,
        money: Money,
        idempotencyKey: String,
        gatewayMetadata: JsonElement? = null,
    ): Payment = transaction(mainDb) {
        val existing = BasePaymentsTable.selectAll()
            .where {
                (BasePaymentsTable.provider eq provider) and
                    (BasePaymentsTable.idempotencyKey eq idempotencyKey)
            }
            .firstOrNull()
        if (existing != null) return@transaction Payment.fromRow(existing)

        val newId = BasePaymentsTable.insert {
            it[BasePaymentsTable.orderId] = orderId
            it[BasePaymentsTable.provider] = provider
            it[BasePaymentsTable.amount] = money.amount
            it[BasePaymentsTable.currency] = money.currency
            it[BasePaymentsTable.idempotencyKey] = idempotencyKey
            it[BasePaymentsTable.gatewayMetadata] = gatewayMetadata
        }[BasePaymentsTable.id]
        loadById(newId)!!
    }

    /** Stamps the provider's id once we get it back from the gateway. */
    open fun setProviderPaymentId(id: Long, providerPaymentId: String) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.providerPaymentId] = providerPaymentId
            }
        }
    }

    open fun markAuthorized(id: Long, gatewayMetadata: JsonElement? = null, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.status] = PaymentStatus.AUTHORIZED.name
                it[BasePaymentsTable.authorizedAt] = now
                if (gatewayMetadata != null) it[BasePaymentsTable.gatewayMetadata] = gatewayMetadata
            }
        }
    }

    open fun markCaptured(id: Long, gatewayMetadata: JsonElement? = null, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.status] = PaymentStatus.CAPTURED.name
                it[BasePaymentsTable.capturedAt] = now
                if (gatewayMetadata != null) it[BasePaymentsTable.gatewayMetadata] = gatewayMetadata
            }
        }
    }

    open fun markFailed(id: Long, reason: String, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.status] = PaymentStatus.FAILED.name
                it[BasePaymentsTable.failedAt] = now
                it[BasePaymentsTable.failureReason] = reason
            }
        }
    }

    open fun markCancelled(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.status] = PaymentStatus.CANCELLED.name
                it[BasePaymentsTable.cancelledAt] = now
            }
        }
    }

    /**
     * Marks the payment fully refunded. Called by RefundsService once
     * matching refunds COMPLETE for the full amount; partial refunds
     * leave the payment status alone.
     */
    open fun markRefunded(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BasePaymentsTable.update({ BasePaymentsTable.id eq id }) {
                it[BasePaymentsTable.status] = PaymentStatus.REFUNDED.name
            }
        }
    }

    open fun findById(id: Long): Payment? = transaction(mainDb) { loadById(id) }

    open fun findByProviderPaymentId(provider: String, providerPaymentId: String): Payment? =
        transaction(mainDb) {
            BasePaymentsTable.selectAll()
                .where {
                    (BasePaymentsTable.provider eq provider) and
                        (BasePaymentsTable.providerPaymentId eq providerPaymentId)
                }
                .firstOrNull()
                ?.let(Payment::fromRow)
        }

    open fun listForOrder(orderId: Long): List<Payment> = transaction(mainDb) {
        BasePaymentsTable.selectAll()
            .where { BasePaymentsTable.orderId eq orderId }
            .orderBy(BasePaymentsTable.initiatedAt to SortOrder.ASC)
            .map(Payment::fromRow)
    }

    /** Returns the most recent CAPTURED payment for the order, if any. */
    open fun findCapturedFor(orderId: Long): Payment? = listForOrder(orderId)
        .lastOrNull { it.status == PaymentStatus.CAPTURED }

    private fun loadById(id: Long): Payment? = BasePaymentsTable.selectAll()
        .where { BasePaymentsTable.id eq id }
        .firstOrNull()
        ?.let(Payment::fromRow)
}
