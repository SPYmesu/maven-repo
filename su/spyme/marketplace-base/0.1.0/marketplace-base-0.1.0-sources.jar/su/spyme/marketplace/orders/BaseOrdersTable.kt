package su.spyme.marketplace.orders

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.orders.state.OrderStatus
import java.time.Instant

/**
 * Exposed mapping for V010.orders. Mirrors the schema column-for-
 * column; CHECK constraints from the migration enforce the canonical
 * status / product_kind alphabets.
 */
object BaseOrdersTable : Table("orders") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val orderNumber: Column<String> = varchar("order_number", 32)
    val status: Column<String> = varchar("status", 32).default("NEW")
    val productKind: Column<String> = varchar("product_kind", 16)
    val subtotalAmount: Column<Long> = long("subtotal_amount").default(0)
    val shippingAmount: Column<Long> = long("shipping_amount").default(0)
    val taxAmount: Column<Long> = long("tax_amount").default(0)
    val discountAmount: Column<Long> = long("discount_amount").default(0)
    val totalAmount: Column<Long> = long("total_amount").default(0)
    val currency: Column<String> = varchar("currency", 3).default("RUB")
    val locale: Column<String> = varchar("locale", 8).default("ru")
    val billingAddress: Column<JsonElement?> =
        jsonb("billing_address", Json, JsonElement.serializer()).nullable()
    val shippingAddress: Column<JsonElement?> =
        jsonb("shipping_address", Json, JsonElement.serializer()).nullable()
    val cancellationReasonCode: Column<String?> = varchar("cancellation_reason_code", 32).nullable()
    val cancellationReasonText: Column<String?> = text("cancellation_reason_text").nullable()
    val cancelledAt: Column<Instant?> = timestamp("cancelled_at").nullable()
    val cancelledBy: Column<Long?> = long("cancelled_by").nullable()
    val placedAt: Column<Instant> = timestamp("placed_at").defaultExpression(NowExpression)
    val paidAt: Column<Instant?> = timestamp("paid_at").nullable()
    val shippedAt: Column<Instant?> = timestamp("shipped_at").nullable()
    val deliveredAt: Column<Instant?> = timestamp("delivered_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Order header row. Line items live in [BaseOrderItemsTable]; per-line
 * stable display data (title at booking time, image, vendor name, …)
 * lives in [BaseOrderItemSnapshotsTable] (per В7).
 *
 * @property status Canonical [OrderStatus] from the architecture plan.
 *           PARTIALLY_REFUNDED / REFUNDED are *not* values here —
 *           they are display states derived from refunds.
 */
data class Order(
    val id: Long,
    val userId: Long,
    val orderNumber: String,
    val status: OrderStatus,
    val productKind: String,
    val total: Money,
    val subtotal: Money,
    val shipping: Money,
    val tax: Money,
    val discount: Money,
    val locale: String,
    val billingAddress: JsonElement?,
    val shippingAddress: JsonElement?,
    val cancellationReasonCode: String?,
    val cancellationReasonText: String?,
    val cancelledAt: Instant?,
    val cancelledBy: Long?,
    val placedAt: Instant,
    val paidAt: Instant?,
    val shippedAt: Instant?,
    val deliveredAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isCancelled: Boolean get() = status == OrderStatus.CANCELLED
    val isComplete: Boolean get() = status == OrderStatus.DELIVERED

    companion object {
        fun fromRow(row: ResultRow): Order {
            val currency = row[BaseOrdersTable.currency]
            return Order(
                id = row[BaseOrdersTable.id],
                userId = row[BaseOrdersTable.userId],
                orderNumber = row[BaseOrdersTable.orderNumber],
                status = OrderStatus.parse(row[BaseOrdersTable.status]),
                productKind = row[BaseOrdersTable.productKind],
                total = Money(row[BaseOrdersTable.totalAmount], currency),
                subtotal = Money(row[BaseOrdersTable.subtotalAmount], currency),
                shipping = Money(row[BaseOrdersTable.shippingAmount], currency),
                tax = Money(row[BaseOrdersTable.taxAmount], currency),
                discount = Money(row[BaseOrdersTable.discountAmount], currency),
                locale = row[BaseOrdersTable.locale],
                billingAddress = row[BaseOrdersTable.billingAddress],
                shippingAddress = row[BaseOrdersTable.shippingAddress],
                cancellationReasonCode = row[BaseOrdersTable.cancellationReasonCode],
                cancellationReasonText = row[BaseOrdersTable.cancellationReasonText],
                cancelledAt = row[BaseOrdersTable.cancelledAt],
                cancelledBy = row[BaseOrdersTable.cancelledBy],
                placedAt = row[BaseOrdersTable.placedAt],
                paidAt = row[BaseOrdersTable.paidAt],
                shippedAt = row[BaseOrdersTable.shippedAt],
                deliveredAt = row[BaseOrdersTable.deliveredAt],
                createdAt = row[BaseOrdersTable.createdAt],
                updatedAt = row[BaseOrdersTable.updatedAt],
            )
        }
    }
}
