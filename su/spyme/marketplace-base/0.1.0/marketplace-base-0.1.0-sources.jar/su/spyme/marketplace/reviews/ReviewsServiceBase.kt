package su.spyme.marketplace.reviews

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update

/**
 * CRUD + moderation around reviews and replies. Open class so hosts
 * can override (e.g. moonstudio enforces "must own the plugin to
 * review" by overriding submit).
 *
 * Posting policy: one review per (user, product). Re-submission by
 * the same user updates the existing row.
 */
open class ReviewsServiceBase(protected val mainDb: Database) {

    /**
     * Creates a new review or updates the existing (user, product)
     * pair. The submission lands in PENDING regardless of whether the
     * row is new — moderation re-examines edits.
     */
    open fun submit(
        userId: Long,
        productId: Long,
        rating: Int,
        body: String,
        title: String? = null,
        locale: String = "ru",
        orderId: Long? = null,
    ): Review {
        require(rating in 1..5) { "rating must be 1-5: $rating" }
        require(body.isNotBlank()) { "review body must not be blank" }

        return transaction(mainDb) {
            val existing = BaseReviewsTable.selectAll()
                .where {
                    (BaseReviewsTable.userId eq userId) and
                        (BaseReviewsTable.productId eq productId)
                }
                .firstOrNull()
                ?.let(Review::fromRow)
            if (existing != null) {
                BaseReviewsTable.update({ BaseReviewsTable.id eq existing.id }) {
                    it[BaseReviewsTable.rating] = rating.toShort()
                    it[BaseReviewsTable.title] = title
                    it[BaseReviewsTable.body] = body
                    it[BaseReviewsTable.locale] = locale
                    if (orderId != null) it[BaseReviewsTable.orderId] = orderId
                    // Re-submission resets moderation.
                    it[BaseReviewsTable.status] = ReviewStatus.PENDING.name
                    it[BaseReviewsTable.moderationNotes] = null
                }
                loadById(existing.id)!!
            } else {
                val id = BaseReviewsTable.insert {
                    it[BaseReviewsTable.userId] = userId
                    it[BaseReviewsTable.productId] = productId
                    it[BaseReviewsTable.orderId] = orderId
                    it[BaseReviewsTable.rating] = rating.toShort()
                    it[BaseReviewsTable.title] = title
                    it[BaseReviewsTable.body] = body
                    it[BaseReviewsTable.locale] = locale
                }[BaseReviewsTable.id]
                loadById(id)!!
            }
        }
    }

    open fun moderate(
        reviewId: Long,
        status: ReviewStatus,
        notes: String? = null,
    ): Review {
        require(status != ReviewStatus.PENDING) { "moderation must move out of PENDING" }
        transaction(mainDb) {
            BaseReviewsTable.update({ BaseReviewsTable.id eq reviewId }) {
                it[BaseReviewsTable.status] = status.name
                if (notes != null) it[BaseReviewsTable.moderationNotes] = notes
            }
        }
        return findById(reviewId)!!
    }

    open fun setVisibility(reviewId: Long, visibility: ReviewVisibility) {
        transaction(mainDb) {
            BaseReviewsTable.update({ BaseReviewsTable.id eq reviewId }) {
                it[BaseReviewsTable.visibility] = visibility.name
            }
        }
    }

    open fun incrementHelpfulCount(reviewId: Long) {
        transaction(mainDb) {
            BaseReviewsTable.update({ BaseReviewsTable.id eq reviewId }) {
                with(org.jetbrains.exposed.sql.SqlExpressionBuilder) {
                    it[BaseReviewsTable.helpfulCount] = BaseReviewsTable.helpfulCount + 1
                }
            }
        }
    }

    open fun findById(id: Long): Review? = transaction(mainDb) { loadById(id) }

    open fun listForProduct(
        productId: Long,
        onlyApproved: Boolean = true,
    ): List<Review> = transaction(mainDb) {
        BaseReviewsTable.selectAll()
            .where {
                val byProduct = BaseReviewsTable.productId eq productId
                if (onlyApproved) {
                    byProduct and (BaseReviewsTable.status eq ReviewStatus.APPROVED.name) and
                        (BaseReviewsTable.visibility eq ReviewVisibility.PUBLIC.name)
                } else byProduct
            }
            .orderBy(BaseReviewsTable.createdAt to SortOrder.DESC)
            .map(Review::fromRow)
    }

    open fun listForUser(userId: Long): List<Review> = transaction(mainDb) {
        BaseReviewsTable.selectAll()
            .where { BaseReviewsTable.userId eq userId }
            .orderBy(BaseReviewsTable.createdAt to SortOrder.DESC)
            .map(Review::fromRow)
    }

    open fun listPending(limit: Int = 50): List<Review> = transaction(mainDb) {
        BaseReviewsTable.selectAll()
            .where { BaseReviewsTable.status eq ReviewStatus.PENDING.name }
            .orderBy(BaseReviewsTable.createdAt to SortOrder.ASC)
            .limit(limit)
            .map(Review::fromRow)
    }

    open fun delete(reviewId: Long): Boolean = transaction(mainDb) {
        BaseReviewsTable.deleteWhere { BaseReviewsTable.id eq reviewId } > 0
    }

    open fun reply(
        reviewId: Long,
        userId: Long,
        body: String,
        isOfficial: Boolean = true,
    ): ReviewReply {
        require(body.isNotBlank()) { "reply body must not be blank" }
        return transaction(mainDb) {
            val id = BaseReviewRepliesTable.insert {
                it[BaseReviewRepliesTable.reviewId] = reviewId
                it[BaseReviewRepliesTable.userId] = userId
                it[BaseReviewRepliesTable.body] = body
                it[BaseReviewRepliesTable.isOfficial] = isOfficial
            }[BaseReviewRepliesTable.id]
            BaseReviewRepliesTable.selectAll()
                .where { BaseReviewRepliesTable.id eq id }
                .first()
                .let(ReviewReply::fromRow)
        }
    }

    open fun listReplies(reviewId: Long): List<ReviewReply> = transaction(mainDb) {
        BaseReviewRepliesTable.selectAll()
            .where { BaseReviewRepliesTable.reviewId eq reviewId }
            .orderBy(BaseReviewRepliesTable.createdAt to SortOrder.ASC)
            .map(ReviewReply::fromRow)
    }

    private fun loadById(id: Long): Review? = BaseReviewsTable.selectAll()
        .where { BaseReviewsTable.id eq id }
        .firstOrNull()
        ?.let(Review::fromRow)
}
