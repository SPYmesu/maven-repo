package su.spyme.marketplace.auth.totp

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.auth.SecretEncryption
import su.spyme.marketplace.core.database.NowExpression
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.and

object BaseTotpSecretsTable : Table("totp_secrets") {
    val userId: Column<Long> = long("user_id")
    val secret: Column<ByteArray> = binary("secret")
    val secretKeyVersion: Column<Short> = short("secret_key_version")
    val digits: Column<Short> = short("digits").default(6)
    val periodSeconds: Column<Short> = short("period_seconds").default(30)
    val algo: Column<String> = varchar("algo", 16).default("HmacSHA1")
    val confirmedAt: Column<Instant?> = timestamp("confirmed_at").nullable()
    val lastUsedStep: Column<Long?> = long("last_used_step").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(userId)
}

object BaseTotpRecoveryCodesTable : Table("totp_recovery_codes") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val codeHash: Column<String> = varchar("code_hash", 64)
    val codeSalt: Column<ByteArray> = binary("code_salt")
    val consumedAt: Column<Instant?> = timestamp("consumed_at").nullable()
    val consumedIp: Column<String?> = varchar("consumed_ip", 64).nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * RFC 6238 TOTP service with AES-256-GCM secret-at-rest encryption
 * (per В2 of the architecture plan).
 *
 * Lifecycle:
 *   1. [enroll] — generate a new 20-byte secret (HMAC-SHA1 default;
 *      configurable per row), encrypt with the active master key,
 *      store as PENDING (`confirmed_at IS NULL`).
 *   2. Caller renders the otpauth:// URI to a QR code; the user
 *      scans it with their authenticator app.
 *   3. [confirm] — user enters the first generated 6-digit code; we
 *      verify, stamp `confirmed_at`, record `last_used_step`.
 *   4. [verify] — every subsequent login challenge runs through here.
 *      Replay protection: reject if the supplied step has already been
 *      used (`last_used_step >= step`).
 *   5. [disable] — admin or user removes 2FA; row is deleted.
 *
 * Recovery codes ([generateRecoveryCodes]) are 8-char base32 strings;
 * stored hashed (SHA-256 + per-code 16-byte salt). Each is single-use:
 * `consumeRecoveryCode` flips `consumed_at`.
 */
open class TotpService(
    protected val mainDb: Database,
    /** Active encryption helper. Bumps when MARKETPLACE_TOTP_KEY_V<N> rotates. */
    protected val encryption: SecretEncryption,
    /** Version stamped onto rows we encrypt today; rotation job re-encrypts older rows. */
    protected val activeKeyVersion: Int = 1,
) {

    /** Generates and persists a fresh PENDING TOTP secret for [userId]. Returns the otpauth:// URI. */
    open fun enroll(
        userId: Long,
        accountLabel: String,
        issuer: String,
        digits: Int = 6,
        periodSeconds: Int = 30,
    ): EnrollResult {
        val secretBytes = ByteArray(20).also { SecureRandom().nextBytes(it) }
        val encrypted = encryption.encrypt(secretBytes)
        val base32Secret = base32Encode(secretBytes)

        transaction(mainDb) {
            BaseTotpSecretsTable.upsert {
                it[BaseTotpSecretsTable.userId] = userId
                it[BaseTotpSecretsTable.secret] = encrypted
                it[BaseTotpSecretsTable.secretKeyVersion] = activeKeyVersion.toShort()
                it[BaseTotpSecretsTable.digits] = digits.toShort()
                it[BaseTotpSecretsTable.periodSeconds] = periodSeconds.toShort()
                it[BaseTotpSecretsTable.algo] = "HmacSHA1"
                it[BaseTotpSecretsTable.confirmedAt] = null
                it[BaseTotpSecretsTable.lastUsedStep] = null
            }
        }

        val uri = buildString {
            append("otpauth://totp/")
            append(java.net.URLEncoder.encode("$issuer:$accountLabel", Charsets.UTF_8))
            append("?secret=").append(base32Secret)
            append("&issuer=").append(java.net.URLEncoder.encode(issuer, Charsets.UTF_8))
            append("&algorithm=SHA1")
            append("&digits=").append(digits)
            append("&period=").append(periodSeconds)
        }
        return EnrollResult(otpauthUri = uri, base32Secret = base32Secret)
    }

    /** Verifies the user's first code and marks the row as confirmed. */
    open fun confirm(userId: Long, code: String, now: Instant = Instant.now()): Boolean {
        val row = loadRow(userId) ?: return false
        if (row.confirmedAt != null) return verify(userId, code, now) // already confirmed; treat as plain verify
        if (!verifyCode(row, code, now)) return false
        val step = currentStep(row, now)
        transaction(mainDb) {
            BaseTotpSecretsTable.update({ BaseTotpSecretsTable.userId eq userId }) {
                it[BaseTotpSecretsTable.confirmedAt] = now
                it[BaseTotpSecretsTable.lastUsedStep] = step
            }
        }
        return true
    }

    /**
     * Verifies a TOTP code at login time. Implements replay protection:
     * a step ≤ `last_used_step` is rejected even if the math checks
     * out, so a sniffed code can't be reused inside the same step
     * window.
     *
     * Tolerance: ±1 step (default 30s either side) absorbs clock drift.
     */
    open fun verify(userId: Long, code: String, now: Instant = Instant.now()): Boolean {
        val row = loadRow(userId) ?: return false
        if (row.confirmedAt == null) return false
        if (!verifyCode(row, code, now)) return false
        val matchedStep = matchingStep(row, code, now) ?: return false
        if (row.lastUsedStep != null && matchedStep <= row.lastUsedStep) return false
        transaction(mainDb) {
            BaseTotpSecretsTable.update({ BaseTotpSecretsTable.userId eq userId }) {
                it[BaseTotpSecretsTable.lastUsedStep] = matchedStep
            }
        }
        return true
    }

    open fun disable(userId: Long): Boolean = transaction(mainDb) {
        val deletedRecovery = BaseTotpRecoveryCodesTable.deleteWhere {
            BaseTotpRecoveryCodesTable.userId eq userId
        }
        val deletedSecret = BaseTotpSecretsTable.deleteWhere {
            BaseTotpSecretsTable.userId eq userId
        }
        @Suppress("UNUSED_VARIABLE")
        val recoveryDropped = deletedRecovery
        deletedSecret > 0
    }

    open fun isEnabled(userId: Long): Boolean = transaction(mainDb) {
        BaseTotpSecretsTable.selectAll()
            .where { BaseTotpSecretsTable.userId eq userId }
            .firstOrNull()
            ?.let { it[BaseTotpSecretsTable.confirmedAt] != null }
            ?: false
    }

    /**
     * Issues [count] one-time recovery codes for [userId]. Returns the
     * plaintext list to render to the user once; the SQL row stores
     * SHA-256(salt || code) and a per-code salt.
     */
    open fun generateRecoveryCodes(userId: Long, count: Int = 8): List<String> {
        val rng = SecureRandom()
        val codes = mutableListOf<String>()
        transaction(mainDb) {
            // Drop any leftover unused codes — re-issue replaces.
            BaseTotpRecoveryCodesTable.deleteWhere {
                BaseTotpRecoveryCodesTable.userId eq userId
            }
            repeat(count) {
                val raw = ByteArray(5).also { rng.nextBytes(it) }
                val code = base32Encode(raw).take(8)
                val salt = ByteArray(16).also { rng.nextBytes(it) }
                val hash = sha256Hex(salt + code.toByteArray(Charsets.UTF_8))
                codes += code
                BaseTotpRecoveryCodesTable.insert {
                    it[BaseTotpRecoveryCodesTable.userId] = userId
                    it[BaseTotpRecoveryCodesTable.codeHash] = hash
                    it[BaseTotpRecoveryCodesTable.codeSalt] = salt
                }
            }
        }
        return codes
    }

    /** Single-use redeem of a recovery code; returns true on success. */
    open fun consumeRecoveryCode(userId: Long, code: String, now: Instant = Instant.now()): Boolean =
        transaction(mainDb) {
            val candidates = BaseTotpRecoveryCodesTable.selectAll()
                .where { BaseTotpRecoveryCodesTable.userId eq userId }
                .toList()
            for (row in candidates) {
                if (row[BaseTotpRecoveryCodesTable.consumedAt] != null) continue
                val hash = sha256Hex(row[BaseTotpRecoveryCodesTable.codeSalt] + code.toByteArray(Charsets.UTF_8))
                if (constantTimeEqualsString(hash, row[BaseTotpRecoveryCodesTable.codeHash])) {
                    BaseTotpRecoveryCodesTable.update({
                        BaseTotpRecoveryCodesTable.id eq row[BaseTotpRecoveryCodesTable.id]
                    }) {
                        it[BaseTotpRecoveryCodesTable.consumedAt] = now
                    }
                    return@transaction true
                }
            }
            false
        }

    /** "How many recovery codes does this user have left" — for the dashboard counter. */
    open fun remainingRecoveryCodes(userId: Long): Long = transaction(mainDb) {
        BaseTotpRecoveryCodesTable.selectAll()
            .where { BaseTotpRecoveryCodesTable.userId eq userId }
            .count() - BaseTotpRecoveryCodesTable.selectAll()
            .where { BaseTotpRecoveryCodesTable.userId eq userId }
            .filter { it[BaseTotpRecoveryCodesTable.consumedAt] != null }
            .size
    }

    private fun loadRow(userId: Long): TotpRow? = transaction(mainDb) {
        BaseTotpSecretsTable.selectAll()
            .where { BaseTotpSecretsTable.userId eq userId }
            .firstOrNull()
            ?.let(TotpRow::fromRow)
    }

    private fun verifyCode(row: TotpRow, code: String, now: Instant): Boolean =
        matchingStep(row, code, now) != null

    private fun matchingStep(row: TotpRow, code: String, now: Instant): Long? {
        val secret = encryption.decrypt(row.secret)
        val step = currentStep(row, now)
        // ±1 step tolerance for clock drift.
        for (offset in -1..1) {
            val candidate = generateCode(secret, step + offset, row.digits)
            if (constantTimeEqualsString(candidate, code)) return step + offset
        }
        return null
    }

    private fun currentStep(row: TotpRow, now: Instant): Long = now.epochSecond / row.periodSeconds

    private fun generateCode(secret: ByteArray, step: Long, digits: Int): String {
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(secret, "HmacSHA1"))
        val message = ByteArray(8)
        for (i in 7 downTo 0) {
            message[i] = (step ushr ((7 - i) * 8) and 0xFF).toByte()
        }
        val hash = mac.doFinal(message)
        val offset = (hash.last() and 0x0f).toInt()
        val truncated = ((hash[offset].toInt() and 0x7f) shl 24) or
            ((hash[offset + 1].toInt() and 0xff) shl 16) or
            ((hash[offset + 2].toInt() and 0xff) shl 8) or
            (hash[offset + 3].toInt() and 0xff)
        val code = truncated % MOD_BY_DIGITS[digits]!!
        return code.toString().padStart(digits, '0')
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes).joinToString("") { "%02x".format(it) }
    }

    private fun base32Encode(bytes: ByteArray): String {
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val sb = StringBuilder()
        var buffer = 0
        var bitsLeft = 0
        for (byte in bytes) {
            buffer = (buffer shl 8) or (byte.toInt() and 0xFF)
            bitsLeft += 8
            while (bitsLeft >= 5) {
                bitsLeft -= 5
                sb.append(alphabet[(buffer shr bitsLeft) and 0x1F])
            }
        }
        if (bitsLeft > 0) {
            sb.append(alphabet[(buffer shl (5 - bitsLeft)) and 0x1F])
        }
        return sb.toString()
    }

    private fun constantTimeEqualsString(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }

    private data class TotpRow(
        val userId: Long,
        val secret: ByteArray,
        val secretKeyVersion: Int,
        val digits: Int,
        val periodSeconds: Int,
        val algo: String,
        val confirmedAt: Instant?,
        val lastUsedStep: Long?,
    ) {
        companion object {
            fun fromRow(row: ResultRow): TotpRow = TotpRow(
                userId = row[BaseTotpSecretsTable.userId],
                secret = row[BaseTotpSecretsTable.secret],
                secretKeyVersion = row[BaseTotpSecretsTable.secretKeyVersion].toInt(),
                digits = row[BaseTotpSecretsTable.digits].toInt(),
                periodSeconds = row[BaseTotpSecretsTable.periodSeconds].toInt(),
                algo = row[BaseTotpSecretsTable.algo],
                confirmedAt = row[BaseTotpSecretsTable.confirmedAt],
                lastUsedStep = row[BaseTotpSecretsTable.lastUsedStep],
            )
        }
    }

    data class EnrollResult(
        val otpauthUri: String,
        val base32Secret: String,
    )

    companion object {
        private val MOD_BY_DIGITS = mapOf(
            6 to 1_000_000,
            8 to 100_000_000,
        )
    }
}
