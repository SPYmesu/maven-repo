package su.spyme.marketplace.core

/**
 * Money carried as a smallest-unit integer + ISO-4217 currency code.
 * Per the architecture plan: BIGINT amount + CHAR(3) currency, no
 * floating-point arithmetic anywhere on the money path.
 */
data class Money(val amount: Long, val currency: String) {
    init {
        require(currency.length == 3) { "currency must be a 3-char ISO-4217 code: $currency" }
        require(currency == currency.uppercase()) { "currency must be UPPER_CASE: $currency" }
    }

    operator fun plus(other: Money): Money {
        require(currency == other.currency) { "cannot add $currency and ${other.currency}" }
        return Money(Math.addExact(amount, other.amount), currency)
    }

    operator fun minus(other: Money): Money {
        require(currency == other.currency) { "cannot subtract $currency from ${other.currency}" }
        return Money(Math.subtractExact(amount, other.amount), currency)
    }

    operator fun times(factor: Int): Money = Money(Math.multiplyExact(amount, factor.toLong()), currency)

    companion object {
        val ZERO_RUB = Money(0, "RUB")
    }
}
