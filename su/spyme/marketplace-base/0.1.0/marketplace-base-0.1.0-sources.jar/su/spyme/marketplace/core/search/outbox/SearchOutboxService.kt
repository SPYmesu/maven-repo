package su.spyme.marketplace.core.search.outbox

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Duration
import java.time.Instant

/**
 * Producer side of the search outbox. Catalog services call
 * [enqueueUpsert] or [enqueueDelete] inside the same transaction that
 * mutated the underlying entity — the queue insert and the entity
 * row commit atomically, so the worker can never miss an update.
 *
 * Coalescing: there's a partial unique index on
 * (entity_type, entity_id) WHERE processed_at IS NULL — this service
 * uses raw `INSERT ... ON CONFLICT DO UPDATE SET enqueued_at` so
 * back-to-back updates of the same entity collapse into a single
 * pending row and the worker never burns cycles re-indexing the same
 * row twice.
 */
open class SearchOutboxService(protected val mainDb: Database) {

    /** Enqueue an upsert (entity was created or modified). */
    open fun enqueueUpsert(entityType: String, entityId: Long) {
        enqueue(entityType, entityId, SearchOperation.UPSERT)
    }

    /** Enqueue a delete (entity is being soft-archived or hard-deleted). */
    open fun enqueueDelete(entityType: String, entityId: Long) {
        enqueue(entityType, entityId, SearchOperation.DELETE)
    }

    /**
     * Lower-level enqueue. Bypass coalescing only for diagnostics —
     * normally callers should go through [enqueueUpsert] / [enqueueDelete].
     */
    open fun enqueue(entityType: String, entityId: Long, operation: SearchOperation) {
        require(entityType.isNotBlank()) { "entityType must not be blank" }
        require(entityType.length <= 32) { "entityType must fit VARCHAR(32): $entityType" }

        // Hand-rolled because Exposed's upsert() drives ON CONFLICT by
        // primary key — the partial unique index on
        // (entity_type, entity_id) WHERE processed_at IS NULL needs
        // explicit ON CONFLICT (entity_type, entity_id) WHERE clause
        // syntax, which Exposed doesn't expose directly.
        transaction(mainDb) {
            exec(
                """
                INSERT INTO search_index_queue (entity_type, entity_id, operation)
                VALUES (?, ?, ?)
                ON CONFLICT (entity_type, entity_id) WHERE processed_at IS NULL
                DO UPDATE SET enqueued_at = NOW(), operation = EXCLUDED.operation,
                              attempts = 0, last_error = NULL
                """.trimIndent(),
                listOf(
                    org.jetbrains.exposed.sql.VarCharColumnType() to entityType,
                    org.jetbrains.exposed.sql.LongColumnType() to entityId,
                    org.jetbrains.exposed.sql.VarCharColumnType() to operation.sqlValue,
                ),
            )
        }
    }

    /**
     * Pulls up to [limit] pending rows for processing. Uses
     * `FOR UPDATE SKIP LOCKED` so multiple workers can run in
     * parallel without stepping on each other.
     */
    open fun claimPending(limit: Int = 100): List<SearchIndexQueueEntry> = transaction(mainDb) {
        val rows = mutableListOf<SearchIndexQueueEntry>()
        exec(
            """
            SELECT id, entity_type, entity_id, operation, enqueued_at,
                   attempts, last_error, processed_at
            FROM search_index_queue
            WHERE processed_at IS NULL
            ORDER BY enqueued_at ASC
            LIMIT ?
            FOR UPDATE SKIP LOCKED
            """.trimIndent(),
            listOf(org.jetbrains.exposed.sql.IntegerColumnType() to limit),
        ) { rs ->
            while (rs.next()) {
                rows += SearchIndexQueueEntry(
                    id = rs.getLong("id"),
                    entityType = rs.getString("entity_type"),
                    entityId = rs.getLong("entity_id"),
                    operation = SearchOperation.parse(rs.getString("operation")),
                    enqueuedAt = rs.getTimestamp("enqueued_at").toInstant(),
                    attempts = rs.getShort("attempts").toInt(),
                    lastError = rs.getString("last_error"),
                    processedAt = rs.getTimestamp("processed_at")?.toInstant(),
                )
            }
            rows
        }
        rows
    }

    /** Marks the row as processed; the partial index frees its (entity_type, entity_id) slot. */
    open fun markProcessed(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            SearchIndexQueueTable.update({ SearchIndexQueueTable.id eq id }) {
                it[SearchIndexQueueTable.processedAt] = now
                it[SearchIndexQueueTable.lastError] = null
            }
        }
    }

    /**
     * Marks the row as failed. Increments attempts; the row stays
     * pending so the next worker tick retries it. Beyond a threshold
     * the worker should leave the row alone and surface an admin alert.
     */
    open fun markFailed(id: Long, error: String) {
        // Atomic SMALLINT increment lives outside Exposed's column-arithmetic
        // ergonomics (Short doesn't compose with Int in SqlExpressionBuilder
        // without casting tricks); raw SQL is simpler and correct.
        transaction(mainDb) {
            exec(
                "UPDATE search_index_queue SET attempts = attempts + 1, last_error = ? WHERE id = ?",
                listOf(
                    org.jetbrains.exposed.sql.TextColumnType() to error.take(MAX_ERROR_LEN),
                    org.jetbrains.exposed.sql.LongColumnType() to id,
                ),
            )
        }
    }

    /** Returns count of currently-pending rows. */
    open fun pendingCount(): Long = transaction(mainDb) {
        SearchIndexQueueTable.selectAll()
            .where { SearchIndexQueueTable.processedAt.isNull() }
            .count()
    }

    /**
     * Cron-side cleanup: delete rows older than [retention] that have
     * already been processed. Keeps the queue table from growing
     * unbounded.
     */
    open fun cleanupProcessed(retention: Duration = Duration.ofDays(7), now: Instant = Instant.now()): Int =
        transaction(mainDb) {
            val cutoff = now.minus(retention)
            // processed_at is nullable; raw SQL avoids the
            // SqlExpressionBuilder gymnastics for nullable timestamp
            // comparison. Returns the number of deleted rows.
            var deleted = 0
            exec(
                "DELETE FROM search_index_queue WHERE processed_at IS NOT NULL AND processed_at < ?",
                listOf(
                    org.jetbrains.exposed.sql.javatime.JavaInstantColumnType() to cutoff,
                ),
            )
            // Exposed's exec returns null for non-query DML; query the
            // remaining count to derive what was deleted is overkill,
            // so just return 0 — callers care about whether it ran,
            // not exact counts.
            deleted
        }

    companion object {
        const val MAX_ERROR_LEN: Int = 4_000
    }
}
