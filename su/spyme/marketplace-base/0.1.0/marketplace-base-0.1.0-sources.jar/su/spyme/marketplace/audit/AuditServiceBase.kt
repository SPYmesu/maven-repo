package su.spyme.marketplace.audit

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.database.inet
import java.time.Duration
import java.time.Instant

object BaseAuditLogTable : Table("audit_log") {
    val id: Column<Long> = long("id").autoIncrement()
    val actorUserId: Column<Long?> = long("actor_user_id").nullable()
    val actorRole: Column<String?> = varchar("actor_role", 32).nullable()
    val actorIp: Column<String?> = inet("actor_ip").nullable()
    val actorUserAgent: Column<String?> = text("actor_user_agent").nullable()
    val action: Column<String> = varchar("action", 64)
    val entityType: Column<String> = varchar("entity_type", 32)
    val entityId: Column<Long?> = long("entity_id").nullable()
    val entitySnapshotBefore: Column<JsonElement?> =
        jsonb("entity_snapshot_before", Json, JsonElement.serializer()).nullable()
    val entitySnapshotAfter: Column<JsonElement?> =
        jsonb("entity_snapshot_after", Json, JsonElement.serializer()).nullable()
    val isReversible: Column<Boolean> = bool("is_reversible").default(true)
    val parentAuditId: Column<Long?> = long("parent_audit_id").nullable()
    val revertedAt: Column<Instant?> = timestamp("reverted_at").nullable()
    val revertedByUserId: Column<Long?> = long("reverted_by_user_id").nullable()
    val revertedAuditId: Column<Long?> = long("reverted_audit_id").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Single audit-log entry. Snapshots are JSONB so the same row can
 * carry whatever shape the entity has — admins read them rendered as
 * a diff in the audit UI.
 */
data class AuditLogEntry(
    val id: Long,
    val actorUserId: Long?,
    val actorRole: String?,
    val actorIp: String?,
    val actorUserAgent: String?,
    val action: String,
    val entityType: String,
    val entityId: Long?,
    val entitySnapshotBefore: JsonElement?,
    val entitySnapshotAfter: JsonElement?,
    val isReversible: Boolean,
    val parentAuditId: Long?,
    val revertedAt: Instant?,
    val revertedByUserId: Long?,
    val revertedAuditId: Long?,
    val createdAt: Instant,
) {
    val isReverted: Boolean get() = revertedAt != null

    companion object {
        fun fromRow(row: ResultRow): AuditLogEntry = AuditLogEntry(
            id = row[BaseAuditLogTable.id],
            actorUserId = row[BaseAuditLogTable.actorUserId],
            actorRole = row[BaseAuditLogTable.actorRole],
            actorIp = row[BaseAuditLogTable.actorIp],
            actorUserAgent = row[BaseAuditLogTable.actorUserAgent],
            action = row[BaseAuditLogTable.action],
            entityType = row[BaseAuditLogTable.entityType],
            entityId = row[BaseAuditLogTable.entityId],
            entitySnapshotBefore = row[BaseAuditLogTable.entitySnapshotBefore],
            entitySnapshotAfter = row[BaseAuditLogTable.entitySnapshotAfter],
            isReversible = row[BaseAuditLogTable.isReversible],
            parentAuditId = row[BaseAuditLogTable.parentAuditId],
            revertedAt = row[BaseAuditLogTable.revertedAt],
            revertedByUserId = row[BaseAuditLogTable.revertedByUserId],
            revertedAuditId = row[BaseAuditLogTable.revertedAuditId],
            createdAt = row[BaseAuditLogTable.createdAt],
        )
    }
}

/** Result of [AuditServiceBase.bulkUndo] — succeeded ids + per-failure context. */
data class BulkUndoReport(
    val succeeded: List<Long>,
    val failed: List<UndoFailure>,
) {
    data class UndoFailure(val auditId: Long, val reason: String)
}

class IrreversibleActionException(val auditId: Long, val action: String) :
    RuntimeException("Audit $auditId / $action is marked is_reversible=false")

class UndoTooOldException(val auditId: Long, val ageDays: Long) :
    RuntimeException("Audit $auditId is older than the maxUndoAge cap ($ageDays days)")

class AlreadyRevertedException(val auditId: Long) :
    RuntimeException("Audit $auditId has already been reverted")

/**
 * Audit log + security undo per Б6 / В5.
 *
 * The service intentionally does *not* know how to apply a snapshot
 * to an entity — every entity owns its own ResultRow shape. Callers
 * register a [SnapshotApplier] per entity_type during bootstrap; the
 * applier replaces the live row with the contents of
 * `entity_snapshot_before`. Without an applier the undo throws.
 *
 * Undo semantics (per В5):
 *   1. is_reversible must be true (raises [IrreversibleActionException]).
 *   2. created_at must be within maxUndoAgeDays (raises [UndoTooOldException]).
 *   3. Already-reverted entries reject (raises [AlreadyRevertedException]).
 *   4. The snapshot is applied; a fresh "AUDIT_UNDO" row is logged
 *      with parent_audit_id pointing at the original; the original
 *      row's reverted_* columns are stamped.
 *   5. Side-effect listeners (notifications, webhooks) are *not*
 *      replayed — undo carries a "warning info" map back to the
 *      caller so the admin can take manual follow-up action.
 *
 * Skip side-effect listeners:
 *   The architecture-plan rule is "skip email/webhook/refund auto on
 *   undo" — any required compensation is a separate manual action.
 */
open class AuditServiceBase(
    protected val mainDb: Database,
    protected val maxUndoAge: Duration = Duration.ofDays(30),
) {
    /** Per-entity-type snapshot reapplier registered by the host. */
    fun interface SnapshotApplier {
        /** Replaces the live entity with [snapshotBefore]; returns warnings for the admin. */
        suspend fun apply(entityId: Long, snapshotBefore: JsonElement): Map<String, JsonElement>
    }

    private val appliers = mutableMapOf<String, SnapshotApplier>()

    fun registerApplier(entityType: String, applier: SnapshotApplier) {
        appliers[entityType]?.let {
            error("SnapshotApplier already registered for entity type '$entityType'")
        }
        appliers[entityType] = applier
    }

    open fun log(
        action: String,
        entityType: String,
        entityId: Long? = null,
        actorUserId: Long? = null,
        actorRole: String? = null,
        actorIp: String? = null,
        actorUserAgent: String? = null,
        snapshotBefore: JsonElement? = null,
        snapshotAfter: JsonElement? = null,
        isReversible: Boolean = true,
        parentAuditId: Long? = null,
    ): AuditLogEntry {
        require(action.isNotBlank()) { "action must not be blank" }
        require(entityType.isNotBlank()) { "entityType must not be blank" }

        return transaction(mainDb) {
            val newId = BaseAuditLogTable.insert {
                it[BaseAuditLogTable.actorUserId] = actorUserId
                it[BaseAuditLogTable.actorRole] = actorRole
                it[BaseAuditLogTable.actorIp] = actorIp
                it[BaseAuditLogTable.actorUserAgent] = actorUserAgent
                it[BaseAuditLogTable.action] = action
                it[BaseAuditLogTable.entityType] = entityType
                it[BaseAuditLogTable.entityId] = entityId
                it[BaseAuditLogTable.entitySnapshotBefore] = snapshotBefore
                it[BaseAuditLogTable.entitySnapshotAfter] = snapshotAfter
                it[BaseAuditLogTable.isReversible] = isReversible
                it[BaseAuditLogTable.parentAuditId] = parentAuditId
            }[BaseAuditLogTable.id]
            loadById(newId)!!
        }
    }

    open fun findById(id: Long): AuditLogEntry? = transaction(mainDb) { loadById(id) }

    open fun listForActor(actorUserId: Long, limit: Int = 100): List<AuditLogEntry> =
        transaction(mainDb) {
            BaseAuditLogTable.selectAll()
                .where { BaseAuditLogTable.actorUserId eq actorUserId }
                .orderBy(BaseAuditLogTable.createdAt to SortOrder.DESC)
                .limit(limit)
                .map(AuditLogEntry::fromRow)
        }

    open fun listForEntity(entityType: String, entityId: Long): List<AuditLogEntry> =
        transaction(mainDb) {
            BaseAuditLogTable.selectAll()
                .where {
                    (BaseAuditLogTable.entityType eq entityType) and
                        (BaseAuditLogTable.entityId eq entityId)
                }
                .orderBy(BaseAuditLogTable.createdAt to SortOrder.DESC)
                .map(AuditLogEntry::fromRow)
        }

    /**
     * Reverses the entity to [AuditLogEntry.entitySnapshotBefore].
     * Returns the new audit row for the undo itself. Throws on any
     * of the В5 invariants.
     */
    open suspend fun undo(
        auditId: Long,
        actorUserId: Long? = null,
        now: Instant = Instant.now(),
    ): AuditLogEntry {
        val original = findById(auditId) ?: throw IllegalArgumentException("audit $auditId not found")
        if (!original.isReversible) throw IrreversibleActionException(auditId, original.action)
        if (original.isReverted) throw AlreadyRevertedException(auditId)

        val ageMs = now.toEpochMilli() - original.createdAt.toEpochMilli()
        if (ageMs > maxUndoAge.toMillis()) {
            throw UndoTooOldException(auditId, ageMs / (1000L * 60 * 60 * 24))
        }

        val applier = appliers[original.entityType]
            ?: error("no SnapshotApplier registered for entityType='${original.entityType}'")
        val before = original.entitySnapshotBefore
            ?: error("audit $auditId has no entity_snapshot_before — undo impossible")
        val entityId = original.entityId
            ?: error("audit $auditId has no entityId — undo target unknown")

        applier.apply(entityId, before)

        val undoEntry = log(
            action = "AUDIT_UNDO",
            entityType = original.entityType,
            entityId = entityId,
            actorUserId = actorUserId,
            actorRole = "ADMIN",
            snapshotBefore = original.entitySnapshotAfter,
            snapshotAfter = before,
            parentAuditId = original.id,
        )
        transaction(mainDb) {
            BaseAuditLogTable.update({ BaseAuditLogTable.id eq original.id }) {
                it[BaseAuditLogTable.revertedAt] = now
                it[BaseAuditLogTable.revertedByUserId] = actorUserId
                it[BaseAuditLogTable.revertedAuditId] = undoEntry.id
            }
        }
        return undoEntry
    }

    /**
     * Reverse-chronologically undo every reversible action by the
     * given actor since [fromTimestamp]. Failures are collected, not
     * thrown — the caller renders the report in admin UI.
     */
    open suspend fun bulkUndo(
        actorUserId: Long,
        fromTimestamp: Instant,
        actorOfUndo: Long? = null,
        now: Instant = Instant.now(),
    ): BulkUndoReport {
        val candidates = transaction(mainDb) {
            BaseAuditLogTable.selectAll()
                .where {
                    (BaseAuditLogTable.actorUserId eq actorUserId) and
                        (BaseAuditLogTable.isReversible eq true)
                }
                .orderBy(BaseAuditLogTable.createdAt to SortOrder.DESC)
                .map(AuditLogEntry::fromRow)
                .filter { it.createdAt >= fromTimestamp && it.revertedAt == null }
        }

        val succeeded = mutableListOf<Long>()
        val failed = mutableListOf<BulkUndoReport.UndoFailure>()
        for (entry in candidates) {
            try {
                undo(entry.id, actorOfUndo, now)
                succeeded += entry.id
            } catch (e: RuntimeException) {
                failed += BulkUndoReport.UndoFailure(entry.id, "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
            }
        }
        return BulkUndoReport(succeeded, failed)
    }

    private fun loadById(id: Long): AuditLogEntry? = BaseAuditLogTable.selectAll()
        .where { BaseAuditLogTable.id eq id }
        .firstOrNull()
        ?.let(AuditLogEntry::fromRow)
}
