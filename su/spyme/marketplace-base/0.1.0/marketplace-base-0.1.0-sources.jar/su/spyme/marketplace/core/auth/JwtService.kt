package su.spyme.marketplace.core.auth

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.auth0.jwt.exceptions.JWTVerificationException
import su.spyme.marketplace.core.BaseConfig
import java.time.Instant
import java.util.Date
import java.util.UUID
import kotlin.time.Duration

/**
 * Issues and verifies access JWTs per В1.
 *
 * Layout:
 *   iss = config.jwtIssuer        (verified)
 *   sub = userId                   (Long-as-string)
 *   jti = UUID                     (random per issue)
 *   sid = sessionId                (custom, links to user_sessions row)
 *   ver = jwt_version              (custom, bulk-revoke check)
 *   iat / exp = standard timestamps
 *
 * verify() validates signature, issuer, and expiration. It does NOT
 * check the user's current jwt_version or the session's revoked_at —
 * the caller (AuthService / authentication plugin) must do that
 * against the database after verify() returns Claims.
 */
class JwtService(private val config: BaseConfig.Auth) {

    private val algorithm: Algorithm =
        Algorithm.HMAC256(config.jwtSigningKey.toByteArray(Charsets.UTF_8))

    private val verifier = JWT.require(algorithm)
        .withIssuer(config.jwtIssuer)
        .build()

    fun issue(
        userId: Long,
        sessionId: UUID,
        jwtVersion: Int,
        ttl: Duration = config.jwtAccessTtl,
        jti: UUID = UUID.randomUUID(),
        issuedAt: Instant = Instant.now(),
    ): IssuedToken {
        // JWT iat/exp are unix-seconds — truncate up front so the value
        // we return matches what verify() reads back later.
        val iat = Instant.ofEpochSecond(issuedAt.epochSecond)
        val expiresAt = iat.plusSeconds(ttl.inWholeSeconds)
        val token = JWT.create()
            .withIssuer(config.jwtIssuer)
            .withSubject(userId.toString())
            .withJWTId(jti.toString())
            .withClaim(CLAIM_SESSION, sessionId.toString())
            .withClaim(CLAIM_VERSION, jwtVersion)
            .withIssuedAt(Date.from(iat))
            .withExpiresAt(Date.from(expiresAt))
            .sign(algorithm)
        return IssuedToken(token = token, jti = jti, expiresAt = expiresAt)
    }

    /**
     * Verifies signature + issuer + expiration. Throws [InvalidJwtException]
     * (wrapping the underlying [JWTVerificationException]) on any failure.
     */
    fun verify(token: String): Claims {
        val decoded = try {
            verifier.verify(token)
        } catch (e: JWTVerificationException) {
            throw InvalidJwtException(e.message ?: "JWT verification failed", e)
        }
        return Claims(
            userId = decoded.subject.toLong(),
            sessionId = UUID.fromString(decoded.getClaim(CLAIM_SESSION).asString()),
            jti = UUID.fromString(decoded.id),
            jwtVersion = decoded.getClaim(CLAIM_VERSION).asInt(),
            issuedAt = decoded.issuedAtAsInstant,
            expiresAt = decoded.expiresAtAsInstant,
        )
    }

    data class IssuedToken(
        val token: String,
        val jti: UUID,
        val expiresAt: Instant,
    )

    data class Claims(
        val userId: Long,
        val sessionId: UUID,
        val jti: UUID,
        val jwtVersion: Int,
        val issuedAt: Instant,
        val expiresAt: Instant,
    )

    companion object {
        private const val CLAIM_SESSION = "sid"
        private const val CLAIM_VERSION = "ver"
    }
}

class InvalidJwtException(message: String, cause: Throwable? = null) :
    RuntimeException(message, cause)
