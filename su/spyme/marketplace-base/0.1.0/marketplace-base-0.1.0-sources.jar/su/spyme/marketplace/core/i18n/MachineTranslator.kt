package su.spyme.marketplace.core.i18n

/**
 * Pluggable machine-translation gateway for admin assistance —
 * pre-fills translation form fields from a source locale, runs over
 * batched form submissions, and seeds initial `*_translations` rows
 * when a host onboards a new market.
 *
 * Implementations are strictly an outbound HTTP gateway concern:
 * they do not persist results, do not own keys (the host injects
 * those), and never throw on partial batch failures — the contract
 * is "best effort, expose per-item status to the caller".
 *
 * Stub implementations live under `i18n.<provider>` packages and are
 * wired manually by hosts (no reflection / classpath scanning); the
 * registry resolves which is active based on `BaseConfig.i18n.translator`.
 *
 * Threading: implementations MUST be safe for concurrent use; admin
 * UIs may fan out fields in parallel.
 */
interface MachineTranslator {

    /** Provider identifier ("yandex" / "google" / "deepl" / "libre" / "noop"). */
    val providerCode: String

    /**
     * Translate a single string. Returns the translated text, or
     * throws [TranslationException] on transport / quota / auth
     * failures.
     *
     * @param text Plain text or HTML — implementation declares which
     *        in its provider docs (most providers accept either with
     *        an explicit format flag).
     * @param from Source locale; null asks the provider to auto-detect.
     * @param to Target locale.
     */
    fun translate(text: String, from: Locale?, to: Locale): String

    /**
     * Bulk variant. Default implementation falls back to per-item
     * [translate]; provider-specific subclasses should override with
     * a single batched HTTP call where the API supports it (Yandex,
     * Google, DeepL all do).
     *
     * Returns one [TranslationResult] per input slot in order. A
     * provider-side per-item failure populates the slot with
     * [TranslationResult.Failure] without aborting the whole batch.
     */
    fun translateBatch(
        texts: List<String>,
        from: Locale?,
        to: Locale,
    ): List<TranslationResult> = texts.map { text ->
        try {
            TranslationResult.Success(translate(text, from, to))
        } catch (ex: TranslationException) {
            TranslationResult.Failure(ex)
        }
    }
}

/**
 * Per-item outcome from [MachineTranslator.translateBatch]. Sealed so
 * callers must handle both branches at a Kotlin `when`.
 */
sealed interface TranslationResult {
    data class Success(val text: String) : TranslationResult
    data class Failure(val cause: TranslationException) : TranslationResult
}

/**
 * Thrown by [MachineTranslator] implementations on irrecoverable
 * failures. Implementations should distinguish quota-exhausted vs.
 * transport vs. auth so admin UIs can render an actionable message.
 */
sealed class TranslationException(message: String, cause: Throwable? = null) : RuntimeException(message, cause) {

    /** Transient (5xx, network reset). Caller may retry with backoff. */
    class Transient(message: String, cause: Throwable? = null) : TranslationException(message, cause)

    /** Provider authentication failed (bad / revoked / missing key). */
    class Unauthorized(message: String, cause: Throwable? = null) : TranslationException(message, cause)

    /** Quota / rate limit hit. Caller should back off until reset window. */
    class QuotaExceeded(message: String, cause: Throwable? = null) : TranslationException(message, cause)

    /** Locale pair not supported by this provider. Caller should fall back to another translator or skip. */
    class UnsupportedLocalePair(message: String) : TranslationException(message)

    /**
     * The provider responded but the response shape couldn't be
     * parsed — typically signals a contract drift on the upstream
     * API.
     */
    class MalformedResponse(message: String, cause: Throwable? = null) : TranslationException(message, cause)
}
