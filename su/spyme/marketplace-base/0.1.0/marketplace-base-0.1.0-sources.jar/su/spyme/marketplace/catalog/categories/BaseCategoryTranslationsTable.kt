package su.spyme.marketplace.catalog.categories

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseCategoryTranslationsTable : Table("category_translations") {
    val categoryId: Column<Long> = long("category_id").references(BaseCategoriesTable.id)
    val locale: Column<String> = varchar("locale", 8)
    val title: Column<String> = text("title")
    val description: Column<String?> = text("description").nullable()
    val isMachineTranslated: Column<Boolean> = bool("is_machine_translated").default(false)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(categoryId, locale)
}
