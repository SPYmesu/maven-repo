package su.spyme.marketplace.core.database

import org.flywaydb.core.Flyway
import org.flywaydb.core.api.output.MigrateResult
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.BaseConfig
import javax.sql.DataSource

class FlywayRunner(
    private val dataSource: DataSource,
    private val environment: BaseConfig.Environment,
    private val locations: List<String> = DEFAULT_LOCATIONS,
) {
    private val log = LoggerFactory.getLogger(FlywayRunner::class.java)

    fun migrate(): MigrateResult {
        val flyway = Flyway.configure()
            .dataSource(dataSource)
            .locations(*locations.toTypedArray())
            .baselineOnMigrate(true)
            .baselineVersion("0")
            .cleanDisabled(environment != BaseConfig.Environment.DEV)
            .table("flyway_schema_history")
            .validateOnMigrate(true)
            .outOfOrder(false)
            .load()

        val result = flyway.migrate()
        if (result.migrationsExecuted == 0) {
            log.info(
                "Flyway: schema up to date (current version: {}, locations: {})",
                result.targetSchemaVersion ?: "<empty>",
                locations.joinToString(),
            )
        } else {
            log.info(
                "Flyway: applied {} migration(s) → version {} (locations: {})",
                result.migrationsExecuted,
                result.targetSchemaVersion,
                locations.joinToString(),
            )
        }
        return result
    }

    /**
     * Drops everything Flyway tracks. ONLY available outside production.
     * Throws on environment != DEV.
     */
    fun clean() {
        require(environment == BaseConfig.Environment.DEV) {
            "Flyway clean is disabled outside DEV (current: $environment)"
        }
        Flyway.configure()
            .dataSource(dataSource)
            .locations(*locations.toTypedArray())
            .cleanDisabled(false)
            .load()
            .clean()
    }

    companion object {
        val DEFAULT_LOCATIONS: List<String> = listOf("classpath:db/migration")
    }
}
