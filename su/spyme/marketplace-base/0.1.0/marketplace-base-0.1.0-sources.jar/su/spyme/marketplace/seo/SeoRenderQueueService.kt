package su.spyme.marketplace.seo

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseSeoRenderQueueTable : Table("seo_render_queue") {
    val id: Column<Long> = long("id").autoIncrement()
    val slug: Column<String> = varchar("slug", 96)
    val kind: Column<String> = varchar("kind", 32)
    val enqueuedAt: Column<Instant> = timestamp("enqueued_at").defaultExpression(NowExpression)
    val attempts: Column<Short> = short("attempts").default(0)
    val lastError: Column<String?> = text("last_error").nullable()
    val renderedAt: Column<Instant?> = timestamp("rendered_at").nullable()

    override val primaryKey = PrimaryKey(id)
}

data class SeoRenderQueueEntry(
    val id: Long,
    val slug: String,
    val kind: String,
    val enqueuedAt: Instant,
    val attempts: Int,
    val lastError: String?,
    val renderedAt: Instant?,
) {
    companion object {
        fun fromRow(row: ResultRow): SeoRenderQueueEntry = SeoRenderQueueEntry(
            id = row[BaseSeoRenderQueueTable.id],
            slug = row[BaseSeoRenderQueueTable.slug],
            kind = row[BaseSeoRenderQueueTable.kind],
            enqueuedAt = row[BaseSeoRenderQueueTable.enqueuedAt],
            attempts = row[BaseSeoRenderQueueTable.attempts].toInt(),
            lastError = row[BaseSeoRenderQueueTable.lastError],
            renderedAt = row[BaseSeoRenderQueueTable.renderedAt],
        )
    }
}

/**
 * Producer + worker hooks for the SEO prerender queue (per М3).
 *
 * Enqueue is idempotent: the partial unique index on (slug, kind)
 * WHERE rendered_at IS NULL ensures repeat updates collapse into one
 * pending row. Producers normally enqueue right after the entity
 * mutation commits; the worker (host module) calls [claimPending]
 * to drain the batch and writes the rendered HTML to the host's
 * data/prerender/ directory before calling [markRendered].
 */
open class SeoRenderQueueService(protected val mainDb: Database) {

    open fun enqueue(slug: String, kind: String) {
        require(slug.isNotBlank()) { "slug must not be blank" }
        require(kind.isNotBlank()) { "kind must not be blank" }

        // Manual ON CONFLICT — Exposed's upsert can't drive the partial
        // unique index condition (WHERE rendered_at IS NULL).
        transaction(mainDb) {
            exec(
                """
                INSERT INTO seo_render_queue (slug, kind)
                VALUES (?, ?)
                ON CONFLICT (slug, kind) WHERE rendered_at IS NULL
                DO UPDATE SET enqueued_at = NOW(), attempts = 0, last_error = NULL
                """.trimIndent(),
                listOf(
                    org.jetbrains.exposed.sql.VarCharColumnType() to slug,
                    org.jetbrains.exposed.sql.VarCharColumnType() to kind,
                ),
            )
        }
    }

    /** Pulls up to [limit] pending rows oldest-first. No locking — single-instance friendly. */
    open fun claimPending(limit: Int = 50): List<SeoRenderQueueEntry> = transaction(mainDb) {
        BaseSeoRenderQueueTable.selectAll()
            .where { BaseSeoRenderQueueTable.renderedAt.isNull() }
            .orderBy(BaseSeoRenderQueueTable.enqueuedAt to SortOrder.ASC)
            .limit(limit)
            .map(SeoRenderQueueEntry::fromRow)
    }

    open fun markRendered(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseSeoRenderQueueTable.update({ BaseSeoRenderQueueTable.id eq id }) {
                it[BaseSeoRenderQueueTable.renderedAt] = now
                it[BaseSeoRenderQueueTable.lastError] = null
            }
        }
    }

    open fun markFailed(id: Long, reason: String) {
        transaction(mainDb) {
            exec(
                "UPDATE seo_render_queue SET attempts = attempts + 1, last_error = ? WHERE id = ?",
                listOf(
                    org.jetbrains.exposed.sql.TextColumnType() to reason.take(MAX_ERROR_LEN),
                    org.jetbrains.exposed.sql.LongColumnType() to id,
                ),
            )
        }
    }

    open fun pendingCount(): Long = transaction(mainDb) {
        BaseSeoRenderQueueTable.selectAll()
            .where { BaseSeoRenderQueueTable.renderedAt.isNull() }
            .count()
    }

    companion object {
        private const val MAX_ERROR_LEN = 4_000
    }
}
