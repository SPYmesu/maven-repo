package su.spyme.marketplace.users

import org.jetbrains.exposed.sql.ResultRow
import java.time.Instant

/**
 * Authenticated marketplace user.
 *
 * Mirrors [BaseUsersTable] one-to-one. Per Б1 the row stays singleton:
 * host extensions live in side-tables (e.g. `user_minecraft_meta`),
 * never as ALTER TABLE on this row.
 *
 * Soft-delete semantics: a user is "deleted" when [deletedAt] is set.
 * The partial unique indexes on `email` and `username` ignore
 * soft-deleted rows so the email/username can be re-registered later.
 *
 * @property roles Role codes from [su.spyme.marketplace.core.auth.RoleRegistry].
 *           Unknown codes (left over from a removed module) are silently
 *           skipped by `hasAtLeast` checks.
 * @property jwtVersion Bumped to invalidate every access token issued
 *           with the previous value. See В1 of the architecture plan.
 */
data class User(
    val id: Long,
    val username: String,
    val email: String,
    val emailVerifiedAt: Instant?,
    val phone: String?,
    val phoneVerifiedAt: Instant?,
    val roles: List<String>,
    val jwtVersion: Int,
    val locale: String,
    val timezone: String?,
    val lastActiveAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
    val deletedAt: Instant?,
) {
    val isDeleted: Boolean get() = deletedAt != null
    val isEmailVerified: Boolean get() = emailVerifiedAt != null
    val isPhoneVerified: Boolean get() = phoneVerifiedAt != null

    companion object {
        /** Maps a [BaseUsersTable] row (or any join including its columns) into a [User]. */
        fun fromRow(row: ResultRow): User = User(
            id = row[BaseUsersTable.id],
            username = row[BaseUsersTable.username],
            email = row[BaseUsersTable.email],
            emailVerifiedAt = row[BaseUsersTable.emailVerifiedAt],
            phone = row[BaseUsersTable.phone],
            phoneVerifiedAt = row[BaseUsersTable.phoneVerifiedAt],
            roles = row[BaseUsersTable.roles],
            jwtVersion = row[BaseUsersTable.jwtVersion],
            locale = row[BaseUsersTable.locale],
            timezone = row[BaseUsersTable.timezone],
            lastActiveAt = row[BaseUsersTable.lastActiveAt],
            createdAt = row[BaseUsersTable.createdAt],
            updatedAt = row[BaseUsersTable.updatedAt],
            deletedAt = row[BaseUsersTable.deletedAt],
        )
    }
}
