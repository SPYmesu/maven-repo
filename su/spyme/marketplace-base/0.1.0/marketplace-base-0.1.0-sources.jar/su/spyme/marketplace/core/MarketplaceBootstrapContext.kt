package su.spyme.marketplace.core

import io.ktor.server.application.Application
import su.spyme.marketplace.core.registry.ConflictRegistry

class MarketplaceBootstrapContext(
    val application: Application,
    val config: BaseConfig,
) {
    private val components = ConflictRegistry<Class<*>, Any>("MarketplaceBootstrapContext")

    fun <T : Any> register(type: Class<T>, instance: T) {
        components.register(type, instance)
    }

    inline fun <reified T : Any> register(instance: T) = register(T::class.java, instance)

    @Suppress("UNCHECKED_CAST")
    fun <T : Any> get(type: Class<T>): T = components.get(type) as T

    inline fun <reified T : Any> get(): T = get(T::class.java)

    @Suppress("UNCHECKED_CAST")
    fun <T : Any> getOrNull(type: Class<T>): T? = components.getOrNull(type) as T?

    inline fun <reified T : Any> getOrNull(): T? = getOrNull(T::class.java)

    fun has(type: Class<*>): Boolean = components.contains(type)
}

class MissingDependencyException(moduleName: String, missingDependency: String) :
    RuntimeException("Module '$moduleName' depends on '$missingDependency' which is not active")
