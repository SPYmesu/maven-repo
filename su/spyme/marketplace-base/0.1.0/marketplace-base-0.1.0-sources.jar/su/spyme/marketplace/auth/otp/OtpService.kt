package su.spyme.marketplace.auth.otp

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import java.security.SecureRandom
import java.time.Duration
import java.time.Instant

enum class OtpChannel(val sqlValue: String) {
    EMAIL("email"), SMS("sms"), TG_BOT("tg-bot"), VK_BOT("vk-bot"),
    TOTP("totp"), EMAIL_2FA("email-2fa"), SMS_2FA("sms-2fa");

    companion object {
        fun parse(value: String): OtpChannel = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown OtpChannel: '$value'")
    }
}

enum class OtpPurpose(val sqlValue: String) {
    LOGIN("login"), REGISTER("register"), VERIFY_EMAIL("verify-email"),
    VERIFY_PHONE("verify-phone"), RESET_PASSWORD("reset-password"),
    LINK_SOCIAL("link-social"), TWO_FA_STEP("2fa-step"), GDPR_DELETE("gdpr-delete");

    companion object {
        fun parse(value: String): OtpPurpose = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown OtpPurpose: '$value'")
    }
}

enum class OtpStatus {
    PENDING, REDEEMED, EXPIRED;

    companion object {
        fun parse(value: String): OtpStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown OtpStatus: '$value'")
    }
}

object BaseOtpCodesTable : Table("otp_codes") {
    val code: Column<String> = varchar("code", 128)
    val userId: Column<Long?> = long("user_id").nullable()
    val channel: Column<String> = varchar("channel", 32)
    val purpose: Column<String> = varchar("purpose", 32)
    val recipient: Column<String> = varchar("recipient", 255)
    val payload: Column<JsonElement?> = jsonb("payload", Json, JsonElement.serializer()).nullable()
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val attempts: Column<Short> = short("attempts").default(0)
    val expiresAt: Column<Instant> = timestamp("expires_at")
    val redeemedAt: Column<Instant?> = timestamp("redeemed_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(code)
}

data class OtpCode(
    val code: String,
    val userId: Long?,
    val channel: OtpChannel,
    val purpose: OtpPurpose,
    val recipient: String,
    val payload: JsonElement?,
    val status: OtpStatus,
    val attempts: Int,
    val expiresAt: Instant,
    val redeemedAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isPending: Boolean get() = status == OtpStatus.PENDING
    val isExpired: Boolean get() = expiresAt.isBefore(Instant.now())

    companion object {
        fun fromRow(row: ResultRow): OtpCode = OtpCode(
            code = row[BaseOtpCodesTable.code],
            userId = row[BaseOtpCodesTable.userId],
            channel = OtpChannel.parse(row[BaseOtpCodesTable.channel]),
            purpose = OtpPurpose.parse(row[BaseOtpCodesTable.purpose]),
            recipient = row[BaseOtpCodesTable.recipient],
            payload = row[BaseOtpCodesTable.payload],
            status = OtpStatus.parse(row[BaseOtpCodesTable.status]),
            attempts = row[BaseOtpCodesTable.attempts].toInt(),
            expiresAt = row[BaseOtpCodesTable.expiresAt],
            redeemedAt = row[BaseOtpCodesTable.redeemedAt],
            createdAt = row[BaseOtpCodesTable.createdAt],
            updatedAt = row[BaseOtpCodesTable.updatedAt],
        )
    }
}

/** Result of [OtpService.redeem] — typed so the caller maps each to a 4xx reason. */
sealed class OtpRedeemResult {
    data class Redeemed(val otp: OtpCode) : OtpRedeemResult()
    data object NotFound : OtpRedeemResult()
    data object Expired : OtpRedeemResult()
    data object AlreadyRedeemed : OtpRedeemResult()
    data class TooManyAttempts(val attempts: Int) : OtpRedeemResult()
}

/**
 * Unified one-time-code service. Generates, redeems, and sweeps stale
 * OTPs for every channel × purpose combination (per the architecture
 * plan's `auth-otp-codes` shared infra).
 *
 * Code shape is channel-specific: the caller picks the alphabet/length
 * (6-digit numeric for SMS, 8-char alphanumeric for email magic link,
 * etc.). [generateNumeric] and [generateAlphanumeric] are convenience
 * factories.
 */
open class OtpService(
    protected val mainDb: Database,
    protected val cronDb: Database,
    private val maxAttempts: Int = 5,
) {

    /**
     * Issues a fresh OTP. The caller has already chosen the [code]
     * (typically via [generateNumeric] / [generateAlphanumeric]). The
     * returned [OtpCode] carries the inserted row.
     */
    open fun issue(
        code: String,
        channel: OtpChannel,
        purpose: OtpPurpose,
        recipient: String,
        ttl: Duration,
        userId: Long? = null,
        payload: JsonElement? = null,
        now: Instant = Instant.now(),
    ): OtpCode {
        require(code.isNotBlank()) { "code must not be blank" }
        require(code.length <= 128) { "code must fit VARCHAR(128)" }
        require(recipient.isNotBlank()) { "recipient must not be blank" }
        require(!ttl.isNegative && !ttl.isZero) { "ttl must be positive" }

        return transaction(mainDb) {
            BaseOtpCodesTable.insert {
                it[BaseOtpCodesTable.code] = code
                it[BaseOtpCodesTable.userId] = userId
                it[BaseOtpCodesTable.channel] = channel.sqlValue
                it[BaseOtpCodesTable.purpose] = purpose.sqlValue
                it[BaseOtpCodesTable.recipient] = recipient
                it[BaseOtpCodesTable.payload] = payload
                it[BaseOtpCodesTable.expiresAt] = now.plus(ttl)
            }
            BaseOtpCodesTable.selectAll()
                .where { BaseOtpCodesTable.code eq code }
                .first()
                .let(OtpCode::fromRow)
        }
    }

    /**
     * Atomic redeem: validates code, expiry, attempts cap, and flips
     * the row to REDEEMED inside one transaction. Returns a typed
     * result so the auth flow can map each branch to a distinct 4xx.
     */
    open fun redeem(
        code: String,
        purpose: OtpPurpose,
        now: Instant = Instant.now(),
    ): OtpRedeemResult = transaction(mainDb) {
        val row = BaseOtpCodesTable.selectAll()
            .where { BaseOtpCodesTable.code eq code }
            .firstOrNull()
            ?.let(OtpCode::fromRow)
            ?: return@transaction OtpRedeemResult.NotFound
        if (row.purpose != purpose) return@transaction OtpRedeemResult.NotFound
        if (row.status == OtpStatus.REDEEMED) return@transaction OtpRedeemResult.AlreadyRedeemed
        if (row.attempts >= maxAttempts) {
            BaseOtpCodesTable.update({ BaseOtpCodesTable.code eq code }) {
                it[BaseOtpCodesTable.status] = OtpStatus.EXPIRED.name
            }
            return@transaction OtpRedeemResult.TooManyAttempts(row.attempts)
        }
        if (row.isExpired) {
            BaseOtpCodesTable.update({ BaseOtpCodesTable.code eq code }) {
                it[BaseOtpCodesTable.status] = OtpStatus.EXPIRED.name
            }
            return@transaction OtpRedeemResult.Expired
        }
        BaseOtpCodesTable.update({ BaseOtpCodesTable.code eq code }) {
            it[BaseOtpCodesTable.status] = OtpStatus.REDEEMED.name
            it[BaseOtpCodesTable.redeemedAt] = now
        }
        OtpRedeemResult.Redeemed(row.copy(status = OtpStatus.REDEEMED, redeemedAt = now))
    }

    /** Counts a failed verify against the row without flipping its status. */
    open fun bumpAttempts(code: String) {
        transaction(mainDb) {
            exec(
                "UPDATE otp_codes SET attempts = attempts + 1 WHERE code = ?",
                listOf(org.jetbrains.exposed.sql.VarCharColumnType() to code),
            )
        }
    }

    open fun findByCode(code: String): OtpCode? = transaction(mainDb) {
        BaseOtpCodesTable.selectAll()
            .where { BaseOtpCodesTable.code eq code }
            .firstOrNull()
            ?.let(OtpCode::fromRow)
    }

    /** "Is there an active OTP this user can use right now?" — drives "resend" UI throttling. */
    open fun findActiveFor(recipient: String, purpose: OtpPurpose, now: Instant = Instant.now()): OtpCode? =
        transaction(mainDb) {
            BaseOtpCodesTable.selectAll()
                .where {
                    (BaseOtpCodesTable.recipient eq recipient) and
                        (BaseOtpCodesTable.purpose eq purpose.sqlValue) and
                        (BaseOtpCodesTable.status eq OtpStatus.PENDING.name)
                }
                .firstOrNull()
                ?.let(OtpCode::fromRow)
                ?.takeIf { it.expiresAt.isAfter(now) }
        }

    /**
     * Cron sweep: flips expired pending rows to EXPIRED + drops rows
     * older than [retention]. Returns the number of expired flips.
     */
    open fun cleanupExpired(retention: Duration = Duration.ofDays(30), now: Instant = Instant.now()): Int =
        transaction(cronDb) {
            // Flip pending → expired.
            val flipped = BaseOtpCodesTable.update({
                (BaseOtpCodesTable.status eq OtpStatus.PENDING.name) and
                    BaseOtpCodesTable.expiresAt.less(now)
            }) {
                it[BaseOtpCodesTable.status] = OtpStatus.EXPIRED.name
            }
            // Hard-delete records older than retention.
            val cutoff = now.minus(retention)
            exec(
                "DELETE FROM otp_codes WHERE created_at < ?",
                listOf(org.jetbrains.exposed.sql.javatime.JavaInstantColumnType() to cutoff),
            )
            flipped
        }

    private fun org.jetbrains.exposed.sql.Column<Instant>.less(value: Instant) =
        org.jetbrains.exposed.sql.Op.build { this@less less value }

    companion object {
        private val NUMERIC_RNG = SecureRandom()
        private val ALPHANUM_ALPHABET =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".toCharArray()

        /** N-digit numeric code (for SMS / Telegram). */
        fun generateNumeric(length: Int = 6): String {
            require(length in 4..10) { "numeric OTP length should be 4..10, was $length" }
            val sb = StringBuilder(length)
            repeat(length) { sb.append(NUMERIC_RNG.nextInt(10)) }
            return sb.toString()
        }

        /** N-char base62 token (for email magic links / link-social tokens). */
        fun generateAlphanumeric(length: Int = 32): String {
            require(length in 8..128) { "alphanumeric OTP length should be 8..128, was $length" }
            val sb = StringBuilder(length)
            repeat(length) { sb.append(ALPHANUM_ALPHABET[NUMERIC_RNG.nextInt(ALPHANUM_ALPHABET.size)]) }
            return sb.toString()
        }
    }
}
