package su.spyme.marketplace.i18n.deepl

import su.spyme.marketplace.core.i18n.Locale
import su.spyme.marketplace.core.i18n.MachineTranslator
import su.spyme.marketplace.core.i18n.TranslationException

/**
 * Stub for DeepL API integration. DeepL has the strictest quality
 * for European-language pairs and is the preferred default for hosts
 * targeting EU markets — Yandex / Google are overall fallbacks.
 *
 * ## Endpoints
 *  - Pro: `https://api.deepl.com/v2/translate`
 *  - Free tier: `https://api-free.deepl.com/v2/translate` — same
 *    contract, different rate limits. Pick via [endpointUrl] at
 *    construction.
 *
 * ## Auth
 *  `Authorization: DeepL-Auth-Key <apiKey>` header.
 *
 * ## Request (form-encoded body)
 *  - `text` — repeated for batch
 *  - `source_lang` — optional, e.g. `EN`. Note: ALL CAPS, not
 *    BCP-47 — translate locale on the way out.
 *  - `target_lang` — required, e.g. `RU`
 *  - `formality` — optional `more` / `less` (only certain target langs)
 *
 * ## Response
 *  ```
 *  {
 *    "translations": [{
 *      "detected_source_language": "EN",
 *      "text": "..."
 *    }]
 *  }
 *  ```
 *
 * ## Quota
 *  Free: 500K chars/mo. Pro: per 1M chars + monthly subscription.
 *  HTTP 456 → quota exceeded; HTTP 429 → temporary rate limit.
 *
 * @property apiKey DeepL auth key (free-tier keys end in `:fx`).
 * @property endpointUrl Pick `api.deepl.com` (Pro) or
 *           `api-free.deepl.com` (Free) depending on plan.
 */
open class DeepLMachineTranslator(
    protected val apiKey: String,
    protected val endpointUrl: String = "https://api.deepl.com/v2/translate",
) : MachineTranslator {

    override val providerCode: String = PROVIDER_CODE

    override fun translate(text: String, from: Locale?, to: Locale): String {
        throw TranslationException.Unauthorized(
            "DeepLMachineTranslator is a stub. Override translate() with a real HTTP call. " +
                "Note: DeepL accepts UPPERCASE locale codes, not BCP-47 — convert in the override.",
        )
    }

    /**
     * Helper for subclasses: DeepL expects `EN`/`RU`/`PT-BR`, not
     * `en`/`ru`/`pt-BR`. Call this when building the request body.
     */
    protected fun toDeepLLocale(locale: Locale): String =
        if (locale.region != null) "${locale.language.uppercase()}-${locale.region!!.uppercase()}"
        else locale.language.uppercase()

    companion object {
        const val PROVIDER_CODE = "deepl"
    }
}
