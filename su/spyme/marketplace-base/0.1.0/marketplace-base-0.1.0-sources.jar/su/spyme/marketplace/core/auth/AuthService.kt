package su.spyme.marketplace.core.auth

import su.spyme.marketplace.core.BaseConfig
import su.spyme.marketplace.users.User
import su.spyme.marketplace.users.UserSession
import su.spyme.marketplace.users.UserSessionsService
import su.spyme.marketplace.users.UsersServiceBase
import java.time.Instant
import java.util.UUID

/**
 * Skeleton auth service. The "credential" (password / OTP / social /
 * passkey) is *outside* this class — auth-* modules drive their own
 * verification, then call [login] with a known user id. This service
 * owns: session creation, JWT minting, revocation checks.
 *
 * Refresh tokens are intentionally absent here — they land in a
 * follow-up commit alongside the auth-password module (E12).
 */
open class AuthService(
    protected val users: UsersServiceBase,
    protected val sessions: UserSessionsService,
    protected val jwt: JwtService,
    protected val authConfig: BaseConfig.Auth,
) {

    /**
     * Mints an access token bound to a freshly created session row.
     * The caller has already authenticated the user out-of-band.
     */
    open fun login(
        userId: Long,
        deviceLabel: String? = null,
        ip: String? = null,
        userAgent: String? = null,
        now: Instant = Instant.now(),
    ): AuthResult {
        val user = users.findById(userId) ?: throw AuthException.UserNotFound(userId)
        if (user.isDeleted) throw AuthException.UserDeleted(userId)

        val sessionId = UUID.randomUUID()
        val jti = UUID.randomUUID()
        val expiresAt = now.plusSeconds(authConfig.jwtAccessTtl.inWholeSeconds)

        val session = sessions.create(
            userId = userId,
            jti = jti,
            expiresAt = expiresAt,
            deviceLabel = deviceLabel,
            ip = ip,
            userAgent = userAgent,
            sessionId = sessionId,
            now = now,
        )

        val issued = jwt.issue(
            userId = userId,
            sessionId = session.id,
            jwtVersion = user.jwtVersion,
            jti = jti,
            issuedAt = now,
        )

        return AuthResult(user = user, session = session, accessToken = issued.token, expiresAt = issued.expiresAt)
    }

    open fun logout(sessionId: UUID): Boolean = sessions.revoke(sessionId)

    open fun logoutAllExceptCurrent(userId: Long, keepSessionId: UUID): Int =
        sessions.revokeAllExceptCurrent(userId, keepSessionId)

    /** Bulk-revoke: bumps users.jwt_version AND revokes every session. */
    open fun logoutEverywhere(userId: Long): Int {
        users.bumpJwtVersion(userId)
        return sessions.revokeAllByUser(userId)
    }

    /**
     * Validates the access token end-to-end:
     *  1. JWT signature + iss + exp (cheap, no DB).
     *  2. user exists, not soft-deleted.
     *  3. user.jwt_version == claim.ver (bulk-revoke check).
     *  4. user_sessions row exists, not revoked, not expired.
     */
    open fun verifyAccessToken(token: String, now: Instant = Instant.now()): VerifiedAuth {
        val claims = jwt.verify(token) // throws InvalidJwtException

        val user = users.findById(claims.userId)
            ?: throw AuthException.UserNotFound(claims.userId)
        if (user.isDeleted) throw AuthException.UserDeleted(claims.userId)
        if (user.jwtVersion != claims.jwtVersion) throw AuthException.TokenRevoked(claims.userId, claims.sessionId, "jwt_version mismatch")

        val session = sessions.findById(claims.sessionId)
            ?: throw AuthException.SessionNotFound(claims.sessionId)
        if (session.userId != claims.userId) throw AuthException.SessionUserMismatch(claims.sessionId, claims.userId)
        if (session.isRevoked) throw AuthException.TokenRevoked(claims.userId, claims.sessionId, "session revoked")
        if (session.expiresAt.isBefore(now)) throw AuthException.SessionExpired(claims.sessionId)

        return VerifiedAuth(user = user, session = session, claims = claims)
    }

    data class AuthResult(
        val user: User,
        val session: UserSession,
        val accessToken: String,
        val expiresAt: Instant,
    )

    data class VerifiedAuth(
        val user: User,
        val session: UserSession,
        val claims: JwtService.Claims,
    )
}

sealed class AuthException(message: String) : RuntimeException(message) {
    class UserNotFound(val userId: Long) : AuthException("User $userId not found")
    class UserDeleted(val userId: Long) : AuthException("User $userId is soft-deleted")
    class SessionNotFound(val sessionId: UUID) : AuthException("Session $sessionId not found")
    class SessionExpired(val sessionId: UUID) : AuthException("Session $sessionId expired")
    class SessionUserMismatch(val sessionId: UUID, val claimUserId: Long) :
        AuthException("Session $sessionId belongs to a different user than claim sub=$claimUserId")
    class TokenRevoked(val userId: Long, val sessionId: UUID, val why: String) :
        AuthException("Access token for user $userId / session $sessionId revoked: $why")
}
