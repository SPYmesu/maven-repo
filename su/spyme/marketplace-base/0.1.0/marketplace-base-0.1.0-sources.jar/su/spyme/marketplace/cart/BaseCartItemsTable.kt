package su.spyme.marketplace.cart

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Exposed mapping for V009.cart_items. Two ownership modes share the
 * row shape; the SQL CHECK constraint forces exactly one of
 * `userId` / `guestToken` to be non-null.
 */
object BaseCartItemsTable : Table("cart_items") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long?> = long("user_id").nullable()
    val guestToken: Column<String?> = varchar("guest_token", 64).nullable()
    val productId: Column<Long> = long("product_id")
    val variantId: Column<Long?> = long("variant_id").nullable()
    val quantity: Column<Int> = integer("quantity").default(1)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Single line in a shopping cart.
 *
 * @property userId Set for authenticated shoppers; mutually exclusive
 *           with [guestToken].
 * @property guestToken Set for anonymous shoppers; rotated by the
 *           host when the cookie expires.
 * @property variantId Selected variant; null for products without a
 *           variant matrix.
 */
data class CartItem(
    val id: Long,
    val userId: Long?,
    val guestToken: String?,
    val productId: Long,
    val variantId: Long?,
    val quantity: Int,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val ownerKey: String
        get() = userId?.let { "user:$it" } ?: "guest:${guestToken!!}"

    companion object {
        fun fromRow(row: ResultRow): CartItem = CartItem(
            id = row[BaseCartItemsTable.id],
            userId = row[BaseCartItemsTable.userId],
            guestToken = row[BaseCartItemsTable.guestToken],
            productId = row[BaseCartItemsTable.productId],
            variantId = row[BaseCartItemsTable.variantId],
            quantity = row[BaseCartItemsTable.quantity],
            createdAt = row[BaseCartItemsTable.createdAt],
            updatedAt = row[BaseCartItemsTable.updatedAt],
        )
    }
}
