package su.spyme.marketplace.catalog.attributes

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import org.jetbrains.exposed.sql.ResultRow
import java.time.Instant

/**
 * Storage shape of an EAV attribute value. Stored as a VARCHAR + CHECK
 * constraint at the SQL layer (soft-typing per the architecture plan)
 * — adding a new type is a single-line CHECK migration.
 *
 * - `STRING` / `TEXT` — short / long localized text (translatable).
 * - `INT` / `DECIMAL` — numeric; `unit` and `validation` describe
 *   bounds and unit suffix.
 * - `BOOL` / `DATE` / `DATETIME` — primitives.
 * - `ENUM` / `ENUM_MULTI` — single / multi pick from a fixed set;
 *   `enumValues` carries the codes, label translations live in
 *   `attribute_enum_value_translations`.
 * - `FILE_REF` — points at an `uploads.id`.
 * - `URL` — raw URL string; storefront renders as a link.
 */
enum class AttributeDataType {
    STRING, TEXT, INT, DECIMAL, BOOL, DATE, DATETIME,
    ENUM, ENUM_MULTI, FILE_REF, URL;

    companion object {
        /** @throws IllegalArgumentException if [value] doesn't match a known data type name. */
        fun parse(value: String): AttributeDataType = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown AttributeDataType: '$value'")
    }
}

/**
 * EAV attribute definition. One row per logical attribute (`COLOR`,
 * `WEIGHT_KG`, `RELEASE_DATE`); products attach values to these
 * definitions via `product_attribute_values`.
 *
 * Lifecycle uses [archivedAt] as a soft-delete marker — archived rows
 * stay reachable so historical product values keep rendering, but new
 * products no longer see them in the editor.
 *
 * @property code Canonical UPPER_CASE identifier, ≤64 chars. Unique.
 * @property isGlobal If true, the attribute auto-applies to every
 *           category without an explicit binding.
 * @property isVariant If true, this attribute defines product variants
 *           (e.g. `SIZE`, `COLOR` form per-variant axes).
 * @property isFacet Surfaced as a faceted filter on the storefront.
 * @property isSearchable Included in the MeiliSearch index body.
 * @property isProtected Seed-driven; admin UI hides edit/delete for
 *           this row to prevent accidental damage to load-bearing
 *           attributes.
 * @property isRequiredDefault Default required state; per-binding
 *           overrides live in [CategoryAttributeBinding.isRequired].
 * @property isPublic Visible on the storefront card; admin-only when
 *           false.
 * @property enumValues Canonical option codes (ENUM/ENUM_MULTI). Null
 *           for other data types.
 * @property validation JSONB-encoded extra validation rules
 *           (`{"min": 0, "max": 100, "pattern": "..."}`). Shape
 *           depends on `dataType`.
 */
data class AttributeDefinition(
    val id: Long,
    val code: String,
    val dataType: AttributeDataType,
    val labelI18nKey: String?,
    val isGlobal: Boolean,
    val isVariant: Boolean,
    val isFacet: Boolean,
    val isSearchable: Boolean,
    val isProtected: Boolean,
    val isRequiredDefault: Boolean,
    val isPublic: Boolean,
    val enumValues: List<String>?,
    val validation: JsonElement?,
    val unit: String?,
    val sortOrder: Int,
    val archivedAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isArchived: Boolean get() = archivedAt != null

    companion object {
        fun fromRow(row: ResultRow): AttributeDefinition = AttributeDefinition(
            id = row[BaseAttributeDefinitionsTable.id],
            code = row[BaseAttributeDefinitionsTable.code],
            dataType = AttributeDataType.parse(row[BaseAttributeDefinitionsTable.dataType]),
            labelI18nKey = row[BaseAttributeDefinitionsTable.labelI18nKey],
            isGlobal = row[BaseAttributeDefinitionsTable.isGlobal],
            isVariant = row[BaseAttributeDefinitionsTable.isVariant],
            isFacet = row[BaseAttributeDefinitionsTable.isFacet],
            isSearchable = row[BaseAttributeDefinitionsTable.isSearchable],
            isProtected = row[BaseAttributeDefinitionsTable.isProtected],
            isRequiredDefault = row[BaseAttributeDefinitionsTable.isRequiredDefault],
            isPublic = row[BaseAttributeDefinitionsTable.isPublic],
            enumValues = row[BaseAttributeDefinitionsTable.enumValues]
                ?.jsonArray
                ?.map { it.jsonPrimitive.content },
            validation = row[BaseAttributeDefinitionsTable.validation],
            unit = row[BaseAttributeDefinitionsTable.unit],
            sortOrder = row[BaseAttributeDefinitionsTable.sortOrder],
            archivedAt = row[BaseAttributeDefinitionsTable.archivedAt],
            createdAt = row[BaseAttributeDefinitionsTable.createdAt],
            updatedAt = row[BaseAttributeDefinitionsTable.updatedAt],
        )
    }
}

/**
 * Many-to-many edge between a category and an attribute definition.
 *
 * @property isRequired Per-binding override of
 *           [AttributeDefinition.isRequiredDefault]. NULL means
 *           "inherit definition default".
 */
data class CategoryAttributeBinding(
    val categoryId: Long,
    val attributeId: Long,
    val sortOrder: Int,
    val isRequired: Boolean?,
) {
    companion object {
        fun fromRow(row: ResultRow): CategoryAttributeBinding = CategoryAttributeBinding(
            categoryId = row[BaseCategoryAttributesTable.categoryId],
            attributeId = row[BaseCategoryAttributesTable.attributeId],
            sortOrder = row[BaseCategoryAttributesTable.sortOrder],
            isRequired = row[BaseCategoryAttributesTable.isRequired],
        )
    }
}
