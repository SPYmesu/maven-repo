package su.spyme.marketplace.catalog.products

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.catalog.attributes.BaseAttributeDefinitionsTable
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * No declared primary key — uniqueness is enforced by the SQL
 * expression index on (product_id, attribute_id, COALESCE(locale, '')).
 * Service-level CRUD reads (product_id, attribute_id, locale) tuples.
 */
object BaseProductAttributeValuesTable : Table("product_attribute_values") {
    val productId: Column<Long> = long("product_id").references(BaseProductsTable.id)
    val attributeId: Column<Long> = long("attribute_id").references(BaseAttributeDefinitionsTable.id)
    val locale: Column<String?> = varchar("locale", 8).nullable()
    val value: Column<JsonElement> = jsonb("value", Json, JsonElement.serializer())
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)
}
