package su.spyme.marketplace.apikeys

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant
import java.util.UUID

object BaseApiKeysTable : Table("api_keys") {
    val id: Column<UUID> = uuid("id")
    val name: Column<String> = varchar("name", 128)
    val keyHash: Column<String> = varchar("key_hash", 64)
    val keySalt: Column<ByteArray> = binary("key_salt")
    val keyPrefix: Column<String> = varchar("key_prefix", 64)
    val env: Column<String> = varchar("env", 8)
    val scopeType: Column<String> = varchar("scope_type", 16)
    val scopeUserId: Column<Long?> = long("scope_user_id").nullable()
    val scopeVendorId: Column<Long?> = long("scope_vendor_id").nullable()
    val rateLimitPerMinute: Column<Int?> = integer("rate_limit_per_minute").nullable()
    val isUnlimited: Column<Boolean> = bool("is_unlimited").default(false)
    val lastUsedAt: Column<Instant?> = timestamp("last_used_at").nullable()
    val expiresAt: Column<Instant?> = timestamp("expires_at").nullable()
    val revokedAt: Column<Instant?> = timestamp("revoked_at").nullable()
    val revokedByUserId: Column<Long?> = long("revoked_by_user_id").nullable()
    val createdByUserId: Column<Long?> = long("created_by_user_id").nullable()
    val metadata: Column<JsonElement?> = jsonb("metadata", Json, JsonElement.serializer()).nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Persisted API key — never carries the plaintext value. Use
 * [keyPrefix] for UI display, [keyHash] + [keySalt] for verification.
 *
 * @property scopeUserId Set when scopeType=USER; null otherwise.
 * @property scopeVendorId Set when scopeType=VENDOR; null otherwise.
 * @property isUnlimited Bypasses rate limiting — admin-only flag for
 *           service keys (ozonbot integration etc.).
 */
data class ApiKey(
    val id: UUID,
    val name: String,
    val keyHash: String,
    val keySalt: ByteArray,
    val keyPrefix: String,
    val env: ApiKeyEnv,
    val scopeType: ApiKeyScopeType,
    val scopeUserId: Long?,
    val scopeVendorId: Long?,
    val rateLimitPerMinute: Int?,
    val isUnlimited: Boolean,
    val lastUsedAt: Instant?,
    val expiresAt: Instant?,
    val revokedAt: Instant?,
    val revokedByUserId: Long?,
    val createdByUserId: Long?,
    val metadata: JsonElement?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isActive: Boolean
        get() = revokedAt == null && (expiresAt == null || expiresAt.isAfter(Instant.now()))
    val isRevoked: Boolean get() = revokedAt != null
    val isExpired: Boolean get() = expiresAt != null && expiresAt.isBefore(Instant.now())

    override fun equals(other: Any?): Boolean = other is ApiKey && id == other.id
    override fun hashCode(): Int = id.hashCode()

    companion object {
        fun fromRow(row: ResultRow): ApiKey = ApiKey(
            id = row[BaseApiKeysTable.id],
            name = row[BaseApiKeysTable.name],
            keyHash = row[BaseApiKeysTable.keyHash],
            keySalt = row[BaseApiKeysTable.keySalt],
            keyPrefix = row[BaseApiKeysTable.keyPrefix],
            env = ApiKeyEnv.parse(row[BaseApiKeysTable.env]),
            scopeType = ApiKeyScopeType.parse(row[BaseApiKeysTable.scopeType]),
            scopeUserId = row[BaseApiKeysTable.scopeUserId],
            scopeVendorId = row[BaseApiKeysTable.scopeVendorId],
            rateLimitPerMinute = row[BaseApiKeysTable.rateLimitPerMinute],
            isUnlimited = row[BaseApiKeysTable.isUnlimited],
            lastUsedAt = row[BaseApiKeysTable.lastUsedAt],
            expiresAt = row[BaseApiKeysTable.expiresAt],
            revokedAt = row[BaseApiKeysTable.revokedAt],
            revokedByUserId = row[BaseApiKeysTable.revokedByUserId],
            createdByUserId = row[BaseApiKeysTable.createdByUserId],
            metadata = row[BaseApiKeysTable.metadata],
            createdAt = row[BaseApiKeysTable.createdAt],
            updatedAt = row[BaseApiKeysTable.updatedAt],
        )
    }
}
