package su.spyme.marketplace.orders.cancellation

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Structured cancellation reason recorded on
 * `orders.cancellation_reason_code` (V010). Each reason carries
 * metadata that drives downstream UX:
 *
 * @property code UPPER_CASE identifier persisted in the SQL row, ≤32
 *           chars to fit `VARCHAR(32)`.
 * @property labelI18nKey Lookup key for the localized display label.
 *           Hosts wire this up in their i18n bundles; the raw code
 *           is the storefront-default fallback.
 * @property blocksReorder When true, the "buy again" button is
 *           disabled for orders cancelled with this reason — typically
 *           OUT_OF_STOCK (refilling the same line ends up at the same
 *           dead end).
 * @property suggestProductAction Hint to the admin UI for follow-up
 *           on the underlying product. Non-null examples:
 *           `"archive"` for OUT_OF_STOCK so the admin can retire the
 *           SKU with one click; `"investigate"` for FRAUD_SUSPECTED.
 * @property requiredText When true, the cancellation flow forces the
 *           actor to type a free-form `cancellation_reason_text` (e.g.
 *           OTHER — "tell us what actually happened").
 */
data class CancellationReason(
    val code: String,
    val labelI18nKey: String,
    val blocksReorder: Boolean = false,
    val suggestProductAction: String? = null,
    val requiredText: Boolean = false,
) {
    init {
        require(code.isNotBlank()) { "code must not be blank" }
        require(code.length <= 32) { "code must fit VARCHAR(32): $code" }
        require(code == code.uppercase()) { "code must be UPPER_CASE: $code" }
    }
}

/**
 * Registry of recognised cancellation reasons. Hosts and modules
 * (e.g. `gdpr-deletion`) register their own codes during the
 * bootstrap registration phase. Order-cancellation code paths
 * validate against this registry — an unknown code throws and the
 * admin/UI is forced to pick a real one.
 *
 * Use [withDefaults] for the ten canonical codes from the
 * architecture plan.
 */
class CancellationReasonRegistry {
    private val backing = ConflictRegistry<String, CancellationReason>("CancellationReasonRegistry")

    fun register(reason: CancellationReason) {
        backing.register(reason.code, reason)
    }

    fun get(code: String): CancellationReason = backing.get(code)
    fun getOrNull(code: String): CancellationReason? = backing.getOrNull(code)
    fun isValid(code: String): Boolean = backing.contains(code)
    fun all(): List<CancellationReason> = backing.values().toList()

    companion object {
        // Ten canonical reasons from the architecture plan.
        val USER_REQUESTED = CancellationReason(
            code = "USER_REQUESTED",
            labelI18nKey = "orders.cancellation.user_requested",
        )
        val OUT_OF_STOCK = CancellationReason(
            code = "OUT_OF_STOCK",
            labelI18nKey = "orders.cancellation.out_of_stock",
            blocksReorder = true,
            suggestProductAction = "archive",
        )
        val PAYMENT_FAILED = CancellationReason(
            code = "PAYMENT_FAILED",
            labelI18nKey = "orders.cancellation.payment_failed",
        )
        val PAYMENT_TIMEOUT = CancellationReason(
            code = "PAYMENT_TIMEOUT",
            labelI18nKey = "orders.cancellation.payment_timeout",
        )
        val MANAGER_DECLINED = CancellationReason(
            code = "MANAGER_DECLINED",
            labelI18nKey = "orders.cancellation.manager_declined",
            requiredText = true,
        )
        val DELIVERY_FAILED = CancellationReason(
            code = "DELIVERY_FAILED",
            labelI18nKey = "orders.cancellation.delivery_failed",
        )
        val DAMAGED_ITEM = CancellationReason(
            code = "DAMAGED_ITEM",
            labelI18nKey = "orders.cancellation.damaged_item",
        )
        val WRONG_ITEM = CancellationReason(
            code = "WRONG_ITEM",
            labelI18nKey = "orders.cancellation.wrong_item",
        )
        val FRAUD_SUSPECTED = CancellationReason(
            code = "FRAUD_SUSPECTED",
            labelI18nKey = "orders.cancellation.fraud_suspected",
            blocksReorder = true,
            suggestProductAction = "investigate",
            requiredText = true,
        )
        val OTHER = CancellationReason(
            code = "OTHER",
            labelI18nKey = "orders.cancellation.other",
            requiredText = true,
        )

        /** Returns a registry pre-loaded with the ten canonical reasons. */
        fun withDefaults(): CancellationReasonRegistry = CancellationReasonRegistry().apply {
            listOf(
                USER_REQUESTED, OUT_OF_STOCK, PAYMENT_FAILED, PAYMENT_TIMEOUT,
                MANAGER_DECLINED, DELIVERY_FAILED, DAMAGED_ITEM, WRONG_ITEM,
                FRAUD_SUSPECTED, OTHER,
            ).forEach(::register)
        }
    }
}
