package su.spyme.marketplace.catalog.categories

import org.jetbrains.exposed.sql.ResultRow
import java.time.Instant

/**
 * Catalog category node. Self-referencing via [parentId]: a `null`
 * value marks a top-level (root) category. Slugs are unique per
 * parent — sibling slugs never clash, but two parents may both
 * contain a `phones` child.
 *
 * @property sortOrder Manual ordering inside the admin UI; ascending.
 * @property isActive Storefront visibility; admin can hide a branch
 *           without deleting it.
 */
data class Category(
    val id: Long,
    val parentId: Long?,
    val slug: String,
    val sortOrder: Int,
    val isActive: Boolean,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isRoot: Boolean get() = parentId == null

    companion object {
        fun fromRow(row: ResultRow): Category = Category(
            id = row[BaseCategoriesTable.id],
            parentId = row[BaseCategoriesTable.parentId],
            slug = row[BaseCategoriesTable.slug],
            sortOrder = row[BaseCategoriesTable.sortOrder],
            isActive = row[BaseCategoriesTable.isActive],
            createdAt = row[BaseCategoriesTable.createdAt],
            updatedAt = row[BaseCategoriesTable.updatedAt],
        )
    }
}

/**
 * Per-locale display strings for a [Category]. (categoryId, locale)
 * is the composite key. [isMachineTranslated] marks rows that came
 * from the "🤖 translate" admin button so they can be reviewed before
 * publication.
 */
data class CategoryTranslation(
    val categoryId: Long,
    val locale: String,
    val title: String,
    val description: String?,
    val isMachineTranslated: Boolean,
) {
    companion object {
        fun fromRow(row: ResultRow): CategoryTranslation = CategoryTranslation(
            categoryId = row[BaseCategoryTranslationsTable.categoryId],
            locale = row[BaseCategoryTranslationsTable.locale],
            title = row[BaseCategoryTranslationsTable.title],
            description = row[BaseCategoryTranslationsTable.description],
            isMachineTranslated = row[BaseCategoryTranslationsTable.isMachineTranslated],
        )
    }
}
