package su.spyme.marketplace.core.database

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import su.spyme.marketplace.core.BaseConfig

object DataSourceFactory {

    fun createMain(config: BaseConfig.Database): HikariDataSource =
        create("marketplace-main", config, config.mainPool)

    fun createCron(config: BaseConfig.Database): HikariDataSource =
        create("marketplace-cron", config, config.cronPool)

    private fun create(
        poolName: String,
        db: BaseConfig.Database,
        pool: BaseConfig.Database.Pool,
    ): HikariDataSource {
        val cfg = HikariConfig().apply {
            this.poolName = poolName
            this.jdbcUrl = db.jdbcUrl
            this.username = db.username
            this.password = db.password
            db.schema?.let { this.schema = it }

            this.maximumPoolSize = pool.maxSize
            this.minimumIdle = pool.minIdle
            this.connectionTimeout = pool.connectionTimeout.inWholeMilliseconds
            this.idleTimeout = pool.idleTimeout.inWholeMilliseconds
            this.maxLifetime = pool.maxLifetime.inWholeMilliseconds
            this.leakDetectionThreshold = pool.leakDetectionThreshold.inWholeMilliseconds

            this.driverClassName = "org.postgresql.Driver"
            this.isAutoCommit = false
            this.transactionIsolation = "TRANSACTION_READ_COMMITTED"

            addDataSourceProperty("ApplicationName", poolName)
            addDataSourceProperty("reWriteBatchedInserts", "true")
        }
        return HikariDataSource(cfg)
    }
}
