package su.spyme.marketplace.core.database

import com.zaxxer.hikari.HikariDataSource
import org.jetbrains.exposed.sql.Database
import su.spyme.marketplace.core.BaseConfig

class Databases(
    val mainSource: HikariDataSource,
    val cronSource: HikariDataSource,
) : AutoCloseable {

    val main: Database = Database.connect(mainSource)
    val cron: Database = Database.connect(cronSource)

    override fun close() {
        runCatching { mainSource.close() }
        runCatching { cronSource.close() }
    }

    companion object {
        fun open(config: BaseConfig.Database): Databases =
            Databases(
                mainSource = DataSourceFactory.createMain(config),
                cronSource = DataSourceFactory.createCron(config),
            )
    }
}
