package su.spyme.marketplace.core.bootstrap

import su.spyme.marketplace.core.MarketplaceModule
import su.spyme.marketplace.core.MissingDependencyException

object ModuleDependencyGraph {

    /**
     * Throws [MissingDependencyException] for any `dependsOn` reference
     * that points to a module not present in [modules].
     */
    fun validate(modules: List<MarketplaceModule>) {
        val names = modules.mapTo(HashSet()) { it.name }
        modules.forEach { m ->
            m.dependsOn.forEach { dep ->
                if (dep !in names) throw MissingDependencyException(m.name, dep)
            }
        }
        val duplicates = modules.groupBy { it.name }.filter { it.value.size > 1 }.keys
        if (duplicates.isNotEmpty()) {
            throw DuplicateModuleException(duplicates)
        }
    }

    /**
     * Returns [modules] sorted so each appears after its dependencies. Uses
     * Kahn's algorithm; throws [CircularDependencyException] if a cycle
     * makes a complete order impossible.
     *
     * Stable: ties (modules at the same dependency depth) preserve input
     * order — useful when the host wants deterministic startup logs.
     */
    fun topologicalOrder(modules: List<MarketplaceModule>): List<MarketplaceModule> {
        validate(modules)

        val byName = modules.associateBy { it.name }
        val indegree = modules.associate { it.name to it.dependsOn.size }.toMutableMap()
        val dependents: Map<String, List<String>> = modules
            .flatMap { m -> m.dependsOn.map { dep -> dep to m.name } }
            .groupBy({ it.first }) { it.second }

        val queue = ArrayDeque<String>()
        modules.forEach { if (indegree[it.name] == 0) queue.addLast(it.name) }

        val result = ArrayList<MarketplaceModule>(modules.size)
        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            result.add(byName.getValue(current))
            dependents[current]?.forEach { d ->
                val newDeg = (indegree[d] ?: 0) - 1
                indegree[d] = newDeg
                if (newDeg == 0) queue.addLast(d)
            }
        }

        if (result.size != modules.size) {
            val unresolved = modules.map { it.name }.toMutableSet().apply {
                removeAll(result.map { it.name }.toSet())
            }
            throw CircularDependencyException(unresolved)
        }
        return result
    }
}

class DuplicateModuleException(val names: Set<String>) :
    RuntimeException("Duplicate module name(s) registered: $names")

class CircularDependencyException(val cycle: Set<String>) :
    RuntimeException("Circular module dependency detected among: $cycle")
