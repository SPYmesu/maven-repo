package su.spyme.marketplace.users

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.database.citext
import su.spyme.marketplace.core.database.stringArray
import java.time.Instant

/**
 * Singleton Exposed table per Б1: hosts extend via side-tables, never
 * via column inheritance. CITEXT and VARCHAR[] are PostgreSQL-specific
 * — declared with `customEnumeration`-style type hints below.
 */
object BaseUsersTable : Table("users") {
    val id: Column<Long> = long("id").autoIncrement()
    val username: Column<String> = citext("username")
    val email: Column<String> = citext("email")
    val emailVerifiedAt: Column<Instant?> = timestamp("email_verified_at").nullable()
    val phone: Column<String?> = varchar("phone", 32).nullable()
    val phoneVerifiedAt: Column<Instant?> = timestamp("phone_verified_at").nullable()
    val roles: Column<List<String>> = stringArray("roles", 32)
    val jwtVersion: Column<Int> = integer("jwt_version").default(0)
    val locale: Column<String> = varchar("locale", 8).default("ru")
    val timezone: Column<String?> = varchar("timezone", 64).nullable()
    val lastActiveAt: Column<Instant?> = timestamp("last_active_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)
    val deletedAt: Column<Instant?> = timestamp("deleted_at").nullable()

    override val primaryKey = PrimaryKey(id)
}
