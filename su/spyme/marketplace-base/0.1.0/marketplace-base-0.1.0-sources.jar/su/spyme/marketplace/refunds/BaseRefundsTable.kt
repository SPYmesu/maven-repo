package su.spyme.marketplace.refunds

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Refund category. `'refund'` is money-back-only; `'return'` adds
 * a GOODS_RECEIVED step before COMPLETED (physical goods coming back
 * to the seller).
 */
enum class RefundType(val sqlValue: String) {
    REFUND("refund"),
    RETURN("return");

    companion object {
        fun parse(value: String): RefundType = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown RefundType: '$value'")
    }
}

/**
 * Lifecycle of a refund row. Mirrors the V012 CHECK alphabet:
 * REQUESTED → APPROVED → (GOODS_RECEIVED for return) → COMPLETED
 *                       ↘ REJECTED.
 */
enum class RefundStatus {
    REQUESTED, APPROVED, GOODS_RECEIVED, COMPLETED, REJECTED;

    companion object {
        fun parse(value: String): RefundStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown RefundStatus: '$value'")
    }
}

object BaseRefundsTable : Table("refunds") {
    val id: Column<Long> = long("id").autoIncrement()
    val orderId: Column<Long> = long("order_id")
    val paymentId: Column<Long?> = long("payment_id").nullable()
    val type: Column<String> = varchar("type", 16)
    val status: Column<String> = varchar("status", 32).default("REQUESTED")
    val amount: Column<Long> = long("amount")
    val currency: Column<String> = varchar("currency", 3)
    val reasonCode: Column<String> = varchar("reason_code", 32)
    val reasonText: Column<String?> = text("reason_text").nullable()
    val requestedBy: Column<Long> = long("requested_by")
    val approvedBy: Column<Long?> = long("approved_by").nullable()
    val refundProviderId: Column<String?> = varchar("refund_provider_id", 128).nullable()
    val gatewayMetadata: Column<JsonElement?> =
        jsonb("gateway_metadata", Json, JsonElement.serializer()).nullable()
    val requestedAt: Column<Instant> = timestamp("requested_at").defaultExpression(NowExpression)
    val approvedAt: Column<Instant?> = timestamp("approved_at").nullable()
    val goodsReceivedAt: Column<Instant?> = timestamp("goods_received_at").nullable()
    val completedAt: Column<Instant?> = timestamp("completed_at").nullable()
    val rejectedAt: Column<Instant?> = timestamp("rejected_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseRefundItemsTable : Table("refund_items") {
    val refundId: Column<Long> = long("refund_id").references(BaseRefundsTable.id)
    val orderItemId: Column<Long> = long("order_item_id")
    val quantity: Column<Int> = integer("quantity")
    val amount: Column<Long> = long("amount")

    override val primaryKey = PrimaryKey(refundId, orderItemId)
}

/**
 * Refund-as-entity. PARTIALLY_REFUNDED / REFUNDED on the order are
 * derived from summing matching rows in this table — never stored on
 * the order row itself.
 *
 * @property paymentId Targets a specific [su.spyme.marketplace.payments.Payment]
 *           row when the refund flows back through the gateway. Null
 *           for store-credit refunds or pre-payment cancellations.
 */
data class Refund(
    val id: Long,
    val orderId: Long,
    val paymentId: Long?,
    val type: RefundType,
    val status: RefundStatus,
    val money: Money,
    val reasonCode: String,
    val reasonText: String?,
    val requestedBy: Long,
    val approvedBy: Long?,
    val refundProviderId: String?,
    val gatewayMetadata: JsonElement?,
    val requestedAt: Instant,
    val approvedAt: Instant?,
    val goodsReceivedAt: Instant?,
    val completedAt: Instant?,
    val rejectedAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isComplete: Boolean get() = status == RefundStatus.COMPLETED
    val isRejected: Boolean get() = status == RefundStatus.REJECTED

    companion object {
        fun fromRow(row: ResultRow): Refund = Refund(
            id = row[BaseRefundsTable.id],
            orderId = row[BaseRefundsTable.orderId],
            paymentId = row[BaseRefundsTable.paymentId],
            type = RefundType.parse(row[BaseRefundsTable.type]),
            status = RefundStatus.parse(row[BaseRefundsTable.status]),
            money = Money(row[BaseRefundsTable.amount], row[BaseRefundsTable.currency]),
            reasonCode = row[BaseRefundsTable.reasonCode],
            reasonText = row[BaseRefundsTable.reasonText],
            requestedBy = row[BaseRefundsTable.requestedBy],
            approvedBy = row[BaseRefundsTable.approvedBy],
            refundProviderId = row[BaseRefundsTable.refundProviderId],
            gatewayMetadata = row[BaseRefundsTable.gatewayMetadata],
            requestedAt = row[BaseRefundsTable.requestedAt],
            approvedAt = row[BaseRefundsTable.approvedAt],
            goodsReceivedAt = row[BaseRefundsTable.goodsReceivedAt],
            completedAt = row[BaseRefundsTable.completedAt],
            rejectedAt = row[BaseRefundsTable.rejectedAt],
            createdAt = row[BaseRefundsTable.createdAt],
            updatedAt = row[BaseRefundsTable.updatedAt],
        )
    }
}

/**
 * Per-line breakdown for a partial refund. A [Refund] without any
 * [RefundItem] rows refunds the whole order; with rows it refunds
 * only those lines.
 */
data class RefundItem(
    val refundId: Long,
    val orderItemId: Long,
    val quantity: Int,
    val amount: Long,
) {
    companion object {
        fun fromRow(row: ResultRow): RefundItem = RefundItem(
            refundId = row[BaseRefundItemsTable.refundId],
            orderItemId = row[BaseRefundItemsTable.orderItemId],
            quantity = row[BaseRefundItemsTable.quantity],
            amount = row[BaseRefundItemsTable.amount],
        )
    }
}
