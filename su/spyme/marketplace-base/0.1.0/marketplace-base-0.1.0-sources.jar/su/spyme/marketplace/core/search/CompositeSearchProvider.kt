package su.spyme.marketplace.core.search

import io.github.resilience4j.circuitbreaker.CallNotPermittedException
import io.github.resilience4j.circuitbreaker.CircuitBreaker
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig
import io.github.resilience4j.kotlin.circuitbreaker.executeSuspendFunction
import org.slf4j.LoggerFactory
import java.time.Duration

/**
 * [SearchProvider] composition with Resilience4j circuit-breaker (per
 * В6 of the architecture plan):
 *
 * - **Searches** flow through the breaker. While the primary
 *   ([primary], normally MeiliSearch) is healthy the breaker is
 *   `CLOSED` and reads return `mode = HEALTHY`. After 5 consecutive
 *   failures inside a 10-call sliding window the breaker opens for
 *   30 seconds and routes traffic to [fallback] (normally pg_trgm) —
 *   the fallback returns `mode = DEGRADED` so the front-end can show
 *   the "search is in fallback mode" banner. After the open duration
 *   passes a single trial call is allowed; success closes the breaker.
 * - **Mutations** (`upsert` / `delete` / `reindex`) go to [primary]
 *   only. The outbox queue is the durability layer: if the primary
 *   is down the row stays pending and the next worker tick replays
 *   it; we never write to the fallback because it doesn't own
 *   storage in the first place.
 * - **isHealthy** asks the primary directly — composing breakers
 *   here would just make the readiness check a function of how
 *   recently we lost MeiliSearch.
 */
class CompositeSearchProvider(
    private val primary: SearchProvider,
    private val fallback: SearchProvider,
    private val circuitBreaker: CircuitBreaker = defaultBreaker(),
) : SearchProvider {

    override val name: String = "composite[${primary.name},${fallback.name}]"

    private val log = LoggerFactory.getLogger(CompositeSearchProvider::class.java)

    override suspend fun isHealthy(): Boolean = primary.isHealthy()

    override suspend fun upsert(document: IndexableDocument) = primary.upsert(document)

    override suspend fun upsertBatch(documents: List<IndexableDocument>) = primary.upsertBatch(documents)

    override suspend fun delete(indexName: String, id: String) = primary.delete(indexName, id)

    override suspend fun deleteBatch(indexName: String, ids: List<String>) = primary.deleteBatch(indexName, ids)

    override suspend fun reindex(indexName: String, documents: Sequence<IndexableDocument>) =
        primary.reindex(indexName, documents)

    override suspend fun search(query: SearchQuery): SearchResult {
        return try {
            circuitBreaker.executeSuspendFunction { primary.search(query) }
        } catch (open: CallNotPermittedException) {
            // Breaker is OPEN — short-circuit straight to fallback.
            log.debug("Circuit breaker {} is OPEN, routing to fallback", circuitBreaker.name)
            fallback.search(query).copy(mode = SearchMode.DEGRADED)
        } catch (e: Exception) {
            // Primary blew up *and* the breaker recorded the failure.
            // Serve degraded results from the fallback so the user
            // still sees something.
            log.warn("Primary search provider {} failed; falling back. {}", primary.name, e.message)
            fallback.search(query).copy(mode = SearchMode.DEGRADED)
        }
    }

    /**
     * Current breaker state — exposed for the admin diagnostics
     * dashboard. The string is one of `CLOSED`, `OPEN`, `HALF_OPEN`,
     * `DISABLED`, `FORCED_OPEN`, `METRICS_ONLY`.
     */
    val breakerState: String get() = circuitBreaker.state.name

    companion object {
        /**
         * Defaults match В6: count-based 10-call sliding window, opens
         * after a 50% failure rate, holds open for 30 seconds before a
         * trial call.
         */
        fun defaultBreaker(name: String = "search"): CircuitBreaker {
            val config = CircuitBreakerConfig.custom()
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(10)
                .minimumNumberOfCalls(5)
                .failureRateThreshold(50f)
                .waitDurationInOpenState(Duration.ofSeconds(30))
                .permittedNumberOfCallsInHalfOpenState(1)
                .automaticTransitionFromOpenToHalfOpenEnabled(true)
                .build()
            return CircuitBreaker.of(name, config)
        }
    }
}
