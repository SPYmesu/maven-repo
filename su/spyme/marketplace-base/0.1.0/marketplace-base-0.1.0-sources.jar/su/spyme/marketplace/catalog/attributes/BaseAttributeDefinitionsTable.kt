package su.spyme.marketplace.catalog.attributes

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseAttributeDefinitionsTable : Table("attribute_definitions") {
    val id: Column<Long> = long("id").autoIncrement()
    val code: Column<String> = varchar("code", 64).uniqueIndex()
    val dataType: Column<String> = varchar("data_type", 32)
    val labelI18nKey: Column<String?> = varchar("label_i18n_key", 128).nullable()
    val isGlobal: Column<Boolean> = bool("is_global").default(false)
    val isVariant: Column<Boolean> = bool("is_variant").default(false)
    val isFacet: Column<Boolean> = bool("is_facet").default(false)
    val isSearchable: Column<Boolean> = bool("is_searchable").default(false)
    val isProtected: Column<Boolean> = bool("is_protected").default(false)
    val isRequiredDefault: Column<Boolean> = bool("is_required_default").default(false)
    val isPublic: Column<Boolean> = bool("is_public").default(true)
    val enumValues: Column<JsonElement?> =
        jsonb("enum_values", Json, JsonElement.serializer()).nullable()
    val validation: Column<JsonElement?> =
        jsonb("validation", Json, JsonElement.serializer()).nullable()
    val unit: Column<String?> = varchar("unit", 32).nullable()
    val sortOrder: Column<Int> = integer("sort_order").default(0)
    val archivedAt: Column<Instant?> = timestamp("archived_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}
