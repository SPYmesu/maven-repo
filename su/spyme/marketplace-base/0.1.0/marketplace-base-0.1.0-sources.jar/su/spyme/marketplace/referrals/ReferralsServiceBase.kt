package su.spyme.marketplace.referrals

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.less
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

enum class ReferralRewardStatus {
    PENDING, AWARDED, EXPIRED;

    companion object {
        fun parse(value: String): ReferralRewardStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown ReferralRewardStatus: '$value'")
    }
}

object BaseReferralRewardsTable : Table("referral_rewards") {
    val id: Column<Long> = long("id").autoIncrement()
    val referrerUserId: Column<Long> = long("referrer_user_id")
    val referredUserId: Column<Long> = long("referred_user_id")
    val orderId: Column<Long?> = long("order_id").nullable()
    val amount: Column<Long> = long("amount")
    val currency: Column<String> = varchar("currency", 3)
    val rewardType: Column<String> = varchar("reward_type", 32)
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val awardedAt: Column<Instant?> = timestamp("awarded_at").nullable()
    val expiresAt: Column<Instant?> = timestamp("expires_at").nullable()
    val metadata: Column<JsonElement?> = jsonb("metadata", Json, JsonElement.serializer()).nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Single ledger entry: someone referred someone, and the host owes
 * the referrer a reward.
 *
 * @property rewardType Free-form host-defined string (`"signup"`,
 *           `"first_purchase"`, `"recurring"`, …) so each host's
 *           referral module can express its own program rules without
 *           needing a SQL migration.
 */
data class ReferralReward(
    val id: Long,
    val referrerUserId: Long,
    val referredUserId: Long,
    val orderId: Long?,
    val money: Money,
    val rewardType: String,
    val status: ReferralRewardStatus,
    val awardedAt: Instant?,
    val expiresAt: Instant?,
    val metadata: JsonElement?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): ReferralReward = ReferralReward(
            id = row[BaseReferralRewardsTable.id],
            referrerUserId = row[BaseReferralRewardsTable.referrerUserId],
            referredUserId = row[BaseReferralRewardsTable.referredUserId],
            orderId = row[BaseReferralRewardsTable.orderId],
            money = Money(
                amount = row[BaseReferralRewardsTable.amount],
                currency = row[BaseReferralRewardsTable.currency],
            ),
            rewardType = row[BaseReferralRewardsTable.rewardType],
            status = ReferralRewardStatus.parse(row[BaseReferralRewardsTable.status]),
            awardedAt = row[BaseReferralRewardsTable.awardedAt],
            expiresAt = row[BaseReferralRewardsTable.expiresAt],
            metadata = row[BaseReferralRewardsTable.metadata],
            createdAt = row[BaseReferralRewardsTable.createdAt],
            updatedAt = row[BaseReferralRewardsTable.updatedAt],
        )
    }
}

/**
 * Pure ledger service. The host module decides when to call [create]
 * (signup with referrer cookie, first-purchase trigger, …) and when
 * to call [markAwarded] (after actually crediting store credit /
 * pushing money). This service just keeps the bookkeeping consistent.
 */
open class ReferralsServiceBase(
    protected val mainDb: Database,
    protected val cronDb: Database,
) {

    open fun create(
        referrerUserId: Long,
        referredUserId: Long,
        money: Money,
        rewardType: String,
        orderId: Long? = null,
        expiresAt: Instant? = null,
        metadata: JsonElement? = null,
    ): ReferralReward {
        require(referrerUserId != referredUserId) { "self-referrals are forbidden" }
        require(money.amount >= 0) { "reward amount must be non-negative" }
        require(rewardType.isNotBlank()) { "rewardType must not be blank" }

        return transaction(mainDb) {
            val newId = BaseReferralRewardsTable.insert {
                it[BaseReferralRewardsTable.referrerUserId] = referrerUserId
                it[BaseReferralRewardsTable.referredUserId] = referredUserId
                it[BaseReferralRewardsTable.orderId] = orderId
                it[BaseReferralRewardsTable.amount] = money.amount
                it[BaseReferralRewardsTable.currency] = money.currency
                it[BaseReferralRewardsTable.rewardType] = rewardType
                it[BaseReferralRewardsTable.expiresAt] = expiresAt
                it[BaseReferralRewardsTable.metadata] = metadata
            }[BaseReferralRewardsTable.id]
            loadById(newId)!!
        }
    }

    /** Marks a PENDING reward as AWARDED — store credit / payout actually happened. */
    open fun markAwarded(rewardId: Long, now: Instant = Instant.now()): Boolean = transaction(mainDb) {
        BaseReferralRewardsTable.update({
            (BaseReferralRewardsTable.id eq rewardId) and
                (BaseReferralRewardsTable.status eq ReferralRewardStatus.PENDING.name)
        }) {
            it[BaseReferralRewardsTable.status] = ReferralRewardStatus.AWARDED.name
            it[BaseReferralRewardsTable.awardedAt] = now
        } > 0
    }

    /**
     * Cron-side sweep: flips PENDING rewards whose `expires_at` has
     * passed to EXPIRED. Returns the number of rewards expired.
     */
    open fun expireStale(now: Instant = Instant.now()): Int = transaction(cronDb) {
        BaseReferralRewardsTable.update({
            (BaseReferralRewardsTable.status eq ReferralRewardStatus.PENDING.name) and
                (BaseReferralRewardsTable.expiresAt less now)
        }) {
            it[BaseReferralRewardsTable.status] = ReferralRewardStatus.EXPIRED.name
        }
    }

    open fun findById(id: Long): ReferralReward? = transaction(mainDb) { loadById(id) }

    open fun listForReferrer(userId: Long): List<ReferralReward> = transaction(mainDb) {
        BaseReferralRewardsTable.selectAll()
            .where { BaseReferralRewardsTable.referrerUserId eq userId }
            .orderBy(BaseReferralRewardsTable.createdAt to SortOrder.DESC)
            .map(ReferralReward::fromRow)
    }

    open fun listPendingForReferrer(userId: Long): List<ReferralReward> = transaction(mainDb) {
        BaseReferralRewardsTable.selectAll()
            .where {
                (BaseReferralRewardsTable.referrerUserId eq userId) and
                    (BaseReferralRewardsTable.status eq ReferralRewardStatus.PENDING.name)
            }
            .orderBy(BaseReferralRewardsTable.createdAt to SortOrder.ASC)
            .map(ReferralReward::fromRow)
    }

    private fun loadById(id: Long): ReferralReward? = BaseReferralRewardsTable.selectAll()
        .where { BaseReferralRewardsTable.id eq id }
        .firstOrNull()
        ?.let(ReferralReward::fromRow)
}
