package su.spyme.marketplace.core.auth

/**
 * Marketplace role definition. `code` is the canonical UPPER_CASE
 * identifier stored in `users.roles` and consumed everywhere; `level`
 * powers hierarchical checks ("user has at least MANAGER"). `label`
 * is a fallback display name — hosts override via i18n.
 */
data class Role(
    val code: String,
    val label: String,
    val level: Int,
) {
    init {
        require(code.isNotBlank()) { "Role code must not be blank" }
        require(code.length <= 32) { "Role code must fit VARCHAR(32): $code" }
        require(code == code.uppercase()) { "Role code must be UPPER_CASE: $code" }
    }
}
