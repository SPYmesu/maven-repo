package su.spyme.marketplace.orders.state

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Factory for the four canonical state machines from the architecture
 * plan. Hosts can reuse these directly or build their own via
 * [OrderStateMachine] and register through [OrderStateMachineRegistry].
 */
object OrderStateMachines {

    /**
     * Physical-goods order:
     * NEW → AWAITING_PAYMENT → PAID → PROCESSING → SHIPPED → DELIVERED.
     * SHIPPED → DELIVERED is allowed by the carrier webhook, the buyer
     * confirming receipt, or staff intervention. PAID → CANCELLED is
     * allowed for staff (out-of-stock, fraud) and triggers a refund.
     */
    fun physical(): OrderStateMachine = OrderStateMachine(
        name = "physical",
        transitions = listOf(
            t(OrderStatus.NEW, OrderStatus.AWAITING_PAYMENT, TransitionActor.SYSTEM, TransitionActor.USER),
            t(OrderStatus.NEW, OrderStatus.CANCELLED, TransitionActor.USER, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_PAYMENT, OrderStatus.PAID, TransitionActor.PAYMENT_GATEWAY, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_PAYMENT, OrderStatus.CANCELLED, TransitionActor.USER, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.PAID, OrderStatus.PROCESSING, TransitionActor.MANAGER, TransitionActor.ADMIN, TransitionActor.SYSTEM),
            t(OrderStatus.PAID, OrderStatus.CANCELLED, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.PROCESSING, OrderStatus.SHIPPED, TransitionActor.MANAGER, TransitionActor.ADMIN, TransitionActor.CARRIER),
            t(OrderStatus.PROCESSING, OrderStatus.CANCELLED, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.SHIPPED, OrderStatus.DELIVERED, TransitionActor.CARRIER, TransitionActor.USER, TransitionActor.MANAGER, TransitionActor.ADMIN),
        ),
    )

    /**
     * Digital-goods order with auto-confirm: PAID → DELIVERED is
     * triggered by the first download (per the architecture plan,
     * `DigitalDeliveryListener.onDownload` flips order_items.delivered_at
     * and the cascade lands here when every digital line has been
     * delivered).
     */
    fun digital(): OrderStateMachine = OrderStateMachine(
        name = "digital",
        transitions = listOf(
            t(OrderStatus.NEW, OrderStatus.AWAITING_PAYMENT, TransitionActor.SYSTEM, TransitionActor.USER),
            t(OrderStatus.NEW, OrderStatus.CANCELLED, TransitionActor.USER, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_PAYMENT, OrderStatus.PAID, TransitionActor.PAYMENT_GATEWAY, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_PAYMENT, OrderStatus.CANCELLED, TransitionActor.USER, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.PAID, OrderStatus.DELIVERED, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.PAID, OrderStatus.CANCELLED, TransitionActor.MANAGER, TransitionActor.ADMIN),
        ),
    )

    /**
     * Digital-goods order with manual moderator confirmation (moonstudio
     * use case). NEW lands directly in AWAITING_MANAGER instead of
     * AWAITING_PAYMENT. No auto-expire — `remindManagersOfPendingOrders`
     * cron pings staff per the plan instead.
     */
    fun digitalManualConfirm(): OrderStateMachine = OrderStateMachine(
        name = "digitalManualConfirm",
        transitions = listOf(
            t(OrderStatus.NEW, OrderStatus.AWAITING_MANAGER, TransitionActor.SYSTEM, TransitionActor.USER),
            t(OrderStatus.NEW, OrderStatus.CANCELLED, TransitionActor.USER, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_MANAGER, OrderStatus.PAID, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.AWAITING_MANAGER, OrderStatus.CANCELLED, TransitionActor.MANAGER, TransitionActor.ADMIN, TransitionActor.USER),
            t(OrderStatus.PAID, OrderStatus.DELIVERED, TransitionActor.SYSTEM, TransitionActor.MANAGER, TransitionActor.ADMIN),
            t(OrderStatus.PAID, OrderStatus.CANCELLED, TransitionActor.MANAGER, TransitionActor.ADMIN),
        ),
    )

    /**
     * Mixed-kind order: digital and physical lines progress through
     * their own per-item states; the order-level status aggregates
     * via min(active item statuses) inside OrdersService. This machine
     * permits the union of physical + digital transitions so the
     * aggregate status can move freely.
     */
    fun mixed(): OrderStateMachine = OrderStateMachine(
        name = "mixed",
        transitions = (physical().transitions + digital().transitions).distinct(),
    )

    private fun t(from: OrderStatus, to: OrderStatus, vararg actors: TransitionActor): OrderTransition =
        OrderTransition(from, to, actors.toSet())
}

/**
 * Lookup of state machines by name. Hosts register custom machines
 * during the bootstrap registration phase; the OrdersServiceBase
 * picks the right one per order via the host-supplied resolver.
 */
class OrderStateMachineRegistry {
    private val backing = ConflictRegistry<String, OrderStateMachine>("OrderStateMachineRegistry")

    fun register(machine: OrderStateMachine) {
        backing.register(machine.name, machine)
    }

    fun get(name: String): OrderStateMachine = backing.get(name)
    fun getOrNull(name: String): OrderStateMachine? = backing.getOrNull(name)
    fun all(): List<OrderStateMachine> = backing.values().toList()

    companion object {
        /** Returns a registry pre-loaded with the four default machines. */
        fun withDefaults(): OrderStateMachineRegistry = OrderStateMachineRegistry().apply {
            register(OrderStateMachines.physical())
            register(OrderStateMachines.digital())
            register(OrderStateMachines.digitalManualConfirm())
            register(OrderStateMachines.mixed())
        }
    }
}
