package su.spyme.marketplace.cart

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.plus
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update

/**
 * Cart owner: either an authenticated user or a guest token. Sealed
 * because exactly one of the two must be set; passing both at the SQL
 * layer would trip the cart_items CHECK constraint.
 */
sealed class CartOwner {
    data class User(val userId: Long) : CartOwner()
    data class Guest(val guestToken: String) : CartOwner()
}

/**
 * Shopping-cart CRUD. Open class — hosts override individual methods
 * (e.g. moonstudio inserts an extra "license-tier" attribute). The
 * service owns nothing about pricing or stock; that lives in
 * OrdersService at checkout time.
 */
open class CartServiceBase(protected val mainDb: Database) {

    /**
     * Adds [quantity] of [productId] (with optional [variantId]) to
     * the cart owned by [owner]. If a matching line already exists it
     * is incremented atomically — no read-modify-write race.
     */
    open fun addItem(
        owner: CartOwner,
        productId: Long,
        variantId: Long? = null,
        quantity: Int = 1,
    ): CartItem {
        require(quantity > 0) { "quantity must be positive: $quantity" }

        return transaction(mainDb) {
            val existing = findExisting(owner, productId, variantId)
            if (existing != null) {
                BaseCartItemsTable.update({ BaseCartItemsTable.id eq existing.id }) {
                    with(org.jetbrains.exposed.sql.SqlExpressionBuilder) {
                        it[BaseCartItemsTable.quantity] = BaseCartItemsTable.quantity + quantity
                    }
                }
                loadById(existing.id)!!
            } else {
                val newId = BaseCartItemsTable.insert {
                    when (owner) {
                        is CartOwner.User -> it[BaseCartItemsTable.userId] = owner.userId
                        is CartOwner.Guest -> it[BaseCartItemsTable.guestToken] = owner.guestToken
                    }
                    it[BaseCartItemsTable.productId] = productId
                    it[BaseCartItemsTable.variantId] = variantId
                    it[BaseCartItemsTable.quantity] = quantity
                }[BaseCartItemsTable.id]
                loadById(newId)!!
            }
        }
    }

    /** Sets the line quantity to [quantity]. Removes the row if [quantity] ≤ 0. */
    open fun updateQuantity(itemId: Long, quantity: Int) {
        if (quantity <= 0) {
            removeItem(itemId)
            return
        }
        transaction(mainDb) {
            BaseCartItemsTable.update({ BaseCartItemsTable.id eq itemId }) {
                it[BaseCartItemsTable.quantity] = quantity
            }
        }
    }

    open fun removeItem(itemId: Long): Boolean = transaction(mainDb) {
        BaseCartItemsTable.deleteWhere { BaseCartItemsTable.id eq itemId } > 0
    }

    open fun list(owner: CartOwner): List<CartItem> = transaction(mainDb) {
        BaseCartItemsTable.selectAll()
            .where { ownerFilter(owner) }
            .map(CartItem::fromRow)
    }

    open fun count(owner: CartOwner): Long = transaction(mainDb) {
        BaseCartItemsTable.selectAll()
            .where { ownerFilter(owner) }
            .count()
    }

    open fun clear(owner: CartOwner): Int = transaction(mainDb) {
        BaseCartItemsTable.deleteWhere { ownerFilter(owner) }
    }

    /**
     * On login, fold the guest cart into the user cart. Quantities
     * combine for matching (productId, variantId) tuples; lines that
     * exist only on one side are kept as-is. The guest cart is dropped
     * after the merge.
     */
    open fun mergeGuestIntoUser(guestToken: String, userId: Long) {
        transaction(mainDb) {
            val guestItems = BaseCartItemsTable.selectAll()
                .where { BaseCartItemsTable.guestToken eq guestToken }
                .map(CartItem::fromRow)

            guestItems.forEach { guestItem ->
                addItem(
                    owner = CartOwner.User(userId),
                    productId = guestItem.productId,
                    variantId = guestItem.variantId,
                    quantity = guestItem.quantity,
                )
            }

            BaseCartItemsTable.deleteWhere { BaseCartItemsTable.guestToken eq guestToken }
        }
    }

    private fun findExisting(owner: CartOwner, productId: Long, variantId: Long?): CartItem? =
        BaseCartItemsTable.selectAll()
            .where {
                val variantFilter = if (variantId == null) {
                    BaseCartItemsTable.variantId.isNull()
                } else {
                    BaseCartItemsTable.variantId eq variantId
                }
                ownerFilter(owner) and (BaseCartItemsTable.productId eq productId) and variantFilter
            }
            .firstOrNull()
            ?.let(CartItem::fromRow)

    private fun loadById(id: Long): CartItem? = BaseCartItemsTable.selectAll()
        .where { BaseCartItemsTable.id eq id }
        .firstOrNull()
        ?.let(CartItem::fromRow)

    private fun ownerFilter(owner: CartOwner): Op<Boolean> = Op.build {
        when (owner) {
            is CartOwner.User -> BaseCartItemsTable.userId eq owner.userId
            is CartOwner.Guest -> BaseCartItemsTable.guestToken eq owner.guestToken
        }
    }
}
