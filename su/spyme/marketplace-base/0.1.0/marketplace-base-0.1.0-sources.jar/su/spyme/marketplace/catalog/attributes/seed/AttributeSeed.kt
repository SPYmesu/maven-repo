package su.spyme.marketplace.catalog.attributes.seed

import kotlinx.serialization.json.JsonElement
import su.spyme.marketplace.catalog.attributes.AttributeDataType

/**
 * Single attribute definition entry from a seed YAML file. Mirrors
 * the constructor params of
 * [su.spyme.marketplace.catalog.attributes.AttributesServiceBase.createDefinition]
 * one-to-one. Optional fields default to safe values; required fields
 * trigger a parse failure if absent.
 *
 * Seed files live under `src/main/resources/seed/attributes/` (in
 * hosts, named e.g. `core.yaml`) and are applied via [AttributeSeedLoader] during the
 * cron-pool boot sequence (idempotent: running twice is a no-op).
 *
 * @property code Canonical UPPER_CASE identifier; uniqueness enforced
 *           by the DB.
 * @property categoryBindings Categories this attribute should auto-
 *           attach to, keyed by category slug (resolved against
 *           `categories.slug` at apply time). Empty when [isGlobal]
 *           is true.
 */
data class AttributeSeed(
    val code: String,
    val dataType: AttributeDataType,
    val labelI18nKey: String? = null,
    val isGlobal: Boolean = false,
    val isVariant: Boolean = false,
    val isFacet: Boolean = false,
    val isSearchable: Boolean = false,
    val isProtected: Boolean = true,
    val isRequiredDefault: Boolean = false,
    val isPublic: Boolean = true,
    val enumValues: List<String>? = null,
    val validation: JsonElement? = null,
    val unit: String? = null,
    val sortOrder: Int = 0,
    val categoryBindings: List<CategoryBinding> = emptyList(),
) {
    init {
        require(code.isNotBlank()) { "AttributeSeed.code must not be blank" }
        require(code.length <= 64) { "AttributeSeed.code must fit VARCHAR(64): '$code'" }
        require(code == code.uppercase()) { "AttributeSeed.code must be UPPER_CASE: '$code'" }
        if (dataType == AttributeDataType.ENUM || dataType == AttributeDataType.ENUM_MULTI) {
            require(!enumValues.isNullOrEmpty()) {
                "AttributeSeed.enumValues required for $dataType (code='$code')"
            }
        }
        require(!(isGlobal && categoryBindings.isNotEmpty())) {
            "AttributeSeed.categoryBindings must be empty when isGlobal=true (code='$code')"
        }
    }

    /**
     * Edge declaration for an attribute-to-category binding inside a
     * seed file. Uses [categorySlug] (not raw ID) so seeds remain
     * portable across environments where category IDs differ.
     */
    data class CategoryBinding(
        val categorySlug: String,
        val sortOrder: Int = 0,
        val isRequired: Boolean? = null,
    )
}

/**
 * Top-level YAML container; lets seed files start with `attributes:`.
 */
data class AttributeSeedFile(val attributes: List<AttributeSeed>)

