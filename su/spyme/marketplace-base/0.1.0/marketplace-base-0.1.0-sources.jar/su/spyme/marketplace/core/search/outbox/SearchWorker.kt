package su.spyme.marketplace.core.search.outbox

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.search.IndexableDocument
import su.spyme.marketplace.core.search.SearchProvider

/**
 * Background worker that drains [SearchOutboxService] into a
 * [SearchProvider] in batches.
 *
 * Loop tick:
 *   1. `outbox.claimPending(batchSize)` reads up to `batchSize` rows
 *      with `FOR UPDATE SKIP LOCKED` — peers don't double-process.
 *   2. Group by (operation, entityType) so each provider call is one
 *      HTTP round-trip per group.
 *   3. UPSERT path: build documents via the registered
 *      [SearchDocumentBuilder]; missing builders or builder failures
 *      mark individual rows failed, the rest of the batch keeps moving.
 *   4. DELETE path: send the entity ids straight to
 *      `provider.deleteBatch`.
 *   5. On batch success, every row in the group is marked processed.
 *      On failure, every row is marked failed (attempts++) — they'll
 *      be retried on the next tick.
 *
 * Caveats on this initial cut:
 * - Pure polling (default 5s); LISTEN/NOTIFY wake-up is a follow-up.
 *   The V008 trigger already fires `pg_notify('search_queue', ...)`
 *   so plumbing it in is just a [java.sql.Connection.unwrap] +
 *   getNotifications() loop on a dedicated connection.
 * - Single-instance friendly; the `FOR UPDATE SKIP LOCKED` claim is
 *   safe with multiple workers but they'll all polling-storm the
 *   queue. Cron leader election (per В10) lands separately.
 * - `markFailed` doesn't enforce a max-attempts cap yet; rows stay
 *   pending forever until an admin "retry" or until the build can
 *   construct a document. The plan calls for an alert at
 *   `attempts > 10` (per В6); the trigger lands when the notification
 *   subsystem is online (E8).
 */
class SearchWorker(
    private val outbox: SearchOutboxService,
    private val provider: SearchProvider,
    private val builders: Map<String, SearchDocumentBuilder>,
    private val pollIntervalMs: Long = 5_000,
    private val batchSize: Int = 100,
) {

    private val log = LoggerFactory.getLogger(SearchWorker::class.java)

    @Volatile
    private var job: Job? = null

    /**
     * Spawns the polling loop on [scope]. Idempotent: a second call
     * while the worker is already running is a no-op.
     */
    fun start(scope: CoroutineScope) {
        if (job != null) {
            log.debug("SearchWorker already running")
            return
        }
        job = scope.launch {
            log.info(
                "SearchWorker started — provider={}, builders={}, pollMs={}",
                provider.name,
                builders.keys,
                pollIntervalMs,
            )
            while (isActive) {
                runCatching { processOnce() }
                    .onFailure { log.warn("SearchWorker tick failed", it) }
                delay(pollIntervalMs)
            }
        }
    }

    /** Stops the loop and joins the coroutine. Safe to call multiple times. */
    suspend fun stop() {
        job?.cancelAndJoin()
        job = null
    }

    /**
     * One polling tick. Public so integration tests can drive the
     * worker deterministically without spinning a real coroutine.
     *
     * @return number of queue rows touched.
     */
    suspend fun processOnce(): Int {
        val pending = outbox.claimPending(batchSize)
        if (pending.isEmpty()) return 0

        val (upserts, deletes) = pending.partition { it.operation == SearchOperation.UPSERT }

        processUpserts(upserts)
        processDeletes(deletes)

        return pending.size
    }

    private suspend fun processUpserts(entries: List<SearchIndexQueueEntry>) {
        if (entries.isEmpty()) return
        entries.groupBy { it.entityType }.forEach { (entityType, group) ->
            val builder = builders[entityType]
            if (builder == null) {
                val msg = "no SearchDocumentBuilder registered for entityType='$entityType'"
                log.warn(msg)
                group.forEach { outbox.markFailed(it.id, msg) }
                return@forEach
            }

            val builtPairs: List<Pair<SearchIndexQueueEntry, IndexableDocument?>> = group.map { entry ->
                val doc = runCatching { builder.buildDocument(entry.entityId) }.getOrElse { e ->
                    outbox.markFailed(entry.id, "buildDocument failed: ${e.javaClass.simpleName}: ${e.message.orEmpty()}")
                    return@map entry to null
                }
                entry to doc
            }

            // Hard-deleted entity: the builder returned null. Treat the
            // outbox row as resolved — there's nothing to push.
            val (resolvable, missing) = builtPairs.partition { it.second != null }
            missing.forEach { (entry, _) -> outbox.markProcessed(entry.id) }

            if (resolvable.isEmpty()) return@forEach

            val docs = resolvable.map { it.second!! }
            runCatching { provider.upsertBatch(docs) }
                .onSuccess { resolvable.forEach { outbox.markProcessed(it.first.id) } }
                .onFailure { e ->
                    log.warn("Provider {} failed to upsert {} docs", provider.name, docs.size, e)
                    val why = "provider upsert failed: ${e.javaClass.simpleName}: ${e.message.orEmpty()}"
                    resolvable.forEach { outbox.markFailed(it.first.id, why) }
                }
        }
    }

    private suspend fun processDeletes(entries: List<SearchIndexQueueEntry>) {
        if (entries.isEmpty()) return
        entries.groupBy { it.entityType }.forEach { (entityType, group) ->
            val builder = builders[entityType]
            if (builder == null) {
                val msg = "no SearchDocumentBuilder registered for entityType='$entityType'"
                log.warn(msg)
                group.forEach { outbox.markFailed(it.id, msg) }
                return@forEach
            }
            val ids = group.map { it.entityId.toString() }
            runCatching { provider.deleteBatch(builder.indexName, ids) }
                .onSuccess { group.forEach { outbox.markProcessed(it.id) } }
                .onFailure { e ->
                    log.warn("Provider {} failed to delete {} docs", provider.name, ids.size, e)
                    val why = "provider delete failed: ${e.javaClass.simpleName}: ${e.message.orEmpty()}"
                    group.forEach { outbox.markFailed(it.id, why) }
                }
        }
    }
}
