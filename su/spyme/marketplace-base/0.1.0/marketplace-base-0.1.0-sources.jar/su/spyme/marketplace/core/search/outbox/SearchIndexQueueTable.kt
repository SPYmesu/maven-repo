package su.spyme.marketplace.core.search.outbox

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Exposed table mirroring V008.search_index_queue. The outbox row is
 * inserted in the same transaction as the entity mutation; a worker
 * later picks rows up via SELECT FOR UPDATE SKIP LOCKED.
 */
object SearchIndexQueueTable : Table("search_index_queue") {
    val id: Column<Long> = long("id").autoIncrement()
    val entityType: Column<String> = varchar("entity_type", 32)
    val entityId: Column<Long> = long("entity_id")
    val operation: Column<String> = varchar("operation", 16)
    val enqueuedAt: Column<Instant> = timestamp("enqueued_at").defaultExpression(NowExpression)
    val attempts: Column<Short> = short("attempts").default(0)
    val lastError: Column<String?> = text("last_error").nullable()
    val processedAt: Column<Instant?> = timestamp("processed_at").nullable()

    override val primaryKey = PrimaryKey(id)
}

/**
 * Domain representation of one queue row.
 *
 * @property operation Either `"upsert"` (rebuild the document) or
 *           `"delete"` (drop it from the index).
 */
data class SearchIndexQueueEntry(
    val id: Long,
    val entityType: String,
    val entityId: Long,
    val operation: SearchOperation,
    val enqueuedAt: Instant,
    val attempts: Int,
    val lastError: String?,
    val processedAt: Instant?,
)

/** Whether the queue row asks for an index upsert or a deletion. */
enum class SearchOperation(val sqlValue: String) {
    UPSERT("upsert"),
    DELETE("delete");

    companion object {
        fun parse(value: String): SearchOperation = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown search operation: '$value'")
    }
}
