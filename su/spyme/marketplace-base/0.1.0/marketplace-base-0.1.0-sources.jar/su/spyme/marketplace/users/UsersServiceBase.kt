package su.spyme.marketplace.users

import com.github.benmanes.caffeine.cache.Cache
import com.github.benmanes.caffeine.cache.Caffeine
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.auth.RoleRegistry
import java.time.Duration
import java.time.Instant

open class UsersServiceBase(
    protected val mainDb: Database,
    protected val roleRegistry: RoleRegistry,
    cacheTtlSeconds: Long = 60,
) {

    private val byIdCache: Cache<Long, User> = Caffeine.newBuilder()
        .expireAfterWrite(Duration.ofSeconds(cacheTtlSeconds))
        .maximumSize(10_000)
        .build()

    open fun createUser(
        username: String,
        email: String,
        roles: List<String> = listOf(RoleRegistry.USER.code),
        locale: String = "ru",
        timezone: String? = null,
        phone: String? = null,
    ): User {
        require(username.isNotBlank()) { "username must not be blank" }
        require(email.isNotBlank()) { "email must not be blank" }
        validateRoles(roles)

        return transaction(mainDb) {
            val newId = BaseUsersTable.insert {
                it[BaseUsersTable.username] = username
                it[BaseUsersTable.email] = email
                it[BaseUsersTable.roles] = roles
                it[BaseUsersTable.locale] = locale
                it[BaseUsersTable.timezone] = timezone
                it[BaseUsersTable.phone] = phone
            }[BaseUsersTable.id]
            loadById(newId, includeDeleted = false) ?: error("Inserted user $newId not found in tx")
        }
    }

    open fun findById(id: Long, includeDeleted: Boolean = false): User? {
        byIdCache.getIfPresent(id)?.let { cached ->
            if (includeDeleted || !cached.isDeleted) return cached
        }
        val loaded = transaction(mainDb) { loadById(id, includeDeleted) }
        if (loaded != null) byIdCache.put(id, loaded)
        return loaded
    }

    open fun findByEmail(email: String, includeDeleted: Boolean = false): User? =
        transaction(mainDb) {
            BaseUsersTable.selectAll()
                .where {
                    if (includeDeleted) BaseUsersTable.email eq email
                    else (BaseUsersTable.email eq email) and BaseUsersTable.deletedAt.isNull()
                }
                .firstOrNull()
                ?.let(User::fromRow)
        }

    open fun findByUsername(username: String, includeDeleted: Boolean = false): User? =
        transaction(mainDb) {
            BaseUsersTable.selectAll()
                .where {
                    if (includeDeleted) BaseUsersTable.username eq username
                    else (BaseUsersTable.username eq username) and BaseUsersTable.deletedAt.isNull()
                }
                .firstOrNull()
                ?.let(User::fromRow)
        }

    open fun assignRoles(id: Long, roles: List<String>) {
        validateRoles(roles)
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.roles] = roles
            }
        }
        byIdCache.invalidate(id)
    }

    open fun markEmailVerified(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.emailVerifiedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    open fun markPhoneVerified(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.phoneVerifiedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    open fun updateLastActiveAt(id: Long, at: Instant = Instant.now()) {
        // last_active_at is cheap and stale reads cost nothing — bypass cache invalidation.
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.lastActiveAt] = at
            }
        }
    }

    /**
     * Increments [BaseUsersTable.jwtVersion] atomically — every JWT
     * minted before this point becomes invalid (per В1 bulk-revoke).
     * Returns the new version.
     */
    open fun bumpJwtVersion(id: Long): Int {
        val newVersion = transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                with(SqlExpressionBuilder) {
                    it[BaseUsersTable.jwtVersion] = BaseUsersTable.jwtVersion + 1
                }
            }
            BaseUsersTable.selectAll()
                .where { BaseUsersTable.id eq id }
                .first()[BaseUsersTable.jwtVersion]
        }
        byIdCache.invalidate(id)
        return newVersion
    }

    open fun softDelete(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({
                (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNull()
            }) {
                it[BaseUsersTable.deletedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    /**
     * Lifts soft-delete. Fails silently if the row's email/username is
     * now claimed by an active user — partial unique indexes will
     * reject the row's resurrection at the SQL layer; caller resolves.
     */
    open fun restoreDeleted(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({
                (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNotNull()
            }) {
                it[BaseUsersTable.deletedAt] = null
            }
        }
        byIdCache.invalidate(id)
    }

    private fun loadById(id: Long, includeDeleted: Boolean): User? =
        BaseUsersTable.selectAll()
            .where {
                if (includeDeleted) BaseUsersTable.id eq id
                else (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNull()
            }
            .firstOrNull()
            ?.let(User::fromRow)

    private fun validateRoles(roles: List<String>) {
        val unknown = roles.filterNot(roleRegistry::isValid)
        require(unknown.isEmpty()) { "Unknown role(s): $unknown" }
    }
}
