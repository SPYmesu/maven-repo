package su.spyme.marketplace.uploads.storage

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.slf4j.LoggerFactory
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import kotlin.io.path.createDirectories
import kotlin.io.path.deleteIfExists
import kotlin.io.path.exists
import kotlin.io.path.inputStream
import kotlin.io.path.isRegularFile
import kotlin.io.path.outputStream
import kotlin.time.Duration

/**
 * [StorageProvider] backed by the local filesystem. Default for dev
 * and small single-host deploys. Production multi-host setups should
 * swap in `S3StorageProvider` (`storage-s3` module).
 *
 * Layout: `<root>/<bucket>/<sharded-key>`. Keys with `/` separators
 * land as nested directories. Sharding (e.g. `aa/bb/<rest>`) is the
 * caller's responsibility — this provider just respects whatever
 * key it gets.
 *
 * Concurrency: writes go through `Files.write(... REPLACE_EXISTING)`,
 * so a concurrent write to the same key produces a deterministic
 * outcome (last-writer-wins). Reads are open-and-stream; the
 * `InputStream` returned by [get] is the caller's to close.
 */
class LocalStorageProvider(
    private val root: Path,
) : StorageProvider {

    override val name: String = "local"

    private val log = LoggerFactory.getLogger(LocalStorageProvider::class.java)

    init {
        if (!root.exists()) {
            root.createDirectories()
            log.info("LocalStorageProvider created storage root at {}", root)
        }
    }

    override suspend fun put(
        bucket: String,
        key: String,
        bytes: ByteArray,
        contentType: String,
    ): StorageRef = withContext(Dispatchers.IO) {
        val target = pathFor(bucket, key)
        target.parent.createDirectories()
        target.outputStream().use { it.write(bytes) }
        StorageRef(provider = name, bucket = bucket, key = key)
    }

    override suspend fun get(bucket: String, key: String): InputStream? = withContext(Dispatchers.IO) {
        val target = pathFor(bucket, key)
        if (!target.exists() || !target.isRegularFile()) null else target.inputStream()
    }

    override suspend fun delete(bucket: String, key: String): Boolean = withContext(Dispatchers.IO) {
        val target = pathFor(bucket, key)
        target.deleteIfExists()
    }

    override suspend fun signedUrl(bucket: String, key: String, ttl: Duration): String? {
        // Local FS doesn't expose blobs over HTTP directly — the host
        // serves them through its own controller. Return null so the
        // caller knows to fall back to that path.
        return null
    }

    /** Test/diagnostic accessor — full filesystem path for a key. */
    fun pathFor(bucket: String, key: String): Path = root.resolve(bucket).resolve(key)

    /**
     * Atomic replace primitive used by host code that buffers data to
     * a temp file before commit. Not part of [StorageProvider] — it's
     * a backend-specific extension.
     */
    fun moveInto(bucket: String, key: String, source: Path) {
        val target = pathFor(bucket, key)
        target.parent.createDirectories()
        Files.move(source, target, StandardCopyOption.REPLACE_EXISTING)
    }
}
