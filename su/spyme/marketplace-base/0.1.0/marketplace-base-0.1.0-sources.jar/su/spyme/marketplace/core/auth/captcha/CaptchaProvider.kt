package su.spyme.marketplace.core.auth.captcha

/**
 * Verifies a CAPTCHA challenge token with an external service. Hosts
 * register exactly one provider via CaptchaProviderRegistry; modules
 * (`captcha-hcaptcha`, `captcha-recaptcha`, `captcha-yandex-smartcaptcha`)
 * implement this contract.
 *
 * If the host doesn't activate any captcha module, the registry stays
 * empty and call sites short-circuit to "verified" — see
 * [NoOpCaptchaProvider].
 */
interface CaptchaProvider {
    val name: String

    suspend fun verify(token: String, action: String, remoteIp: String): VerificationResult

    sealed class VerificationResult {
        data object Verified : VerificationResult()
        data class Failed(val reason: String) : VerificationResult()
    }
}

/** Default no-op provider — accepts any token. Used when no captcha module is wired up. */
object NoOpCaptchaProvider : CaptchaProvider {
    override val name: String = "noop"
    override suspend fun verify(token: String, action: String, remoteIp: String): CaptchaProvider.VerificationResult =
        CaptchaProvider.VerificationResult.Verified
}
