package su.spyme.marketplace.catalog.attributes

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import su.spyme.marketplace.catalog.categories.BaseCategoriesTable

object BaseCategoryAttributesTable : Table("category_attributes") {
    val categoryId: Column<Long> = long("category_id").references(BaseCategoriesTable.id)
    val attributeId: Column<Long> = long("attribute_id").references(BaseAttributeDefinitionsTable.id)
    val sortOrder: Column<Int> = integer("sort_order").default(0)
    val isRequired: Column<Boolean?> = bool("is_required").nullable()

    override val primaryKey = PrimaryKey(categoryId, attributeId)
}
