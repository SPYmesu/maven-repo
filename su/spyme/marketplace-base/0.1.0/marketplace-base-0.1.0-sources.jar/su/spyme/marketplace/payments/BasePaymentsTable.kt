package su.spyme.marketplace.payments

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/**
 * Payment lifecycle status, decoupled from order status. Mirrors the
 * V011 CHECK constraint.
 *
 * - INITIATED: created locally, gateway hasn't accepted yet.
 * - AUTHORIZED: funds reserved (3-D Secure / hold flow).
 * - CAPTURED: funds taken; OrdersService can move the order to PAID.
 * - FAILED: gateway rejected.
 * - CANCELLED: user/admin abandoned before capture.
 * - REFUNDED: bookkeeping state once a matching refund completes the
 *   full amount.
 */
enum class PaymentStatus {
    INITIATED, AUTHORIZED, CAPTURED, FAILED, CANCELLED, REFUNDED;

    companion object {
        fun parse(value: String): PaymentStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown PaymentStatus: '$value'")
    }
}

object BasePaymentsTable : Table("payments") {
    val id: Column<Long> = long("id").autoIncrement()
    val orderId: Column<Long> = long("order_id")
    val provider: Column<String> = varchar("provider", 32)
    val providerPaymentId: Column<String?> = varchar("provider_payment_id", 128).nullable()
    val status: Column<String> = varchar("status", 32).default("INITIATED")
    val amount: Column<Long> = long("amount")
    val currency: Column<String> = varchar("currency", 3)
    val idempotencyKey: Column<String> = varchar("idempotency_key", 128)
    val gatewayMetadata: Column<JsonElement?> =
        jsonb("gateway_metadata", Json, JsonElement.serializer()).nullable()
    val failureReason: Column<String?> = text("failure_reason").nullable()
    val initiatedAt: Column<Instant> = timestamp("initiated_at").defaultExpression(NowExpression)
    val authorizedAt: Column<Instant?> = timestamp("authorized_at").nullable()
    val capturedAt: Column<Instant?> = timestamp("captured_at").nullable()
    val failedAt: Column<Instant?> = timestamp("failed_at").nullable()
    val cancelledAt: Column<Instant?> = timestamp("cancelled_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * One payment attempt. Multiple rows per order are normal (retries,
 * authorize+capture, refunds writing their own rows in subsequent
 * E6.4 work).
 *
 * @property idempotencyKey Producer-supplied — combined with provider
 *           it uniquely identifies the attempt so the gateway can
 *           safely retry transient errors.
 */
data class Payment(
    val id: Long,
    val orderId: Long,
    val provider: String,
    val providerPaymentId: String?,
    val status: PaymentStatus,
    val money: Money,
    val idempotencyKey: String,
    val gatewayMetadata: JsonElement?,
    val failureReason: String?,
    val initiatedAt: Instant,
    val authorizedAt: Instant?,
    val capturedAt: Instant?,
    val failedAt: Instant?,
    val cancelledAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isSettled: Boolean get() = status == PaymentStatus.CAPTURED || status == PaymentStatus.REFUNDED

    companion object {
        fun fromRow(row: ResultRow): Payment = Payment(
            id = row[BasePaymentsTable.id],
            orderId = row[BasePaymentsTable.orderId],
            provider = row[BasePaymentsTable.provider],
            providerPaymentId = row[BasePaymentsTable.providerPaymentId],
            status = PaymentStatus.parse(row[BasePaymentsTable.status]),
            money = Money(row[BasePaymentsTable.amount], row[BasePaymentsTable.currency]),
            idempotencyKey = row[BasePaymentsTable.idempotencyKey],
            gatewayMetadata = row[BasePaymentsTable.gatewayMetadata],
            failureReason = row[BasePaymentsTable.failureReason],
            initiatedAt = row[BasePaymentsTable.initiatedAt],
            authorizedAt = row[BasePaymentsTable.authorizedAt],
            capturedAt = row[BasePaymentsTable.capturedAt],
            failedAt = row[BasePaymentsTable.failedAt],
            cancelledAt = row[BasePaymentsTable.cancelledAt],
            createdAt = row[BasePaymentsTable.createdAt],
            updatedAt = row[BasePaymentsTable.updatedAt],
        )
    }
}
