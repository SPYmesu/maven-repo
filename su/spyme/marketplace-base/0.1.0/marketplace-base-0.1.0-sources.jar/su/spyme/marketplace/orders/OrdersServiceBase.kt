package su.spyme.marketplace.orders

import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.orders.cancellation.CancellationReasonRegistry
import su.spyme.marketplace.orders.state.OrderStateMachine
import su.spyme.marketplace.orders.state.OrderStateMachineRegistry
import su.spyme.marketplace.orders.state.OrderStatus
import su.spyme.marketplace.orders.state.OrderTransitionEvent
import su.spyme.marketplace.orders.state.OrderTransitionListenerRegistry
import su.spyme.marketplace.orders.state.TransitionActor
import su.spyme.marketplace.refunds.BaseRefundsTable
import su.spyme.marketplace.refunds.RefundStatus
import java.time.Instant
import java.util.concurrent.atomic.AtomicLong

/**
 * Spec for one line being added to a brand-new order. Carries the
 * stable presentation snapshot the OrdersService writes into
 * [BaseOrderItemSnapshotsTable] — caller (CheckoutService / cart
 * conversion) builds it from the live product + translation rows.
 */
data class NewOrderItem(
    val productId: Long,
    val variantId: Long? = null,
    val vendorId: Long? = null,
    val quantity: Int,
    val unitPrice: Money,
    val snapshotMeta: JsonElement,
)

/**
 * Display status visible on the storefront / admin order list. Mirrors
 * [OrderStatus] but adds PARTIALLY_REFUNDED / REFUNDED — derived from
 * the refunds table, never persisted on the order row.
 */
enum class DisplayOrderStatus {
    NEW, AWAITING_PAYMENT, AWAITING_MANAGER, PAID, PROCESSING, SHIPPED,
    DELIVERED, CANCELLED, PARTIALLY_REFUNDED, REFUNDED,
}

/**
 * High-level orchestration over orders. Open class so hosts can
 * override individual steps — the moonstudio host overrides
 * `chooseStateMachine` to send digital orders through
 * `digitalManualConfirm` regardless of product_kind.
 */
open class OrdersServiceBase(
    protected val mainDb: Database,
    protected val stateMachines: OrderStateMachineRegistry,
    protected val listeners: OrderTransitionListenerRegistry,
    protected val cancellationReasons: CancellationReasonRegistry,
    /** Per-marketplace order-number prefix — e.g. "MS" for moonstudio. */
    protected val orderNumberPrefix: String = "MP",
) {

    private val log = LoggerFactory.getLogger(OrdersServiceBase::class.java)

    // Simple in-process counter for the suffix portion of order_number.
    // Real production deployments swap this for a sequence; the SQL
    // UNIQUE on order_number catches collisions either way.
    private val orderCounter = AtomicLong(System.currentTimeMillis() % 1_000_000)

    /**
     * Creates a new order in a single transaction:
     *   1. INSERT orders row in status NEW.
     *   2. INSERT order_items rows + matching order_item_snapshots.
     *   3. Compute totals; UPDATE orders row.
     * Caller transitions the order to AWAITING_PAYMENT / AWAITING_MANAGER
     * via [transition] right after — the split keeps creation atomic
     * even if a listener fails on the first transition.
     */
    open fun createOrder(
        userId: Long,
        productKind: String,
        items: List<NewOrderItem>,
        currency: String = "RUB",
        locale: String = "ru",
        billingAddress: JsonElement? = null,
        shippingAddress: JsonElement? = null,
        shipping: Money = Money(0, currency),
        tax: Money = Money(0, currency),
        discount: Money = Money(0, currency),
    ): Order {
        require(items.isNotEmpty()) { "order must have at least one item" }
        require(items.all { it.unitPrice.currency == currency }) {
            "all line items must use the order currency '$currency'"
        }

        return transaction(mainDb) {
            val newId = BaseOrdersTable.insert {
                it[BaseOrdersTable.userId] = userId
                it[BaseOrdersTable.orderNumber] = nextOrderNumber()
                it[BaseOrdersTable.status] = OrderStatus.NEW.name
                it[BaseOrdersTable.productKind] = productKind
                it[BaseOrdersTable.currency] = currency
                it[BaseOrdersTable.locale] = locale
                it[BaseOrdersTable.billingAddress] = billingAddress
                it[BaseOrdersTable.shippingAddress] = shippingAddress
                it[BaseOrdersTable.shippingAmount] = shipping.amount
                it[BaseOrdersTable.taxAmount] = tax.amount
                it[BaseOrdersTable.discountAmount] = discount.amount
            }[BaseOrdersTable.id]

            var subtotal = 0L
            items.forEach { item ->
                val lineTotal = Money(
                    amount = Math.multiplyExact(item.unitPrice.amount, item.quantity.toLong()),
                    currency = currency,
                )
                subtotal = Math.addExact(subtotal, lineTotal.amount)

                val itemId = BaseOrderItemsTable.insert {
                    it[BaseOrderItemsTable.orderId] = newId
                    it[BaseOrderItemsTable.productId] = item.productId
                    it[BaseOrderItemsTable.variantId] = item.variantId
                    it[BaseOrderItemsTable.vendorId] = item.vendorId
                    it[BaseOrderItemsTable.quantity] = item.quantity
                    it[BaseOrderItemsTable.unitPriceAmount] = item.unitPrice.amount
                    it[BaseOrderItemsTable.unitPriceCurrency] = currency
                    it[BaseOrderItemsTable.lineTotalAmount] = lineTotal.amount
                }[BaseOrderItemsTable.id]

                BaseOrderItemSnapshotsTable.insert {
                    it[BaseOrderItemSnapshotsTable.orderItemId] = itemId
                    it[BaseOrderItemSnapshotsTable.snapshotMeta] = item.snapshotMeta
                }
            }

            val total = Math.addExact(
                Math.addExact(Math.addExact(subtotal, shipping.amount), tax.amount),
                -discount.amount,
            )
            BaseOrdersTable.update({ BaseOrdersTable.id eq newId }) {
                it[BaseOrdersTable.subtotalAmount] = subtotal
                it[BaseOrdersTable.totalAmount] = total
            }

            loadById(newId)!!
        }
    }

    open fun findById(id: Long): Order? = transaction(mainDb) { loadById(id) }

    open fun findByOrderNumber(orderNumber: String): Order? = transaction(mainDb) {
        BaseOrdersTable.selectAll()
            .where { BaseOrdersTable.orderNumber eq orderNumber }
            .firstOrNull()
            ?.let(Order::fromRow)
    }

    open fun listForUser(userId: Long): List<Order> = transaction(mainDb) {
        BaseOrdersTable.selectAll()
            .where { BaseOrdersTable.userId eq userId }
            .orderBy(BaseOrdersTable.placedAt to SortOrder.DESC)
            .map(Order::fromRow)
    }

    open fun listItems(orderId: Long): List<OrderItem> = transaction(mainDb) {
        BaseOrderItemsTable.selectAll()
            .where { BaseOrderItemsTable.orderId eq orderId }
            .map(OrderItem::fromRow)
    }

    /**
     * Drives a status transition through the state machine, fires
     * transition listeners, and stamps the matching timestamp column
     * (paid_at / shipped_at / delivered_at).
     *
     * Validation throws [su.spyme.marketplace.orders.state.IllegalOrderTransitionException]
     * before any SQL writes — so callers can map it to a 422 response.
     */
    open fun transition(
        orderId: Long,
        to: OrderStatus,
        actor: TransitionActor,
        actorUserId: Long? = null,
        reason: String? = null,
        machineName: String? = null,
        now: Instant = Instant.now(),
    ): Order {
        val order = findById(orderId) ?: error("Order $orderId not found")
        val machine = chooseStateMachine(order, machineName)
        machine.validate(order.status, to, actor)

        val updated = transaction(mainDb) {
            BaseOrdersTable.update({ BaseOrdersTable.id eq orderId }) {
                it[BaseOrdersTable.status] = to.name
                when (to) {
                    OrderStatus.PAID -> it[BaseOrdersTable.paidAt] = now
                    OrderStatus.SHIPPED -> it[BaseOrdersTable.shippedAt] = now
                    OrderStatus.DELIVERED -> it[BaseOrdersTable.deliveredAt] = now
                    OrderStatus.CANCELLED -> {
                        it[BaseOrdersTable.cancelledAt] = now
                        it[BaseOrdersTable.cancelledBy] = actorUserId
                    }
                    else -> Unit
                }
            }
            loadById(orderId)!!
        }

        fireListeners(
            OrderTransitionEvent(
                orderId = orderId,
                from = order.status,
                to = to,
                actor = actor,
                actorUserId = actorUserId,
                reason = reason,
                occurredAt = now,
            ),
        )
        return updated
    }

    /**
     * Convenience around [transition] for cancellation. Validates the
     * reason against the registry and stamps the structured columns.
     */
    open fun cancel(
        orderId: Long,
        reasonCode: String,
        reasonText: String? = null,
        actor: TransitionActor,
        actorUserId: Long? = null,
        machineName: String? = null,
        now: Instant = Instant.now(),
    ): Order {
        val reason = cancellationReasons.getOrNull(reasonCode)
            ?: throw IllegalArgumentException("Unknown cancellation reason: '$reasonCode'")
        if (reason.requiredText) {
            require(!reasonText.isNullOrBlank()) {
                "reason '$reasonCode' requires a free-form reason_text"
            }
        }
        // Stamp the structured columns BEFORE transition fires listeners
        // so listener side-effects can read the reason.
        transaction(mainDb) {
            BaseOrdersTable.update({ BaseOrdersTable.id eq orderId }) {
                it[BaseOrdersTable.cancellationReasonCode] = reason.code
                it[BaseOrdersTable.cancellationReasonText] = reasonText
            }
        }
        return transition(
            orderId = orderId,
            to = OrderStatus.CANCELLED,
            actor = actor,
            actorUserId = actorUserId,
            reason = reasonText ?: reason.code,
            machineName = machineName,
            now = now,
        )
    }

    /**
     * Combines the operational [OrderStatus] with the refunds table to
     * produce the storefront-visible status. PARTIALLY_REFUNDED /
     * REFUNDED are *display* states — they live nowhere on the order
     * row.
     */
    open fun deriveDisplayStatus(order: Order): DisplayOrderStatus {
        val refundedAmount: Long = transaction(mainDb) {
            BaseRefundsTable.selectAll()
                .where {
                    (BaseRefundsTable.orderId eq order.id) and
                        (BaseRefundsTable.status eq RefundStatus.COMPLETED.name)
                }
                .sumOf { it[BaseRefundsTable.amount] }
        }
        return when {
            refundedAmount <= 0 -> order.status.toDisplay()
            refundedAmount >= order.total.amount -> DisplayOrderStatus.REFUNDED
            else -> DisplayOrderStatus.PARTIALLY_REFUNDED
        }
    }

    /** Override hook for hosts that pick a state machine by host policy. */
    protected open fun chooseStateMachine(order: Order, requestedName: String?): OrderStateMachine {
        val name = requestedName ?: when (order.productKind) {
            "DIGITAL" -> "digital"
            "PHYSICAL" -> "physical"
            else -> "mixed"
        }
        return stateMachines.get(name)
    }

    private fun fireListeners(event: OrderTransitionEvent) {
        if (listeners.isEmpty()) return
        runBlocking {
            listeners.all().forEach { listener ->
                runCatching { listener.onTransition(event) }
                    .onFailure { log.warn("OrderTransitionListener failed for {}", event, it) }
            }
        }
    }

    private fun loadById(id: Long): Order? = BaseOrdersTable.selectAll()
        .where { BaseOrdersTable.id eq id }
        .firstOrNull()
        ?.let(Order::fromRow)

    private fun nextOrderNumber(): String {
        val now = Instant.now()
        val year = now.toString().substring(0, 4)
        val seq = orderCounter.incrementAndGet().toString().padStart(6, '0')
        return "${orderNumberPrefix}-${year}-${seq}"
    }
}

private fun OrderStatus.toDisplay(): DisplayOrderStatus = DisplayOrderStatus.valueOf(this.name)
