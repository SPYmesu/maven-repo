package su.spyme.marketplace.core.search.pgtrgm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.search.IndexableDocument
import su.spyme.marketplace.core.search.SearchMode
import su.spyme.marketplace.core.search.SearchProvider
import su.spyme.marketplace.core.search.SearchQuery
import su.spyme.marketplace.core.search.SearchResult
import java.sql.ResultSet

/**
 * Degraded fallback [SearchProvider] backed by PostgreSQL's `pg_trgm`
 * extension. Per В6 of the architecture plan, this is what answers
 * search traffic while the circuit breaker around MeiliSearch is open.
 *
 * Compromises (about 60% of full-fidelity search):
 * - No typo-tolerance — pg_trgm uses trigram overlap.
 * - No ranking rules — purely `similarity()` desc.
 * - No facets — returns an empty `facetDistribution`.
 * - No filters — host plan implementations can layer them in via
 *   subclassing if absolutely needed.
 *
 * Mutating operations (`upsert`, `delete`, `reindex`) are no-ops:
 * pg_trgm reads the source tables directly, so producers don't need
 * to push anything into a separate index.
 *
 * Plan registry: each logical index name (`products`, `users`, …)
 * maps to a [PgTrgmSearchPlan] describing the FROM clause, the
 * trigram-comparable columns, and how to decode result rows. Hosts
 * register plans during the bootstrap registration phase; an unknown
 * index returns an empty page.
 *
 * Result mode is always `DEGRADED` — front-ends use that signal to
 * show "search is in fallback mode" banners.
 */
open class PgTrgmSearchProvider(
    protected val mainDb: Database,
    protected val plans: Map<String, PgTrgmSearchPlan> = emptyMap(),
    protected val similarityThreshold: Double = 0.3,
) : SearchProvider {

    override val name: String = "pg_trgm"

    private val log = LoggerFactory.getLogger(PgTrgmSearchProvider::class.java)

    override suspend fun isHealthy(): Boolean = true

    override suspend fun upsert(document: IndexableDocument) {
        // pg_trgm reads source tables directly — nothing to push.
    }

    override suspend fun upsertBatch(documents: List<IndexableDocument>) {
        // intentional no-op
    }

    override suspend fun delete(indexName: String, id: String) {
        // intentional no-op
    }

    override suspend fun deleteBatch(indexName: String, ids: List<String>) {
        // intentional no-op
    }

    override suspend fun reindex(indexName: String, documents: Sequence<IndexableDocument>) {
        // Drain the producer side so it can shut down.
        documents.count()
    }

    override suspend fun search(query: SearchQuery): SearchResult = withContext(Dispatchers.IO) {
        val plan = plans[query.indexName]
        if (plan == null) {
            log.debug("No pg_trgm plan registered for index '{}'; returning empty result", query.indexName)
            return@withContext emptyResult(query)
        }

        val term = query.query?.takeIf { it.isNotBlank() }

        transaction(mainDb) {
            executeSearch(plan, query, term)
        }
    }

    /** Override hook for hosts that want to layer in custom filter / sort SQL. */
    protected open fun executeSearch(
        plan: PgTrgmSearchPlan,
        query: SearchQuery,
        term: String?,
    ): SearchResult {
        val (countSql, dataSql, params) = plan.buildSql(
            term = term,
            similarityThreshold = similarityThreshold,
            limit = query.limit,
            offset = query.offset,
        )

        var total: Long = 0
        org.jetbrains.exposed.sql.transactions.TransactionManager.current().connection.prepareStatement(countSql, false).run {
            params.forEach { (idx, value) -> setStmtParam(this, idx, value) }
            executeQuery().use { rs ->
                if (rs.next()) total = rs.getLong(1)
            }
        }

        val hits: List<IndexableDocument> = org.jetbrains.exposed.sql.transactions.TransactionManager.current()
            .connection.prepareStatement(dataSql, false).run {
                params.forEach { (idx, value) -> setStmtParam(this, idx, value) }
                executeQuery().use { rs ->
                    buildList {
                        while (rs.next()) add(plan.decodeRow(query.indexName, rs))
                    }
                }
            }

        return SearchResult(
            indexName = query.indexName,
            totalHits = total,
            limit = query.limit,
            offset = query.offset,
            hits = hits,
            facetDistribution = emptyMap(),
            mode = SearchMode.DEGRADED,
        )
    }

    private fun emptyResult(query: SearchQuery): SearchResult = SearchResult(
        indexName = query.indexName,
        totalHits = 0,
        limit = query.limit,
        offset = query.offset,
        hits = emptyList(),
        mode = SearchMode.DEGRADED,
    )

    private fun setStmtParam(
        stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi,
        index: Int,
        value: Any?,
    ) {
        when (value) {
            null -> stmt.fillParameters(emptyList())
            is String -> stmt[index] = value
            is Number -> stmt[index] = value
            is Boolean -> stmt[index] = value
            else -> stmt[index] = value.toString()
        }
    }
}

/**
 * Wire-up plan for one logical index. Host registers an instance per
 * index name during bootstrap; the provider consults this when
 * answering [SearchProvider.search] in degraded mode.
 */
interface PgTrgmSearchPlan {
    val indexName: String

    /**
     * Builds the SQL pair `(countSql, dataSql)` plus the indexed
     * parameters to bind. The query references the search term as
     * needed; pass `null` to mean "match all rows".
     *
     * @param term The user's free-form search term, or `null` to skip
     *        similarity filtering.
     * @param similarityThreshold Trigram threshold used in
     *        `similarity(col, term) > threshold` predicates. Ignored
     *        when [term] is null.
     */
    fun buildSql(
        term: String?,
        similarityThreshold: Double,
        limit: Int,
        offset: Int,
    ): SqlPair

    /** Decodes a single row from the data query into an [IndexableDocument]. */
    fun decodeRow(indexName: String, rs: ResultSet): IndexableDocument

    /**
     * SQL statements + parameter binds for the search.
     *
     * @property countSql `SELECT COUNT(*) FROM ...` — must accept the
     *           same params (or a subset) as [dataSql].
     * @property dataSql `SELECT id, ... FROM ... LIMIT ? OFFSET ?` —
     *           returns the page of hits.
     * @property params Indexed binds keyed by 1-based parameter index.
     */
    data class SqlPair(
        val countSql: String,
        val dataSql: String,
        val params: Map<Int, Any?>,
    )
}

/**
 * Convenience helper for hosts to assemble a [JsonObject] of fields
 * for [IndexableDocument] from a JDBC [ResultSet].
 */
fun ResultSet.readJsonFields(columns: List<String>): JsonObject {
    val map = LinkedHashMap<String, JsonElement>()
    columns.forEach { col ->
        val value = getObject(col)
        map[col] = when (value) {
            null -> JsonPrimitive(null as String?)
            is Number -> JsonPrimitive(value)
            is Boolean -> JsonPrimitive(value)
            else -> JsonPrimitive(value.toString())
        }
    }
    return JsonObject(map)
}
