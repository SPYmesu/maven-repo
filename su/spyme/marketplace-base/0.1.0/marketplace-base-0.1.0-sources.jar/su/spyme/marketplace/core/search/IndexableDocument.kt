package su.spyme.marketplace.core.search

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Single document destined for the search index. The producer (e.g.
 * `ProductsServiceBase`) builds these and hands them to a
 * [SearchProvider]; provider implementations decide how the JSON
 * structure maps onto their wire format.
 *
 * @property indexName Logical index — e.g. `"products"`, `"users"`.
 *           Real provider names are namespaced via
 *           [su.spyme.marketplace.core.BaseConfig.Search.indexPrefix]
 *           so two marketplaces can share one MeiliSearch instance.
 * @property id Entity primary key as a string. The same id used to
 *           upsert is used to delete.
 * @property fields Indexed payload. Convention: scalar values stay
 *           scalar (`"price": 1234`); arrays stay arrays
 *           (`"category_path": ["Electronics", "Phones"]`).
 */
data class IndexableDocument(
    val indexName: String,
    val id: String,
    val fields: JsonObject,
) {
    /** Convenience accessor for a single field. */
    operator fun get(name: String): JsonElement? = fields[name]
}
