package su.spyme.marketplace.core.auth

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-GCM helper for at-rest encryption of secrets per В2 of the
 * architecture plan. Used by TotpService (TOTP secrets), OAuth token
 * storage, WebAuthn credentials, and GDPR legal-archive PII payloads.
 *
 * Wire format (in the SQL BYTEA column):
 *   nonce(12) || ciphertext || tag(16)
 *
 * Each [encrypt] call generates a fresh 12-byte nonce — never reuse
 * a (key, nonce) pair under GCM. The 16-byte authentication tag is
 * appended by the cipher; decryption fails with [BadPaddingException]
 * if the bytes were tampered.
 *
 * Key rotation: master keys live in env (e.g. `MARKETPLACE_TOTP_KEY_V1`)
 * with version suffixes. Pass [keyVersion] = 1 alongside the
 * ciphertext to remember which key wrapped it; a background job
 * walks rows when activeKeyVersion bumps and re-encrypts to the new
 * key.
 *
 * @property key Raw 32-byte (256-bit) AES key. Hosts decode this from
 *           the base64-encoded env var.
 */
class SecretEncryption(private val key: ByteArray) {

    init {
        require(key.size == 32) { "AES-256-GCM requires a 32-byte key, got ${key.size}" }
    }

    fun encrypt(plaintext: ByteArray): ByteArray {
        val nonce = ByteArray(NONCE_LEN).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_LEN_BITS, nonce))
        val sealed = cipher.doFinal(plaintext)
        return nonce + sealed // sealed already carries the appended 16-byte tag
    }

    fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > NONCE_LEN + TAG_LEN_BITS / 8) { "blob too short to contain nonce+tag" }
        val nonce = blob.copyOfRange(0, NONCE_LEN)
        val sealed = blob.copyOfRange(NONCE_LEN, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_LEN_BITS, nonce))
        return cipher.doFinal(sealed)
    }

    fun encryptString(plaintext: String): ByteArray = encrypt(plaintext.toByteArray(Charsets.UTF_8))
    fun decryptString(blob: ByteArray): String = String(decrypt(blob), Charsets.UTF_8)

    companion object {
        const val NONCE_LEN = 12
        const val TAG_LEN_BITS = 128

        /** Convenience: decode a base64 master key from an env var. */
        fun fromBase64Key(base64: String): SecretEncryption =
            SecretEncryption(Base64.getDecoder().decode(base64))
    }
}
