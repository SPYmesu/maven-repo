package su.spyme.marketplace.core.i18n

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Per-host registry of machine-translation providers. Hosts register
 * one or more concrete [MachineTranslator] instances during phase-2
 * (Plugins) of the bootstrap; admin UIs and seed routines pick one
 * via [active] (or [pickOrDefault] when an explicit provider key is
 * configured per-form).
 *
 * The default active translator is whichever was registered first.
 * Hosts override by calling [setActive] explicitly. A
 * [NoOpMachineTranslator] is registered automatically on construction
 * so calls never NPE before the host has wired up a real provider.
 *
 * Threading: registration happens single-threaded during bootstrap;
 * [active] / [setActive] are guarded for concurrent reads/writes
 * because admin UI fan-out happens on multiple Ktor request threads.
 */
class MachineTranslatorRegistry {

    private val registry = ConflictRegistry<String, MachineTranslator>("MachineTranslatorRegistry")
    private val active = java.util.concurrent.atomic.AtomicReference<MachineTranslator>()

    init {
        val noop = NoOpMachineTranslator()
        registry.register(noop.providerCode, noop)
        active.set(noop)
    }

    /** Register [translator]; throws [su.spyme.marketplace.core.registry.DuplicateRegistrationException] if its [MachineTranslator.providerCode] is taken. */
    fun register(translator: MachineTranslator) {
        registry.register(translator.providerCode, translator)
    }

    /**
     * Pin [providerCode] as the default for unscoped calls. Subsequent
     * calls to [active] return that translator; per-call
     * [pickOrDefault] still respects an explicit override.
     *
     * @throws su.spyme.marketplace.core.registry.MissingRegistrationException if [providerCode] was never registered.
     */
    fun setActive(providerCode: String) {
        active.set(registry.get(providerCode))
    }

    /** The currently active translator. Defaults to NoOp until a real provider is registered + selected. */
    fun active(): MachineTranslator = active.get()

    /** Look up a specific translator. Useful for A/B comparisons in admin UIs. */
    fun get(providerCode: String): MachineTranslator = registry.get(providerCode)

    /**
     * Returns the translator for [providerCode] when the caller knows
     * which one it wants (typically from `BaseConfig.i18n.translator`),
     * or [active] when the caller is happy with the host default.
     */
    fun pickOrDefault(providerCode: String?): MachineTranslator =
        if (providerCode == null) active() else registry.get(providerCode)

    /** All registered providers in registration order. */
    fun list(): List<MachineTranslator> = registry.values().toList()
}
