package su.spyme.marketplace.catalog.products

import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.upsert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import java.time.Instant

open class ProductsServiceBase(protected val mainDb: Database) {

    open fun createProduct(
        categoryId: Long,
        slug: String,
        productKind: ProductKind,
        price: Money = Money.ZERO_RUB,
        status: ProductStatus = ProductStatus.DRAFT,
        vendorId: Long? = null,
        maxTotalPurchases: Int? = null,
        maxPerUserPurchases: Int? = null,
    ): Product {
        require(slug.isNotBlank()) { "slug must not be blank" }
        require((maxTotalPurchases ?: 1) > 0) { "maxTotalPurchases must be positive" }
        require((maxPerUserPurchases ?: 1) > 0) { "maxPerUserPurchases must be positive" }

        return transaction(mainDb) {
            val newId = BaseProductsTable.insert {
                it[BaseProductsTable.categoryId] = categoryId
                it[BaseProductsTable.slug] = slug
                it[BaseProductsTable.productKind] = productKind.name
                it[BaseProductsTable.status] = status.name
                it[BaseProductsTable.vendorId] = vendorId
                it[BaseProductsTable.priceAmount] = price.amount
                it[BaseProductsTable.priceCurrency] = price.currency
                it[BaseProductsTable.maxTotalPurchases] = maxTotalPurchases
                it[BaseProductsTable.maxPerUserPurchases] = maxPerUserPurchases
                if (status == ProductStatus.PUBLISHED) {
                    it[BaseProductsTable.publishedAt] = Instant.now()
                }
            }[BaseProductsTable.id]
            loadById(newId, includeArchived = true) ?: error("inserted product $newId not found in tx")
        }
    }

    open fun findById(id: Long, includeArchived: Boolean = false): Product? = transaction(mainDb) {
        loadById(id, includeArchived)
    }

    open fun findBySlug(slug: String, includeArchived: Boolean = false): Product? = transaction(mainDb) {
        BaseProductsTable.selectAll()
            .where {
                if (includeArchived) BaseProductsTable.slug eq slug
                else (BaseProductsTable.slug eq slug) and BaseProductsTable.archivedAt.isNull()
            }
            .firstOrNull()
            ?.let(Product::fromRow)
    }

    open fun listByCategory(
        categoryId: Long,
        status: ProductStatus? = ProductStatus.PUBLISHED,
    ): List<Product> = transaction(mainDb) {
        BaseProductsTable.selectAll()
            .where {
                val byCategory = (BaseProductsTable.categoryId eq categoryId) and
                    BaseProductsTable.archivedAt.isNull()
                if (status == null) byCategory else byCategory and (BaseProductsTable.status eq status.name)
            }
            .orderBy(BaseProductsTable.publishedAt to SortOrder.DESC_NULLS_LAST)
            .map(Product::fromRow)
    }

    open fun updatePrice(id: Long, price: Money) {
        transaction(mainDb) {
            BaseProductsTable.update({ BaseProductsTable.id eq id }) {
                it[BaseProductsTable.priceAmount] = price.amount
                it[BaseProductsTable.priceCurrency] = price.currency
            }
        }
    }

    open fun publish(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseProductsTable.update({ BaseProductsTable.id eq id }) {
                it[BaseProductsTable.status] = ProductStatus.PUBLISHED.name
                it[BaseProductsTable.publishedAt] = now
            }
        }
    }

    open fun archive(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseProductsTable.update({ BaseProductsTable.id eq id }) {
                it[BaseProductsTable.status] = ProductStatus.ARCHIVED.name
                it[BaseProductsTable.archivedAt] = now
            }
        }
    }

    open fun restoreFromArchive(id: Long) {
        transaction(mainDb) {
            BaseProductsTable.update({ BaseProductsTable.id eq id }) {
                it[BaseProductsTable.status] = ProductStatus.DRAFT.name
                it[BaseProductsTable.archivedAt] = null
            }
        }
    }

    open fun upsertTranslation(
        productId: Long,
        locale: String,
        title: String,
        shortDescription: String? = null,
        description: String? = null,
        isMachineTranslated: Boolean = false,
    ): ProductTranslation = transaction(mainDb) {
        BaseProductTranslationsTable.upsert {
            it[BaseProductTranslationsTable.productId] = productId
            it[BaseProductTranslationsTable.locale] = locale
            it[BaseProductTranslationsTable.title] = title
            it[BaseProductTranslationsTable.shortDescription] = shortDescription
            it[BaseProductTranslationsTable.description] = description
            it[BaseProductTranslationsTable.isMachineTranslated] = isMachineTranslated
        }
        BaseProductTranslationsTable.selectAll()
            .where {
                (BaseProductTranslationsTable.productId eq productId) and
                    (BaseProductTranslationsTable.locale eq locale)
            }
            .first()
            .let(ProductTranslation::fromRow)
    }

    open fun listTranslations(productId: Long): List<ProductTranslation> = transaction(mainDb) {
        BaseProductTranslationsTable.selectAll()
            .where { BaseProductTranslationsTable.productId eq productId }
            .map(ProductTranslation::fromRow)
    }

    /**
     * Upsert one EAV value. locale=NULL for non-translatable attributes;
     * pass a language tag for translatable STRING/TEXT attributes.
     * Manual upsert because the SQL uniqueness lives in an expression
     * index and Exposed's replace() doesn't drive expression indexes.
     */
    open fun setAttributeValue(
        productId: Long,
        attributeId: Long,
        value: JsonElement,
        locale: String? = null,
    ) {
        transaction(mainDb) {
            val matched = BaseProductAttributeValuesTable.update({ matchValueRow(productId, attributeId, locale) }) {
                it[BaseProductAttributeValuesTable.value] = value
            }
            if (matched == 0) {
                BaseProductAttributeValuesTable.insert {
                    it[BaseProductAttributeValuesTable.productId] = productId
                    it[BaseProductAttributeValuesTable.attributeId] = attributeId
                    it[BaseProductAttributeValuesTable.locale] = locale
                    it[BaseProductAttributeValuesTable.value] = value
                }
            }
        }
    }

    open fun removeAttributeValue(productId: Long, attributeId: Long, locale: String? = null): Boolean =
        transaction(mainDb) {
            BaseProductAttributeValuesTable.deleteWhere { matchValueRow(productId, attributeId, locale) } > 0
        }

    /** All EAV values for a product, regardless of attribute archive status. */
    open fun listAttributeValues(productId: Long): List<ProductAttributeValue> = transaction(mainDb) {
        BaseProductAttributeValuesTable.selectAll()
            .where { BaseProductAttributeValuesTable.productId eq productId }
            .map { row ->
                ProductAttributeValue(
                    productId = row[BaseProductAttributeValuesTable.productId],
                    attributeId = row[BaseProductAttributeValuesTable.attributeId],
                    locale = row[BaseProductAttributeValuesTable.locale],
                    value = row[BaseProductAttributeValuesTable.value],
                )
            }
    }

    open fun incrementPurchaseCount(id: Long, by: Int = 1) {
        require(by > 0) { "increment must be positive" }
        transaction(mainDb) {
            BaseProductsTable.update({ BaseProductsTable.id eq id }) {
                with(org.jetbrains.exposed.sql.SqlExpressionBuilder) {
                    it[BaseProductsTable.totalPurchaseCount] = BaseProductsTable.totalPurchaseCount + by
                }
            }
        }
    }

    private fun loadById(id: Long, includeArchived: Boolean): Product? =
        BaseProductsTable.selectAll()
            .where {
                if (includeArchived) BaseProductsTable.id eq id
                else (BaseProductsTable.id eq id) and BaseProductsTable.archivedAt.isNull()
            }
            .firstOrNull()
            ?.let(Product::fromRow)

    private fun matchValueRow(productId: Long, attributeId: Long, locale: String?): Op<Boolean> = Op.build {
        val productAndAttr = (BaseProductAttributeValuesTable.productId eq productId) and
            (BaseProductAttributeValuesTable.attributeId eq attributeId)
        if (locale == null) {
            productAndAttr and BaseProductAttributeValuesTable.locale.isNull()
        } else {
            productAndAttr and (BaseProductAttributeValuesTable.locale eq locale)
        }
    }
}

data class ProductAttributeValue(
    val productId: Long,
    val attributeId: Long,
    val locale: String?,
    val value: JsonElement,
)
