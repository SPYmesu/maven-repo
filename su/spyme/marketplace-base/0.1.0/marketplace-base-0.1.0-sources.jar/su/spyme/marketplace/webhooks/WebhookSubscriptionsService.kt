package su.spyme.marketplace.webhooks

import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.security.SecureRandom
import java.time.Instant
import java.util.UUID

/**
 * CRUD around webhook subscriptions. Validates `event_types` against
 * the [WebhookEventRegistry] so consumers never accidentally
 * subscribe to a typo.
 */
open class WebhookSubscriptionsService(
    protected val mainDb: Database,
    protected val events: WebhookEventRegistry,
) {

    /**
     * Creates a subscription. The signing secret is generated server-
     * side; the caller renders it once in the admin UI for the
     * consumer to install on their endpoint.
     */
    open fun create(
        name: String,
        targetUrl: String,
        eventTypes: List<String>,
        ownerUserId: Long? = null,
        maxConcurrentDeliveries: Int = 5,
        maxPerMinute: Int = 600,
        coalescingWindowSeconds: Int = 0,
        filters: JsonElement? = null,
    ): CreatedSubscription {
        require(name.isNotBlank()) { "name must not be blank" }
        require(targetUrl.startsWith("http")) { "targetUrl must be an http(s) URL" }
        require(eventTypes.isNotEmpty()) { "eventTypes must not be empty" }
        validateEventTypes(eventTypes)

        val secret = generateSecret()
        val rowId = UUID.randomUUID()
        val sub = transaction(mainDb) {
            BaseWebhookSubscriptionsTable.insert {
                it[BaseWebhookSubscriptionsTable.id] = rowId
                it[BaseWebhookSubscriptionsTable.name] = name
                it[BaseWebhookSubscriptionsTable.targetUrl] = targetUrl
                it[BaseWebhookSubscriptionsTable.eventTypes] = eventTypes
                it[BaseWebhookSubscriptionsTable.secretCurrent] = secret
                it[BaseWebhookSubscriptionsTable.maxConcurrentDeliveries] = maxConcurrentDeliveries.toShort()
                it[BaseWebhookSubscriptionsTable.maxPerMinute] = maxPerMinute
                it[BaseWebhookSubscriptionsTable.coalescingWindowSeconds] = coalescingWindowSeconds
                it[BaseWebhookSubscriptionsTable.filters] = filters
                it[BaseWebhookSubscriptionsTable.ownerUserId] = ownerUserId
            }
            loadById(rowId)!!
        }
        return CreatedSubscription(subscription = sub, plaintextSecret = secret)
    }

    /**
     * Rotates the signing secret. Old secret remains valid for the
     * grace window (Б5: 7 days) — controlled by
     * [BaseConfig.Webhook.secretRotationGrace] when host wires it.
     * Returns the new plaintext secret to render in admin UI once.
     */
    open fun rotateSecret(id: UUID, now: Instant = Instant.now()): String {
        val newSecret = generateSecret()
        transaction(mainDb) {
            val current = loadById(id)?.secretCurrent
                ?: error("subscription $id not found")
            BaseWebhookSubscriptionsTable.update({ BaseWebhookSubscriptionsTable.id eq id }) {
                it[BaseWebhookSubscriptionsTable.secretPrevious] = current
                it[BaseWebhookSubscriptionsTable.secretCurrent] = newSecret
                it[BaseWebhookSubscriptionsTable.secretRotatedAt] = now
            }
        }
        return newSecret
    }

    /** Marks the subscription inactive — worker stops dispatching but rows stay. */
    open fun deactivate(id: UUID) {
        transaction(mainDb) {
            BaseWebhookSubscriptionsTable.update({ BaseWebhookSubscriptionsTable.id eq id }) {
                it[BaseWebhookSubscriptionsTable.isActive] = false
            }
        }
    }

    open fun activate(id: UUID) {
        transaction(mainDb) {
            BaseWebhookSubscriptionsTable.update({ BaseWebhookSubscriptionsTable.id eq id }) {
                it[BaseWebhookSubscriptionsTable.isActive] = true
            }
        }
    }

    open fun delete(id: UUID): Boolean = transaction(mainDb) {
        BaseWebhookSubscriptionsTable.deleteWhere { BaseWebhookSubscriptionsTable.id eq id } > 0
    }

    open fun findById(id: UUID): WebhookSubscription? = transaction(mainDb) { loadById(id) }

    open fun listForOwner(userId: Long): List<WebhookSubscription> = transaction(mainDb) {
        BaseWebhookSubscriptionsTable.selectAll()
            .where { BaseWebhookSubscriptionsTable.ownerUserId eq userId }
            .map(WebhookSubscription::fromRow)
    }

    open fun listAll(activeOnly: Boolean = false): List<WebhookSubscription> = transaction(mainDb) {
        BaseWebhookSubscriptionsTable.selectAll()
            .where {
                if (activeOnly) BaseWebhookSubscriptionsTable.isActive eq true
                else org.jetbrains.exposed.sql.Op.TRUE
            }
            .map(WebhookSubscription::fromRow)
    }

    /**
     * Finds subscriptions interested in [eventCode] using the GIN
     * index on event_types. Includes wildcards `*` subscribers.
     */
    open fun listForEvent(eventCode: String): List<WebhookSubscription> = transaction(mainDb) {
        // Plain SELECT … WHERE event_types && ARRAY['code', '*']. Exposed
        // doesn't surface the && operator natively, so raw SQL.
        val rows = mutableListOf<WebhookSubscription>()
        exec(
            """
            SELECT id, name, target_url, event_types, secret_current, secret_previous,
                   secret_rotated_at, max_concurrent_deliveries, max_per_minute,
                   coalescing_window_seconds, filters, owner_user_id, is_active,
                   created_at, updated_at
            FROM webhook_subscriptions
            WHERE is_active = TRUE
              AND event_types && ARRAY[?, '*']::VARCHAR(128)[]
            """.trimIndent(),
            listOf(org.jetbrains.exposed.sql.VarCharColumnType() to eventCode),
        ) { rs ->
            while (rs.next()) {
                @Suppress("UNCHECKED_CAST")
                val eventTypes = (rs.getArray("event_types").array as Array<String?>)
                    .filterNotNull()
                rows += WebhookSubscription(
                    id = rs.getObject("id", UUID::class.java),
                    name = rs.getString("name"),
                    targetUrl = rs.getString("target_url"),
                    eventTypes = eventTypes,
                    secretCurrent = rs.getString("secret_current"),
                    secretPrevious = rs.getString("secret_previous"),
                    secretRotatedAt = rs.getTimestamp("secret_rotated_at")?.toInstant(),
                    maxConcurrentDeliveries = rs.getShort("max_concurrent_deliveries").toInt(),
                    maxPerMinute = rs.getInt("max_per_minute"),
                    coalescingWindowSeconds = rs.getInt("coalescing_window_seconds"),
                    filters = null, // raw fetch skips JSONB; admin UI fetches via findById
                    ownerUserId = rs.getLong("owner_user_id").let { if (rs.wasNull()) null else it },
                    isActive = rs.getBoolean("is_active"),
                    createdAt = rs.getTimestamp("created_at").toInstant(),
                    updatedAt = rs.getTimestamp("updated_at").toInstant(),
                )
            }
            rows
        }
        rows
    }

    private fun validateEventTypes(eventTypes: List<String>) {
        val unknown = eventTypes.filter { it != "*" && !events.isValid(it) }
        require(unknown.isEmpty()) { "Unknown event type(s): $unknown" }
    }

    private fun generateSecret(): String {
        val rng = SecureRandom()
        val bytes = ByteArray(32)
        rng.nextBytes(bytes)
        return "whsec_" + bytes.joinToString("") { "%02x".format(it) }
    }

    private fun loadById(id: UUID): WebhookSubscription? = BaseWebhookSubscriptionsTable.selectAll()
        .where { BaseWebhookSubscriptionsTable.id eq id }
        .firstOrNull()
        ?.let(WebhookSubscription::fromRow)
}

data class CreatedSubscription(
    val subscription: WebhookSubscription,
    val plaintextSecret: String,
)
