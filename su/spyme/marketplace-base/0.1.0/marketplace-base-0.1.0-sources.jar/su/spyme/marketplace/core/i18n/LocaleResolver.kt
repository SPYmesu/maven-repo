package su.spyme.marketplace.core.i18n

/**
 * Resolves the storefront locale for a given request. Strategy:
 *
 *  1. Explicit per-request override (e.g. `?lang=ru` query param,
 *     resolved by the host route handler before calling here).
 *  2. Persisted user preference (host plugs in via [userPreference]
 *     callback that loads it from `users` or `user_preferences`).
 *  3. The first supported locale in the request's `Accept-Language`
 *     header.
 *  4. Configured default locale.
 *
 * Hosts wire one instance per Ktor application; the resolver
 * itself is stateless beyond the constructor parameters.
 *
 * @property defaultLocale Fallback when nothing else matches — also
 *           rejected during construction if not in [supportedLocales].
 * @property supportedLocales Locales the storefront can render. The
 *           order matters — listing `ru` before `ru-RU` makes the
 *           bare language match first.
 */
class LocaleResolver(
    val defaultLocale: Locale,
    val supportedLocales: List<Locale>,
) {

    init {
        require(supportedLocales.isNotEmpty()) { "supportedLocales must not be empty" }
        require(defaultLocale in supportedLocales) { "defaultLocale $defaultLocale not in supportedLocales=$supportedLocales" }
    }

    /** Whether [locale] is one this storefront supports. */
    fun supports(locale: Locale): Boolean = locale in supportedLocales

    /**
     * Locks resolution to the four-step cascade described above.
     *
     * @param explicit Per-request override; takes precedence over all other
     *        signals when non-null AND supported.
     * @param userPreference Persisted per-user choice; checked second.
     * @param acceptLanguageHeader Raw HTTP header value, may be null.
     */
    fun resolve(
        explicit: Locale? = null,
        userPreference: Locale? = null,
        acceptLanguageHeader: String? = null,
    ): Locale {
        if (explicit != null && supports(explicit)) return explicit
        if (userPreference != null && supports(userPreference)) return userPreference
        val fromHeader = acceptLanguageHeader?.let { parseAcceptLanguage(it) }
            ?.firstOrNull { (locale, _) -> supports(locale) }
            ?.first
        return fromHeader ?: defaultLocale
    }

    /**
     * Parses an HTTP `Accept-Language` header into `(Locale, q)` pairs
     * sorted by descending q-value. Malformed entries are silently
     * skipped — the header is user-supplied and we never want to 400
     * a request because of a bad browser config.
     *
     * Quality factors default to 1.0 when missing; ties keep the
     * input order (RFC 7231 leaves this implementation-defined; we
     * do "first wins" so the most explicit locale per the user's
     * preference is picked first).
     */
    fun parseAcceptLanguage(header: String): List<Pair<Locale, Double>> =
        header.split(',')
            .mapIndexed { idx, raw -> idx to raw.trim() }
            .filter { (_, raw) -> raw.isNotEmpty() }
            .mapNotNull { (idx, raw) ->
                val parts = raw.split(';').map { it.trim() }
                val tag = parts[0]
                if (tag == "*" || tag.isEmpty()) return@mapNotNull null
                val q = parts.drop(1)
                    .firstOrNull { it.startsWith("q=") }
                    ?.removePrefix("q=")
                    ?.toDoubleOrNull()
                    ?: 1.0
                val locale = Locale.parseOrNull(tag) ?: return@mapNotNull null
                Triple(idx, locale, q)
            }
            .sortedWith(compareByDescending<Triple<Int, Locale, Double>> { it.third }.thenBy { it.first })
            .map { it.second to it.third }
}
