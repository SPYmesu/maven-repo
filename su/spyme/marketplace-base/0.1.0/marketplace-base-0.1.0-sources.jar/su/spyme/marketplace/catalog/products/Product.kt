package su.spyme.marketplace.catalog.products

import org.jetbrains.exposed.sql.ResultRow
import su.spyme.marketplace.core.Money
import java.time.Instant

/**
 * Whether the product is a digital good (downloads, plugins, license
 * keys) or a physical one that ships through a carrier. Narrower than
 * [su.spyme.marketplace.core.MarketplaceKind] because no individual
 * product can be "MIXED" — a MIXED marketplace just lists products of
 * both kinds side by side.
 */
enum class ProductKind { DIGITAL, PHYSICAL }

/**
 * Lifecycle of a [Product] row.
 *
 * - `DRAFT` — work in progress, hidden from the storefront.
 * - `PUBLISHED` — live; `published_at` is stamped on transition.
 * - `ARCHIVED` — soft-deleted; `archived_at` is stamped, slug is freed
 *   for re-use because the unique index is partial on
 *   `archived_at IS NULL`.
 */
enum class ProductStatus {
    DRAFT, PUBLISHED, ARCHIVED;

    companion object {
        /** @throws IllegalArgumentException if [value] doesn't match a known status name. */
        fun parse(value: String): ProductStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown ProductStatus: '$value'")
    }
}

/**
 * A buyable item in the catalog. Singleton row per Б1; host extensions
 * (e.g. `product_minecraft_meta`) live in side-tables, never as
 * additional columns on this row.
 *
 * @property vendorId Owner vendor when the multi-vendor module is
 *           active (V150). NULL means "the marketplace itself sells
 *           this".
 * @property maxTotalPurchases Cap on purchases across all users; null
 *           means unlimited. The denormalized [totalPurchaseCount]
 *           saves a `COUNT(*)` on the catalog hot path; refunds
 *           decrement it.
 * @property maxPerUserPurchases Cap per-user; enforced at order
 *           creation, paired with subscription module for "concurrent
 *           licenses" semantics.
 */
data class Product(
    val id: Long,
    val vendorId: Long?,
    val categoryId: Long,
    val slug: String,
    val productKind: ProductKind,
    val status: ProductStatus,
    val price: Money,
    val maxTotalPurchases: Int?,
    val maxPerUserPurchases: Int?,
    val totalPurchaseCount: Int,
    val createdAt: Instant,
    val updatedAt: Instant,
    val publishedAt: Instant?,
    val archivedAt: Instant?,
) {
    val isArchived: Boolean get() = archivedAt != null
    val isPublished: Boolean get() = status == ProductStatus.PUBLISHED && !isArchived

    /** True if total_purchase_count has caught up to max_total_purchases. */
    val isSoldOut: Boolean
        get() = maxTotalPurchases != null && totalPurchaseCount >= maxTotalPurchases

    companion object {
        fun fromRow(row: ResultRow): Product = Product(
            id = row[BaseProductsTable.id],
            vendorId = row[BaseProductsTable.vendorId],
            categoryId = row[BaseProductsTable.categoryId],
            slug = row[BaseProductsTable.slug],
            productKind = ProductKind.valueOf(row[BaseProductsTable.productKind]),
            status = ProductStatus.parse(row[BaseProductsTable.status]),
            price = Money(
                amount = row[BaseProductsTable.priceAmount],
                currency = row[BaseProductsTable.priceCurrency],
            ),
            maxTotalPurchases = row[BaseProductsTable.maxTotalPurchases],
            maxPerUserPurchases = row[BaseProductsTable.maxPerUserPurchases],
            totalPurchaseCount = row[BaseProductsTable.totalPurchaseCount],
            createdAt = row[BaseProductsTable.createdAt],
            updatedAt = row[BaseProductsTable.updatedAt],
            publishedAt = row[BaseProductsTable.publishedAt],
            archivedAt = row[BaseProductsTable.archivedAt],
        )
    }
}

/**
 * Per-locale text for a [Product]. (productId, locale) composite PK.
 *
 * @property shortDescription Used on list-view cards.
 * @property description Full markdown body for the product page.
 */
data class ProductTranslation(
    val productId: Long,
    val locale: String,
    val title: String,
    val shortDescription: String?,
    val description: String?,
    val isMachineTranslated: Boolean,
) {
    companion object {
        fun fromRow(row: ResultRow): ProductTranslation = ProductTranslation(
            productId = row[BaseProductTranslationsTable.productId],
            locale = row[BaseProductTranslationsTable.locale],
            title = row[BaseProductTranslationsTable.title],
            shortDescription = row[BaseProductTranslationsTable.shortDescription],
            description = row[BaseProductTranslationsTable.description],
            isMachineTranslated = row[BaseProductTranslationsTable.isMachineTranslated],
        )
    }
}
