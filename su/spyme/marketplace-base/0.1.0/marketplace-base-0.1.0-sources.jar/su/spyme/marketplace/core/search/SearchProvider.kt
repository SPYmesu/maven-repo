package su.spyme.marketplace.core.search

/**
 * Abstraction over a search engine. Hosts wire exactly one
 * [SearchProvider] per environment — production normally uses
 * `MeilisearchSearchProvider`; local dev without Docker uses
 * [NoOpSearchProvider]; when MeiliSearch is unavailable the
 * `CompositeSearchProvider` (E5 follow-up) routes traffic to
 * `PgTrgmSearchProvider` automatically.
 *
 * All methods are `suspend` — implementations may be IO-heavy.
 *
 * Document lifecycle: [upsert]/[upsertBatch] add or replace by id;
 * [delete]/[deleteBatch] remove. The outbox worker calls these in
 * batches of 100; admin-side reindex jobs call [reindex] with the
 * full snapshot.
 */
interface SearchProvider {
    /** Stable identifier for diagnostics and admin UI. */
    val name: String

    /** Quick liveness probe — providers should return false rather than throw on transient failure. */
    suspend fun isHealthy(): Boolean

    suspend fun upsert(document: IndexableDocument)

    suspend fun upsertBatch(documents: List<IndexableDocument>)

    suspend fun delete(indexName: String, id: String)

    suspend fun deleteBatch(indexName: String, ids: List<String>)

    suspend fun search(query: SearchQuery): SearchResult

    /**
     * Drops every document under [indexName] and replays [documents]
     * in batches. Used by `./gradlew reindex` and the admin reindex
     * UI; can take minutes for large catalogs.
     */
    suspend fun reindex(indexName: String, documents: Sequence<IndexableDocument>)
}
