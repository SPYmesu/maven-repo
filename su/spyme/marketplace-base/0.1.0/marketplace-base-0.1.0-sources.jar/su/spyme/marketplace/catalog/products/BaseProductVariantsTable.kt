package su.spyme.marketplace.catalog.products

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import su.spyme.marketplace.catalog.attributes.BaseAttributeDefinitionsTable
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseProductVariantsTable : Table("product_variants") {
    val id: Column<Long> = long("id").autoIncrement()
    val productId: Column<Long> = long("product_id").references(BaseProductsTable.id)
    val sku: Column<String?> = varchar("sku", 64).nullable()
    val priceAmount: Column<Long?> = long("price_amount").nullable()
    val priceCurrency: Column<String?> = varchar("price_currency", 3).nullable()
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val sortOrder: Column<Int> = integer("sort_order").default(0)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseProductVariantAttributeValuesTable : Table("product_variant_attribute_values") {
    val variantId: Column<Long> = long("variant_id").references(BaseProductVariantsTable.id)
    val attributeId: Column<Long> = long("attribute_id").references(BaseAttributeDefinitionsTable.id)
    val value: Column<JsonElement> = jsonb("value", Json, JsonElement.serializer())

    override val primaryKey = PrimaryKey(variantId, attributeId)
}
