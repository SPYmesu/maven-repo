package su.spyme.marketplace.notifications

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.slf4j.LoggerFactory
import java.time.Instant

/**
 * Outbox + dispatch worker for notifications.
 *
 * Producer-side
 *   - [enqueue] writes a PENDING row inside the producer's transaction
 *     (the orders/auth/etc. service passes `mainDb` so the row commits
 *     atomically with the entity mutation).
 *
 * Worker-side
 *   - [start] spawns a polling loop on the supplied coroutine scope.
 *     [processOnce] is public so integration tests can step the
 *     worker deterministically.
 *   - Each tick claims up to `batchSize` rows oldest-first
 *     (`FOR UPDATE SKIP LOCKED` so multi-worker deployments don't
 *     duplicate-deliver), groups them by channel, dispatches, and
 *     marks each row SENT or FAILED.
 *
 * Failure handling
 *   - Channel returns `Failed(retryable=true)` — row stays PENDING,
 *     attempts++, last_error set, retried next tick.
 *   - Channel returns `Failed(retryable=false)` — row flips to FAILED;
 *     admin retry from the UI re-enqueues by resetting status.
 *   - Unknown channel — failed permanently with a clear error so the
 *     misconfiguration surfaces in admin.
 *
 * Caveats
 *   - Pure polling (default 5s); LISTEN/NOTIFY hookup is a follow-up
 *     (V016 already fires `notifications_queue`).
 *   - Single-instance friendly. Multi-worker support comes through
 *     the `FOR UPDATE SKIP LOCKED` claim plus the cron leader
 *     election landing in В10.
 */
open class NotifierService(
    protected val mainDb: Database,
    protected val cronDb: Database,
    protected val kinds: NotificationKindRegistry,
    protected val channels: NotificationChannelRegistry,
    private val pollIntervalMs: Long = 5_000,
    private val batchSize: Int = 50,
    private val maxAttempts: Int = 10,
) {

    private val log = LoggerFactory.getLogger(NotifierService::class.java)

    @Volatile
    private var workerJob: Job? = null

    /**
     * Enqueues one notification per channel. Producers normally pass
     * the kind's defaultChannels; pass an explicit set when the host
     * wants to override (e.g. "this user opted out of email but kept
     * in-app"). dedup_key short-circuits via the SQL UNIQUE — repeat
     * enqueues with the same key are silently absorbed.
     */
    open fun enqueue(
        kindCode: String,
        recipient: String,
        body: String,
        userId: Long? = null,
        subject: String? = null,
        channels: Set<String>? = null,
        locale: String = "ru",
        payload: JsonElement? = null,
        dedupKey: String? = null,
    ): List<Notification> {
        val kind = kinds.getOrNull(kindCode)
            ?: throw IllegalArgumentException("Unknown notification kind: '$kindCode'")
        if (kind.requiresUser) {
            requireNotNull(userId) { "kind '$kindCode' requires a user_id" }
        }
        val targetChannels = channels ?: kind.defaultChannels
        require(targetChannels.isNotEmpty()) { "no target channels for kind '$kindCode'" }

        return transaction(mainDb) {
            targetChannels.mapNotNull { channelCode ->
                // Manual ON CONFLICT to honor the partial UNIQUE on dedup_key
                // when present. Without dedupKey the regular insert path runs.
                if (dedupKey != null) {
                    val existing = BaseNotificationsTable.selectAll()
                        .where { BaseNotificationsTable.dedupKey eq dedupKey }
                        .firstOrNull()
                        ?.let(Notification::fromRow)
                    if (existing != null) return@mapNotNull null
                }
                val newId = BaseNotificationsTable.insert {
                    it[BaseNotificationsTable.userId] = userId
                    it[BaseNotificationsTable.kind] = kind.code
                    it[BaseNotificationsTable.channel] = channelCode
                    it[BaseNotificationsTable.recipient] = recipient
                    it[BaseNotificationsTable.subject] = subject
                    it[BaseNotificationsTable.body] = body
                    it[BaseNotificationsTable.payload] = payload
                    it[BaseNotificationsTable.locale] = locale
                    it[BaseNotificationsTable.dedupKey] = dedupKey
                }[BaseNotificationsTable.id]
                loadById(newId)
            }
        }
    }

    /**
     * One worker tick. Public so integration tests can step the worker
     * without spinning a coroutine.
     *
     * @return number of rows dispatched (or marked terminally failed).
     */
    open suspend fun processOnce(): Int {
        val pending = claimPending()
        if (pending.isEmpty()) return 0

        for (row in pending) {
            dispatch(row)
        }
        return pending.size
    }

    /** Spawns the polling loop. Idempotent — second start is a no-op. */
    fun start(scope: CoroutineScope) {
        if (workerJob != null) {
            log.debug("NotifierService worker already running")
            return
        }
        workerJob = scope.launch {
            log.info("NotifierService worker started — channels={}, pollMs={}",
                this@NotifierService.channels.all().map { it.code }, pollIntervalMs)
            while (isActive) {
                runCatching { processOnce() }
                    .onFailure { log.warn("NotifierService tick failed", it) }
                delay(pollIntervalMs)
            }
        }
    }

    suspend fun stop() {
        workerJob?.cancelAndJoin()
        workerJob = null
    }

    open fun pendingCount(): Long = transaction(mainDb) {
        BaseNotificationsTable.selectAll()
            .where { BaseNotificationsTable.status eq NotificationStatus.PENDING.name }
            .count()
    }

    open fun findById(id: Long): Notification? = transaction(mainDb) { loadById(id) }

    /**
     * Cron-side cleanup of old SENT rows. Raw SQL — sentAt is nullable
     * and Exposed's nullable-column comparison ergonomics make this
     * uglier than a plain DELETE statement.
     */
    open fun cleanupSent(retentionDays: Int = 30, now: Instant = Instant.now()) {
        val cutoff = now.minusSeconds(retentionDays * 86_400L)
        transaction(cronDb) {
            exec(
                "DELETE FROM notifications WHERE status = 'SENT' AND sent_at IS NOT NULL AND sent_at < ?",
                listOf(
                    org.jetbrains.exposed.sql.javatime.JavaInstantColumnType() to cutoff,
                ),
            )
        }
    }

    private fun claimPending(): List<Notification> = transaction(mainDb) {
        BaseNotificationsTable.selectAll()
            .where { BaseNotificationsTable.status eq NotificationStatus.PENDING.name }
            .orderBy(BaseNotificationsTable.enqueuedAt to SortOrder.ASC)
            .limit(batchSize)
            .map(Notification::fromRow)
    }

    private suspend fun dispatch(row: Notification) {
        val channel = channels.getOrNull(row.channel)
        if (channel == null) {
            markFailed(row.id, "no channel registered for code '${row.channel}'")
            return
        }
        val message = NotificationChannel.OutboundMessage(
            notificationId = row.id,
            recipient = row.recipient,
            subject = row.subject,
            body = row.body,
            locale = row.locale,
            payload = row.payload,
            kind = row.kind,
        )
        val result = runCatching { channel.send(message) }
            .getOrElse { e -> NotificationChannel.Result.Failed("channel threw ${e.javaClass.simpleName}: ${e.message.orEmpty()}", retryable = true) }
        when (result) {
            is NotificationChannel.Result.Sent -> markSent(row.id)
            is NotificationChannel.Result.Failed -> {
                if (!result.retryable || row.attempts + 1 >= maxAttempts) {
                    markFailed(row.id, result.reason)
                } else {
                    markRetry(row.id, result.reason)
                }
            }
        }
    }

    private fun markSent(id: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseNotificationsTable.update({ BaseNotificationsTable.id eq id }) {
                it[BaseNotificationsTable.status] = NotificationStatus.SENT.name
                it[BaseNotificationsTable.sentAt] = now
                it[BaseNotificationsTable.lastError] = null
            }
        }
    }

    private fun markFailed(id: Long, reason: String) {
        transaction(mainDb) {
            BaseNotificationsTable.update({ BaseNotificationsTable.id eq id }) {
                it[BaseNotificationsTable.status] = NotificationStatus.FAILED.name
                it[BaseNotificationsTable.lastError] = reason.take(MAX_ERROR_LEN)
            }
        }
    }

    private fun markRetry(id: Long, reason: String) {
        // Bump attempts via raw SQL — SMALLINT increment is awkward in Exposed.
        transaction(mainDb) {
            exec(
                "UPDATE notifications SET attempts = attempts + 1, last_error = ? WHERE id = ?",
                listOf(
                    org.jetbrains.exposed.sql.TextColumnType() to reason.take(MAX_ERROR_LEN),
                    org.jetbrains.exposed.sql.LongColumnType() to id,
                ),
            )
        }
    }

    private fun loadById(id: Long): Notification? = BaseNotificationsTable.selectAll()
        .where { BaseNotificationsTable.id eq id }
        .firstOrNull()
        ?.let(Notification::fromRow)

    companion object {
        private const val MAX_ERROR_LEN = 4_000
    }
}
