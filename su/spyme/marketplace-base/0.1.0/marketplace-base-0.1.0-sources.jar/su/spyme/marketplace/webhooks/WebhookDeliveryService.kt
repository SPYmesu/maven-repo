package su.spyme.marketplace.webhooks

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Duration
import java.time.Instant
import java.util.UUID

/**
 * Outbox + retry-schedule manager for outbound webhook deliveries.
 *
 * Producer side: [enqueue] writes a PENDING row in the producer's
 * transaction so a webhook never goes out without the underlying
 * entity changing.
 *
 * Worker side (host-supplied HTTP client):
 *   1. [claimDue] returns PENDING rows whose `scheduled_at` has
 *      passed.
 *   2. Worker computes the signature with [WebhookHmacSigner],
 *      POSTs to the subscription's `target_url`.
 *   3. [markSuccess] / [markFailed] update the row. markFailed
 *      schedules the next retry per the 1s/30s/5m/30m/2h/12h ladder
 *      from Б5; after the last step the row stays FAILED for admin
 *      replay.
 */
open class WebhookDeliveryService(protected val mainDb: Database) {

    private val json = Json { encodeDefaults = false }

    /**
     * Schedules a delivery. Skips creation if a row already exists for
     * (subscription_id, event_id) — UNIQUE in V023 means a duplicate
     * enqueue is a no-op rather than an exception.
     */
    open fun enqueue(
        subscription: WebhookSubscription,
        eventType: String,
        payload: JsonElement,
        eventId: UUID = UUID.randomUUID(),
        scheduledAt: Instant = Instant.now(),
    ): WebhookDelivery? {
        require(subscription.matches(eventType)) {
            "subscription ${subscription.id} doesn't match eventType '$eventType'"
        }

        val rowId = UUID.randomUUID()
        return transaction(mainDb) {
            val existing = BaseWebhookDeliveriesTable.selectAll()
                .where {
                    (BaseWebhookDeliveriesTable.subscriptionId eq subscription.id) and
                        (BaseWebhookDeliveriesTable.eventId eq eventId)
                }
                .firstOrNull()
            if (existing != null) return@transaction WebhookDelivery.fromRow(existing)
            BaseWebhookDeliveriesTable.insert {
                it[BaseWebhookDeliveriesTable.id] = rowId
                it[BaseWebhookDeliveriesTable.subscriptionId] = subscription.id
                it[BaseWebhookDeliveriesTable.eventId] = eventId
                it[BaseWebhookDeliveriesTable.eventType] = eventType
                it[BaseWebhookDeliveriesTable.payload] = payload
                it[BaseWebhookDeliveriesTable.scheduledAt] = scheduledAt
            }
            loadById(rowId)!!
        }
    }

    /** Worker's claim path. Returns up to [limit] due rows ordered by [BaseWebhookDeliveriesTable.scheduledAt]. */
    open fun claimDue(limit: Int = 50, now: Instant = Instant.now()): List<WebhookDelivery> = transaction(mainDb) {
        // Plain Exposed query — the worker's locking strategy is up to
        // the host (FOR UPDATE SKIP LOCKED in production).
        val rows = mutableListOf<WebhookDelivery>()
        exec(
            """
            SELECT id, subscription_id, event_id, event_type, payload, attempt, status,
                   http_status, response_body, response_headers, latency_ms, signature,
                   last_error, scheduled_at, sent_at, completed_at, created_at, updated_at
            FROM webhook_deliveries
            WHERE status = 'PENDING' AND scheduled_at <= ?
            ORDER BY scheduled_at ASC
            LIMIT ?
            """.trimIndent(),
            listOf(
                org.jetbrains.exposed.sql.javatime.JavaInstantColumnType() to now,
                org.jetbrains.exposed.sql.IntegerColumnType() to limit,
            ),
        ) { rs ->
            while (rs.next()) rows += WebhookDelivery(
                id = rs.getObject("id", UUID::class.java),
                subscriptionId = rs.getObject("subscription_id", UUID::class.java),
                eventId = rs.getObject("event_id", UUID::class.java),
                eventType = rs.getString("event_type"),
                payload = rs.getString("payload")?.let(json::parseToJsonElement)
                    ?: kotlinx.serialization.json.JsonNull,
                attempt = rs.getShort("attempt").toInt(),
                status = WebhookDeliveryStatus.parse(rs.getString("status")),
                httpStatus = rs.getInt("http_status").let { if (rs.wasNull()) null else it },
                responseBody = rs.getString("response_body"),
                responseHeaders = rs.getString("response_headers")?.let(json::parseToJsonElement),
                latencyMs = rs.getInt("latency_ms").let { if (rs.wasNull()) null else it },
                signature = rs.getString("signature"),
                lastError = rs.getString("last_error"),
                scheduledAt = rs.getTimestamp("scheduled_at").toInstant(),
                sentAt = rs.getTimestamp("sent_at")?.toInstant(),
                completedAt = rs.getTimestamp("completed_at")?.toInstant(),
                createdAt = rs.getTimestamp("created_at").toInstant(),
                updatedAt = rs.getTimestamp("updated_at").toInstant(),
            )
            rows
        }
        rows
    }

    open fun markSuccess(
        id: UUID,
        httpStatus: Int,
        responseBody: String? = null,
        responseHeaders: JsonElement? = null,
        latencyMs: Int? = null,
        signature: String? = null,
        now: Instant = Instant.now(),
    ) {
        transaction(mainDb) {
            BaseWebhookDeliveriesTable.update({ BaseWebhookDeliveriesTable.id eq id }) {
                it[BaseWebhookDeliveriesTable.status] = WebhookDeliveryStatus.SUCCESS.name
                it[BaseWebhookDeliveriesTable.httpStatus] = httpStatus
                if (responseBody != null) it[BaseWebhookDeliveriesTable.responseBody] = responseBody.take(MAX_RESP_LEN)
                if (responseHeaders != null) it[BaseWebhookDeliveriesTable.responseHeaders] = responseHeaders
                if (latencyMs != null) it[BaseWebhookDeliveriesTable.latencyMs] = latencyMs
                if (signature != null) it[BaseWebhookDeliveriesTable.signature] = signature
                it[BaseWebhookDeliveriesTable.sentAt] = now
                it[BaseWebhookDeliveriesTable.completedAt] = now
            }
        }
    }

    /**
     * Marks a delivery failed and schedules the next retry per Б5.
     * Sequence (1-indexed by attempt): 1s → 30s → 5m → 30m → 2h → 12h.
     * After the 6th attempt the row stays FAILED until admin replays.
     */
    open fun markFailed(
        id: UUID,
        reason: String,
        httpStatus: Int? = null,
        responseBody: String? = null,
        latencyMs: Int? = null,
        signature: String? = null,
        now: Instant = Instant.now(),
    ): Instant? {
        val current = findById(id) ?: return null
        val nextAttempt = current.attempt + 1
        val nextRunAt = nextRetryDelay(nextAttempt)?.let { now.plus(it) }
        val terminal = nextRunAt == null
        transaction(mainDb) {
            BaseWebhookDeliveriesTable.update({ BaseWebhookDeliveriesTable.id eq id }) {
                it[BaseWebhookDeliveriesTable.attempt] = nextAttempt.toShort()
                it[BaseWebhookDeliveriesTable.lastError] = reason.take(MAX_RESP_LEN)
                if (httpStatus != null) it[BaseWebhookDeliveriesTable.httpStatus] = httpStatus
                if (responseBody != null) it[BaseWebhookDeliveriesTable.responseBody] = responseBody.take(MAX_RESP_LEN)
                if (latencyMs != null) it[BaseWebhookDeliveriesTable.latencyMs] = latencyMs
                if (signature != null) it[BaseWebhookDeliveriesTable.signature] = signature
                it[BaseWebhookDeliveriesTable.sentAt] = now
                if (terminal) {
                    it[BaseWebhookDeliveriesTable.status] = WebhookDeliveryStatus.FAILED.name
                    it[BaseWebhookDeliveriesTable.completedAt] = now
                } else {
                    it[BaseWebhookDeliveriesTable.scheduledAt] = nextRunAt
                }
            }
        }
        return nextRunAt
    }

    /** Replays a FAILED delivery: resets to PENDING with scheduled_at = now. */
    open fun replay(id: UUID, now: Instant = Instant.now()): Boolean = transaction(mainDb) {
        BaseWebhookDeliveriesTable.update({
            (BaseWebhookDeliveriesTable.id eq id) and
                (BaseWebhookDeliveriesTable.status eq WebhookDeliveryStatus.FAILED.name)
        }) {
            it[BaseWebhookDeliveriesTable.status] = WebhookDeliveryStatus.PENDING.name
            it[BaseWebhookDeliveriesTable.scheduledAt] = now
            it[BaseWebhookDeliveriesTable.lastError] = null
        } > 0
    }

    open fun findById(id: UUID): WebhookDelivery? = transaction(mainDb) { loadById(id) }

    open fun listForSubscription(subscriptionId: UUID, limit: Int = 100): List<WebhookDelivery> =
        transaction(mainDb) {
            BaseWebhookDeliveriesTable.selectAll()
                .where { BaseWebhookDeliveriesTable.subscriptionId eq subscriptionId }
                .orderBy(BaseWebhookDeliveriesTable.createdAt to SortOrder.DESC)
                .limit(limit)
                .map(WebhookDelivery::fromRow)
        }

    private fun loadById(id: UUID): WebhookDelivery? = BaseWebhookDeliveriesTable.selectAll()
        .where { BaseWebhookDeliveriesTable.id eq id }
        .firstOrNull()
        ?.let(WebhookDelivery::fromRow)

    /** Per Б5: 1s → 30s → 5m → 30m → 2h → 12h. Null past the last step. */
    internal fun nextRetryDelay(attempt: Int): Duration? = when (attempt) {
        1 -> Duration.ofSeconds(1)
        2 -> Duration.ofSeconds(30)
        3 -> Duration.ofMinutes(5)
        4 -> Duration.ofMinutes(30)
        5 -> Duration.ofHours(2)
        6 -> Duration.ofHours(12)
        else -> null
    }

    companion object {
        private const val MAX_RESP_LEN = 4_000
    }
}
