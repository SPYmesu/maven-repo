package su.spyme.marketplace.core.search.meilisearch

import com.meilisearch.sdk.Client
import com.meilisearch.sdk.SearchRequest
import com.meilisearch.sdk.model.SearchResult as MeiliSearchResult
import com.meilisearch.sdk.model.Searchable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.encodeToJsonElement
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.search.IndexableDocument
import su.spyme.marketplace.core.search.SearchFilter
import su.spyme.marketplace.core.search.SearchMode
import su.spyme.marketplace.core.search.SearchProvider
import su.spyme.marketplace.core.search.SearchQuery
import su.spyme.marketplace.core.search.SearchResult

/**
 * [SearchProvider] backed by a MeiliSearch instance via the official
 * Java SDK. Production-grade provider for the storefront search.
 *
 * Index naming: a [BaseConfig.Search.indexPrefix][su.spyme.marketplace.core.BaseConfig.Search.indexPrefix]
 * scoping prefix is prepended to the logical index name so two
 * marketplaces (moonstudio, incomeauto) can share a single MeiliSearch
 * instance. Default is no prefix.
 *
 * Document shape: each [IndexableDocument] is sent with `id` injected
 * as the primary key; arbitrary scalar/array/object fields ride along
 * untouched. `addDocuments(json, "id")` lets MeiliSearch upsert by
 * primary key.
 *
 * Filter translation: the sealed [SearchFilter] hierarchy maps onto
 * MeiliSearch's filter DSL. AND / OR / NOT compose; Eq/In/Range emit
 * comparators on the named field. Strings are quoted and escaped.
 *
 * Concurrency: MeiliSearch SDK is blocking; every call body wraps
 * `withContext(Dispatchers.IO)` so the request thread isn't held
 * waiting on HTTP.
 *
 * Errors: this provider does not catch SDK exceptions. The caller
 * (typically `CompositeSearchProvider` with a Resilience4j circuit
 * breaker) decides whether to fall back to pg_trgm.
 */
class MeilisearchSearchProvider(
    private val client: Client,
    private val indexPrefix: String = "",
    private val batchSize: Int = 100,
) : SearchProvider {

    override val name: String = "meilisearch"

    private val log = LoggerFactory.getLogger(MeilisearchSearchProvider::class.java)
    private val json = Json { encodeDefaults = false; ignoreUnknownKeys = true }

    override suspend fun isHealthy(): Boolean = withContext(Dispatchers.IO) {
        try {
            client.health()
            true
        } catch (t: Throwable) {
            log.debug("MeiliSearch health check failed: {}", t.message)
            false
        }
    }

    override suspend fun upsert(document: IndexableDocument) {
        upsertBatch(listOf(document))
    }

    override suspend fun upsertBatch(documents: List<IndexableDocument>): Unit = withContext(Dispatchers.IO) {
        if (documents.isEmpty()) return@withContext
        documents.groupBy { it.indexName }.forEach { (logicalIndex, docs) ->
            val handle = client.index(prefixed(logicalIndex))
            docs.chunked(batchSize).forEach { chunk ->
                val payload = buildJsonArray {
                    chunk.forEach { doc ->
                        add(
                            buildJsonObject {
                                put("id", JsonPrimitive(doc.id))
                                doc.fields.forEach { (k, v) -> put(k, v) }
                            }
                        )
                    }
                }
                handle.addDocuments(json.encodeToString(JsonArray.serializer(), payload), "id")
            }
        }
    }

    override suspend fun delete(indexName: String, id: String): Unit = withContext(Dispatchers.IO) {
        client.index(prefixed(indexName)).deleteDocument(id)
    }

    override suspend fun deleteBatch(indexName: String, ids: List<String>): Unit = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext
        // SDK 0.14: Index.deleteDocuments(List<String>) is marked
        // @Deprecated against the 0.16+ rename to deleteDocumentsByBatch,
        // but the method still works on the SDK we ship against and
        // the migration path requires a SDK bump (planned for 0.2.x).
        @Suppress("DEPRECATION")
        client.index(prefixed(indexName)).deleteDocuments(ids)
    }

    override suspend fun search(query: SearchQuery): SearchResult = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()

        val builder = SearchRequest.builder()
            .q(query.query.orEmpty())
            .limit(query.limit)
            .offset(query.offset)

        if (query.filters.isNotEmpty()) {
            // SDK 0.14: builder methods filter / facets / sort all take String[].
            builder.filter(arrayOf(translateFilter(SearchFilter.And(query.filters))))
        }
        if (query.facets.isNotEmpty()) {
            builder.facets(query.facets.toTypedArray())
        }
        if (query.sort.isNotEmpty()) {
            builder.sort(
                query.sort.map { "${it.field}:${it.direction.name.lowercase()}" }.toTypedArray()
            )
        }

        val raw: Searchable = client.index(prefixed(query.indexName)).search(builder.build())
        translateResult(query, raw, System.currentTimeMillis() - started)
    }

    override suspend fun reindex(indexName: String, documents: Sequence<IndexableDocument>): Unit =
        withContext(Dispatchers.IO) {
            // Drop existing docs first; ignored when the index doesn't exist yet.
            runCatching { client.index(prefixed(indexName)).deleteAllDocuments() }
            // Stream the sequence in batches; producer can be a DB cursor with millions of rows.
            documents.chunked(batchSize).forEach { chunk -> upsertBatch(chunk) }
        }

    private fun prefixed(logicalIndex: String): String =
        if (indexPrefix.isBlank()) logicalIndex else "${indexPrefix}_$logicalIndex"

    /** Renders a [SearchFilter] tree as MeiliSearch's filter DSL. */
    internal fun translateFilter(filter: SearchFilter): String = when (filter) {
        is SearchFilter.Eq -> "${filter.field} = ${quote(filter.value)}"
        is SearchFilter.In -> {
            val joined = filter.values.joinToString(", ") { quote(it) }
            "${filter.field} IN [$joined]"
        }
        is SearchFilter.Range -> {
            val parts = buildList {
                filter.min?.let { add("${filter.field} >= $it") }
                filter.max?.let { add("${filter.field} <= $it") }
            }
            if (parts.isEmpty()) "" else parts.joinToString(" AND ", prefix = "(", postfix = ")")
        }
        is SearchFilter.Not -> "NOT (${translateFilter(filter.inner)})"
        is SearchFilter.And -> filter.children
            .map(::translateFilter)
            .filter { it.isNotBlank() }
            .joinToString(" AND ", prefix = "(", postfix = ")")
        is SearchFilter.Or -> filter.children
            .map(::translateFilter)
            .filter { it.isNotBlank() }
            .joinToString(" OR ", prefix = "(", postfix = ")")
    }

    private fun quote(value: JsonElement): String = when {
        value is JsonPrimitive && value.isString ->
            "\"" + value.content.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
        value is JsonPrimitive -> value.content
        else -> "\"${value.toString().replace("\"", "\\\"")}\""
    }

    @Suppress("UNCHECKED_CAST")
    private fun translateResult(
        query: SearchQuery,
        raw: Searchable,
        elapsedMs: Long,
    ): SearchResult {
        val hits: List<IndexableDocument> = (raw.hits as List<Map<String, Any?>>?)
            .orEmpty()
            .map { hit ->
                val id = hit["id"]?.toString().orEmpty()
                val fields = hit
                    .filterKeys { it != "id" }
                    .mapValues { (_, v) -> json.encodeToJsonElement(serializerForAny(v), v) }
                IndexableDocument(
                    indexName = query.indexName,
                    id = id,
                    fields = JsonObject(fields),
                )
            }

        // estimatedTotalHits and facetDistribution-as-Map only exist on
        // SearchResult; SearchResultPaginated wraps them differently.
        // Cast and degrade gracefully for the paginated case.
        val concrete = raw as? MeiliSearchResult
        val total: Long = (concrete?.estimatedTotalHits ?: 0).toLong()

        // facetDistribution is typed as Object — Gson hands us back a
        // Map<String, Map<String, Double>>. Walk it with raw maps.
        val facetDist: Map<String, Map<String, Long>> = run {
            val rawDist = concrete?.facetDistribution as? Map<*, *> ?: return@run emptyMap()
            rawDist.entries
                .mapNotNull { (facetField, valueCounts) ->
                    val name = facetField as? String ?: return@mapNotNull null
                    val counts = valueCounts as? Map<*, *> ?: return@mapNotNull null
                    val mapped = counts.entries.mapNotNull { (value, count) ->
                        val v = value as? String ?: return@mapNotNull null
                        val c = (count as? Number)?.toLong() ?: return@mapNotNull null
                        v to c
                    }.toMap()
                    name to mapped
                }
                .toMap()
        }

        return SearchResult(
            indexName = query.indexName,
            totalHits = total,
            limit = query.limit,
            offset = query.offset,
            hits = hits,
            facetDistribution = facetDist,
            processingTimeMs = if (raw.processingTimeMs > 0) raw.processingTimeMs.toLong() else elapsedMs,
            mode = SearchMode.HEALTHY,
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun serializerForAny(v: Any?): kotlinx.serialization.KSerializer<Any?> {
        // kotlinx-serialization can't infer for raw Any; route everything
        // through Gson-like ad-hoc encoding instead of declaring a custom
        // serializer per shape. The MeiliSearch SDK already shipped a
        // Gson-decoded Map<String, Any?>, so we just rebuild a JsonElement.
        @Suppress("UNUSED_VARIABLE")
        val ignored = v
        return AnyJsonSerializer as kotlinx.serialization.KSerializer<Any?>
    }
}

private object AnyJsonSerializer : kotlinx.serialization.KSerializer<Any?> {
    override val descriptor: kotlinx.serialization.descriptors.SerialDescriptor =
        kotlinx.serialization.descriptors.PrimitiveSerialDescriptor(
            "Any",
            kotlinx.serialization.descriptors.PrimitiveKind.STRING,
        )

    override fun serialize(encoder: kotlinx.serialization.encoding.Encoder, value: Any?) {
        val element = toJsonElement(value)
        val composite = encoder as? kotlinx.serialization.json.JsonEncoder
            ?: error("AnyJsonSerializer requires a JsonEncoder")
        composite.encodeJsonElement(element)
    }

    override fun deserialize(decoder: kotlinx.serialization.encoding.Decoder): Any? {
        error("AnyJsonSerializer is encode-only")
    }

    private fun toJsonElement(value: Any?): JsonElement = when (value) {
        null -> JsonPrimitive(null as String?)
        is Number -> JsonPrimitive(value)
        is Boolean -> JsonPrimitive(value)
        is String -> JsonPrimitive(value)
        is List<*> -> JsonArray(value.map(::toJsonElement))
        is Map<*, *> -> JsonObject(value.entries.associate { (k, v) -> k.toString() to toJsonElement(v) })
        else -> JsonPrimitive(value.toString())
    }
}
