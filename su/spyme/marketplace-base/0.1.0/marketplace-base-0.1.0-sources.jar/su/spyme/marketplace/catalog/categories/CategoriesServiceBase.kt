package su.spyme.marketplace.catalog.categories

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.upsert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update

open class CategoriesServiceBase(protected val mainDb: Database) {

    open fun createCategory(
        slug: String,
        parentId: Long? = null,
        sortOrder: Int = 0,
        isActive: Boolean = true,
    ): Category {
        require(slug.isNotBlank()) { "slug must not be blank" }
        return transaction(mainDb) {
            BaseCategoriesTable.insert {
                it[BaseCategoriesTable.parentId] = parentId
                it[BaseCategoriesTable.slug] = slug
                it[BaseCategoriesTable.sortOrder] = sortOrder
                it[BaseCategoriesTable.isActive] = isActive
            }
            BaseCategoriesTable.selectAll()
                .where { (BaseCategoriesTable.slug eq slug) and (BaseCategoriesTable.parentId.eqOrNull(parentId)) }
                .first()
                .let(Category::fromRow)
        }
    }

    open fun findById(id: Long): Category? = transaction(mainDb) {
        BaseCategoriesTable.selectAll()
            .where { BaseCategoriesTable.id eq id }
            .firstOrNull()
            ?.let(Category::fromRow)
    }

    open fun findBySlug(slug: String, parentId: Long? = null): Category? = transaction(mainDb) {
        BaseCategoriesTable.selectAll()
            .where { (BaseCategoriesTable.slug eq slug) and (BaseCategoriesTable.parentId.eqOrNull(parentId)) }
            .firstOrNull()
            ?.let(Category::fromRow)
    }

    /** Returns immediate children only, sorted by sortOrder then slug. */
    open fun listChildren(parentId: Long?, includeInactive: Boolean = false): List<Category> =
        transaction(mainDb) {
            val query = BaseCategoriesTable.selectAll()
                .where {
                    val byParent = BaseCategoriesTable.parentId.eqOrNull(parentId)
                    if (includeInactive) byParent else byParent and (BaseCategoriesTable.isActive eq true)
                }
                .orderBy(BaseCategoriesTable.sortOrder to SortOrder.ASC, BaseCategoriesTable.slug to SortOrder.ASC)
            query.map(Category::fromRow)
        }

    open fun setActive(id: Long, isActive: Boolean) {
        transaction(mainDb) {
            BaseCategoriesTable.update({ BaseCategoriesTable.id eq id }) {
                it[BaseCategoriesTable.isActive] = isActive
            }
        }
    }

    /** Upserts (categoryId, locale) — idempotent translation set. */
    open fun upsertTranslation(
        categoryId: Long,
        locale: String,
        title: String,
        description: String? = null,
        isMachineTranslated: Boolean = false,
    ): CategoryTranslation = transaction(mainDb) {
        BaseCategoryTranslationsTable.upsert {
            it[BaseCategoryTranslationsTable.categoryId] = categoryId
            it[BaseCategoryTranslationsTable.locale] = locale
            it[BaseCategoryTranslationsTable.title] = title
            it[BaseCategoryTranslationsTable.description] = description
            it[BaseCategoryTranslationsTable.isMachineTranslated] = isMachineTranslated
        }
        BaseCategoryTranslationsTable.selectAll()
            .where {
                (BaseCategoryTranslationsTable.categoryId eq categoryId) and
                    (BaseCategoryTranslationsTable.locale eq locale)
            }
            .first()
            .let(CategoryTranslation::fromRow)
    }

    open fun listTranslations(categoryId: Long): List<CategoryTranslation> = transaction(mainDb) {
        BaseCategoryTranslationsTable.selectAll()
            .where { BaseCategoryTranslationsTable.categoryId eq categoryId }
            .map(CategoryTranslation::fromRow)
    }

    /**
     * Drops the row and lets ON DELETE RESTRICT bubble up if children
     * reference it — caller relocates children first.
     */
    open fun delete(id: Long): Boolean = transaction(mainDb) {
        BaseCategoriesTable.deleteWhere { BaseCategoriesTable.id eq id } > 0
    }

    private fun Column<Long?>.eqOrNull(value: Long?): Op<Boolean> = Op.build {
        if (value == null) this@eqOrNull.isNull() else this@eqOrNull eq value
    }
}
