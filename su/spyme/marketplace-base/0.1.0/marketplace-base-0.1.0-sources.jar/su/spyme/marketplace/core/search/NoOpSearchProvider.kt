package su.spyme.marketplace.core.search

/**
 * Default no-op provider for environments without MeiliSearch:
 * unit-test runs, local dev launched with `SEARCH_PROVIDER=noop`,
 * and the early-stage host scaffolding before the search module is
 * activated.
 *
 * - `upsert` / `delete` / `reindex` swallow input silently — outbox
 *   workers can run, the queue drains, but nothing reaches a real
 *   search engine.
 * - `search` always returns an empty page with `mode=DEGRADED` so the
 *   front-end can render the empty state correctly.
 * - `isHealthy()` returns true — the provider itself is fine, even if
 *   it can't help you find anything.
 */
object NoOpSearchProvider : SearchProvider {
    override val name: String = "noop"

    override suspend fun isHealthy(): Boolean = true

    override suspend fun upsert(document: IndexableDocument) {
        // intentional no-op
    }

    override suspend fun upsertBatch(documents: List<IndexableDocument>) {
        // intentional no-op
    }

    override suspend fun delete(indexName: String, id: String) {
        // intentional no-op
    }

    override suspend fun deleteBatch(indexName: String, ids: List<String>) {
        // intentional no-op
    }

    override suspend fun search(query: SearchQuery): SearchResult = SearchResult(
        indexName = query.indexName,
        totalHits = 0,
        limit = query.limit,
        offset = query.offset,
        hits = emptyList(),
        mode = SearchMode.DEGRADED,
    )

    override suspend fun reindex(indexName: String, documents: Sequence<IndexableDocument>) {
        // intentional no-op — drain the sequence so the caller's
        // generator can shut down, even though nothing is indexed.
        documents.count()
    }
}
