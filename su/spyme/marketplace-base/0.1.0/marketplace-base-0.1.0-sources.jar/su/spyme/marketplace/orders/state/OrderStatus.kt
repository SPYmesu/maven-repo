package su.spyme.marketplace.orders.state

/**
 * Canonical order status alphabet. Matches the CHECK constraint on
 * `orders.status` (V010). Per the architecture plan PARTIALLY_REFUNDED
 * and REFUNDED are *not* listed here — they are display-only states
 * derived from the refunds table at read time.
 *
 * EXPIRED is also intentionally absent; payment-timeout cancellations
 * become CANCELLED with cancellation_reason_code='PAYMENT_TIMEOUT'.
 */
enum class OrderStatus {
    NEW,
    AWAITING_PAYMENT,
    AWAITING_MANAGER,
    PAID,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED;

    val isTerminal: Boolean
        get() = this == DELIVERED || this == CANCELLED

    companion object {
        /** Maps SQL status string to enum; throws on unknown. */
        fun parse(value: String): OrderStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown OrderStatus: '$value'")
    }
}

/**
 * Who is allowed to drive an order through a transition. Used by the
 * state machine to gate transitions that only a specific actor type
 * may perform (e.g. SHIPPED → DELIVERED via CARRIER webhook).
 */
enum class TransitionActor {
    USER,
    MANAGER,
    ADMIN,
    SYSTEM,
    PAYMENT_GATEWAY,
    CARRIER,
    EXTERNAL_API,
}
