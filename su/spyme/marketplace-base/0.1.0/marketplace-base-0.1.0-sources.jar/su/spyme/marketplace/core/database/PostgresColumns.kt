package su.spyme.marketplace.core.database

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Expression
import org.jetbrains.exposed.sql.QueryBuilder
import org.jetbrains.exposed.sql.Table
import java.time.Instant

/**
 * `CITEXT NOT NULL` column. CITEXT extension is enabled in V001. Binds
 * parameters as a `PGobject` with type=citext so PostgreSQL keeps the
 * case-insensitive collation on both sides of the comparison; if we
 * sent plain VARCHAR the resolver falls back to text and CITEXT loses
 * its meaning.
 */
fun Table.citext(name: String): Column<String> =
    registerColumn(name, CitextColumnType())

private class CitextColumnType : org.jetbrains.exposed.sql.ColumnType<String>() {
    override fun sqlType(): String = "CITEXT"

    override fun valueFromDB(value: Any): String = value.toString()

    override fun notNullValueToDB(value: String): Any =
        org.postgresql.util.PGobject().apply {
            type = "citext"
            this.value = value
        }

    override fun setParameter(
        stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi,
        index: Int,
        value: Any?,
    ) {
        if (value == null) {
            stmt.setNull(index, this)
            return
        }
        val obj = when (value) {
            is org.postgresql.util.PGobject -> value
            else -> org.postgresql.util.PGobject().apply {
                type = "citext"
                this.value = value.toString()
            }
        }
        stmt[index] = obj
    }
}

/**
 * `VARCHAR(elementSize)[] NOT NULL DEFAULT ARRAY[]::VARCHAR[]` column.
 * Kotlin side is List<String>; the JDBC driver reads/writes via
 * java.sql.Array.
 */
fun Table.stringArray(name: String, elementSize: Int): Column<List<String>> =
    registerColumn(name, StringArrayColumnType(elementSize))

private class StringArrayColumnType(private val elementSize: Int) :
    org.jetbrains.exposed.sql.ColumnType<List<String>>() {

    override fun sqlType(): String = "VARCHAR($elementSize)[]"

    override fun valueFromDB(value: Any): List<String> = when (value) {
        is java.sql.Array -> {
            @Suppress("UNCHECKED_CAST")
            (value.array as Array<String?>).filterNotNull()
        }
        is List<*> -> value.filterIsInstance<String>()
        else -> error("Unexpected SQL Array value: ${value::class}")
    }

    override fun notNullValueToDB(value: List<String>): Any = value.toTypedArray()

    override fun setParameter(stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi, index: Int, value: Any?) {
        if (value == null) {
            stmt.setNull(index, this)
            return
        }
        val raw = (value as? List<*>)?.toTypedArray() ?: value
        val conn = (stmt as? org.jetbrains.exposed.sql.statements.jdbc.JdbcPreparedStatementImpl)?.statement?.connection
            ?: error("PostgreSQL connection required for VARCHAR[] binding")
        @Suppress("UNCHECKED_CAST")
        val array = conn.createArrayOf("VARCHAR", raw as Array<out Any?>)
        stmt[index] = array
    }
}

/**
 * `INET NOT NULL` column on the SQL side, String on Kotlin side. Stored
 * as e.g. "192.168.0.1" or "2001:db8::1" — the driver converts to/from
 * the PG INET wire format. Use `null` via `.nullable()` extension.
 */
fun Table.inet(name: String): Column<String> =
    registerColumn(name, InetColumnType())

private class InetColumnType : org.jetbrains.exposed.sql.ColumnType<String>() {
    override fun sqlType(): String = "INET"

    override fun valueFromDB(value: Any): String = value.toString()

    override fun notNullValueToDB(value: String): Any = value

    override fun setParameter(stmt: org.jetbrains.exposed.sql.statements.api.PreparedStatementApi, index: Int, value: Any?) {
        if (value == null) {
            stmt.setNull(index, this)
            return
        }
        val obj = org.postgresql.util.PGobject().apply {
            type = "inet"
            this.value = value.toString()
        }
        stmt[index] = obj
    }
}

/**
 * `NOW()` expression for `defaultExpression()` on TIMESTAMP columns.
 */
object NowExpression : Expression<Instant>() {
    override fun toQueryBuilder(queryBuilder: QueryBuilder) {
        queryBuilder.append("NOW()")
    }
}
