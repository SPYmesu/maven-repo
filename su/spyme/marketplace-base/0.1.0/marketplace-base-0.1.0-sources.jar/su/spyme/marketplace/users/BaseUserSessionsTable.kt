package su.spyme.marketplace.users

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.database.inet
import java.time.Instant
import java.util.UUID

/**
 * Singleton Exposed table for granular per-session JWT revocation
 * (per В1). One row per active access JWT; jti claim references this
 * row's primary key.
 */
object BaseUserSessionsTable : Table("user_sessions") {
    val id: Column<UUID> = uuid("id")
    val userId: Column<Long> = long("user_id").references(BaseUsersTable.id)
    val jti: Column<UUID> = uuid("jti").uniqueIndex()
    val deviceLabel: Column<String?> = varchar("device_label", 128).nullable()
    val ip: Column<String?> = inet("ip").nullable()
    val userAgent: Column<String?> = text("user_agent").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val lastActiveAt: Column<Instant> = timestamp("last_active_at").defaultExpression(NowExpression)
    val revokedAt: Column<Instant?> = timestamp("revoked_at").nullable()
    val expiresAt: Column<Instant> = timestamp("expires_at")

    override val primaryKey = PrimaryKey(id)
}
