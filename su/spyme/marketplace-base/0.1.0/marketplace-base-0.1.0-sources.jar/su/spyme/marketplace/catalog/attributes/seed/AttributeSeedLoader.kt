package su.spyme.marketplace.catalog.attributes.seed

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.yaml.snakeyaml.Yaml
import su.spyme.marketplace.catalog.attributes.AttributeDataType
import su.spyme.marketplace.catalog.attributes.AttributesServiceBase
import su.spyme.marketplace.catalog.categories.BaseCategoriesTable
import java.io.InputStream
import java.io.Reader

/**
 * Loads attribute seed YAML files and applies them via
 * [AttributesServiceBase]. Idempotent — re-running on a populated DB
 * leaves rows untouched (decisions: existing definitions are NOT
 * mutated; existing bindings are NOT detached). Hosts wire this into
 * the cron-pool boot sequence so newly added seed entries propagate
 * on next deploy without manual SQL.
 *
 * ## YAML format
 * ```yaml
 * attributes:
 *   - code: COLOR
 *     dataType: ENUM
 *     isFacet: true
 *     isVariant: true
 *     enumValues: [red, green, blue]
 *     sortOrder: 10
 *     categoryBindings:
 *       - categorySlug: shirts
 *         sortOrder: 1
 *         isRequired: true
 *   - code: WEIGHT_KG
 *     dataType: DECIMAL
 *     unit: kg
 *     isGlobal: true
 *     validation: { min: 0, max: 1000 }
 *     sortOrder: 20
 * ```
 *
 * `validation` is preserved as-is into a JSONB column — its shape is
 * dataType-specific and validated client-side at form submission.
 *
 * ## Resolution rules for `categoryBindings`
 *  - `categorySlug` matches `categories.slug` (NOT `id`) so seeds are
 *    portable across environments.
 *  - When the slug doesn't exist yet, the binding is **silently
 *    skipped**. Hosts seed categories first then attributes, so this
 *    is the expected case during partial bootstraps. The summary
 *    return value records which slugs went unresolved.
 *  - When a slug exists for multiple parent categories, the first
 *    one ordered by id is picked. Treat this as a known limitation
 *    of the seed format — hosts that need deep-tree bindings should
 *    call `attachToCategory` manually after the loader runs.
 *
 * @property attributesService Backing service used to upsert
 *           definitions and category bindings.
 * @property mainDb Used directly only to look up category IDs by
 *           slug; all writes go through [attributesService].
 */
class AttributeSeedLoader(
    private val attributesService: AttributesServiceBase,
    private val mainDb: Database,
) {

    /** Load YAML from the classpath (e.g. `seed/attributes/core.yaml`). */
    fun loadFromClasspath(resourcePath: String): AttributeSeedFile {
        val stream = javaClass.classLoader.getResourceAsStream(resourcePath)
            ?: throw IllegalArgumentException("seed resource not found on classpath: $resourcePath")
        return stream.use(::parseYaml)
    }

    /** Load YAML from any [InputStream] — used by tests with bundled fixtures. */
    fun parseYaml(input: InputStream): AttributeSeedFile = parseYaml(input.reader())

    fun parseYaml(reader: Reader): AttributeSeedFile {
        @Suppress("UNCHECKED_CAST")
        val raw: Map<String, Any?> = Yaml().load(reader) ?: emptyMap<String, Any?>()
        return mapToFile(raw)
    }

    /**
     * Apply [file] to the database. Returns a summary suitable for
     * structured logging.
     *
     * Idempotency: a definition whose [AttributeSeed.code] already
     * exists is left alone (not patched). Bindings are upserted via
     * `attachToCategory` — re-running keeps them in sync.
     */
    fun apply(file: AttributeSeedFile): SeedApplyReport {
        var inserted = 0
        var skippedExisting = 0
        var bindingsAttached = 0
        val unresolvedSlugs = mutableListOf<UnresolvedBinding>()

        for (seed in file.attributes) {
            val existing = attributesService.findByCode(seed.code)
            val def = if (existing != null) {
                skippedExisting++
                existing
            } else {
                inserted++
                attributesService.createDefinition(
                    code = seed.code,
                    dataType = seed.dataType,
                    labelI18nKey = seed.labelI18nKey,
                    isGlobal = seed.isGlobal,
                    isVariant = seed.isVariant,
                    isFacet = seed.isFacet,
                    isSearchable = seed.isSearchable,
                    isProtected = seed.isProtected,
                    isRequiredDefault = seed.isRequiredDefault,
                    isPublic = seed.isPublic,
                    enumValues = seed.enumValues,
                    validation = seed.validation,
                    unit = seed.unit,
                    sortOrder = seed.sortOrder,
                )
            }

            for (binding in seed.categoryBindings) {
                val categoryId = resolveCategoryIdBySlug(binding.categorySlug)
                if (categoryId == null) {
                    unresolvedSlugs += UnresolvedBinding(seed.code, binding.categorySlug)
                    continue
                }
                attributesService.attachToCategory(
                    categoryId = categoryId,
                    attributeId = def.id,
                    sortOrder = binding.sortOrder,
                    isRequired = binding.isRequired,
                )
                bindingsAttached++
            }
        }

        return SeedApplyReport(
            inserted = inserted,
            skippedExisting = skippedExisting,
            bindingsAttached = bindingsAttached,
            unresolvedBindings = unresolvedSlugs,
        )
    }

    /** Convenience: parse classpath resource and apply in one call. */
    fun loadAndApply(resourcePath: String): SeedApplyReport = apply(loadFromClasspath(resourcePath))

    private fun resolveCategoryIdBySlug(slug: String): Long? = transaction(mainDb) {
        BaseCategoriesTable.selectAll()
            .where { BaseCategoriesTable.slug eq slug }
            .orderBy(BaseCategoriesTable.id)
            .limit(1)
            .firstOrNull()
            ?.get(BaseCategoriesTable.id)
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapToFile(raw: Map<String, Any?>): AttributeSeedFile {
        val attributesNode = raw["attributes"]
            ?: throw IllegalArgumentException("YAML missing top-level 'attributes' list")
        require(attributesNode is List<*>) { "'attributes' must be a YAML list, got ${attributesNode::class.simpleName}" }
        val seeds = attributesNode.map { node ->
            require(node is Map<*, *>) { "each attribute entry must be a map, got ${node?.let { it::class.simpleName }}" }
            mapToSeed(node as Map<String, Any?>)
        }
        return AttributeSeedFile(seeds)
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapToSeed(node: Map<String, Any?>): AttributeSeed {
        val code = (node["code"] as? String)
            ?: throw IllegalArgumentException("attribute entry missing 'code'")
        val dataTypeRaw = (node["dataType"] as? String)
            ?: throw IllegalArgumentException("attribute '$code' missing 'dataType'")
        val enumValues = (node["enumValues"] as? List<*>)?.map { it.toString() }
        val bindings = (node["categoryBindings"] as? List<*>)?.map { b ->
            require(b is Map<*, *>) { "categoryBinding entry must be a map" }
            val bMap = b as Map<String, Any?>
            AttributeSeed.CategoryBinding(
                categorySlug = (bMap["categorySlug"] as? String)
                    ?: throw IllegalArgumentException("binding for '$code' missing 'categorySlug'"),
                sortOrder = (bMap["sortOrder"] as? Number)?.toInt() ?: 0,
                isRequired = bMap["isRequired"] as? Boolean,
            )
        } ?: emptyList()

        return AttributeSeed(
            code = code,
            dataType = AttributeDataType.parse(dataTypeRaw),
            labelI18nKey = node["labelI18nKey"] as? String,
            isGlobal = node["isGlobal"] as? Boolean ?: false,
            isVariant = node["isVariant"] as? Boolean ?: false,
            isFacet = node["isFacet"] as? Boolean ?: false,
            isSearchable = node["isSearchable"] as? Boolean ?: false,
            isProtected = node["isProtected"] as? Boolean ?: true,
            isRequiredDefault = node["isRequiredDefault"] as? Boolean ?: false,
            isPublic = node["isPublic"] as? Boolean ?: true,
            enumValues = enumValues,
            validation = node["validation"]?.let(::yamlValueToJson),
            unit = node["unit"] as? String,
            sortOrder = (node["sortOrder"] as? Number)?.toInt() ?: 0,
            categoryBindings = bindings,
        )
    }

    /**
     * Translates SnakeYAML's loose `Any?` tree into kotlinx.serialization
     * [JsonElement] so it can land in the Exposed `jsonb<JsonElement>`
     * column without a second hop through string-encoding.
     */
    @Suppress("UNCHECKED_CAST")
    private fun yamlValueToJson(value: Any?): JsonElement = when (value) {
        null -> JsonNull
        is Boolean -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is String -> JsonPrimitive(value)
        is List<*> -> JsonArray(value.map(::yamlValueToJson))
        is Map<*, *> -> JsonObject((value as Map<String, Any?>).mapValues { yamlValueToJson(it.value) })
        else -> JsonPrimitive(value.toString())
    }

    /** Returned by [apply] for structured logging. */
    data class SeedApplyReport(
        val inserted: Int,
        val skippedExisting: Int,
        val bindingsAttached: Int,
        val unresolvedBindings: List<UnresolvedBinding>,
    )

    data class UnresolvedBinding(val attributeCode: String, val categorySlug: String)
}
