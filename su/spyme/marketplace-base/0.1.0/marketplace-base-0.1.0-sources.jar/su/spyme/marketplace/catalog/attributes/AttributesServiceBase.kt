package su.spyme.marketplace.catalog.attributes

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.innerJoin
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.upsert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant

open class AttributesServiceBase(protected val mainDb: Database) {

    open fun createDefinition(
        code: String,
        dataType: AttributeDataType,
        labelI18nKey: String? = null,
        isGlobal: Boolean = false,
        isVariant: Boolean = false,
        isFacet: Boolean = false,
        isSearchable: Boolean = false,
        isProtected: Boolean = false,
        isRequiredDefault: Boolean = false,
        isPublic: Boolean = true,
        enumValues: List<String>? = null,
        validation: JsonElement? = null,
        unit: String? = null,
        sortOrder: Int = 0,
    ): AttributeDefinition {
        require(code.isNotBlank()) { "code must not be blank" }
        require(code.length <= 64) { "code must fit VARCHAR(64): $code" }
        if (dataType == AttributeDataType.ENUM || dataType == AttributeDataType.ENUM_MULTI) {
            require(!enumValues.isNullOrEmpty()) { "enumValues required for $dataType" }
        }

        val enumJson: JsonElement? = enumValues?.let { values ->
            JsonArray(values.map { JsonPrimitive(it) })
        }

        return transaction(mainDb) {
            BaseAttributeDefinitionsTable.insert {
                it[BaseAttributeDefinitionsTable.code] = code
                it[BaseAttributeDefinitionsTable.dataType] = dataType.name
                it[BaseAttributeDefinitionsTable.labelI18nKey] = labelI18nKey
                it[BaseAttributeDefinitionsTable.isGlobal] = isGlobal
                it[BaseAttributeDefinitionsTable.isVariant] = isVariant
                it[BaseAttributeDefinitionsTable.isFacet] = isFacet
                it[BaseAttributeDefinitionsTable.isSearchable] = isSearchable
                it[BaseAttributeDefinitionsTable.isProtected] = isProtected
                it[BaseAttributeDefinitionsTable.isRequiredDefault] = isRequiredDefault
                it[BaseAttributeDefinitionsTable.isPublic] = isPublic
                it[BaseAttributeDefinitionsTable.enumValues] = enumJson
                it[BaseAttributeDefinitionsTable.validation] = validation
                it[BaseAttributeDefinitionsTable.unit] = unit
                it[BaseAttributeDefinitionsTable.sortOrder] = sortOrder
            }
            findByCodeInternal(code) ?: error("inserted attribute $code not found in tx")
        }
    }

    open fun findById(id: Long): AttributeDefinition? = transaction(mainDb) {
        BaseAttributeDefinitionsTable.selectAll()
            .where { BaseAttributeDefinitionsTable.id eq id }
            .firstOrNull()
            ?.let(AttributeDefinition::fromRow)
    }

    open fun findByCode(code: String): AttributeDefinition? = transaction(mainDb) {
        findByCodeInternal(code)
    }

    open fun listActive(): List<AttributeDefinition> = transaction(mainDb) {
        BaseAttributeDefinitionsTable.selectAll()
            .where { BaseAttributeDefinitionsTable.archivedAt.isNull() }
            .orderBy(BaseAttributeDefinitionsTable.sortOrder to SortOrder.ASC)
            .map(AttributeDefinition::fromRow)
    }

    open fun archive(id: Long) {
        transaction(mainDb) {
            BaseAttributeDefinitionsTable.update({ BaseAttributeDefinitionsTable.id eq id }) {
                it[BaseAttributeDefinitionsTable.archivedAt] = Instant.now()
            }
        }
    }

    open fun unarchive(id: Long) {
        transaction(mainDb) {
            BaseAttributeDefinitionsTable.update({ BaseAttributeDefinitionsTable.id eq id }) {
                it[BaseAttributeDefinitionsTable.archivedAt] = null
            }
        }
    }

    open fun attachToCategory(
        categoryId: Long,
        attributeId: Long,
        sortOrder: Int = 0,
        isRequired: Boolean? = null,
    ): CategoryAttributeBinding = transaction(mainDb) {
        BaseCategoryAttributesTable.upsert {
            it[BaseCategoryAttributesTable.categoryId] = categoryId
            it[BaseCategoryAttributesTable.attributeId] = attributeId
            it[BaseCategoryAttributesTable.sortOrder] = sortOrder
            it[BaseCategoryAttributesTable.isRequired] = isRequired
        }
        BaseCategoryAttributesTable.selectAll()
            .where {
                (BaseCategoryAttributesTable.categoryId eq categoryId) and
                    (BaseCategoryAttributesTable.attributeId eq attributeId)
            }
            .first()
            .let(CategoryAttributeBinding::fromRow)
    }

    open fun detachFromCategory(categoryId: Long, attributeId: Long): Boolean = transaction(mainDb) {
        BaseCategoryAttributesTable.deleteWhere {
            (BaseCategoryAttributesTable.categoryId eq categoryId) and
                (BaseCategoryAttributesTable.attributeId eq attributeId)
        } > 0
    }

    /**
     * Returns attributes attached to [categoryId] plus, when
     * [includeGlobal] is true, every active is_global definition. Order:
     * bindings by their sortOrder, then global attributes by their own
     * sortOrder. Archived definitions are excluded.
     */
    open fun listForCategory(categoryId: Long, includeGlobal: Boolean = true): List<AttributeDefinition> =
        transaction(mainDb) {
            val bound = (BaseCategoryAttributesTable innerJoin BaseAttributeDefinitionsTable)
                .selectAll()
                .where {
                    (BaseCategoryAttributesTable.categoryId eq categoryId) and
                        BaseAttributeDefinitionsTable.archivedAt.isNull()
                }
                .orderBy(BaseCategoryAttributesTable.sortOrder to SortOrder.ASC)
                .map(AttributeDefinition::fromRow)

            if (!includeGlobal) return@transaction bound

            val globals = BaseAttributeDefinitionsTable.selectAll()
                .where {
                    (BaseAttributeDefinitionsTable.isGlobal eq true) and
                        BaseAttributeDefinitionsTable.archivedAt.isNull()
                }
                .orderBy(BaseAttributeDefinitionsTable.sortOrder to SortOrder.ASC)
                .map(AttributeDefinition::fromRow)

            (bound + globals).distinctBy { it.id }
        }

    private fun findByCodeInternal(code: String): AttributeDefinition? =
        BaseAttributeDefinitionsTable.selectAll()
            .where { BaseAttributeDefinitionsTable.code eq code }
            .firstOrNull()
            ?.let(AttributeDefinition::fromRow)
}
