package su.spyme.marketplace.uploads

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/** Status alphabet for the uploads row. Matches V020 CHECK. */
enum class UploadStatus {
    UPLOADED, PROCESSING, READY, ARCHIVED;

    companion object {
        fun parse(value: String): UploadStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown UploadStatus: '$value'")
    }
}

object BaseUploadsTable : Table("uploads") {
    val id: Column<Long> = long("id").autoIncrement()
    val bucket: Column<String> = varchar("bucket", 64)
    val storageKey: Column<String> = varchar("storage_key", 512)
    val originalFilename: Column<String?> = varchar("original_filename", 255).nullable()
    val contentType: Column<String> = varchar("content_type", 128)
    val sizeBytes: Column<Long> = long("size_bytes")
    val uploadedByUserId: Column<Long?> = long("uploaded_by_user_id").nullable()
    val entityType: Column<String?> = varchar("entity_type", 32).nullable()
    val entityId: Column<Long?> = long("entity_id").nullable()
    val metadata: Column<JsonElement?> = jsonb("metadata", Json, JsonElement.serializer()).nullable()
    val status: Column<String> = varchar("status", 16).default("UPLOADED")
    val archivedAt: Column<Instant?> = timestamp("archived_at").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/** One uploaded blob, indexed by metadata. The actual bytes live in the StorageProvider. */
data class Upload(
    val id: Long,
    val bucket: String,
    val storageKey: String,
    val originalFilename: String?,
    val contentType: String,
    val sizeBytes: Long,
    val uploadedByUserId: Long?,
    val entityType: String?,
    val entityId: Long?,
    val metadata: JsonElement?,
    val status: UploadStatus,
    val archivedAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isArchived: Boolean get() = archivedAt != null

    companion object {
        fun fromRow(row: ResultRow): Upload = Upload(
            id = row[BaseUploadsTable.id],
            bucket = row[BaseUploadsTable.bucket],
            storageKey = row[BaseUploadsTable.storageKey],
            originalFilename = row[BaseUploadsTable.originalFilename],
            contentType = row[BaseUploadsTable.contentType],
            sizeBytes = row[BaseUploadsTable.sizeBytes],
            uploadedByUserId = row[BaseUploadsTable.uploadedByUserId],
            entityType = row[BaseUploadsTable.entityType],
            entityId = row[BaseUploadsTable.entityId],
            metadata = row[BaseUploadsTable.metadata],
            status = UploadStatus.parse(row[BaseUploadsTable.status]),
            archivedAt = row[BaseUploadsTable.archivedAt],
            createdAt = row[BaseUploadsTable.createdAt],
            updatedAt = row[BaseUploadsTable.updatedAt],
        )
    }
}

/**
 * Metadata-side service for the [BaseUploadsTable]. Doesn't touch the
 * actual bytes — that's the StorageProvider's job. Producer flow:
 *   1. Host route receives multipart upload; streams bytes to a
 *      temp file with size + content-type checks against
 *      [BaseConfig.uploads.maxMultipartSize].
 *   2. Host calls StorageProvider.put(bucket, key, bytes, contentType).
 *   3. Host calls UploadsServiceBase.register(...) with the metadata.
 *   4. (Optional) ImageProcessingService.enqueueThumbnails(uploadId)
 *      kicks off async resize jobs.
 */
open class UploadsServiceBase(protected val mainDb: Database) {

    open fun register(
        bucket: String,
        storageKey: String,
        contentType: String,
        sizeBytes: Long,
        originalFilename: String? = null,
        uploadedByUserId: Long? = null,
        entityType: String? = null,
        entityId: Long? = null,
        metadata: JsonElement? = null,
    ): Upload {
        require(bucket.isNotBlank()) { "bucket must not be blank" }
        require(storageKey.isNotBlank()) { "storageKey must not be blank" }
        require(sizeBytes >= 0) { "sizeBytes must be non-negative" }

        return transaction(mainDb) {
            val newId = BaseUploadsTable.insert {
                it[BaseUploadsTable.bucket] = bucket
                it[BaseUploadsTable.storageKey] = storageKey
                it[BaseUploadsTable.contentType] = contentType
                it[BaseUploadsTable.sizeBytes] = sizeBytes
                it[BaseUploadsTable.originalFilename] = originalFilename
                it[BaseUploadsTable.uploadedByUserId] = uploadedByUserId
                it[BaseUploadsTable.entityType] = entityType
                it[BaseUploadsTable.entityId] = entityId
                it[BaseUploadsTable.metadata] = metadata
            }[BaseUploadsTable.id]
            loadById(newId)!!
        }
    }

    open fun findById(id: Long): Upload? = transaction(mainDb) { loadById(id) }

    open fun findByStorageKey(bucket: String, storageKey: String): Upload? = transaction(mainDb) {
        BaseUploadsTable.selectAll()
            .where {
                (BaseUploadsTable.bucket eq bucket) and (BaseUploadsTable.storageKey eq storageKey)
            }
            .firstOrNull()
            ?.let(Upload::fromRow)
    }

    open fun listForEntity(entityType: String, entityId: Long): List<Upload> = transaction(mainDb) {
        BaseUploadsTable.selectAll()
            .where {
                (BaseUploadsTable.entityType eq entityType) and (BaseUploadsTable.entityId eq entityId)
            }
            .orderBy(BaseUploadsTable.createdAt to SortOrder.ASC)
            .map(Upload::fromRow)
    }

    open fun listForUser(userId: Long): List<Upload> = transaction(mainDb) {
        BaseUploadsTable.selectAll()
            .where { BaseUploadsTable.uploadedByUserId eq userId }
            .orderBy(BaseUploadsTable.createdAt to SortOrder.DESC)
            .map(Upload::fromRow)
    }

    /** Re-attaches a previously-orphaned upload to a domain entity. */
    open fun attachToEntity(uploadId: Long, entityType: String, entityId: Long) {
        transaction(mainDb) {
            BaseUploadsTable.update({ BaseUploadsTable.id eq uploadId }) {
                it[BaseUploadsTable.entityType] = entityType
                it[BaseUploadsTable.entityId] = entityId
            }
        }
    }

    open fun setStatus(uploadId: Long, status: UploadStatus) {
        transaction(mainDb) {
            BaseUploadsTable.update({ BaseUploadsTable.id eq uploadId }) {
                it[BaseUploadsTable.status] = status.name
            }
        }
    }

    /** Soft-deletes the upload row. The blob in storage stays (5-year retention per the plan). */
    open fun archive(uploadId: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseUploadsTable.update({ BaseUploadsTable.id eq uploadId }) {
                it[BaseUploadsTable.status] = UploadStatus.ARCHIVED.name
                it[BaseUploadsTable.archivedAt] = now
            }
        }
    }

    private fun loadById(id: Long): Upload? = BaseUploadsTable.selectAll()
        .where { BaseUploadsTable.id eq id }
        .firstOrNull()
        ?.let(Upload::fromRow)
}
