package su.spyme.marketplace.orders.state

import su.spyme.marketplace.core.registry.ConflictRegistry
import java.time.Instant

/**
 * Event raised by [su.spyme.marketplace.orders.OrdersServiceBase]
 * after a successful order status transition. Listeners attach
 * side-effects (email notifications, webhook deliveries, inventory
 * adjustments, refund creation, …) without coupling them to the
 * orders service.
 *
 * @property reason Free-form text the actor supplied (e.g. cancellation
 *           reason text, manager note). Cancellation reason *code*
 *           lives on the order row directly.
 */
data class OrderTransitionEvent(
    val orderId: Long,
    val from: OrderStatus,
    val to: OrderStatus,
    val actor: TransitionActor,
    val actorUserId: Long?,
    val reason: String?,
    val occurredAt: Instant,
)

/**
 * Side-effect callback fired after a successful transition. Listeners
 * are invoked in registration order; an exception in one listener is
 * logged but does not block subsequent listeners — the actual SQL
 * status update has already committed by the time listeners run.
 */
fun interface OrderTransitionListener {
    suspend fun onTransition(event: OrderTransitionEvent)
}

/**
 * Registry of listeners keyed by name. Modules register themselves
 * during the bootstrap registration phase; the OrdersService walks
 * [all] when firing transition events.
 */
class OrderTransitionListenerRegistry {
    private val backing = ConflictRegistry<String, OrderTransitionListener>("OrderTransitionListenerRegistry")

    fun register(name: String, listener: OrderTransitionListener) {
        backing.register(name, listener)
    }

    fun all(): List<OrderTransitionListener> = backing.values().toList()
    fun isEmpty(): Boolean = backing.isEmpty()
}
