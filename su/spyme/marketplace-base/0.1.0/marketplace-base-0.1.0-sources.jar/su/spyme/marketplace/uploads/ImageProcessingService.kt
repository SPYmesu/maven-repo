package su.spyme.marketplace.uploads

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

enum class ThumbnailSize(val sqlValue: String, val maxDimension: Int) {
    SM("sm", 320),
    MD("md", 768),
    LG("lg", 1280),
    XL("xl", 1920);

    companion object {
        fun parse(value: String): ThumbnailSize = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown ThumbnailSize: '$value'")
    }
}

enum class ThumbnailFormat(val sqlValue: String, val mimeType: String) {
    WEBP("webp", "image/webp"),
    JPEG("jpeg", "image/jpeg"),
    PNG("png", "image/png");

    companion object {
        fun parse(value: String): ThumbnailFormat = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown ThumbnailFormat: '$value'")
    }
}

enum class ImageJobStatus {
    PENDING, PROCESSING, DONE, FAILED;

    companion object {
        fun parse(value: String): ImageJobStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown ImageJobStatus: '$value'")
    }
}

object BaseImageProcessingQueueTable : Table("image_processing_queue") {
    val id: Column<Long> = long("id").autoIncrement()
    val uploadId: Column<Long> = long("upload_id").references(BaseUploadsTable.id)
    val targetSize: Column<String> = varchar("target_size", 8)
    val targetFormat: Column<String> = varchar("target_format", 8).default("webp")
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val attempts: Column<Short> = short("attempts").default(0)
    val lastError: Column<String?> = text("last_error").nullable()
    val enqueuedAt: Column<Instant> = timestamp("enqueued_at").defaultExpression(NowExpression)
    val processedAt: Column<Instant?> = timestamp("processed_at").nullable()

    override val primaryKey = PrimaryKey(id)
}

data class ImageProcessingJob(
    val id: Long,
    val uploadId: Long,
    val targetSize: ThumbnailSize,
    val targetFormat: ThumbnailFormat,
    val status: ImageJobStatus,
    val attempts: Int,
    val lastError: String?,
    val enqueuedAt: Instant,
    val processedAt: Instant?,
) {
    companion object {
        fun fromRow(row: ResultRow): ImageProcessingJob = ImageProcessingJob(
            id = row[BaseImageProcessingQueueTable.id],
            uploadId = row[BaseImageProcessingQueueTable.uploadId],
            targetSize = ThumbnailSize.parse(row[BaseImageProcessingQueueTable.targetSize]),
            targetFormat = ThumbnailFormat.parse(row[BaseImageProcessingQueueTable.targetFormat]),
            status = ImageJobStatus.parse(row[BaseImageProcessingQueueTable.status]),
            attempts = row[BaseImageProcessingQueueTable.attempts].toInt(),
            lastError = row[BaseImageProcessingQueueTable.lastError],
            enqueuedAt = row[BaseImageProcessingQueueTable.enqueuedAt],
            processedAt = row[BaseImageProcessingQueueTable.processedAt],
        )
    }
}

/**
 * Async thumbnail-generation queue manager (per М2). Knows the SQL
 * lifecycle; the actual imgscalr resize lives in a host-supplied
 * worker that calls [claimPending], does the resize, calls
 * [markDone] / [markFailed].
 *
 * Sharing the queue between sizes/formats lets the worker batch on
 * read but execute one job at a time — image resize is CPU-bound.
 */
open class ImageProcessingService(protected val mainDb: Database) {

    /**
     * Enqueues thumbnail jobs for the given upload. Default: all four
     * sizes in WebP. Repeat enqueues are absorbed by the partial
     * unique index on (upload_id, target_size, target_format) WHERE
     * processed_at IS NULL.
     */
    open fun enqueueThumbnails(
        uploadId: Long,
        sizes: Set<ThumbnailSize> = ThumbnailSize.entries.toSet(),
        format: ThumbnailFormat = ThumbnailFormat.WEBP,
    ): List<ImageProcessingJob> {
        require(sizes.isNotEmpty()) { "must request at least one size" }
        return transaction(mainDb) {
            sizes.map { size ->
                exec(
                    """
                    INSERT INTO image_processing_queue (upload_id, target_size, target_format)
                    VALUES (?, ?, ?)
                    ON CONFLICT (upload_id, target_size, target_format) WHERE processed_at IS NULL
                    DO UPDATE SET enqueued_at = NOW(), attempts = 0, last_error = NULL, status = 'PENDING'
                    """.trimIndent(),
                    listOf(
                        org.jetbrains.exposed.sql.LongColumnType() to uploadId,
                        org.jetbrains.exposed.sql.VarCharColumnType() to size.sqlValue,
                        org.jetbrains.exposed.sql.VarCharColumnType() to format.sqlValue,
                    ),
                )
                BaseImageProcessingQueueTable.selectAll()
                    .where {
                        (BaseImageProcessingQueueTable.uploadId eq uploadId) and
                            (BaseImageProcessingQueueTable.targetSize eq size.sqlValue) and
                            (BaseImageProcessingQueueTable.targetFormat eq format.sqlValue) and
                            BaseImageProcessingQueueTable.processedAt.isNull()
                    }
                    .first()
                    .let(ImageProcessingJob::fromRow)
            }
        }
    }

    open fun claimPending(limit: Int = 5): List<ImageProcessingJob> = transaction(mainDb) {
        BaseImageProcessingQueueTable.selectAll()
            .where { BaseImageProcessingQueueTable.status eq ImageJobStatus.PENDING.name }
            .orderBy(BaseImageProcessingQueueTable.enqueuedAt to SortOrder.ASC)
            .limit(limit)
            .map(ImageProcessingJob::fromRow)
    }

    open fun markProcessing(jobId: Long) {
        transaction(mainDb) {
            BaseImageProcessingQueueTable.update({ BaseImageProcessingQueueTable.id eq jobId }) {
                it[BaseImageProcessingQueueTable.status] = ImageJobStatus.PROCESSING.name
            }
        }
    }

    open fun markDone(jobId: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseImageProcessingQueueTable.update({ BaseImageProcessingQueueTable.id eq jobId }) {
                it[BaseImageProcessingQueueTable.status] = ImageJobStatus.DONE.name
                it[BaseImageProcessingQueueTable.processedAt] = now
                it[BaseImageProcessingQueueTable.lastError] = null
            }
        }
    }

    open fun markFailed(jobId: Long, reason: String) {
        transaction(mainDb) {
            exec(
                """
                UPDATE image_processing_queue
                SET status = 'FAILED', attempts = attempts + 1, last_error = ?
                WHERE id = ?
                """.trimIndent(),
                listOf(
                    org.jetbrains.exposed.sql.TextColumnType() to reason.take(MAX_ERROR_LEN),
                    org.jetbrains.exposed.sql.LongColumnType() to jobId,
                ),
            )
        }
    }

    open fun listForUpload(uploadId: Long): List<ImageProcessingJob> = transaction(mainDb) {
        BaseImageProcessingQueueTable.selectAll()
            .where { BaseImageProcessingQueueTable.uploadId eq uploadId }
            .orderBy(BaseImageProcessingQueueTable.enqueuedAt to SortOrder.ASC)
            .map(ImageProcessingJob::fromRow)
    }

    open fun pendingCount(): Long = transaction(mainDb) {
        BaseImageProcessingQueueTable.selectAll()
            .where { BaseImageProcessingQueueTable.status eq ImageJobStatus.PENDING.name }
            .count()
    }

    companion object {
        private const val MAX_ERROR_LEN = 4_000
    }
}
