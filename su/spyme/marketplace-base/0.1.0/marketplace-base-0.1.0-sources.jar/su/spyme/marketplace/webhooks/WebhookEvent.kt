package su.spyme.marketplace.webhooks

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Schema describing one webhook event type. The wire payload always
 * follows the envelope:
 *
 * ```
 * {
 *   "event_id": "evt_<uuid>",
 *   "event_type": "order.paid",
 *   "event_version": "YYYY-MM-DD",
 *   "created_at": "ISO8601",
 *   "data": { ... event-specific shape ... },
 *   "context": { "marketplace_id": "...", "test_mode": false }
 * }
 * ```
 *
 * Convention is `entity.action` lowercase; bulk variants use
 * `<entity>.bulk_<action>` (per В9).
 *
 * @property code Stable SQL value, persisted on
 *           `webhook_subscriptions.event_types` and
 *           `webhook_deliveries.event_type`.
 * @property labelI18nKey Lookup key for the localized human-readable
 *           label rendered in admin UI.
 * @property moduleSource `"core"`, `"multi-vendor"`, `"inventory"`,
 *           `"shipping"`, `"subscriptions"`, etc. Lets the admin UI
 *           group events by source module.
 * @property version Date-based payload schema version (Stripe-style).
 *           Bumped when a non-additive change ships.
 */
data class WebhookEvent(
    val code: String,
    val labelI18nKey: String,
    val moduleSource: String = "core",
    val version: String = "2026-05-10",
) {
    init {
        require(code.isNotBlank()) { "code must not be blank" }
        require(code.length <= 128) { "code must fit VARCHAR(128): $code" }
        require(code == code.lowercase()) { "code must be lowercase: $code" }
    }
}

/**
 * Registry of recognised webhook event types. Backed by
 * [ConflictRegistry]; modules register their own events during the
 * bootstrap registration phase. WebhookSubscriptionsService validates
 * subscription `event_types` against this registry — unknown codes
 * are rejected at the API boundary so a typo doesn't silently
 * subscribe to nothing.
 *
 * `withCoreDefaults()` seeds the canonical 26 core events from the
 * architecture plan; module registries (multi-vendor, inventory,
 * shipping, subscriptions) own their own additions.
 */
class WebhookEventRegistry {
    private val backing = ConflictRegistry<String, WebhookEvent>("WebhookEventRegistry")

    fun register(event: WebhookEvent) {
        backing.register(event.code, event)
    }

    fun get(code: String): WebhookEvent = backing.get(code)
    fun getOrNull(code: String): WebhookEvent? = backing.getOrNull(code)
    fun isValid(code: String): Boolean = backing.contains(code)
    fun all(): List<WebhookEvent> = backing.values().toList()

    companion object {
        // Core baseline — 26 events grouped by entity. Modules add
        // vendor/stock/shipment/subscription events when activated.
        val CORE_EVENTS: List<WebhookEvent> = listOf(
            // order
            we("order.created", "webhooks.order.created"),
            we("order.transitioned", "webhooks.order.transitioned"),
            we("order.paid", "webhooks.order.paid"),
            we("order.cancelled", "webhooks.order.cancelled"),
            we("order.completed", "webhooks.order.completed"),
            we("order.item_added", "webhooks.order.item_added"),
            we("order.item_removed", "webhooks.order.item_removed"),
            // payment
            we("payment.initiated", "webhooks.payment.initiated"),
            we("payment.completed", "webhooks.payment.completed"),
            we("payment.failed", "webhooks.payment.failed"),
            we("payment.refunded", "webhooks.payment.refunded"),
            // refund
            we("refund.requested", "webhooks.refund.requested"),
            we("refund.approved", "webhooks.refund.approved"),
            we("refund.completed", "webhooks.refund.completed"),
            we("refund.rejected", "webhooks.refund.rejected"),
            // product
            we("product.created", "webhooks.product.created"),
            we("product.updated", "webhooks.product.updated"),
            we("product.published", "webhooks.product.published"),
            we("product.archived", "webhooks.product.archived"),
            we("product.deleted", "webhooks.product.deleted"),
            we("product.bulk_updated", "webhooks.product.bulk_updated"),
            // category
            we("category.created", "webhooks.category.created"),
            we("category.updated", "webhooks.category.updated"),
            we("category.deleted", "webhooks.category.deleted"),
            // user
            we("user.registered", "webhooks.user.registered"),
            we("user.email_verified", "webhooks.user.email_verified"),
            we("user.deleted", "webhooks.user.deleted"),
            // review
            we("review.created", "webhooks.review.created"),
            we("review.replied", "webhooks.review.replied"),
        )

        private fun we(code: String, key: String) = WebhookEvent(code = code, labelI18nKey = key)

        /** Returns a registry pre-loaded with the core event set. */
        fun withCoreDefaults(): WebhookEventRegistry = WebhookEventRegistry().apply {
            CORE_EVENTS.forEach(::register)
        }
    }
}
