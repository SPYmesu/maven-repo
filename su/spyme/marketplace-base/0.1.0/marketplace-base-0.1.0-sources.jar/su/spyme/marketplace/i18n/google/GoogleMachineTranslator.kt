package su.spyme.marketplace.i18n.google

import su.spyme.marketplace.core.i18n.Locale
import su.spyme.marketplace.core.i18n.MachineTranslator
import su.spyme.marketplace.core.i18n.TranslationException

/**
 * Stub for Google Cloud Translation API v3 integration.
 *
 * Two auth modes — API key (simpler) and service-account JWT (required
 * for advanced features like glossary / model selection). This stub
 * documents only the API-key flow; hosts that need glossaries should
 * override and inject a `google-auth-library` token provider.
 *
 * ## Endpoint
 *  POST `https://translation.googleapis.com/language/translate/v2?key=<apiKey>`
 *
 * ## Request (form params)
 *  - `q` — text to translate (repeat for batch)
 *  - `source` — optional ISO-639-1 (omit for auto-detect)
 *  - `target` — required ISO-639-1
 *  - `format` — `text` or `html`
 *
 * ## Response
 *  ```
 *  {
 *    "data": {
 *      "translations": [{
 *        "translatedText": "...",
 *        "detectedSourceLanguage": "en"
 *      }]
 *    }
 *  }
 *  ```
 *
 * ## Quota
 *  Google charges $20/1M chars (basic tier). Free trial = $300 credit.
 *  HTTP 403 with `userRateLimitExceeded` → map to
 *  [TranslationException.QuotaExceeded].
 *
 * @property apiKey Google Cloud API key (restrict to translate-only
 *           scope in production).
 * @property endpointUrl Override only for testing; default points at
 *           production.
 */
open class GoogleMachineTranslator(
    protected val apiKey: String,
    protected val endpointUrl: String = "https://translation.googleapis.com/language/translate/v2",
) : MachineTranslator {

    override val providerCode: String = PROVIDER_CODE

    override fun translate(text: String, from: Locale?, to: Locale): String {
        throw TranslationException.Unauthorized(
            "GoogleMachineTranslator is a stub. Override translate() with a real HTTP call against $endpointUrl.",
        )
    }

    companion object {
        const val PROVIDER_CODE = "google"
    }
}
