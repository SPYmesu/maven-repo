package su.spyme.marketplace.auth.password

import org.bouncycastle.crypto.generators.OpenBSDBCrypt
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.database.NowExpression
import java.security.SecureRandom
import java.time.Instant

object BasePasswordCredentialsTable : Table("password_credentials") {
    val userId: Column<Long> = long("user_id")
    val passwordHash: Column<String> = varchar("password_hash", 255)
    val algo: Column<String> = varchar("algo", 16).default("bcrypt")
    val lastChangedAt: Column<Instant> = timestamp("last_changed_at").defaultExpression(NowExpression)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(userId)
}

data class PasswordCredential(
    val userId: Long,
    val passwordHash: String,
    val algo: String,
    val lastChangedAt: Instant,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): PasswordCredential = PasswordCredential(
            userId = row[BasePasswordCredentialsTable.userId],
            passwordHash = row[BasePasswordCredentialsTable.passwordHash],
            algo = row[BasePasswordCredentialsTable.algo],
            lastChangedAt = row[BasePasswordCredentialsTable.lastChangedAt],
            createdAt = row[BasePasswordCredentialsTable.createdAt],
            updatedAt = row[BasePasswordCredentialsTable.updatedAt],
        )
    }
}

/**
 * `auth-password` module's storage service. bcrypt-only at launch
 * (the SQL CHECK enforces it); future migrations could add argon2id.
 *
 * The bcrypt implementation is BouncyCastle's OpenBSDBCrypt — the
 * Modular Crypt Format (`$2a$` / `$2y$`) the rest of the world reads.
 * Cost factor is 10 by default (~70ms on commodity hardware), tunable
 * via the constructor for hosts with stronger CPUs.
 */
open class PasswordAuthService(
    protected val mainDb: Database,
    private val bcryptCost: Int = 10,
) {

    init {
        require(bcryptCost in 4..30) { "bcryptCost must be 4..30, was $bcryptCost" }
    }

    /** Sets or replaces the password for [userId]. */
    open fun set(userId: Long, plaintext: String, now: Instant = Instant.now()) {
        require(plaintext.length >= MIN_PASSWORD_LEN) {
            "password must be at least $MIN_PASSWORD_LEN characters"
        }
        val hash = bcryptHash(plaintext)
        transaction(mainDb) {
            BasePasswordCredentialsTable.upsert {
                it[BasePasswordCredentialsTable.userId] = userId
                it[BasePasswordCredentialsTable.passwordHash] = hash
                it[BasePasswordCredentialsTable.algo] = "bcrypt"
                it[BasePasswordCredentialsTable.lastChangedAt] = now
            }
        }
    }

    /** Constant-time-ish password verification. Returns true on match. */
    open fun verify(userId: Long, plaintext: String): Boolean {
        val cred = find(userId) ?: return false
        return bcryptVerify(plaintext, cred.passwordHash)
    }

    open fun find(userId: Long): PasswordCredential? = transaction(mainDb) {
        BasePasswordCredentialsTable.selectAll()
            .where { BasePasswordCredentialsTable.userId eq userId }
            .firstOrNull()
            ?.let(PasswordCredential::fromRow)
    }

    /** Removes the password row — used by the "switch to passkey-only" flow. */
    open fun unset(userId: Long): Boolean = transaction(mainDb) {
        BasePasswordCredentialsTable.deleteWhere { BasePasswordCredentialsTable.userId eq userId } > 0
    }

    /** True iff the user currently has a password set. */
    open fun isSet(userId: Long): Boolean = find(userId) != null

    private fun bcryptHash(plaintext: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        // OpenBSDBCrypt.generate emits the standard `$2a$<cost>$<22-char-salt><31-char-hash>` MCF string.
        return OpenBSDBCrypt.generate(plaintext.toCharArray(), salt, bcryptCost)
    }

    private fun bcryptVerify(plaintext: String, mcfHash: String): Boolean = try {
        OpenBSDBCrypt.checkPassword(mcfHash, plaintext.toCharArray())
    } catch (e: Exception) {
        false
    }

    companion object {
        const val MIN_PASSWORD_LEN: Int = 8
    }
}
