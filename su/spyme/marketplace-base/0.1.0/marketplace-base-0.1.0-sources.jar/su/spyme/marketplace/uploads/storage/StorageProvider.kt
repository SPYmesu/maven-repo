package su.spyme.marketplace.uploads.storage

import su.spyme.marketplace.core.registry.ConflictRegistry
import java.io.InputStream
import kotlin.time.Duration

/**
 * Pluggable blob storage abstraction (per М1). Concrete providers:
 * - `LocalStorageProvider` — writes under `data/uploads/<bucket>/...`.
 *   Ships in core; default for dev and small single-host deploys.
 * - `S3StorageProvider` — comes in the optional `storage-s3` module.
 *   Targets Selectel / Yandex Object Storage / Backblaze / vanilla S3.
 *
 * Hosts register exactly one provider during the bootstrap registration
 * phase via [StorageRegistry]; the [su.spyme.marketplace.uploads.UploadsServiceBase]
 * dispatches to it when reading/writing blobs.
 */
interface StorageProvider {
    /** Stable identifier for diagnostics and admin UI. */
    val name: String

    /**
     * Stores [bytes] at (bucket, key). Replaces any existing blob at
     * the same address.
     *
     * @return [StorageRef] carrying the resolved key + provider name —
     *         hosts persist this on the `uploads` row.
     */
    suspend fun put(bucket: String, key: String, bytes: ByteArray, contentType: String): StorageRef

    /** Retrieves the blob; returns null when missing. */
    suspend fun get(bucket: String, key: String): InputStream?

    /** Drops the blob; returns true if it existed. */
    suspend fun delete(bucket: String, key: String): Boolean

    /**
     * Generates a time-limited URL the caller can hand to the user's
     * browser. Returns null when the provider doesn't support signed
     * URLs (`LocalStorageProvider` returns `null` — host serves the
     * file through its own route in that case).
     */
    suspend fun signedUrl(bucket: String, key: String, ttl: Duration): String?

    /**
     * Lightweight existence check. Default implementation does a `get`
     * and closes immediately; overrides can do better when the
     * underlying storage offers a HEAD-style call.
     */
    suspend fun exists(bucket: String, key: String): Boolean = get(bucket, key)?.also { it.close() } != null
}

/**
 * Reference returned by [StorageProvider.put]. Persisting the
 * (provider, bucket, key) triple lets the host re-read the blob
 * later through whichever provider was active at write time, so a
 * mid-flight migration from local → S3 doesn't lose old content.
 */
data class StorageRef(
    val provider: String,
    val bucket: String,
    val key: String,
)

/**
 * Lookup for active storage providers. Backed by [ConflictRegistry];
 * duplicate provider names trip at bootstrap.
 */
class StorageRegistry {
    private val backing = ConflictRegistry<String, StorageProvider>("StorageRegistry")

    fun register(provider: StorageProvider) {
        backing.register(provider.name, provider)
    }

    fun get(name: String): StorageProvider = backing.get(name)
    fun getOrNull(name: String): StorageProvider? = backing.getOrNull(name)
    fun all(): List<StorageProvider> = backing.values().toList()

    /**
     * The host's "default" provider — typically the only one
     * registered. Throws if zero or multiple are present without a
     * named lookup.
     */
    fun default(): StorageProvider {
        val all = backing.values()
        return when (all.size) {
            0 -> error("no StorageProvider registered")
            1 -> all.first()
            else -> error("multiple StorageProviders registered (${all.map { it.name }}); pick one by name")
        }
    }
}
