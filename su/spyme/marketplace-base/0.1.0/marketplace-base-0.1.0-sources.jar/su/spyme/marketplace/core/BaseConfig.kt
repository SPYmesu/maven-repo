package su.spyme.marketplace.core

import kotlin.time.Duration
import kotlin.time.Duration.Companion.days
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

data class BaseConfig(
    val marketplaceKind: MarketplaceKind,
    val marketplaceName: String,
    val publicUrl: String,
    val supportEmail: String,
    val environment: Environment = Environment.DEV,
    val activeModules: List<String> = emptyList(),
    val database: Database,
    val auth: Auth,
    val search: Search = Search(),
    val webhook: Webhook = Webhook(),
    val uploads: Uploads = Uploads(),
    val templates: Templates = Templates(),
    val audit: Audit = Audit(),
    val gdpr: Gdpr = Gdpr(),
    val webauthn: WebAuthn = WebAuthn(),
    val multiVendor: MultiVendor = MultiVendor(),
    val totp: KeyVersion = KeyVersion(),
    val oauth: KeyVersion = KeyVersion(),
    val pii: KeyVersion = KeyVersion(),
    val webhookSecrets: KeyVersion = KeyVersion(),
    val externalApi: ExternalApi = ExternalApi(),
    val devSeed: DevSeed = DevSeed(),
) {
    enum class Environment { DEV, STAGING, PROD }

    data class Database(
        val jdbcUrl: String,
        val username: String,
        val password: String,
        val schema: String? = null,
        val mainPool: Pool = Pool(
            maxSize = 15,
            connectionTimeout = 30.seconds,
            leakDetectionThreshold = 1.minutes,
        ),
        val cronPool: Pool = Pool(
            maxSize = 5,
            connectionTimeout = 60.seconds,
            leakDetectionThreshold = 10.minutes,
        ),
    ) {
        data class Pool(
            val maxSize: Int,
            val minIdle: Int = (maxSize / 3).coerceAtLeast(1),
            val connectionTimeout: Duration,
            val idleTimeout: Duration = 10.minutes,
            val maxLifetime: Duration = 30.minutes,
            val leakDetectionThreshold: Duration,
        )
    }

    data class Auth(
        val jwtSigningKey: String,
        val jwtIssuer: String,
        val jwtAccessTtl: Duration = 24.hours,
        val userCacheTtlSeconds: Long = 60,
        val orderPaymentTimeoutMinutes: Long = 30,
    ) {
        init {
            require(jwtSigningKey.length >= 32) {
                "jwtSigningKey must be at least 32 chars (HMAC-SHA256 needs ≥256 bits of key material)"
            }
            require(jwtIssuer.isNotBlank()) { "jwtIssuer must not be blank" }
        }
    }

    data class Search(
        val indexPrefix: String = "",
        val bulkReindexThreshold: Int = 1000,
        val bulkReindexRatePerSecond: Int = 500,
        val fallback: Fallback = Fallback(),
    ) {
        data class Fallback(val enabled: Boolean = true)
    }

    data class Webhook(
        val deliveryRetentionDays: Int = 90,
        val toleranceWindow: Duration = 5.minutes,
    )

    data class Uploads(
        val maxMultipartSize: Long = 50L * 1024 * 1024,
    )

    data class Templates(
        val externalPath: String? = null,
    )

    data class Audit(
        val maxUndoAgeDays: Int = 30,
    )

    data class Gdpr(
        val userRetentionYears: Int = 3,
        val financialRetentionYears: Int = 5,
        val deletionGracePeriodDays: Int = 30,
    )

    data class WebAuthn(
        val residentKey: ResidentKey = ResidentKey.PREFERRED,
        val maxCredentialsPerUser: Int = 20,
    ) {
        enum class ResidentKey { REQUIRED, PREFERRED, DISCOURAGED }
    }

    data class MultiVendor(
        val onboardingMode: OnboardingMode = OnboardingMode.INVITE_ONLY,
        val urlPrefix: String = "v",
        val enableRls: Boolean = false,
    ) {
        enum class OnboardingMode { INVITE_ONLY, APPLICATION, AUTO_BY_ROLE }
    }

    data class KeyVersion(
        val activeKeyVersion: Int = 1,
    )

    data class ExternalApi(
        val stabilityLevel: StabilityLevel = StabilityLevel.BETA,
    ) {
        enum class StabilityLevel { BETA, STABLE }
    }

    data class DevSeed(
        val enabled: Boolean = false,
    )

    companion object {
        val DEFAULT_TOLERANCE_WINDOW: Duration = 5.minutes
        val DEFAULT_GRACE_PERIOD: Duration = 30.days
    }
}
