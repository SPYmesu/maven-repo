package su.spyme.marketplace.core.search

/**
 * Provider-agnostic search response.
 *
 * @property totalHits Total matching documents server-side. May exceed
 *           the size of [hits] when pagination is in play.
 * @property hits Documents for the requested page, in result order.
 * @property facetDistribution Faceted counts: `field → value → count`.
 *           Empty when no facets were requested or the provider
 *           doesn't support facets in degraded mode.
 * @property mode `HEALTHY` when the primary provider answered;
 *           `DEGRADED` when the request fell back to pg_trgm because
 *           the circuit breaker was open. Surfaced to the front-end
 *           via the `X-Search-Mode` header so it can show a banner.
 */
data class SearchResult(
    val indexName: String,
    val totalHits: Long,
    val limit: Int,
    val offset: Int,
    val hits: List<IndexableDocument>,
    val facetDistribution: Map<String, Map<String, Long>> = emptyMap(),
    val processingTimeMs: Long = 0,
    val mode: SearchMode = SearchMode.HEALTHY,
)

enum class SearchMode { HEALTHY, DEGRADED }
