package su.spyme.marketplace.notifications

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Logical notification template — one per "thing that can be sent".
 * Hosts and modules register their own; the ten core kinds the
 * architecture plan calls out are pre-loaded by [withDefaults].
 *
 * @property code Stable identifier persisted on
 *           `notifications.kind`. Convention: `entity.action`
 *           (e.g. `order.paid`, `review.replied`) — matches the
 *           webhook event naming so notifications and webhooks read
 *           consistently in audit logs.
 * @property defaultChannels Channels the host fans out to by default
 *           when the producer doesn't specify. Matches
 *           [ChannelCodes] strings.
 * @property dedupable If true, callers should compute a dedup_key —
 *           the kind is one that often fires in bursts (e.g. daily
 *           digest, "new comment on your review" flurry). Pure
 *           informational; the SQL UNIQUE on dedup_key is what
 *           actually enforces idempotency.
 * @property requiresUser If false, recipient can be a raw address
 *           without a `users.id` link (e.g. password-reset email
 *           before the row is even created).
 */
data class NotificationKind(
    val code: String,
    val labelI18nKey: String,
    val defaultChannels: Set<String>,
    val dedupable: Boolean = false,
    val requiresUser: Boolean = true,
) {
    init {
        require(code.isNotBlank()) { "code must not be blank" }
        require(code.length <= 64) { "code must fit VARCHAR(64): $code" }
    }
}

/** Canonical channel codes. Hosts/modules can register more via [ChannelRegistry]. */
object ChannelCodes {
    const val EMAIL = "email"
    const val TELEGRAM = "tg"
    const val VK = "vk"
    const val SMS = "sms"
    const val IN_APP = "in-app"
}

/**
 * Lookup for [NotificationKind]s. Backed by [ConflictRegistry] so a
 * duplicate code at bootstrap fails fast.
 */
class NotificationKindRegistry {
    private val backing = ConflictRegistry<String, NotificationKind>("NotificationKindRegistry")

    fun register(kind: NotificationKind) {
        backing.register(kind.code, kind)
    }

    fun get(code: String): NotificationKind = backing.get(code)
    fun getOrNull(code: String): NotificationKind? = backing.getOrNull(code)
    fun isValid(code: String): Boolean = backing.contains(code)
    fun all(): List<NotificationKind> = backing.values().toList()

    companion object {
        // Ten baseline kinds named in the architecture plan (E8 brief).
        val ORDER_CREATED = NotificationKind(
            code = "order.created",
            labelI18nKey = "notifications.order.created",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val ORDER_PAID = NotificationKind(
            code = "order.paid",
            labelI18nKey = "notifications.order.paid",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val ORDER_SHIPPED = NotificationKind(
            code = "order.shipped",
            labelI18nKey = "notifications.order.shipped",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val PAYMENT_FAILED = NotificationKind(
            code = "payment.failed",
            labelI18nKey = "notifications.payment.failed",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val REFUND_COMPLETED = NotificationKind(
            code = "refund.completed",
            labelI18nKey = "notifications.refund.completed",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val REVIEW_RECEIVED = NotificationKind(
            code = "review.received",
            labelI18nKey = "notifications.review.received",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val REVIEW_REPLIED = NotificationKind(
            code = "review.replied",
            labelI18nKey = "notifications.review.replied",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )
        val ACCOUNT_CREATED = NotificationKind(
            code = "account.created",
            labelI18nKey = "notifications.account.created",
            defaultChannels = setOf(ChannelCodes.EMAIL),
        )
        val PASSWORD_RESET = NotificationKind(
            code = "password.reset",
            labelI18nKey = "notifications.password.reset",
            defaultChannels = setOf(ChannelCodes.EMAIL),
            requiresUser = false,
        )
        val SECURITY_ALERT = NotificationKind(
            code = "security.alert",
            labelI18nKey = "notifications.security.alert",
            defaultChannels = setOf(ChannelCodes.EMAIL, ChannelCodes.IN_APP),
        )

        fun withDefaults(): NotificationKindRegistry = NotificationKindRegistry().apply {
            listOf(
                ORDER_CREATED, ORDER_PAID, ORDER_SHIPPED,
                PAYMENT_FAILED, REFUND_COMPLETED,
                REVIEW_RECEIVED, REVIEW_REPLIED,
                ACCOUNT_CREATED, PASSWORD_RESET, SECURITY_ALERT,
            ).forEach(::register)
        }
    }
}
