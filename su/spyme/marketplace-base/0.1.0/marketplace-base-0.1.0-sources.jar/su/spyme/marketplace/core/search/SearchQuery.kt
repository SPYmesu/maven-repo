package su.spyme.marketplace.core.search

import kotlinx.serialization.json.JsonElement

/**
 * Provider-agnostic search request. Concrete [SearchProvider]
 * implementations translate this into MeiliSearch / pg_trgm / etc.
 * — providers must not silently drop unsupported features (filters
 * the implementation can't express) but should throw a clear
 * [UnsupportedSearchFeatureException] so a regression doesn't sneak
 * through as "weird empty results".
 *
 * @property query Free-form full-text query. `null` (or blank) means
 *           "match all rows", which is the standard pattern for
 *           filter-only browsing.
 * @property limit Capped at [MAX_LIMIT] by providers — clients can
 *           ask for more but won't get it.
 */
data class SearchQuery(
    val indexName: String,
    val query: String? = null,
    val filters: List<SearchFilter> = emptyList(),
    val facets: List<String> = emptyList(),
    val sort: List<SearchSort> = emptyList(),
    val limit: Int = DEFAULT_LIMIT,
    val offset: Int = 0,
) {
    init {
        require(limit in 0..MAX_LIMIT) { "limit must be in 0..$MAX_LIMIT, was $limit" }
        require(offset >= 0) { "offset must be non-negative, was $offset" }
    }

    companion object {
        const val DEFAULT_LIMIT = 20
        const val MAX_LIMIT = 100
    }
}

/**
 * Storefront-facing filter primitives. The set is intentionally small
 * — providers map each variant onto their own filter language. New
 * variants land via discussion (Stripe-style additive contract).
 */
sealed class SearchFilter {
    data class Eq(val field: String, val value: JsonElement) : SearchFilter()
    data class In(val field: String, val values: List<JsonElement>) : SearchFilter()
    data class Range(val field: String, val min: Number?, val max: Number?) : SearchFilter()
    data class Not(val inner: SearchFilter) : SearchFilter()
    data class And(val children: List<SearchFilter>) : SearchFilter()
    data class Or(val children: List<SearchFilter>) : SearchFilter()
}

/** Single sort axis. Composite sorts come from a list of these. */
data class SearchSort(val field: String, val direction: SortDirection) {
    enum class SortDirection { ASC, DESC }
}

class UnsupportedSearchFeatureException(message: String) : RuntimeException(message)
