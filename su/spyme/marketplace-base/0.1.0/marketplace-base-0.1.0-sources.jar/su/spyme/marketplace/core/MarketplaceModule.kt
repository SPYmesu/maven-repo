package su.spyme.marketplace.core

import io.ktor.server.routing.Routing

interface MarketplaceModule {
    val name: String

    val dependsOn: List<String>
        get() = emptyList()

    /**
     * Marketplace kinds this module can run under. Default: all three kinds.
     * Modules that only make sense for one kind override this — e.g. the
     * `shipping` module returns {PHYSICAL, MIXED}, `digital-delivery`
     * returns {DIGITAL, MIXED}.
     */
    val supportedKinds: Set<MarketplaceKind>
        get() = MarketplaceKind.entries.toSet()

    fun bootstrap(context: MarketplaceBootstrapContext)

    fun routes(routing: Routing, context: MarketplaceBootstrapContext) {}

    fun startCron(context: MarketplaceBootstrapContext) {}
}
