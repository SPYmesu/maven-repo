package su.spyme.marketplace.reviews

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/** Moderation outcome for a review. Mirrors the V013 CHECK alphabet. */
enum class ReviewStatus {
    PENDING, APPROVED, REJECTED, HIDDEN;

    companion object {
        fun parse(value: String): ReviewStatus = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown ReviewStatus: '$value'")
    }
}

/** Storefront visibility independent of moderation status. */
enum class ReviewVisibility {
    PUBLIC, PRIVATE;

    companion object {
        fun parse(value: String): ReviewVisibility = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Unknown ReviewVisibility: '$value'")
    }
}

object BaseReviewsTable : Table("reviews") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val productId: Column<Long> = long("product_id")
    val orderId: Column<Long?> = long("order_id").nullable()
    val rating: Column<Short> = short("rating")
    val title: Column<String?> = text("title").nullable()
    val body: Column<String> = text("body")
    val locale: Column<String> = varchar("locale", 8).default("ru")
    val status: Column<String> = varchar("status", 16).default("PENDING")
    val visibility: Column<String> = varchar("visibility", 16).default("PUBLIC")
    val moderationNotes: Column<String?> = text("moderation_notes").nullable()
    val helpfulCount: Column<Int> = integer("helpful_count").default(0)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

object BaseReviewRepliesTable : Table("review_replies") {
    val id: Column<Long> = long("id").autoIncrement()
    val reviewId: Column<Long> = long("review_id").references(BaseReviewsTable.id)
    val userId: Column<Long> = long("user_id")
    val body: Column<String> = text("body")
    val isOfficial: Column<Boolean> = bool("is_official").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * One review per (user, product). Verified-buyer reviews carry
 * [orderId]; staff-seeded or anonymous-on-import reviews leave it
 * null.
 *
 * @property rating 1-5 (SQL CHECK enforces).
 * @property visibility Independent of [status]: an APPROVED review
 *           can still be PRIVATE for moderation/legal reasons.
 */
data class Review(
    val id: Long,
    val userId: Long,
    val productId: Long,
    val orderId: Long?,
    val rating: Short,
    val title: String?,
    val body: String,
    val locale: String,
    val status: ReviewStatus,
    val visibility: ReviewVisibility,
    val moderationNotes: String?,
    val helpfulCount: Int,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    val isVerifiedBuyer: Boolean get() = orderId != null
    val isPublic: Boolean get() = status == ReviewStatus.APPROVED && visibility == ReviewVisibility.PUBLIC

    companion object {
        fun fromRow(row: ResultRow): Review = Review(
            id = row[BaseReviewsTable.id],
            userId = row[BaseReviewsTable.userId],
            productId = row[BaseReviewsTable.productId],
            orderId = row[BaseReviewsTable.orderId],
            rating = row[BaseReviewsTable.rating],
            title = row[BaseReviewsTable.title],
            body = row[BaseReviewsTable.body],
            locale = row[BaseReviewsTable.locale],
            status = ReviewStatus.parse(row[BaseReviewsTable.status]),
            visibility = ReviewVisibility.parse(row[BaseReviewsTable.visibility]),
            moderationNotes = row[BaseReviewsTable.moderationNotes],
            helpfulCount = row[BaseReviewsTable.helpfulCount],
            createdAt = row[BaseReviewsTable.createdAt],
            updatedAt = row[BaseReviewsTable.updatedAt],
        )
    }
}

/** Vendor / admin (or escalated user) reply on a review. */
data class ReviewReply(
    val id: Long,
    val reviewId: Long,
    val userId: Long,
    val body: String,
    val isOfficial: Boolean,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): ReviewReply = ReviewReply(
            id = row[BaseReviewRepliesTable.id],
            reviewId = row[BaseReviewRepliesTable.reviewId],
            userId = row[BaseReviewRepliesTable.userId],
            body = row[BaseReviewRepliesTable.body],
            isOfficial = row[BaseReviewRepliesTable.isOfficial],
            createdAt = row[BaseReviewRepliesTable.createdAt],
            updatedAt = row[BaseReviewRepliesTable.updatedAt],
        )
    }
}
