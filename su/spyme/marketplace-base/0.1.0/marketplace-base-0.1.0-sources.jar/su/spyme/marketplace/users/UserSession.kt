package su.spyme.marketplace.users

import org.jetbrains.exposed.sql.ResultRow
import java.time.Instant
import java.util.UUID

/**
 * Single login session record — one row per access JWT minted by
 * [su.spyme.marketplace.core.auth.AuthService.login].
 *
 * The granular half of the JWT-revocation pair from В1: `users.jwt_version`
 * provides bulk revocation across every device, while a UserSession
 * row backs revocation of one device at a time. The access token's
 * `sid` claim points at [id]; verification fails if [revokedAt] is
 * set or [expiresAt] has passed.
 *
 * @property jti Random per-issue token id stamped into the JWT's
 *           `jti` claim. Distinct from [id] because a session can be
 *           reissued (refresh flow in E12) keeping [id] but minting a
 *           new [jti].
 * @property ip String-encoded INET column on the SQL side; client
 *           address recorded for the "My sessions" UI.
 */
data class UserSession(
    val id: UUID,
    val userId: Long,
    val jti: UUID,
    val deviceLabel: String?,
    val ip: String?,
    val userAgent: String?,
    val createdAt: Instant,
    val lastActiveAt: Instant,
    val revokedAt: Instant?,
    val expiresAt: Instant,
) {
    val isActive: Boolean
        get() = revokedAt == null && expiresAt.isAfter(Instant.now())

    val isRevoked: Boolean get() = revokedAt != null
    val isExpired: Boolean get() = expiresAt.isBefore(Instant.now())

    companion object {
        /** Maps a [BaseUserSessionsTable] row (or any join including its columns) into a [UserSession]. */
        fun fromRow(row: ResultRow): UserSession = UserSession(
            id = row[BaseUserSessionsTable.id],
            userId = row[BaseUserSessionsTable.userId],
            jti = row[BaseUserSessionsTable.jti],
            deviceLabel = row[BaseUserSessionsTable.deviceLabel],
            ip = row[BaseUserSessionsTable.ip],
            userAgent = row[BaseUserSessionsTable.userAgent],
            createdAt = row[BaseUserSessionsTable.createdAt],
            lastActiveAt = row[BaseUserSessionsTable.lastActiveAt],
            revokedAt = row[BaseUserSessionsTable.revokedAt],
            expiresAt = row[BaseUserSessionsTable.expiresAt],
        )
    }
}
