package su.spyme.marketplace.core.i18n

/**
 * Default fallback translator. Echoes the input back unchanged so
 * marketplace flows that opportunistically request a translation
 * (admin form pre-fill, attribute label seed) keep working when no
 * provider module is wired up.
 *
 * Returns the source text wrapped in `[??] ...` brackets so reviewers
 * spot un-translated content in admin views without breaking
 * downstream layout. This is intentionally surface-level visible —
 * silent passthrough would have leaked English copy into other-locale
 * storefronts during onboarding.
 */
class NoOpMachineTranslator : MachineTranslator {
    override val providerCode: String = "noop"

    override fun translate(text: String, from: Locale?, to: Locale): String =
        if (text.isBlank()) text else "[??] $text"
}
