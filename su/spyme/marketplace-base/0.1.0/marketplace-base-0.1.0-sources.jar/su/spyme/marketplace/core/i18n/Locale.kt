package su.spyme.marketplace.core.i18n

/**
 * Marketplace-wide locale identifier — used for storefront resolution,
 * machine-translation routing, and persisted entity translations
 * (`*_translations` tables, `attribute_label_translations`, etc.).
 *
 * Accepts BCP 47 forms but normalizes the language to lowercase and
 * the optional region to uppercase (`en` ↔ `en-US`, `ru` ↔ `ru-RU`).
 * Pure language codes ([code] like `"en"`) are the common case;
 * region-tagged codes are kept verbatim so that hosts targeting a
 * specific market can override (e.g. `"pt-BR"` vs `"pt-PT"`).
 *
 * Use [parse] for input from HTTP headers / config / DB rows. Use
 * the [companion] constants for compile-time references.
 *
 * Holds a single non-blank lowercase-language string; the wrapper is
 * a value class to make signatures self-documenting without the
 * runtime cost of an extra heap object.
 *
 * @property code The normalized locale tag ("en", "ru", "en-US").
 */
@JvmInline
value class Locale private constructor(val code: String) {

    val language: String get() = code.substringBefore('-')
    val region: String? get() = code.substringAfter('-', missingDelimiterValue = "").takeIf { it.isNotEmpty() }

    override fun toString(): String = code

    companion object {
        val EN = Locale("en")
        val RU = Locale("ru")
        val DE = Locale("de")
        val FR = Locale("fr")
        val ES = Locale("es")
        val ZH = Locale("zh")

        /**
         * Parses a BCP-47 locale tag with light normalization. Rejects
         * empty / blank input; regions are uppercased; languages are
         * lowercased; unknown shapes throw rather than silently coerce
         * — callers should canonicalize at the boundary, not deeper
         * inside the call graph.
         *
         * @throws IllegalArgumentException if [tag] is not a recognized
         *         BCP-47 prefix (`xx`, `xxx`, `xx-YY`).
         */
        fun parse(tag: String): Locale {
            require(tag.isNotBlank()) { "locale tag must not be blank" }
            val parts = tag.trim().split('-', '_')
            require(parts[0].length in 2..3 && parts[0].all { it.isLetter() }) {
                "locale language part must be 2-3 letters: '$tag'"
            }
            return when (parts.size) {
                1 -> Locale(parts[0].lowercase())
                2 -> {
                    require(parts[1].length in 2..3) {
                        "locale region must be 2-3 chars: '$tag'"
                    }
                    Locale("${parts[0].lowercase()}-${parts[1].uppercase()}")
                }
                else -> throw IllegalArgumentException("locale tag has too many segments: '$tag'")
            }
        }

        /** Same as [parse] but returns null instead of throwing. */
        fun parseOrNull(tag: String): Locale? = runCatching { parse(tag) }.getOrNull()
    }
}
