package su.spyme.marketplace.core.search.outbox

import su.spyme.marketplace.core.search.IndexableDocument

/**
 * Bridge between an entity's primary key and the search document
 * shape. The catalog enqueues `(entityType, entityId)` pairs into the
 * outbox; the worker consults the registered builder for each
 * `entityType` to materialize the JSON payload.
 *
 * Hosts implement this once per logical index. Example:
 *
 * ```
 * class ProductsSearchDocumentBuilder(private val products: ProductsServiceBase) :
 *     SearchDocumentBuilder {
 *     override val entityType = "product"
 *     override val indexName = "products"
 *     override suspend fun buildDocument(entityId: Long): IndexableDocument? {
 *         val product = products.findById(entityId, includeArchived = true) ?: return null
 *         val translations = products.listTranslations(entityId)
 *         val fields = buildJsonObject {
 *             put("title_ru", JsonPrimitive(translations.firstOrNull { it.locale == "ru" }?.title.orEmpty()))
 *             put("price", JsonPrimitive(product.price.amount))
 *             put("category_id", JsonPrimitive(product.categoryId))
 *         }
 *         return IndexableDocument(indexName, entityId.toString(), fields)
 *     }
 * }
 * ```
 *
 * @return `null` if the entity was hard-deleted before the worker
 *         got to it; the worker treats that as "process and move on".
 */
interface SearchDocumentBuilder {
    /** Matches `search_index_queue.entity_type`. */
    val entityType: String

    /** Logical index name passed to the [su.spyme.marketplace.core.search.SearchProvider]. */
    val indexName: String

    suspend fun buildDocument(entityId: Long): IndexableDocument?
}
