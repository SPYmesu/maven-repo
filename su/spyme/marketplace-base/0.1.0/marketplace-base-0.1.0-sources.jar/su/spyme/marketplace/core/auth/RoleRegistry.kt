package su.spyme.marketplace.core.auth

import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Registry of roles available in the marketplace. Backed by
 * [ConflictRegistry] so duplicate-code registration fails fast at
 * bootstrap. Hosts and modules call [register] with their own roles
 * (e.g. moonstudio's DEVELOPER, incomeauto-host's CSR) during
 * Application.marketplaceModule() phase 1.
 *
 * Use [withDefaults] to seed the four base roles per the architecture
 * plan: GUEST (anonymous), USER (authenticated), MANAGER (operations),
 * ADMIN (full control).
 */
class RoleRegistry {
    private val backing = ConflictRegistry<String, Role>("RoleRegistry")

    fun register(role: Role) {
        backing.register(role.code, role)
    }

    fun get(code: String): Role = backing.get(code)
    fun getOrNull(code: String): Role? = backing.getOrNull(code)
    fun isValid(code: String): Boolean = backing.contains(code)
    fun all(): List<Role> = backing.values().sortedBy { it.level }

    /**
     * True if any of [userRoles] meets or exceeds the level of
     * [minimum]. Unknown role codes in [userRoles] are skipped — they
     * could be artifacts of a since-removed module's role.
     */
    fun hasAtLeast(userRoles: Collection<String>, minimum: String): Boolean {
        val threshold = get(minimum).level
        return userRoles.any { code -> (getOrNull(code)?.level ?: -1) >= threshold }
    }

    companion object {
        val GUEST = Role(code = "GUEST", label = "Guest", level = 0)
        val USER = Role(code = "USER", label = "User", level = 10)
        val MANAGER = Role(code = "MANAGER", label = "Manager", level = 50)
        val ADMIN = Role(code = "ADMIN", label = "Administrator", level = 100)

        /** Returns a registry pre-loaded with the four base roles. */
        fun withDefaults(): RoleRegistry = RoleRegistry().apply {
            register(GUEST)
            register(USER)
            register(MANAGER)
            register(ADMIN)
        }
    }
}
