package su.spyme.marketplace.users

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.greater
import org.jetbrains.exposed.sql.SqlExpressionBuilder.less
import org.jetbrains.exposed.sql.SqlExpressionBuilder.neq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Duration
import java.time.Instant
import java.util.UUID

open class UserSessionsService(
    protected val mainDb: Database,
    protected val cronDb: Database,
    /** Per-В1: revoked sessions linger this long for incident review. */
    private val revokedRetention: Duration = Duration.ofDays(7),
) {

    open fun create(
        userId: Long,
        jti: UUID,
        expiresAt: Instant,
        deviceLabel: String? = null,
        ip: String? = null,
        userAgent: String? = null,
        sessionId: UUID = UUID.randomUUID(),
        now: Instant = Instant.now(),
    ): UserSession = transaction(mainDb) {
        BaseUserSessionsTable.insert {
            it[BaseUserSessionsTable.id] = sessionId
            it[BaseUserSessionsTable.userId] = userId
            it[BaseUserSessionsTable.jti] = jti
            it[BaseUserSessionsTable.deviceLabel] = deviceLabel
            it[BaseUserSessionsTable.ip] = ip
            it[BaseUserSessionsTable.userAgent] = userAgent
            it[BaseUserSessionsTable.createdAt] = now
            it[BaseUserSessionsTable.lastActiveAt] = now
            it[BaseUserSessionsTable.expiresAt] = expiresAt
        }
        loadById(sessionId) ?: error("session $sessionId vanished from its own transaction")
    }

    open fun findById(sessionId: UUID): UserSession? =
        transaction(mainDb) { loadById(sessionId) }

    open fun findByJti(jti: UUID): UserSession? =
        transaction(mainDb) {
            BaseUserSessionsTable.selectAll()
                .where { BaseUserSessionsTable.jti eq jti }
                .firstOrNull()
                ?.let(UserSession::fromRow)
        }

    open fun listActiveByUser(userId: Long, now: Instant = Instant.now()): List<UserSession> =
        transaction(mainDb) {
            BaseUserSessionsTable.selectAll()
                .where {
                    (BaseUserSessionsTable.userId eq userId) and
                        BaseUserSessionsTable.revokedAt.isNull() and
                        (BaseUserSessionsTable.expiresAt greater now)
                }
                .map(UserSession::fromRow)
        }

    open fun listAllByUser(userId: Long): List<UserSession> =
        transaction(mainDb) {
            BaseUserSessionsTable.selectAll()
                .where { BaseUserSessionsTable.userId eq userId }
                .map(UserSession::fromRow)
        }

    /** Revokes a single session. Idempotent: returns true on first call, false on repeats. */
    open fun revoke(sessionId: UUID, now: Instant = Instant.now()): Boolean = transaction(mainDb) {
        val updated = BaseUserSessionsTable.update({
            (BaseUserSessionsTable.id eq sessionId) and BaseUserSessionsTable.revokedAt.isNull()
        }) {
            it[BaseUserSessionsTable.revokedAt] = now
        }
        updated > 0
    }

    /** Revokes every active session for [userId] except [keepSessionId]. Returns the count revoked. */
    open fun revokeAllExceptCurrent(
        userId: Long,
        keepSessionId: UUID,
        now: Instant = Instant.now(),
    ): Int = transaction(mainDb) {
        BaseUserSessionsTable.update({
            (BaseUserSessionsTable.userId eq userId) and
                (BaseUserSessionsTable.id neq keepSessionId) and
                BaseUserSessionsTable.revokedAt.isNull()
        }) {
            it[BaseUserSessionsTable.revokedAt] = now
        }
    }

    open fun revokeAllByUser(userId: Long, now: Instant = Instant.now()): Int = transaction(mainDb) {
        BaseUserSessionsTable.update({
            (BaseUserSessionsTable.userId eq userId) and BaseUserSessionsTable.revokedAt.isNull()
        }) {
            it[BaseUserSessionsTable.revokedAt] = now
        }
    }

    open fun updateLastActiveAt(sessionId: UUID, at: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseUserSessionsTable.update({ BaseUserSessionsTable.id eq sessionId }) {
                it[BaseUserSessionsTable.lastActiveAt] = at
            }
        }
    }

    /**
     * Hard-deletes:
     *   1. expired rows (no point keeping non-revoked once exp passed)
     *   2. revoked rows older than [revokedRetention]
     * Runs on the cron pool — safe to call from a scheduled job.
     */
    open fun cleanupStale(now: Instant = Instant.now()): Int = transaction(cronDb) {
        val revokedThreshold = now.minus(revokedRetention)
        // Two delete passes is simpler than the disjunctive predicate and
        // performs identically — both have indexes on (expires_at) and
        // (revoked_at).
        val expiredCount = BaseUserSessionsTable.deleteWhere {
            BaseUserSessionsTable.expiresAt less now
        }
        val staleRevokedCount = BaseUserSessionsTable.deleteWhere {
            BaseUserSessionsTable.revokedAt less revokedThreshold
        }
        expiredCount + staleRevokedCount
    }

    private fun loadById(sessionId: UUID): UserSession? =
        BaseUserSessionsTable.selectAll()
            .where { BaseUserSessionsTable.id eq sessionId }
            .firstOrNull()
            ?.let(UserSession::fromRow)
}
