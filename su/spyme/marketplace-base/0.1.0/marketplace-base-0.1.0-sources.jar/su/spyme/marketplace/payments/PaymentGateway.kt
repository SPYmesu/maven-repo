package su.spyme.marketplace.payments

import kotlinx.serialization.json.JsonElement
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Pluggable payment-gateway adapter. Module implementations (yookassa,
 * tinkoff, cloudpayments, robokassa, manual, test) wire one of these
 * during the bootstrap registration phase; PaymentsService picks the
 * matching one by [name].
 *
 * Methods are `suspend` — gateway calls cross the network and we want
 * to keep request threads available.
 */
interface PaymentGateway {
    /** Stable identifier matching `payments.provider`. */
    val name: String

    /**
     * Asks the gateway to start a payment session. Most providers
     * return a redirect URL the host then renders to the user.
     *
     * @param idempotencyKey Producer-supplied retry token; the
     *        gateway must treat repeated calls with the same value
     *        as the same attempt.
     */
    suspend fun initiate(
        orderId: Long,
        amount: Money,
        idempotencyKey: String,
        returnUrl: String,
        metadata: Map<String, String> = emptyMap(),
    ): InitiateResult

    /** Captures funds previously authorized (3DS / hold flow). */
    suspend fun capture(providerPaymentId: String): CaptureResult

    /** Cancels an in-flight payment that hasn't been captured yet. */
    suspend fun cancel(providerPaymentId: String): Boolean

    /**
     * Refunds either fully or partially. Implementations return their
     * own refund id; the host stores it on `refunds.refund_provider_id`.
     */
    suspend fun refund(
        providerPaymentId: String,
        amount: Money,
        idempotencyKey: String,
    ): RefundResult

    /**
     * Verifies and parses an inbound webhook. Implementations decide
     * how the signature is checked (HMAC-SHA256 for most). Returning
     * null means "this payload doesn't belong to a known payment" —
     * the host responds 200 to ack but ignores it.
     */
    suspend fun parseWebhook(headers: Map<String, String>, body: String): WebhookEvent?

    data class InitiateResult(
        val providerPaymentId: String,
        val redirectUrl: String?,
        val gatewayMetadata: JsonElement?,
    )

    data class CaptureResult(
        val captured: Boolean,
        val gatewayMetadata: JsonElement?,
        val failureReason: String? = null,
    )

    data class RefundResult(
        val refundProviderId: String,
        val gatewayMetadata: JsonElement?,
    )

    /** Inbound webhook decoded into a status nudge for the local payment row. */
    data class WebhookEvent(
        val providerPaymentId: String,
        val newStatus: PaymentStatus,
        val failureReason: String? = null,
        val gatewayMetadata: JsonElement? = null,
    )
}

/**
 * Registry of active payment gateways. Hosts register one or more
 * during bootstrap; PaymentsService routes calls by `payments.provider`
 * value. ConflictRegistry semantics mean re-registering the same
 * provider name fails fast.
 */
class PaymentGatewayRegistry {
    private val backing = ConflictRegistry<String, PaymentGateway>("PaymentGatewayRegistry")

    fun register(gateway: PaymentGateway) {
        backing.register(gateway.name, gateway)
    }

    fun get(name: String): PaymentGateway = backing.get(name)
    fun getOrNull(name: String): PaymentGateway? = backing.getOrNull(name)
    fun all(): List<PaymentGateway> = backing.values().toList()
    fun isEmpty(): Boolean = backing.isEmpty()
}
