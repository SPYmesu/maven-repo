package su.spyme.marketplace.catalog.attributes

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

object BaseAttributeLabelTranslationsTable : Table("attribute_label_translations") {
    val attributeId: Column<Long> = long("attribute_id").references(BaseAttributeDefinitionsTable.id)
    val locale: Column<String> = varchar("locale", 8)
    val label: Column<String> = text("label")
    val hint: Column<String?> = text("hint").nullable()
    val isMachineTranslated: Column<Boolean> = bool("is_machine_translated").default(false)

    override val primaryKey = PrimaryKey(attributeId, locale)
}

object BaseAttributeEnumValueTranslationsTable : Table("attribute_enum_value_translations") {
    val attributeId: Column<Long> = long("attribute_id").references(BaseAttributeDefinitionsTable.id)
    val value: Column<String> = varchar("value", 64)
    val locale: Column<String> = varchar("locale", 8)
    val label: Column<String> = text("label")
    val isMachineTranslated: Column<Boolean> = bool("is_machine_translated").default(false)

    override val primaryKey = PrimaryKey(attributeId, value, locale)
}
