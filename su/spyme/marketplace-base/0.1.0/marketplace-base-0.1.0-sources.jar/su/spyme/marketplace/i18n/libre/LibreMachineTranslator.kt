package su.spyme.marketplace.i18n.libre

import su.spyme.marketplace.core.i18n.Locale
import su.spyme.marketplace.core.i18n.MachineTranslator
import su.spyme.marketplace.core.i18n.TranslationException

/**
 * Stub for self-hosted LibreTranslate (libretranslate.com / OSS).
 * Useful when GDPR / data-residency rules forbid sending content to
 * a US/EU SaaS provider — admins run LibreTranslate inside the same
 * VPC.
 *
 * Quality is the lowest of the four (community-trained models) but
 * the only zero-cost option once self-hosted.
 *
 * ## Endpoint
 *  POST `<self-hosted-url>/translate` (default mirror:
 *  `https://libretranslate.de/translate`, but rate-limited and not
 *  suitable for production).
 *
 * ## Auth
 *  Optional `api_key` form field. Self-hosted instances usually skip
 *  the key entirely; pass `apiKey = null` in that case.
 *
 * ## Request (JSON or form)
 *  ```
 *  {
 *    "q": "...",        // string OR string[]
 *    "source": "en",    // or "auto"
 *    "target": "ru",
 *    "format": "text",  // or "html"
 *    "api_key": "..."   // optional
 *  }
 *  ```
 *
 * ## Response
 *  ```
 *  { "translatedText": "..." }                   // single text
 *  { "translatedText": ["...", "..."] }           // batch
 *  ```
 *
 * ## Quota
 *  Self-hosted = no quota. Public mirrors throttle aggressively
 *  (HTTP 429); for production, pin a self-hosted URL via
 *  [endpointUrl].
 *
 * @property endpointUrl Self-hosted base URL — e.g.
 *           `http://libretranslate.internal:5000/translate`.
 * @property apiKey Optional; only some hosted instances require one.
 */
open class LibreMachineTranslator(
    protected val endpointUrl: String,
    protected val apiKey: String? = null,
) : MachineTranslator {

    override val providerCode: String = PROVIDER_CODE

    override fun translate(text: String, from: Locale?, to: Locale): String {
        throw TranslationException.Unauthorized(
            "LibreMachineTranslator is a stub. Override translate() with a real HTTP call to $endpointUrl.",
        )
    }

    companion object {
        const val PROVIDER_CODE = "libre"
    }
}
