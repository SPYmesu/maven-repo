package su.spyme.marketplace.notifications

import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.registry.ConflictRegistry

/**
 * Pluggable transport for a single delivery. Modules implement one
 * channel each (`channel-email`, `channel-telegram`, `channel-vk`,
 * `channel-sms`); the host picks which to activate.
 *
 * `send` returns a [Result] so the [Notifier] worker can decide
 * whether to mark the row SENT or FAILED without each implementation
 * needing to throw a typed exception.
 */
interface NotificationChannel {
    /** Stable code matching `notifications.channel`. */
    val code: String

    suspend fun send(message: OutboundMessage): Result

    /** Decoded notification row at the moment of dispatch. */
    data class OutboundMessage(
        val notificationId: Long,
        val recipient: String,
        val subject: String?,
        val body: String,
        val locale: String,
        val payload: kotlinx.serialization.json.JsonElement?,
        val kind: String,
    )

    /** Channel response — `Sent` is success, `Failed` carries a reason for the audit row. */
    sealed class Result {
        data object Sent : Result()
        data class Failed(val reason: String, val retryable: Boolean = true) : Result()
    }
}

/**
 * Default no-op channel. Used in tests and dry-run environments —
 * always reports `Sent` and logs at debug.
 */
object NoOpNotificationChannel : NotificationChannel {
    override val code: String = "noop"
    private val log = LoggerFactory.getLogger(NoOpNotificationChannel::class.java)

    override suspend fun send(message: NotificationChannel.OutboundMessage): NotificationChannel.Result {
        log.debug("[noop] notification id={} kind={} → {}", message.notificationId, message.kind, message.recipient)
        return NotificationChannel.Result.Sent
    }
}

/**
 * Lookup of registered [NotificationChannel] implementations. Hosts
 * register one per active channel during the bootstrap registration
 * phase; the [Notifier] worker pulls by `notifications.channel` value.
 */
class NotificationChannelRegistry {
    private val backing = ConflictRegistry<String, NotificationChannel>("NotificationChannelRegistry")

    fun register(channel: NotificationChannel) {
        backing.register(channel.code, channel)
    }

    fun get(code: String): NotificationChannel = backing.get(code)
    fun getOrNull(code: String): NotificationChannel? = backing.getOrNull(code)
    fun all(): List<NotificationChannel> = backing.values().toList()
    fun isEmpty(): Boolean = backing.isEmpty()
}
