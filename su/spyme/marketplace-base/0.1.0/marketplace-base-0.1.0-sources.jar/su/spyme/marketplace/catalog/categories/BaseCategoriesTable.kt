package su.spyme.marketplace.catalog.categories

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

object BaseCategoriesTable : Table("categories") {
    val id: Column<Long> = long("id").autoIncrement()
    val parentId: Column<Long?> = long("parent_id").references(id).nullable()
    val slug: Column<String> = varchar("slug", 96)
    val sortOrder: Column<Int> = integer("sort_order").default(0)
    val isActive: Column<Boolean> = bool("is_active").default(true)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}
