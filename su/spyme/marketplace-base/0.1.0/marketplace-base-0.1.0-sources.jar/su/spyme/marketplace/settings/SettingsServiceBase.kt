package su.spyme.marketplace.settings

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/** Wire format for the settings.value_type column. */
enum class SettingValueType(val sqlValue: String) {
    STRING("string"),
    INT("int"),
    LONG("long"),
    BOOL("bool"),
    JSON("json");

    companion object {
        fun parse(value: String): SettingValueType = entries.firstOrNull { it.sqlValue == value }
            ?: throw IllegalArgumentException("Unknown SettingValueType: '$value'")
    }
}

object BaseSettingsTable : Table("settings") {
    val key: Column<String> = varchar("key", 128)
    val value: Column<String?> = text("value").nullable()
    val valueType: Column<String> = varchar("value_type", 32)
    val description: Column<String?> = text("description").nullable()
    val isRuntimeOverride: Column<Boolean> = bool("is_runtime_override").default(true)
    val updatedBy: Column<Long?> = long("updated_by").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(key)
}

data class SettingEntry(
    val key: String,
    val value: String?,
    val valueType: SettingValueType,
    val description: String?,
    val isRuntimeOverride: Boolean,
    val updatedBy: Long?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow): SettingEntry = SettingEntry(
            key = row[BaseSettingsTable.key],
            value = row[BaseSettingsTable.value],
            valueType = SettingValueType.parse(row[BaseSettingsTable.valueType]),
            description = row[BaseSettingsTable.description],
            isRuntimeOverride = row[BaseSettingsTable.isRuntimeOverride],
            updatedBy = row[BaseSettingsTable.updatedBy],
            createdAt = row[BaseSettingsTable.createdAt],
            updatedAt = row[BaseSettingsTable.updatedAt],
        )
    }
}

/**
 * Typed accessors over the settings KV table. Code-default values
 * live in [su.spyme.marketplace.core.BaseConfig]; this service is
 * the runtime override store that admin-UI edits write to.
 *
 * Access pattern: every getter takes a fallback so a missing row is
 * the same as "use the code default".
 */
open class SettingsServiceBase(protected val mainDb: Database) {

    private val json = Json { ignoreUnknownKeys = true }

    open fun getString(key: String, default: String? = null): String? =
        find(key)?.takeIf { it.valueType == SettingValueType.STRING }?.value ?: default

    open fun getInt(key: String, default: Int? = null): Int? =
        find(key)?.takeIf { it.valueType == SettingValueType.INT }?.value?.toIntOrNull() ?: default

    open fun getLong(key: String, default: Long? = null): Long? =
        find(key)?.takeIf { it.valueType == SettingValueType.LONG }?.value?.toLongOrNull() ?: default

    open fun getBool(key: String, default: Boolean? = null): Boolean? =
        find(key)?.takeIf { it.valueType == SettingValueType.BOOL }?.value?.toBoolean() ?: default

    open fun getJson(key: String): JsonElement? =
        find(key)?.takeIf { it.valueType == SettingValueType.JSON }?.value
            ?.let(json::parseToJsonElement)

    open fun setString(
        key: String,
        value: String?,
        description: String? = null,
        isRuntimeOverride: Boolean = true,
        updatedBy: Long? = null,
    ) = upsertRow(key, value, SettingValueType.STRING, description, isRuntimeOverride, updatedBy)

    open fun setInt(
        key: String,
        value: Int,
        description: String? = null,
        isRuntimeOverride: Boolean = true,
        updatedBy: Long? = null,
    ) = upsertRow(key, value.toString(), SettingValueType.INT, description, isRuntimeOverride, updatedBy)

    open fun setLong(
        key: String,
        value: Long,
        description: String? = null,
        isRuntimeOverride: Boolean = true,
        updatedBy: Long? = null,
    ) = upsertRow(key, value.toString(), SettingValueType.LONG, description, isRuntimeOverride, updatedBy)

    open fun setBool(
        key: String,
        value: Boolean,
        description: String? = null,
        isRuntimeOverride: Boolean = true,
        updatedBy: Long? = null,
    ) = upsertRow(key, value.toString(), SettingValueType.BOOL, description, isRuntimeOverride, updatedBy)

    open fun setJson(
        key: String,
        value: JsonElement,
        description: String? = null,
        isRuntimeOverride: Boolean = true,
        updatedBy: Long? = null,
    ) = upsertRow(key, value.toString(), SettingValueType.JSON, description, isRuntimeOverride, updatedBy)

    open fun delete(key: String): Boolean = transaction(mainDb) {
        BaseSettingsTable.deleteWhere { BaseSettingsTable.key eq key } > 0
    }

    open fun find(key: String): SettingEntry? = transaction(mainDb) {
        BaseSettingsTable.selectAll()
            .where { BaseSettingsTable.key eq key }
            .firstOrNull()
            ?.let(SettingEntry::fromRow)
    }

    open fun listAll(runtimeOnly: Boolean = false): List<SettingEntry> = transaction(mainDb) {
        BaseSettingsTable.selectAll()
            .where {
                if (runtimeOnly) BaseSettingsTable.isRuntimeOverride eq true
                else org.jetbrains.exposed.sql.Op.TRUE
            }
            .map(SettingEntry::fromRow)
    }

    private fun upsertRow(
        key: String,
        value: String?,
        type: SettingValueType,
        description: String?,
        isRuntimeOverride: Boolean,
        updatedBy: Long?,
    ) {
        require(key.isNotBlank()) { "key must not be blank" }
        require(key.length <= 128) { "key must fit VARCHAR(128): $key" }
        transaction(mainDb) {
            BaseSettingsTable.upsert {
                it[BaseSettingsTable.key] = key
                it[BaseSettingsTable.value] = value
                it[BaseSettingsTable.valueType] = type.sqlValue
                if (description != null) it[BaseSettingsTable.description] = description
                it[BaseSettingsTable.isRuntimeOverride] = isRuntimeOverride
                it[BaseSettingsTable.updatedBy] = updatedBy
            }
        }
    }
}
