package su.spyme.marketplace.core.registry

open class ConflictRegistry<K : Any, V : Any>(val name: String) {
    private val entries = LinkedHashMap<K, V>()

    fun register(key: K, value: V) {
        val existing = entries.putIfAbsent(key, value)
        if (existing != null && existing !== value) {
            throw DuplicateRegistrationException(name, key, existing, value)
        }
    }

    fun get(key: K): V =
        entries[key] ?: throw MissingRegistrationException(name, key)

    fun getOrNull(key: K): V? = entries[key]

    fun contains(key: K): Boolean = entries.containsKey(key)

    fun keys(): Set<K> = entries.keys.toSet()

    fun values(): Collection<V> = entries.values.toList()

    fun entries(): Map<K, V> = entries.toMap()

    fun size(): Int = entries.size

    fun isEmpty(): Boolean = entries.isEmpty()
}

class DuplicateRegistrationException(
    val registryName: String,
    val key: Any,
    val existing: Any,
    val attempted: Any,
) : RuntimeException(
    "Duplicate registration in '$registryName' for key=$key: " +
        "existing=${existing::class.simpleName ?: existing::class}, " +
        "attempted=${attempted::class.simpleName ?: attempted::class}",
)

class MissingRegistrationException(
    val registryName: String,
    val key: Any,
) : RuntimeException("No registration in '$registryName' for key=$key")
