-- V017 — settings (generic KV with runtime override).
--
-- The architecture plan calls for `BaseSettingsTable` — a key-value
-- store with type tagging so a single SQL row can carry strings,
-- numbers, booleans, or JSON objects without per-type sub-tables.
-- Admin UI for runtime overrides reads/writes here; code defaults
-- live in BaseConfig and are the fallback when a key is absent.
--
-- value_type alphabet: 'string', 'int', 'long', 'bool', 'json'.
-- The service layer parses `value` according to this column.

CREATE TABLE settings (
    key                     VARCHAR(128) PRIMARY KEY,
    value                   TEXT NULL,
    value_type              VARCHAR(32) NOT NULL CHECK (value_type IN (
        'string', 'int', 'long', 'bool', 'json'
    )),
    description             TEXT NULL,
    is_runtime_override     BOOLEAN NOT NULL DEFAULT TRUE,
    updated_by              BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Filter for the admin UI: runtime-only keys (the things admin can
-- actually edit) vs read-only / code-default keys.
CREATE INDEX settings_runtime_idx ON settings (is_runtime_override);

CREATE TRIGGER settings_set_updated_at_trigger
BEFORE UPDATE ON settings
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
