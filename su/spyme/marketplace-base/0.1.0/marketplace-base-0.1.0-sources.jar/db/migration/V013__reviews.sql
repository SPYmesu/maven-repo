-- V013 — reviews + review_replies.
--
-- One review per (user, product) — repeat purchases don't generate
-- new review rows; the existing one is edited. Verified-buyer reviews
-- carry the order_id pointer (host can render a "verified purchase"
-- badge); non-buyer / staff-seeded reviews leave it null.
--
-- Moderation lifecycle: PENDING → APPROVED | REJECTED | HIDDEN.
-- HIDDEN is "approved then later removed" (admin action with audit);
-- REJECTED is "never made it past moderation".

CREATE TABLE reviews (
    id                  BIGSERIAL PRIMARY KEY,
    user_id             BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id          BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    order_id            BIGINT NULL REFERENCES orders(id) ON DELETE SET NULL,
    rating              SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    title               TEXT NULL,
    body                TEXT NOT NULL,
    locale              VARCHAR(8) NOT NULL DEFAULT 'ru',
    status              VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'APPROVED', 'REJECTED', 'HIDDEN'
    )),
    visibility          VARCHAR(16) NOT NULL DEFAULT 'PUBLIC' CHECK (visibility IN (
        'PUBLIC', 'PRIVATE'
    )),
    moderation_notes    TEXT NULL,
    helpful_count       INT NOT NULL DEFAULT 0 CHECK (helpful_count >= 0),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- One review per (user, product). Soft constraint at the SQL layer
-- because the architecture plan forbids duplicate reviews; the
-- service layer routes "second submission" to update.
CREATE UNIQUE INDEX reviews_user_product_uniq_idx ON reviews (user_id, product_id);

CREATE INDEX reviews_product_status_idx ON reviews (product_id, status);
CREATE INDEX reviews_user_idx ON reviews (user_id);
CREATE INDEX reviews_status_created_idx ON reviews (status, created_at DESC);

CREATE TRIGGER reviews_set_updated_at_trigger
BEFORE UPDATE ON reviews
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Vendor/admin reply to a review. One review can have multiple replies
-- (escalation flow: vendor responds, customer follow-ups, admin steps in).
CREATE TABLE review_replies (
    id              BIGSERIAL PRIMARY KEY,
    review_id       BIGINT NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body            TEXT NOT NULL,
    is_official     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX review_replies_review_idx ON review_replies (review_id);
CREATE INDEX review_replies_user_idx ON review_replies (user_id);

CREATE TRIGGER review_replies_set_updated_at_trigger
BEFORE UPDATE ON review_replies
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
