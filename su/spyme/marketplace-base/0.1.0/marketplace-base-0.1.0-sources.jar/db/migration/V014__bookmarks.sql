-- V014 — bookmarks ("wishlist").
--
-- Composite PK keeps the row idempotent: bookmarking twice is a
-- no-op. Pure many-to-many between users and products.

CREATE TABLE bookmarks (
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id  BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, product_id)
);

CREATE INDEX bookmarks_product_idx ON bookmarks (product_id);
