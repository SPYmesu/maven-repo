-- V010 — orders + order_items + order_item_snapshots.
--
-- Canonical order statuses per the plan (see project memory,
-- "State machines"):
--   NEW, AWAITING_PAYMENT, AWAITING_MANAGER, PAID, PROCESSING,
--   SHIPPED, DELIVERED, CANCELLED.
-- EXPIRED is intentionally absent — payment-timeout cancellations
-- become CANCELLED with cancellation_reason_code='PAYMENT_TIMEOUT'.
-- PARTIALLY_REFUNDED / REFUNDED are *display* states derived from the
-- refunds table at read time, not values stored here.
--
-- Money: BIGINT amounts + CHAR(3) currency, no FP arithmetic on the
-- money path (Money value class enforces overflow-safe add/subtract).

CREATE TABLE orders (
    id                          BIGSERIAL PRIMARY KEY,
    user_id                     BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    order_number                VARCHAR(32) NOT NULL,
    status                      VARCHAR(32) NOT NULL DEFAULT 'NEW' CHECK (status IN (
        'NEW', 'AWAITING_PAYMENT', 'AWAITING_MANAGER', 'PAID',
        'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'
    )),
    product_kind                VARCHAR(16) NOT NULL CHECK (product_kind IN ('DIGITAL', 'PHYSICAL', 'MIXED')),
    subtotal_amount             BIGINT NOT NULL DEFAULT 0 CHECK (subtotal_amount >= 0),
    shipping_amount             BIGINT NOT NULL DEFAULT 0 CHECK (shipping_amount >= 0),
    tax_amount                  BIGINT NOT NULL DEFAULT 0 CHECK (tax_amount >= 0),
    discount_amount             BIGINT NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    total_amount                BIGINT NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    currency                    CHAR(3) NOT NULL DEFAULT 'RUB',
    locale                      VARCHAR(8) NOT NULL DEFAULT 'ru',
    billing_address             JSONB NULL,
    shipping_address            JSONB NULL,
    cancellation_reason_code    VARCHAR(32) NULL,
    cancellation_reason_text    TEXT NULL,
    cancelled_at                TIMESTAMP NULL,
    cancelled_by                BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    placed_at                   TIMESTAMP NOT NULL DEFAULT NOW(),
    paid_at                     TIMESTAMP NULL,
    shipped_at                  TIMESTAMP NULL,
    delivered_at                TIMESTAMP NULL,
    created_at                  TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX orders_order_number_idx ON orders (order_number);
CREATE INDEX orders_user_status_idx ON orders (user_id, status);
CREATE INDEX orders_status_placed_at_idx ON orders (status, placed_at DESC);
CREATE INDEX orders_placed_at_idx ON orders (placed_at DESC);

CREATE TRIGGER orders_set_updated_at_trigger
BEFORE UPDATE ON orders
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Order line items.
CREATE TABLE order_items (
    id                      BIGSERIAL PRIMARY KEY,
    order_id                BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id              BIGINT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    variant_id              BIGINT NULL REFERENCES product_variants(id) ON DELETE RESTRICT,
    vendor_id               BIGINT NULL,
    quantity                INT NOT NULL CHECK (quantity > 0),
    unit_price_amount       BIGINT NOT NULL CHECK (unit_price_amount >= 0),
    unit_price_currency     CHAR(3) NOT NULL,
    line_total_amount       BIGINT NOT NULL CHECK (line_total_amount >= 0),
    delivered_at            TIMESTAMP NULL,
    -- status is NULL for the common "follows the parent order" case;
    -- only set when partial refund / mixed-kind flows force a per-line
    -- divergence (per the architecture plan).
    status                  VARCHAR(16) NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX order_items_order_idx ON order_items (order_id);
CREATE INDEX order_items_product_idx ON order_items (product_id);
CREATE INDEX order_items_vendor_idx ON order_items (vendor_id) WHERE vendor_id IS NOT NULL;

CREATE TRIGGER order_items_set_updated_at_trigger
BEFORE UPDATE ON order_items
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- В7: snapshot stored in a separate table so the operational row stays
-- lean and the JSONB blob only loads when the UI asks for the order
-- detail page. CASCADE-deletes with the order_item.
CREATE TABLE order_item_snapshots (
    order_item_id   BIGINT PRIMARY KEY REFERENCES order_items(id) ON DELETE CASCADE,
    snapshot_meta   JSONB NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
