-- V019 — seo_render_queue (М3 SEO prerender coalescing).
--
-- Producer side: when a product/category page payload changes,
-- enqueue (slug, kind). The partial unique index ensures repeated
-- updates of the same (slug, kind) collapse into one pending row,
-- so a flurry of edits on a single product produces one render job
-- rather than N. Worker picks rows oldest-first, calls the host's
-- prerender hook (writes <slug>.html into data/prerender/), and
-- stamps rendered_at.

CREATE TABLE seo_render_queue (
    id              BIGSERIAL PRIMARY KEY,
    slug            VARCHAR(96) NOT NULL,
    kind            VARCHAR(32) NOT NULL,
    enqueued_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    attempts        SMALLINT NOT NULL DEFAULT 0,
    last_error      TEXT NULL,
    rendered_at     TIMESTAMP NULL
);

-- Coalescing: at most one pending row per (slug, kind).
CREATE UNIQUE INDEX seo_render_queue_pending_uniq_idx
    ON seo_render_queue (slug, kind)
    WHERE rendered_at IS NULL;

-- Worker scan order.
CREATE INDEX seo_render_queue_pending_enqueued_idx
    ON seo_render_queue (enqueued_at)
    WHERE rendered_at IS NULL;
