-- V016 — notifications outbox.
--
-- Producer side (OrdersService, AuthService, ReviewsService, …)
-- enqueues a row in the same transaction as the entity mutation.
-- A worker drains pending rows and dispatches them via the matching
-- NotificationChannel (telegram / email / vk / in-app).
--
-- Status alphabet:
-- - PENDING — fresh, awaiting dispatch.
-- - SENT — channel reported success.
-- - FAILED — channel reported a non-retryable error; manual replay
--   from admin UI.
--
-- Dedup_key is producer-supplied: callers building digest-style or
-- "daily summary" notifications pass a stable key (e.g.
-- "daily-digest:user42:2026-05-10") so retries don't double-deliver.

CREATE TABLE notifications (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind            VARCHAR(64) NOT NULL,
    channel         VARCHAR(32) NOT NULL,
    recipient       VARCHAR(255) NOT NULL,
    subject         TEXT NULL,
    body            TEXT NOT NULL,
    payload         JSONB NULL,
    locale          VARCHAR(8) NOT NULL DEFAULT 'ru',
    status          VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'SENT', 'FAILED'
    )),
    attempts        SMALLINT NOT NULL DEFAULT 0,
    last_error      TEXT NULL,
    dedup_key       VARCHAR(128) NULL,
    enqueued_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    sent_at         TIMESTAMP NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Idempotency: at most one row per dedup_key. NULL keys are skipped
-- (the partial index ignores them — producers without a dedup
-- contract enqueue freely).
CREATE UNIQUE INDEX notifications_dedup_idx
    ON notifications (dedup_key)
    WHERE dedup_key IS NOT NULL;

CREATE INDEX notifications_pending_idx
    ON notifications (enqueued_at)
    WHERE status = 'PENDING';

CREATE INDEX notifications_user_idx ON notifications (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX notifications_kind_idx ON notifications (kind);

-- pg_notify hook so workers wake up immediately. Mirrors the
-- search_index_queue pattern from V008.
CREATE OR REPLACE FUNCTION notifications_notify()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM pg_notify('notifications_queue', NEW.id::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notifications_insert_notify_trigger
AFTER INSERT ON notifications
FOR EACH ROW
WHEN (NEW.status = 'PENDING')
EXECUTE FUNCTION notifications_notify();

CREATE TRIGGER notifications_set_updated_at_trigger
BEFORE UPDATE ON notifications
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
