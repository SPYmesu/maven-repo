-- V005 — EAV attribute definitions, per-category bindings, translations.
--
-- Soft-typing: data_type is VARCHAR + CHECK constraint, not a SQL ENUM.
-- New types ship by an admin migration that just edits the CHECK list,
-- so we don't fight ALTER TYPE limitations.
--
-- archived_at = soft-delete: archived definitions stay referenced by
-- legacy product_attribute_values rows but are hidden from new product
-- editors and admin lists by default.

CREATE TABLE attribute_definitions (
    id                  BIGSERIAL PRIMARY KEY,
    code                VARCHAR(64) NOT NULL UNIQUE,
    data_type           VARCHAR(32) NOT NULL CHECK (data_type IN (
        'STRING', 'TEXT', 'INT', 'DECIMAL', 'BOOL', 'DATE', 'DATETIME',
        'ENUM', 'ENUM_MULTI', 'FILE_REF', 'URL'
    )),
    label_i18n_key      VARCHAR(128) NULL,
    is_global           BOOLEAN NOT NULL DEFAULT FALSE,
    is_variant          BOOLEAN NOT NULL DEFAULT FALSE,
    is_facet            BOOLEAN NOT NULL DEFAULT FALSE,
    is_searchable       BOOLEAN NOT NULL DEFAULT FALSE,
    is_protected        BOOLEAN NOT NULL DEFAULT FALSE,
    is_required_default BOOLEAN NOT NULL DEFAULT FALSE,
    is_public           BOOLEAN NOT NULL DEFAULT TRUE,
    enum_values         JSONB NULL,
    validation          JSONB NULL,
    unit                VARCHAR(32) NULL,
    sort_order          INT NOT NULL DEFAULT 0,
    archived_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX attribute_definitions_active_idx
    ON attribute_definitions (sort_order)
    WHERE archived_at IS NULL;

CREATE INDEX attribute_definitions_global_idx
    ON attribute_definitions (is_global)
    WHERE is_global AND archived_at IS NULL;

CREATE TRIGGER attribute_definitions_set_updated_at_trigger
BEFORE UPDATE ON attribute_definitions
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Many-to-many: which attributes apply to which categories.
-- is_required NULL means "use definition default".
CREATE TABLE category_attributes (
    category_id     BIGINT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    attribute_id    BIGINT NOT NULL REFERENCES attribute_definitions(id) ON DELETE CASCADE,
    sort_order      INT NOT NULL DEFAULT 0,
    is_required     BOOLEAN NULL,
    PRIMARY KEY (category_id, attribute_id)
);

CREATE INDEX category_attributes_attribute_idx ON category_attributes (attribute_id);
CREATE INDEX category_attributes_category_sort_idx ON category_attributes (category_id, sort_order);

-- Per-locale label override for attribute display name.
CREATE TABLE attribute_label_translations (
    attribute_id            BIGINT NOT NULL REFERENCES attribute_definitions(id) ON DELETE CASCADE,
    locale                  VARCHAR(8) NOT NULL,
    label                   TEXT NOT NULL,
    hint                    TEXT NULL,
    is_machine_translated   BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (attribute_id, locale)
);

-- Per-locale label override for ENUM/ENUM_MULTI value codes.
CREATE TABLE attribute_enum_value_translations (
    attribute_id            BIGINT NOT NULL REFERENCES attribute_definitions(id) ON DELETE CASCADE,
    value                   VARCHAR(64) NOT NULL,
    locale                  VARCHAR(8) NOT NULL,
    label                   TEXT NOT NULL,
    is_machine_translated   BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (attribute_id, value, locale)
);
