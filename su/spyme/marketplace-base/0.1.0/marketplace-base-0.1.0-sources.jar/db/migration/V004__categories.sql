-- V004 — categories + category_translations.
--
-- Self-referencing tree via parent_id. Slugs are unique per parent
-- (top-level slugs scoped to "no parent"); duplicates within different
-- parents are fine. category_translations holds per-locale title and
-- description; the canonical (untranslated) title lives there too as
-- a row with the marketplace's default locale — host decides how it
-- renders fallbacks.

CREATE TABLE categories (
    id              BIGSERIAL PRIMARY KEY,
    parent_id       BIGINT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    slug            VARCHAR(96) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- COALESCE so top-level (parent_id IS NULL) categories share a single
-- "virtual root" slug namespace.
CREATE UNIQUE INDEX categories_parent_slug_idx
    ON categories (COALESCE(parent_id, 0), slug);

CREATE INDEX categories_parent_id_idx ON categories (parent_id);
CREATE INDEX categories_active_sort_idx ON categories (is_active, sort_order);

CREATE TRIGGER categories_set_updated_at_trigger
BEFORE UPDATE ON categories
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

CREATE TABLE category_translations (
    category_id             BIGINT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    locale                  VARCHAR(8) NOT NULL,
    title                   TEXT NOT NULL,
    description             TEXT NULL,
    is_machine_translated   BOOLEAN NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (category_id, locale)
);

CREATE INDEX category_translations_locale_idx ON category_translations (locale);

CREATE TRIGGER category_translations_set_updated_at_trigger
BEFORE UPDATE ON category_translations
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
