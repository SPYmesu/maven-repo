-- V028 — social_links + oauth_tokens.
--
-- social_links: which external identity (Telegram, VK, Google, ...)
-- maps to a marketplace user. Many-to-one — one user can have a
-- Telegram link AND a Google link; each provider is unique per user.
--
-- oauth_tokens: short-lived access tokens / refresh tokens for
-- providers that need ongoing API access (Google Calendar / Discord
-- profile sync etc.). access_token + refresh_token are AES-256-GCM
-- encrypted; secret_key_version names the master key that wraps them.
-- Telegram / VK / "login only" providers don't need this table.

CREATE TABLE social_links (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider        VARCHAR(32) NOT NULL,
    external_id     VARCHAR(255) NOT NULL,
    display_name    VARCHAR(255) NULL,
    metadata        JSONB NULL,
    linked_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- One link per (provider, external_id) globally — a Telegram account
-- can't be attached to two marketplace users.
CREATE UNIQUE INDEX social_links_provider_external_idx
    ON social_links (provider, external_id);

-- One link per (user, provider) — a user can have at most one
-- Telegram identity, one VK identity, etc.
CREATE UNIQUE INDEX social_links_user_provider_idx
    ON social_links (user_id, provider);

CREATE TRIGGER social_links_set_updated_at_trigger
BEFORE UPDATE ON social_links
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

CREATE TABLE oauth_tokens (
    id                      BIGSERIAL PRIMARY KEY,
    user_id                 BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider                VARCHAR(32) NOT NULL,
    access_token            BYTEA NOT NULL,
    refresh_token           BYTEA NULL,
    secret_key_version      SMALLINT NOT NULL,
    scope                   VARCHAR(512) NULL,
    token_type              VARCHAR(32) NOT NULL DEFAULT 'Bearer',
    expires_at              TIMESTAMP NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX oauth_tokens_user_provider_idx ON oauth_tokens (user_id, provider);
CREATE INDEX oauth_tokens_expires_at_idx ON oauth_tokens (expires_at)
    WHERE expires_at IS NOT NULL;

CREATE TRIGGER oauth_tokens_set_updated_at_trigger
BEFORE UPDATE ON oauth_tokens
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
