-- V024 — otp_codes (unified one-time-codes table per the architecture plan).
--
-- One row per generated OTP, regardless of channel (email / sms / tg-bot
-- / vk-bot / totp / email-2fa / sms-2fa) and purpose (login / register /
-- verify-email / verify-phone / reset-password / link-social / 2fa-step
-- / gdpr-delete).
--
-- Status lifecycle: PENDING → REDEEMED | EXPIRED.
-- attempts counter caps brute-force; service layer rejects after N tries.
-- payload is purpose-specific extra (e.g. pending email change target).
--
-- code is the primary key — generated via SecureRandom and uniquely
-- identifies the OTP. Code length and alphabet are channel-specific
-- (6-digit numeric for SMS, 8-char base32 for TOTP recovery, 64-char
-- base62 for email magic links); the SQL layer just enforces that
-- whatever lands here is unique.

CREATE TABLE otp_codes (
    code            VARCHAR(128) PRIMARY KEY,
    user_id         BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    channel         VARCHAR(32) NOT NULL CHECK (channel IN (
        'email', 'sms', 'tg-bot', 'vk-bot', 'totp', 'email-2fa', 'sms-2fa'
    )),
    purpose         VARCHAR(32) NOT NULL CHECK (purpose IN (
        'login', 'register', 'verify-email', 'verify-phone', 'reset-password',
        'link-social', '2fa-step', 'gdpr-delete'
    )),
    recipient       VARCHAR(255) NOT NULL,
    payload         JSONB NULL,
    status          VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'REDEEMED', 'EXPIRED'
    )),
    attempts        SMALLINT NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    expires_at      TIMESTAMP NOT NULL,
    redeemed_at     TIMESTAMP NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- "Active OTPs for this user" — admin / debug.
CREATE INDEX otp_codes_user_idx ON otp_codes (user_id) WHERE user_id IS NOT NULL;

-- Cron sweep finds expired pending rows.
CREATE INDEX otp_codes_expires_at_idx ON otp_codes (expires_at)
    WHERE status = 'PENDING';

-- Resend / dedup lookup: "is there a pending OTP for this recipient + purpose?"
CREATE INDEX otp_codes_recipient_purpose_idx
    ON otp_codes (recipient, purpose)
    WHERE status = 'PENDING';

CREATE TRIGGER otp_codes_set_updated_at_trigger
BEFORE UPDATE ON otp_codes
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
