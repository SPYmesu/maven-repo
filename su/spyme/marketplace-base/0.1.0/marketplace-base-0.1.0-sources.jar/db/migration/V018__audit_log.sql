-- V018 — audit_log with security undo (per Б6 + В5).
--
-- Records every mutating admin/user action with enough context to
-- replay or undo. Snapshots are JSONB blobs of the row before/after
-- the change; the undo flow reads `entity_snapshot_before` to
-- restore. Each undo is itself an audit row with parent_audit_id
-- pointing at the original — undo chains are walkable in either
-- direction.
--
-- Non-reversible actions (payment.captured, notification.sent,
-- webhook.delivered, gdpr_deletion.completed, legal_archive.created)
-- carry is_reversible=false so AuditService.undo refuses them.

CREATE TABLE audit_log (
    id                          BIGSERIAL PRIMARY KEY,
    actor_user_id               BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    actor_role                  VARCHAR(32) NULL,
    actor_ip                    INET NULL,
    actor_user_agent            TEXT NULL,
    action                      VARCHAR(64) NOT NULL,
    entity_type                 VARCHAR(32) NOT NULL,
    entity_id                   BIGINT NULL,
    entity_snapshot_before      JSONB NULL,
    entity_snapshot_after       JSONB NULL,
    is_reversible               BOOLEAN NOT NULL DEFAULT TRUE,
    parent_audit_id             BIGINT NULL REFERENCES audit_log(id) ON DELETE SET NULL,
    reverted_at                 TIMESTAMP NULL,
    reverted_by_user_id         BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    reverted_audit_id           BIGINT NULL REFERENCES audit_log(id) ON DELETE SET NULL,
    created_at                  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Hot read paths
CREATE INDEX audit_log_actor_idx ON audit_log (actor_user_id) WHERE actor_user_id IS NOT NULL;
CREATE INDEX audit_log_entity_idx ON audit_log (entity_type, entity_id);
CREATE INDEX audit_log_action_idx ON audit_log (action, created_at DESC);
CREATE INDEX audit_log_created_at_idx ON audit_log (created_at DESC);

-- The "what's still undoable" query (admin UI undo list).
CREATE INDEX audit_log_pending_undo_idx ON audit_log (created_at DESC)
    WHERE reverted_at IS NULL AND is_reversible;

-- Bulk-undo lookup: "all reversible actions by user X since timestamp Y".
CREATE INDEX audit_log_actor_created_idx ON audit_log (actor_user_id, created_at DESC)
    WHERE reverted_at IS NULL AND is_reversible;
