-- V021 — api_keys (per V4 / Б7).
--
-- Format: mp_<env>_<scope>_<entropy24>_<checksum8> Stripe-style.
-- - env: 'live' | 'test'
-- - scope: 'user' | 'vendor' | 'admin' — drives the scope_* FK columns
-- - entropy24: 24 chars base62 (~144 bits)
-- - checksum8: HMAC(format_secret, env_scope_entropy)[:8] in base62
--
-- The plaintext key never lands in the DB. We store:
-- - key_hash: SHA-256 hex of the supplied entropy + per-key salt.
-- - key_salt: 16-byte random per key.
-- - key_prefix: visible portion shown in admin UI (mp_live_user_aBcD12***IjKl).
--
-- Validation order on a request:
--   1. Parse the format; reject malformed strings without DB hit.
--   2. Recompute checksum; reject if it doesn't match.
--   3. Hit api_keys by SHA-256(salt || entropy).
--   4. Check revoked_at, expires_at, scope.
-- The format secret stops third parties from generating valid-
-- looking keys without it.

CREATE TABLE api_keys (
    id                      UUID PRIMARY KEY,
    name                    VARCHAR(128) NOT NULL,
    key_hash                VARCHAR(64) NOT NULL,
    key_salt                BYTEA NOT NULL,
    key_prefix              VARCHAR(64) NOT NULL,
    env                     VARCHAR(8) NOT NULL CHECK (env IN ('live', 'test')),
    scope_type              VARCHAR(16) NOT NULL CHECK (scope_type IN ('user', 'vendor', 'admin')),
    scope_user_id           BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    scope_vendor_id         BIGINT NULL,
    rate_limit_per_minute   INT NULL CHECK (rate_limit_per_minute IS NULL OR rate_limit_per_minute > 0),
    is_unlimited            BOOLEAN NOT NULL DEFAULT FALSE,
    last_used_at            TIMESTAMP NULL,
    expires_at              TIMESTAMP NULL,
    revoked_at              TIMESTAMP NULL,
    revoked_by_user_id      BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    created_by_user_id      BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    metadata                JSONB NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT api_keys_scope_consistency CHECK (
        (scope_type = 'user'   AND scope_user_id IS NOT NULL AND scope_vendor_id IS NULL) OR
        (scope_type = 'vendor' AND scope_user_id IS NULL     AND scope_vendor_id IS NOT NULL) OR
        (scope_type = 'admin'  AND scope_user_id IS NULL     AND scope_vendor_id IS NULL)
    )
);

-- key_hash is the verify-time hot path; uniqueness is enforced.
CREATE UNIQUE INDEX api_keys_hash_idx ON api_keys (key_hash);

-- "Show this user's keys" / "Show this vendor's keys".
CREATE INDEX api_keys_scope_user_idx ON api_keys (scope_user_id) WHERE scope_user_id IS NOT NULL;
CREATE INDEX api_keys_scope_vendor_idx ON api_keys (scope_vendor_id) WHERE scope_vendor_id IS NOT NULL;

-- Active keys (not revoked, not expired) — admin index UI.
CREATE INDEX api_keys_active_idx ON api_keys (created_at DESC)
    WHERE revoked_at IS NULL;

CREATE TRIGGER api_keys_set_updated_at_trigger
BEFORE UPDATE ON api_keys
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
