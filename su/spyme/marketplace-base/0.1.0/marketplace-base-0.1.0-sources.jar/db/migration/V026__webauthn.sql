-- V026 — webauthn_credentials + webauthn_challenges (per В3).
--
-- One row per registered passkey. sign_count tracks the credential's
-- signature counter for clone detection; non-monotonic counts that
-- aren't both zero block the credential (per В3 policy).
--
-- secret_key_version supports key rotation per В2: encryption key
-- changes bump activeKeyVersion in BaseConfig; a background job
-- re-encrypts old rows.

CREATE TABLE webauthn_credentials (
    id                  BIGSERIAL PRIMARY KEY,
    user_id             BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    credential_id       BYTEA NOT NULL,
    public_key          BYTEA NOT NULL,
    sign_count          BIGINT NOT NULL DEFAULT 0,
    transports          VARCHAR(32)[] NOT NULL DEFAULT ARRAY[]::VARCHAR(32)[],
    is_passkey          BOOLEAN NOT NULL DEFAULT TRUE,
    name                VARCHAR(64) NOT NULL,
    last_used_at        TIMESTAMP NULL,
    blocked_at          TIMESTAMP NULL,
    blocked_reason      VARCHAR(64) NULL,
    secret_key_version  SMALLINT NOT NULL DEFAULT 1,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Authenticate-time hot path: locate by credentialId.
CREATE UNIQUE INDEX webauthn_credentials_credential_id_idx ON webauthn_credentials (credential_id);

-- "My passkeys" UI.
CREATE INDEX webauthn_credentials_user_idx ON webauthn_credentials (user_id);

CREATE TRIGGER webauthn_credentials_set_updated_at_trigger
BEFORE UPDATE ON webauthn_credentials
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Short-lived challenges generated during register / authenticate
-- ceremonies. Cleaned up by an hourly cron once expires_at passes.
CREATE TABLE webauthn_challenges (
    challenge       BYTEA PRIMARY KEY,
    user_id         BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    purpose         VARCHAR(16) NOT NULL CHECK (purpose IN ('register', 'authenticate')),
    request_meta    JSONB NULL,
    consumed_at     TIMESTAMP NULL,
    expires_at      TIMESTAMP NOT NULL DEFAULT (NOW() + INTERVAL '5 minutes'),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX webauthn_challenges_expires_at_idx ON webauthn_challenges (expires_at);
CREATE INDEX webauthn_challenges_user_idx ON webauthn_challenges (user_id) WHERE user_id IS NOT NULL;
