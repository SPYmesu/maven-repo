-- V022 — webhook_subscriptions (per Б5 / В9).
--
-- One row per subscriber endpoint. event_types is a Postgres array
-- of event-name strings the WebhookEventRegistry validates against
-- at the service layer; '*' means "deliver every event".
--
-- secret_current + secret_previous + secret_rotated_at implement the
-- 7-day grace rotation from Б5: when an admin rotates the secret,
-- the previous one stays valid for 7 days so subscribers have time
-- to migrate. The signature header lists both during the grace window.
--
-- max_concurrent_deliveries / max_per_minute back per-subscriber
-- rate-limiting from В9 (default 5 / 600).
--
-- coalescing_window_seconds enables opt-in bulk delivery: when > 0,
-- multiple events that arrive inside the window pack into one
-- bulk_<entity>_<action> payload (per В9). 0 disables coalescing.
--
-- filters carries the per-subscription filter JSONB ({ "product_id":
-- 42, "vendor_id": 7 }) — the producer applies it before queueing
-- the delivery.

CREATE TABLE webhook_subscriptions (
    id                          UUID PRIMARY KEY,
    name                        VARCHAR(128) NOT NULL,
    target_url                  VARCHAR(2048) NOT NULL,
    event_types                 VARCHAR(128)[] NOT NULL DEFAULT ARRAY[]::VARCHAR(128)[],
    secret_current              VARCHAR(128) NOT NULL,
    secret_previous             VARCHAR(128) NULL,
    secret_rotated_at           TIMESTAMP NULL,
    max_concurrent_deliveries   SMALLINT NOT NULL DEFAULT 5
        CHECK (max_concurrent_deliveries > 0 AND max_concurrent_deliveries <= 100),
    max_per_minute              INT NOT NULL DEFAULT 600 CHECK (max_per_minute > 0),
    coalescing_window_seconds   INT NOT NULL DEFAULT 0 CHECK (coalescing_window_seconds >= 0),
    filters                     JSONB NULL,
    owner_user_id               BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at                  TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX webhook_subscriptions_owner_idx ON webhook_subscriptions (owner_user_id)
    WHERE owner_user_id IS NOT NULL;
CREATE INDEX webhook_subscriptions_active_idx ON webhook_subscriptions (is_active);
-- GIN over event_types lets producers find "subscribers for this event"
-- with `WHERE event_types && ARRAY['order.paid']` cheaply.
CREATE INDEX webhook_subscriptions_events_gin_idx ON webhook_subscriptions USING gin (event_types);

CREATE TRIGGER webhook_subscriptions_set_updated_at_trigger
BEFORE UPDATE ON webhook_subscriptions
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
