-- V027 — totp_secrets + recovery_codes (per В2).
--
-- TOTP secret is AES-256-GCM encrypted at rest. The 12-byte nonce +
-- ciphertext + 16-byte tag are concatenated into the secret BYTEA;
-- secret_key_version names which env-supplied master key encrypted it
-- (MARKETPLACE_TOTP_KEY_V<N>). Background rotation job re-encrypts old
-- rows when activeKeyVersion bumps.
--
-- confirmed_at is null until the user verifies the first 6-digit code
-- — tampering with this column lets a half-set-up TOTP get accepted.

CREATE TABLE totp_secrets (
    user_id             BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    secret              BYTEA NOT NULL,
    secret_key_version  SMALLINT NOT NULL,
    digits              SMALLINT NOT NULL DEFAULT 6 CHECK (digits IN (6, 8)),
    period_seconds      SMALLINT NOT NULL DEFAULT 30 CHECK (period_seconds IN (30, 60)),
    algo                VARCHAR(16) NOT NULL DEFAULT 'HmacSHA1' CHECK (algo IN ('HmacSHA1', 'HmacSHA256')),
    confirmed_at        TIMESTAMP NULL,
    last_used_step      BIGINT NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TRIGGER totp_secrets_set_updated_at_trigger
BEFORE UPDATE ON totp_secrets
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- One-time recovery codes for users who lose their TOTP device.
-- Stored as SHA-256(salt || code); plaintext shown to the user once
-- at issue. Each code is single-use; consumed_at flips on redeem.
CREATE TABLE totp_recovery_codes (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code_hash       VARCHAR(64) NOT NULL,
    code_salt       BYTEA NOT NULL,
    consumed_at     TIMESTAMP NULL,
    consumed_ip     INET NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX totp_recovery_codes_user_idx ON totp_recovery_codes (user_id);
-- "Active codes for this user" — drives the "remaining recovery codes" UI.
CREATE INDEX totp_recovery_codes_user_active_idx
    ON totp_recovery_codes (user_id)
    WHERE consumed_at IS NULL;
