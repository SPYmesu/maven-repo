-- V025 — password_credentials (`auth-password` module storage).
--
-- One row per user that has a password set; users authenticated only
-- via OTP / passkey / social have no row here.
--
-- algo: 'bcrypt' is the only supported value at launch (the Spring
-- Security style identifier). Future migrations could add 'argon2id'
-- or 'scrypt' without rewriting consumers — the password hash already
-- carries the cost factor.

CREATE TABLE password_credentials (
    user_id         BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    password_hash   VARCHAR(255) NOT NULL,
    algo            VARCHAR(16) NOT NULL DEFAULT 'bcrypt' CHECK (algo IN ('bcrypt')),
    last_changed_at TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TRIGGER password_credentials_set_updated_at_trigger
BEFORE UPDATE ON password_credentials
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
