-- V020 — uploads + image_processing_queue.
--
-- Per М1: StorageProvider abstracts the actual storage backend
-- (local filesystem, S3, etc.); this table is the metadata index
-- the rest of the codebase joins against. content_type +
-- size_bytes are filled from the upload request; storage_key is
-- the provider-specific lookup string.
--
-- Per М2: thumbnails are generated async by a worker reading from
-- image_processing_queue. The original is saved synchronously; the
-- worker writes sm/md/lg/xl variants alongside it.
--
-- Retention 5 years per the architecture plan: uploads are never
-- hard-deleted by application code, only flipped to ARCHIVED. A
-- separate retention cron eventually purges archived rows older
-- than the cap (host-specific, lands with the GDPR module).

CREATE TABLE uploads (
    id                          BIGSERIAL PRIMARY KEY,
    bucket                      VARCHAR(64) NOT NULL,
    storage_key                 VARCHAR(512) NOT NULL,
    original_filename           VARCHAR(255) NULL,
    content_type                VARCHAR(128) NOT NULL,
    size_bytes                  BIGINT NOT NULL CHECK (size_bytes >= 0),
    uploaded_by_user_id         BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    entity_type                 VARCHAR(32) NULL,
    entity_id                   BIGINT NULL,
    metadata                    JSONB NULL,
    status                      VARCHAR(16) NOT NULL DEFAULT 'UPLOADED' CHECK (status IN (
        'UPLOADED', 'PROCESSING', 'READY', 'ARCHIVED'
    )),
    archived_at                 TIMESTAMP NULL,
    created_at                  TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Lookup hot path: same storage_key never duplicated within a bucket.
CREATE UNIQUE INDEX uploads_bucket_key_idx ON uploads (bucket, storage_key);

-- Reverse-attach lookup: "all uploads for this product".
CREATE INDEX uploads_entity_idx ON uploads (entity_type, entity_id)
    WHERE entity_type IS NOT NULL AND entity_id IS NOT NULL;

-- "My uploads" UI.
CREATE INDEX uploads_uploaded_by_idx ON uploads (uploaded_by_user_id)
    WHERE uploaded_by_user_id IS NOT NULL;

CREATE INDEX uploads_status_idx ON uploads (status);

CREATE TRIGGER uploads_set_updated_at_trigger
BEFORE UPDATE ON uploads
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Async thumbnail generation queue (per М2).
-- The variant alphabet matches the architecture plan: sm 320, md
-- 768, lg 1280, xl 1920. WebP-conversion is the default; legacy
-- jpeg variants are an optional extra.
CREATE TABLE image_processing_queue (
    id              BIGSERIAL PRIMARY KEY,
    upload_id       BIGINT NOT NULL REFERENCES uploads(id) ON DELETE CASCADE,
    target_size     VARCHAR(8) NOT NULL CHECK (target_size IN ('sm', 'md', 'lg', 'xl')),
    target_format   VARCHAR(8) NOT NULL DEFAULT 'webp' CHECK (target_format IN ('webp', 'jpeg', 'png')),
    status          VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'PROCESSING', 'DONE', 'FAILED'
    )),
    attempts        SMALLINT NOT NULL DEFAULT 0,
    last_error      TEXT NULL,
    enqueued_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    processed_at    TIMESTAMP NULL
);

-- One pending job per (upload, size, format) — repeat enqueues are
-- absorbed.
CREATE UNIQUE INDEX image_processing_queue_pending_uniq_idx
    ON image_processing_queue (upload_id, target_size, target_format)
    WHERE processed_at IS NULL;

CREATE INDEX image_processing_queue_pending_enqueued_idx
    ON image_processing_queue (enqueued_at)
    WHERE status = 'PENDING';

CREATE INDEX image_processing_queue_upload_idx ON image_processing_queue (upload_id);
