-- V007 — product_attribute_values + product_variants.
--
-- The EAV value side: actual product attribute payloads, plus the
-- variant rows + their per-variant attribute values.

-- One row per (product, attribute, locale). value is JSONB — service
-- layer decodes it according to attribute_definitions.data_type.
-- locale is NULL for non-translatable attributes; translatable
-- attributes (short STRING / TEXT) keep one row per language.
CREATE TABLE product_attribute_values (
    product_id      BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    attribute_id    BIGINT NOT NULL REFERENCES attribute_definitions(id) ON DELETE RESTRICT,
    locale          VARCHAR(8) NULL,
    value           JSONB NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Standard SQL treats two rows with NULL locale as distinct, so a
-- plain UNIQUE constraint won't enforce one row per (product,
-- attribute) for non-translatable attributes. Expression index over
-- COALESCE works around it.
CREATE UNIQUE INDEX product_attribute_values_uniq_idx
    ON product_attribute_values (product_id, attribute_id, COALESCE(locale, ''));

CREATE INDEX product_attribute_values_product_idx ON product_attribute_values (product_id);
CREATE INDEX product_attribute_values_attribute_idx ON product_attribute_values (attribute_id);

CREATE TRIGGER product_attribute_values_set_updated_at_trigger
BEFORE UPDATE ON product_attribute_values
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Variants: one row per concrete buyable SKU. Optional price override
-- so colourways/sizes can carry their own price without duplicating
-- the parent row.
CREATE TABLE product_variants (
    id              BIGSERIAL PRIMARY KEY,
    product_id      BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    sku             VARCHAR(64) NULL,
    price_amount    BIGINT NULL CHECK (price_amount IS NULL OR price_amount >= 0),
    price_currency  CHAR(3) NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX product_variants_product_idx ON product_variants (product_id);

-- SKUs are globally unique when supplied; null SKUs are allowed
-- (e.g. moonstudio's "no SKU" digital variants).
CREATE UNIQUE INDEX product_variants_sku_idx
    ON product_variants (sku)
    WHERE sku IS NOT NULL;

CREATE TRIGGER product_variants_set_updated_at_trigger
BEFORE UPDATE ON product_variants
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Variant axis values: only attributes flagged is_variant=true should
-- end up here, but the constraint is enforced at the service layer
-- (attribute_definitions.is_variant) — pure SQL would need a trigger.
CREATE TABLE product_variant_attribute_values (
    variant_id      BIGINT NOT NULL REFERENCES product_variants(id) ON DELETE CASCADE,
    attribute_id    BIGINT NOT NULL REFERENCES attribute_definitions(id) ON DELETE RESTRICT,
    value           JSONB NOT NULL,
    PRIMARY KEY (variant_id, attribute_id)
);

CREATE INDEX product_variant_attribute_values_attribute_idx
    ON product_variant_attribute_values (attribute_id);
