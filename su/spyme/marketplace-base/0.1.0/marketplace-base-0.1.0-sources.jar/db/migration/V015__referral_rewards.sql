-- V015 — referral_rewards.
--
-- Per the architecture plan: no business defaults baked into core
-- (the host decides how many points / what % of order). This table
-- is the ledger; the host's referral module wires up triggers (a new
-- signup with referrer_id, a first purchase, etc.) and calls
-- ReferralsService.create.
--
-- Status lifecycle: PENDING → AWARDED → EXPIRED?
-- - AWARDED: host has actually credited the reward (added store
--   credit / pushed money / dropped points).
-- - EXPIRED: time-bound rewards (e.g. "spend within 30 days") that
--   the user didn't claim.

CREATE TABLE referral_rewards (
    id                  BIGSERIAL PRIMARY KEY,
    referrer_user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    order_id            BIGINT NULL REFERENCES orders(id) ON DELETE SET NULL,
    amount              BIGINT NOT NULL CHECK (amount >= 0),
    currency            CHAR(3) NOT NULL,
    reward_type         VARCHAR(32) NOT NULL,
    status              VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'AWARDED', 'EXPIRED'
    )),
    awarded_at          TIMESTAMP NULL,
    expires_at          TIMESTAMP NULL,
    metadata            JSONB NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    -- Self-referral is nonsensical and a common abuse vector.
    CONSTRAINT referral_rewards_no_self_referral
        CHECK (referrer_user_id <> referred_user_id)
);

CREATE INDEX referral_rewards_referrer_idx ON referral_rewards (referrer_user_id);
CREATE INDEX referral_rewards_referred_idx ON referral_rewards (referred_user_id);
CREATE INDEX referral_rewards_order_idx ON referral_rewards (order_id) WHERE order_id IS NOT NULL;
CREATE INDEX referral_rewards_status_idx ON referral_rewards (status);
CREATE INDEX referral_rewards_expires_at_idx ON referral_rewards (expires_at)
    WHERE expires_at IS NOT NULL AND status = 'PENDING';

CREATE TRIGGER referral_rewards_set_updated_at_trigger
BEFORE UPDATE ON referral_rewards
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
