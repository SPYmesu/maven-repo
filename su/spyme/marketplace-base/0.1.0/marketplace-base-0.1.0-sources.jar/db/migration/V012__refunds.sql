-- V012 — refunds + refund_items.
--
-- Refund-as-separate-entity per the architecture plan: order-level
-- PARTIALLY_REFUNDED / REFUNDED are *display* states derived from
-- summing matching refund rows, never stored on orders.
--
-- Two refund types:
-- - 'refund' — money back, no goods exchange. DIGITAL goods, dropped
--   physical orders before shipping, etc.
-- - 'return' — physical goods come back to the seller. Adds the
--   GOODS_RECEIVED step to the lifecycle.
--
-- Status lifecycle:
--   REQUESTED → APPROVED → (GOODS_RECEIVED for return) → COMPLETED
--                       ↘ REJECTED
-- After COMPLETED the matching payment row may flip to REFUNDED if
-- the refund covers the full payment amount.

CREATE TABLE refunds (
    id                      BIGSERIAL PRIMARY KEY,
    order_id                BIGINT NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    payment_id              BIGINT NULL REFERENCES payments(id) ON DELETE RESTRICT,
    type                    VARCHAR(16) NOT NULL CHECK (type IN ('refund', 'return')),
    status                  VARCHAR(32) NOT NULL DEFAULT 'REQUESTED' CHECK (status IN (
        'REQUESTED', 'APPROVED', 'GOODS_RECEIVED', 'COMPLETED', 'REJECTED'
    )),
    amount                  BIGINT NOT NULL CHECK (amount >= 0),
    currency                CHAR(3) NOT NULL,
    reason_code             VARCHAR(32) NOT NULL,
    reason_text             TEXT NULL,
    requested_by            BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    approved_by             BIGINT NULL REFERENCES users(id) ON DELETE SET NULL,
    refund_provider_id      VARCHAR(128) NULL,
    gateway_metadata        JSONB NULL,
    requested_at            TIMESTAMP NOT NULL DEFAULT NOW(),
    approved_at             TIMESTAMP NULL,
    goods_received_at       TIMESTAMP NULL,
    completed_at            TIMESTAMP NULL,
    rejected_at             TIMESTAMP NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX refunds_order_idx ON refunds (order_id);
CREATE INDEX refunds_payment_idx ON refunds (payment_id) WHERE payment_id IS NOT NULL;
CREATE INDEX refunds_status_idx ON refunds (status);
CREATE INDEX refunds_requested_at_idx ON refunds (requested_at DESC);

CREATE TRIGGER refunds_set_updated_at_trigger
BEFORE UPDATE ON refunds
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Per-line refund detail. A refund without items refunds the whole
-- order; a refund with items refunds those lines (partial refund).
CREATE TABLE refund_items (
    refund_id           BIGINT NOT NULL REFERENCES refunds(id) ON DELETE CASCADE,
    order_item_id       BIGINT NOT NULL REFERENCES order_items(id) ON DELETE RESTRICT,
    quantity            INT NOT NULL CHECK (quantity > 0),
    amount              BIGINT NOT NULL CHECK (amount >= 0),
    PRIMARY KEY (refund_id, order_item_id)
);

CREATE INDEX refund_items_order_item_idx ON refund_items (order_item_id);
