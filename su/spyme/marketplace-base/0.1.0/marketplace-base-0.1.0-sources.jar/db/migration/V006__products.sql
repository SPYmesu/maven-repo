-- V006 — products + product_translations.
--
-- Singleton products table per Б1. Host extensions live in side-tables
-- (product_minecraft_meta, product_auto_specs, …), never on this row.
-- vendor_id is just a column for now — multi-vendor (V150) wires the
-- FK + RLS later.

CREATE TABLE products (
    id                      BIGSERIAL PRIMARY KEY,
    vendor_id               BIGINT NULL,
    category_id             BIGINT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    slug                    VARCHAR(96) NOT NULL,
    product_kind            VARCHAR(16) NOT NULL CHECK (product_kind IN ('DIGITAL', 'PHYSICAL')),
    status                  VARCHAR(16) NOT NULL DEFAULT 'DRAFT' CHECK (status IN (
        'DRAFT', 'PUBLISHED', 'ARCHIVED'
    )),
    price_amount            BIGINT NOT NULL DEFAULT 0 CHECK (price_amount >= 0),
    price_currency          CHAR(3) NOT NULL DEFAULT 'RUB',
    max_total_purchases     INT NULL CHECK (max_total_purchases IS NULL OR max_total_purchases > 0),
    max_per_user_purchases  INT NULL CHECK (max_per_user_purchases IS NULL OR max_per_user_purchases > 0),
    total_purchase_count    INT NOT NULL DEFAULT 0 CHECK (total_purchase_count >= 0),
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    published_at            TIMESTAMP NULL,
    archived_at             TIMESTAMP NULL
);

-- Slug uniqueness only among non-archived rows so an archived item
-- frees its slug for re-use.
CREATE UNIQUE INDEX products_slug_active_idx
    ON products (slug)
    WHERE archived_at IS NULL;

-- Catalog browsing: filter by category + status.
CREATE INDEX products_category_status_idx
    ON products (category_id, status)
    WHERE archived_at IS NULL;

-- Vendor dashboard: list this seller's products.
CREATE INDEX products_vendor_idx
    ON products (vendor_id)
    WHERE archived_at IS NULL AND vendor_id IS NOT NULL;

-- "Recently published" feed.
CREATE INDEX products_status_published_at_idx
    ON products (status, published_at DESC)
    WHERE archived_at IS NULL;

CREATE TRIGGER products_set_updated_at_trigger
BEFORE UPDATE ON products
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

CREATE TABLE product_translations (
    product_id              BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    locale                  VARCHAR(8) NOT NULL,
    title                   TEXT NOT NULL,
    short_description       TEXT NULL,
    description             TEXT NULL,
    is_machine_translated   BOOLEAN NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (product_id, locale)
);

-- Trigram index for admin search by title; storefront search goes
-- through MeiliSearch (E5).
CREATE INDEX product_translations_title_trgm_idx
    ON product_translations USING gin (title gin_trgm_ops);

CREATE INDEX product_translations_locale_idx ON product_translations (locale);

CREATE TRIGGER product_translations_set_updated_at_trigger
BEFORE UPDATE ON product_translations
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
