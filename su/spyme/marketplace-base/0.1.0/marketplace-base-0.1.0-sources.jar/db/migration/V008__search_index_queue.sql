-- V008 — search_index_queue (outbox pattern per В6).
--
-- Producers (catalog services etc.) INSERT a row inside the same
-- transaction that mutates the entity. The worker pulls rows in
-- batches via `SELECT ... FOR UPDATE SKIP LOCKED LIMIT 100`, calls the
-- active SearchProvider, then sets processed_at.
--
-- Coalescing: the partial unique index on (entity_type, entity_id)
-- WHERE processed_at IS NULL means N updates of the same entity
-- inside a tight loop produce a single pending row — the producer
-- side does ON CONFLICT DO UPDATE SET enqueued_at = excluded.enqueued_at.

CREATE TABLE search_index_queue (
    id              BIGSERIAL PRIMARY KEY,
    entity_type     VARCHAR(32) NOT NULL,
    entity_id       BIGINT NOT NULL,
    operation       VARCHAR(16) NOT NULL CHECK (operation IN ('upsert', 'delete')),
    enqueued_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    attempts        SMALLINT NOT NULL DEFAULT 0,
    last_error      TEXT NULL,
    processed_at    TIMESTAMP NULL
);

-- One pending row per (entity_type, entity_id). Producers ON CONFLICT
-- bump enqueued_at instead of inserting a duplicate.
CREATE UNIQUE INDEX search_index_queue_pending_uniq_idx
    ON search_index_queue (entity_type, entity_id)
    WHERE processed_at IS NULL;

-- Worker reads pending rows oldest-first.
CREATE INDEX search_index_queue_pending_enqueued_idx
    ON search_index_queue (enqueued_at)
    WHERE processed_at IS NULL;

-- pg_notify on insert + on enqueued_at bump (i.e. ON CONFLICT update).
-- Workers LISTEN 'search_queue' for sub-100ms latency; the polling
-- fallback (5s) handles connection drops.
CREATE OR REPLACE FUNCTION search_index_queue_notify()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM pg_notify('search_queue', NEW.id::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER search_index_queue_insert_notify_trigger
AFTER INSERT ON search_index_queue
FOR EACH ROW
EXECUTE FUNCTION search_index_queue_notify();

CREATE TRIGGER search_index_queue_update_notify_trigger
AFTER UPDATE OF enqueued_at ON search_index_queue
FOR EACH ROW
WHEN (NEW.enqueued_at IS DISTINCT FROM OLD.enqueued_at)
EXECUTE FUNCTION search_index_queue_notify();
