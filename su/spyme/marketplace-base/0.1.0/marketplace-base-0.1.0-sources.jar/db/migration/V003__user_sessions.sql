-- V003 — user_sessions table.
--
-- Granular per-session JWT revocation per В1: каждый JWT carries jti
-- referencing a row here. Logout = set revoked_at; "logout all but
-- current" = bulk update; access без revoked_at и до expires_at = valid.
--
-- UUID PK на стороне приложения (UUID.randomUUID), не БД-default —
-- детерминируемо в тестах через инжектируемый генератор.

CREATE TABLE user_sessions (
    id              UUID PRIMARY KEY,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    jti             UUID NOT NULL UNIQUE,
    device_label    VARCHAR(128) NULL,
    ip              INET NULL,
    user_agent      TEXT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    last_active_at  TIMESTAMP NOT NULL DEFAULT NOW(),
    revoked_at      TIMESTAMP NULL,
    expires_at      TIMESTAMP NOT NULL
);

CREATE INDEX user_sessions_user_id_idx     ON user_sessions (user_id);
CREATE INDEX user_sessions_expires_at_idx  ON user_sessions (expires_at);
-- Запросы "активные сессии юзера" — самый частый pattern в /profile/sessions.
CREATE INDEX user_sessions_user_active_idx ON user_sessions (user_id)
    WHERE revoked_at IS NULL;
