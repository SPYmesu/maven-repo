-- V009 — cart_items (guest + authenticated users).
--
-- Two ownership modes share one table:
-- - Authenticated user → user_id is set, guest_token is NULL.
-- - Anonymous shopper → guest_token is set (random 32-char string in
--   the cookie), user_id is NULL.
-- Exactly one must be present; the CHECK constraint enforces it.
--
-- Variant column is nullable: products without variant axes leave it
-- NULL; variant-bearing products set it. Cart-merge on login takes
-- (user_id, product_id, variant_id) tuples from the guest cart and
-- folds them into the user cart, summing quantities.

CREATE TABLE cart_items (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NULL REFERENCES users(id) ON DELETE CASCADE,
    guest_token     VARCHAR(64) NULL,
    product_id      BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id      BIGINT NULL REFERENCES product_variants(id) ON DELETE CASCADE,
    quantity        INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    -- Either authenticated or guest, never both, never neither.
    CONSTRAINT cart_items_owner_xor CHECK (
        (user_id IS NOT NULL AND guest_token IS NULL) OR
        (user_id IS NULL     AND guest_token IS NOT NULL)
    )
);

-- One line per (owner, product, variant). Two partial unique indexes
-- because PostgreSQL treats nullable columns specially.
CREATE UNIQUE INDEX cart_items_user_product_variant_idx
    ON cart_items (user_id, product_id, COALESCE(variant_id, 0))
    WHERE user_id IS NOT NULL;

CREATE UNIQUE INDEX cart_items_guest_product_variant_idx
    ON cart_items (guest_token, product_id, COALESCE(variant_id, 0))
    WHERE guest_token IS NOT NULL;

-- Frequent reads: list cart for a known owner.
CREATE INDEX cart_items_user_idx ON cart_items (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX cart_items_guest_idx ON cart_items (guest_token) WHERE guest_token IS NOT NULL;

-- For the abandoned-cart cron: rows older than N days, sweep them.
CREATE INDEX cart_items_updated_at_idx ON cart_items (updated_at);

CREATE TRIGGER cart_items_set_updated_at_trigger
BEFORE UPDATE ON cart_items
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
