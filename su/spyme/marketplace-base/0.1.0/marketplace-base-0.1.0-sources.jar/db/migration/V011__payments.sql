-- V011 — payments.
--
-- One row per attempted payment. Multiple rows per order are normal
-- (retry after FAILED, refund creating a new row, etc.). The order
-- status is computed from this table + refunds.
--
-- Status alphabet (decoupled from order status):
-- - INITIATED  — created locally, gateway hasn't accepted yet.
-- - AUTHORIZED — funds reserved (3-D Secure / hold flow).
-- - CAPTURED   — funds taken. Order can move to PAID.
-- - FAILED     — gateway rejected.
-- - CANCELLED  — user/admin abandoned before capture.
-- - REFUNDED   — derived bookkeeping state once a matching refund row
--                completes; refunds.amount = payments.amount.
--
-- idempotency_key: producer-supplied string that lets the gateway
-- safely retry on transient errors. Combined with provider it must
-- be unique so a duplicate API call hits the same record.

CREATE TABLE payments (
    id                      BIGSERIAL PRIMARY KEY,
    order_id                BIGINT NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    provider                VARCHAR(32) NOT NULL,
    provider_payment_id     VARCHAR(128) NULL,
    status                  VARCHAR(32) NOT NULL DEFAULT 'INITIATED' CHECK (status IN (
        'INITIATED', 'AUTHORIZED', 'CAPTURED', 'FAILED', 'CANCELLED', 'REFUNDED'
    )),
    amount                  BIGINT NOT NULL CHECK (amount >= 0),
    currency                CHAR(3) NOT NULL,
    idempotency_key         VARCHAR(128) NOT NULL,
    gateway_metadata        JSONB NULL,
    failure_reason          TEXT NULL,
    initiated_at            TIMESTAMP NOT NULL DEFAULT NOW(),
    authorized_at           TIMESTAMP NULL,
    captured_at             TIMESTAMP NULL,
    failed_at               TIMESTAMP NULL,
    cancelled_at            TIMESTAMP NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Webhook lookup hot path: gateway hands us back its id, we find the
-- row.
CREATE UNIQUE INDEX payments_provider_payment_id_idx
    ON payments (provider, provider_payment_id)
    WHERE provider_payment_id IS NOT NULL;

-- Idempotency: one record per (provider, idempotency_key).
CREATE UNIQUE INDEX payments_provider_idempotency_idx
    ON payments (provider, idempotency_key);

-- Order timeline + admin search.
CREATE INDEX payments_order_idx ON payments (order_id);
CREATE INDEX payments_status_idx ON payments (status);
CREATE INDEX payments_initiated_at_idx ON payments (initiated_at DESC);

CREATE TRIGGER payments_set_updated_at_trigger
BEFORE UPDATE ON payments
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
