-- V002 — users table.
--
-- Singleton-таблица per Б1: host расширяет через side-tables, не ALTER TABLE.
-- Soft-delete через deleted_at; partial unique indexes исключают
-- удалённых юзеров. CITEXT для email/username даёт case-insensitive
-- сравнение без LOWER() в каждом запросе.

CREATE TABLE users (
    id                  BIGSERIAL PRIMARY KEY,
    username            CITEXT NOT NULL,
    email               CITEXT NOT NULL,
    email_verified_at   TIMESTAMP NULL,
    phone               VARCHAR(32) NULL,
    phone_verified_at   TIMESTAMP NULL,
    roles               VARCHAR(32)[] NOT NULL DEFAULT ARRAY[]::VARCHAR(32)[],
    jwt_version         INT NOT NULL DEFAULT 0,
    locale              VARCHAR(8) NOT NULL DEFAULT 'ru',
    timezone            VARCHAR(64) NULL,
    last_active_at      TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at          TIMESTAMP NULL
);

-- Уникальность только среди активных юзеров — soft-deleted освобождает
-- email/username для повторной регистрации.
CREATE UNIQUE INDEX users_username_active_idx ON users (username) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX users_email_active_idx    ON users (email)    WHERE deleted_at IS NULL;

-- Trigram-индексы для admin-search (fuzzy).
CREATE INDEX users_username_trgm_idx ON users USING gin (username gin_trgm_ops);
CREATE INDEX users_email_trgm_idx    ON users USING gin (email gin_trgm_ops);

-- Generic updated_at trigger function — переиспользуется другими таблицами.
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_set_updated_at_trigger
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
