-- Initial migration: PostgreSQL extensions only.
--
-- Tables come in subsequent migrations:
--   V002 — users + auth core (E3)
--   V003 — categories + EAV (E4)
--   V004 — products + variants (E4)
--   V005 — cart_items + orders + payments (E6)
--   ...

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS btree_gin;
CREATE EXTENSION IF NOT EXISTS citext;
