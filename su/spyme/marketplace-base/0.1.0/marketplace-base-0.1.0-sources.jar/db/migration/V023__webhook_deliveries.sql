-- V023 — webhook_deliveries.
--
-- Outbox table for outbound webhooks. One row per delivery attempt.
-- The producer side (e.g. OrdersService transition listeners) inserts
-- a PENDING row in the same transaction as the entity mutation; a
-- worker drains, signs, POSTs, and stamps the result.
--
-- Retry schedule (Б5 / Stripe-style): 1s, 30s, 5m, 30m, 2h, 12h.
-- scheduled_at is updated to the next retry time on failure; the
-- worker only picks rows where scheduled_at <= NOW().
--
-- Status: PENDING → SUCCESS | FAILED. SUCCESS rows are kept for
-- BaseConfig.webhookDeliveryRetentionDays (default 90) for the
-- delivery-history admin UI; cleanup cron eventually drops them.

CREATE TABLE webhook_deliveries (
    id                  UUID PRIMARY KEY,
    subscription_id     UUID NOT NULL REFERENCES webhook_subscriptions(id) ON DELETE CASCADE,
    event_id            UUID NOT NULL,
    event_type          VARCHAR(128) NOT NULL,
    payload             JSONB NOT NULL,
    attempt             SMALLINT NOT NULL DEFAULT 0,
    status              VARCHAR(16) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
        'PENDING', 'SUCCESS', 'FAILED'
    )),
    http_status         INT NULL,
    response_body       TEXT NULL,
    response_headers    JSONB NULL,
    latency_ms          INT NULL,
    signature           VARCHAR(256) NULL,
    last_error          TEXT NULL,
    scheduled_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    sent_at             TIMESTAMP NULL,
    completed_at        TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Worker scan path: pending deliveries whose scheduled_at has passed.
CREATE INDEX webhook_deliveries_due_idx ON webhook_deliveries (scheduled_at)
    WHERE status = 'PENDING';

-- "Deliveries for this subscription" admin UI hot path.
CREATE INDEX webhook_deliveries_subscription_idx
    ON webhook_deliveries (subscription_id, created_at DESC);

-- Idempotency / replay: same event id can't get queued twice for
-- the same subscription accidentally.
CREATE UNIQUE INDEX webhook_deliveries_subscription_event_idx
    ON webhook_deliveries (subscription_id, event_id);

CREATE INDEX webhook_deliveries_status_idx ON webhook_deliveries (status);

-- pg_notify hook so the worker wakes up immediately on enqueue.
CREATE OR REPLACE FUNCTION webhook_deliveries_notify()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM pg_notify('webhook_deliveries_queue', NEW.id::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER webhook_deliveries_insert_notify_trigger
AFTER INSERT ON webhook_deliveries
FOR EACH ROW
WHEN (NEW.status = 'PENDING')
EXECUTE FUNCTION webhook_deliveries_notify();

CREATE TRIGGER webhook_deliveries_set_updated_at_trigger
BEFORE UPDATE ON webhook_deliveries
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
