package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.like
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.or
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.orders.BaseOrdersTable
import su.spyme.marketplace.orders.Order
import su.spyme.marketplace.orders.state.IllegalOrderTransitionException
import su.spyme.marketplace.orders.state.OrderStatus
import su.spyme.marketplace.orders.state.TransitionActor
import su.spyme.marketplace.refunds.NewRefundLine
import su.spyme.marketplace.refunds.Refund
import su.spyme.marketplace.refunds.RefundType
import su.spyme.marketplace.shipping.ShipmentStatus
import su.spyme.marketplace.users.BaseUsersTable
import su.spyme.marketplace.users.User

/**
 * Staff endpoints under `/api/admin`, open to [StorefrontConfig.adminRole] and
 * above: order list, status transitions (as the order's state machine allows),
 * cancel, and refunds through the gateway.
 */
fun Route.adminOrderRoutes(deps: StorefrontDeps) {
    val web = deps.web

    endpoint(HttpMethod.Get, "/api/admin/orders") {
        val staff = web.sessions.requireStaff(this)
        val actor = actorFor(deps, staff)
        val (offset, limit) = page()
        val status = request.queryParameters["status"]?.takeIf { it.isNotBlank() }?.let { s ->
            runCatching { OrderStatus.parse(s) }.getOrNull() ?: throw badRequest("BAD_STATUS", "Unknown status '$s'")
        }
        val q = request.queryParameters["q"]?.trim()?.takeIf { it.isNotEmpty() }
        val (rows, total) = transaction(deps.mainDb) {
            val query = BaseOrdersTable.join(BaseUsersTable, org.jetbrains.exposed.sql.JoinType.INNER, BaseOrdersTable.userId, BaseUsersTable.id)
                .selectAll()
            val filter: Op<Boolean> = listOfNotNull(
                status?.let { Op.build { BaseOrdersTable.status eq it.name } },
                q?.let { raw ->
                    val pattern = "%" + raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
                    Op.build {
                        (BaseOrdersTable.orderNumber like pattern.uppercase()) or
                            (BaseUsersTable.username like pattern) or (BaseUsersTable.email like pattern)
                    }
                },
            ).fold(Op.TRUE as Op<Boolean>) { acc, op -> acc and op }
            val matching = query.where { filter }
            val count = matching.count()
            val page = matching.orderBy(BaseOrdersTable.id to SortOrder.DESC).limit(limit).offset(offset.toLong())
                .map { Order.fromRow(it) to User.fromRow(it) }
            page to count
        }
        respondJson(pageJson(rows.map { (order, customer) -> web.views.json(order, customer, actor) }, total, offset, limit))
    }

    endpoint(HttpMethod.Post, "/api/admin/orders/{id}/transition") {
        val staff = web.sessions.requireStaff(this)
        val order = orderParam(deps, this)
        val body = jsonBody()
        val to = body.str("to")?.let { s ->
            runCatching { OrderStatus.parse(s) }.getOrNull() ?: throw badRequest("BAD_STATUS", "Unknown status '$s'")
        } ?: throw badRequest("BAD_STATUS", "to is required")
        if (to == OrderStatus.CANCELLED) {
            // Cancelling needs a structured reason, so it takes the cancel path.
            val reason = body.str("comment")?.takeIf { it.isNotBlank() } ?: throw badRequest("REASON_REQUIRED", "comment is required to cancel")
            respondJson(web.views.json(web.checkout.cancel(order, actorFor(deps, staff), staff.id, reason, "OTHER"), actor = actorFor(deps, staff)))
            return@endpoint
        }

        val updated = try {
            deps.orders.transition(order.id, to, actorFor(deps, staff), staff.id, reason = body.str("comment")?.take(500))
        } catch (e: IllegalOrderTransitionException) {
            throw conflict("INVALID_TRANSITION", e.why)
        }
        val tracking = body.str("trackingNumber")?.trim()?.takeIf { it.isNotEmpty() }
        if (to == OrderStatus.SHIPPED && tracking != null) {
            val shipment = deps.shipping.createShipment(order.id, trackingNumber = tracking)
            deps.orders.listItems(order.id).forEach { deps.shipping.addShipmentItem(shipment.id, it.id, it.quantity) }
            deps.shipping.updateShipmentStatus(shipment.id, ShipmentStatus.IN_TRANSIT)
        }
        if (to == OrderStatus.DELIVERED) {
            deps.shipping.listShipmentsForOrder(order.id).forEach { deps.shipping.updateShipmentStatus(it.id, ShipmentStatus.DELIVERED) }
        }
        respondJson(web.views.json(updated, actor = actorFor(deps, staff)))
    }

    endpoint(HttpMethod.Post, "/api/admin/orders/{id}/cancel") {
        val staff = web.sessions.requireStaff(this)
        val order = orderParam(deps, this)
        val reason = jsonBody().str("reason")?.takeIf { it.isNotBlank() } ?: throw badRequest("REASON_REQUIRED", "reason is required")
        respondJson(web.views.json(web.checkout.cancel(order, actorFor(deps, staff), staff.id, reason, "OTHER"), actor = actorFor(deps, staff)))
    }

    endpoint(HttpMethod.Post, "/api/admin/refunds") {
        val staff = web.sessions.requireStaff(this)
        val body = jsonBody()
        val order = body.long("orderId")?.let { deps.orders.findById(it) } ?: throw notFound("ORDER_NOT_FOUND")
        val reason = body.str("reason")?.takeIf { it.isNotBlank() } ?: throw badRequest("REASON_REQUIRED", "reason is required")
        val payment = deps.payments.findCapturedFor(order.id) ?: throw conflict("NOT_PAID", "The order has no captured payment")
        val gateway = deps.gateways.getOrNull(payment.provider)
        val providerId = payment.providerPaymentId
        if (gateway == null || providerId == null) throw ApiException(HttpStatusCode.BadGateway, "NO_GATEWAY", "Payment provider is unavailable")

        // Requested lines, or the whole not-yet-refunded remainder when none are given.
        val items = deps.orders.listItems(order.id).associateBy { it.id }
        val lines = (body["items"] as? JsonArray).orEmpty().map { e ->
            val o = e as? JsonObject ?: throw badRequest("BAD_ITEMS", "items must be objects")
            val item = o.long("orderItemId")?.let { items[it] } ?: throw badRequest("BAD_ITEMS", "unknown orderItemId")
            val qty = o.int("quantity") ?: throw badRequest("BAD_ITEMS", "quantity is required")
            if (qty !in 1..item.quantity) throw badRequest("BAD_ITEMS", "quantity must be 1..${item.quantity}")
            NewRefundLine(item.id, qty, item.unitPrice * qty)
        }
        val remaining = payment.money.amount - deps.refunds.totalCompletedForOrder(order.id)
        val amount = if (lines.isEmpty()) remaining else lines.sumOf { it.amount.amount }
        if (amount <= 0 || amount > remaining) throw conflict("REFUND_EXCEEDS_PAYMENT", "Refund exceeds the refundable remainder ($remaining)")
        val money = Money(amount, payment.money.currency)

        val (code, text) = web.checkout.resolveReason(reason, "OTHER")
        val refund = try {
            deps.refunds.requestRefund(
                order.id, RefundType.REFUND, money, code, staff.id,
                paymentId = payment.id, reasonText = text, lines = lines.ifEmpty { null },
            )
        } catch (e: IllegalArgumentException) {
            throw badRequest("BAD_REFUND", e.message ?: "bad refund")
        }
        deps.refunds.approve(refund.id, staff.id)
        val result = try {
            gateway.refund(providerId, money, "refund-${refund.id}")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            deps.refunds.reject(refund.id, staff.id)
            throw ApiException(HttpStatusCode.BadGateway, "REFUND_FAILED", "The provider refused the refund")
        }
        val done = try {
            deps.refunds.complete(refund.id, result.refundProviderId, result.gatewayMetadata)
        } catch (e: IllegalArgumentException) {
            throw conflict("REFUND_EXCEEDS_PAYMENT", e.message ?: "refund exceeds payment")
        }
        respondJson(HttpStatusCode.Created, refundJson(deps, done))
    }
}

private fun orderParam(deps: StorefrontDeps, call: ApplicationCall): Order =
    call.parameters["id"]?.toLongOrNull()?.let { deps.orders.findById(it) } ?: throw notFound("ORDER_NOT_FOUND")

/** Staff acting as ADMIN when they hold that role, else as MANAGER (the machines distinguish them). */
private fun actorFor(deps: StorefrontDeps, staff: User) =
    if ("ADMIN" in staff.roles) TransitionActor.ADMIN else TransitionActor.MANAGER

private fun refundJson(deps: StorefrontDeps, r: Refund): JsonObject = buildJsonObject {
    put("id", r.id)
    put("orderId", r.orderId)
    put("amount", r.money.toJson())
    put("status", r.status.name)
    put("reason", r.reasonText ?: r.reasonCode)
    put("createdAt", r.createdAt.toJson())
    put("items", JsonArray(deps.refunds.listLinesFor(r.id).map { l ->
        buildJsonObject {
            put("orderItemId", l.orderItemId)
            put("quantity", l.quantity)
            put("amount", Money(l.amount, r.money.currency).toJson())
        }
    }))
}
