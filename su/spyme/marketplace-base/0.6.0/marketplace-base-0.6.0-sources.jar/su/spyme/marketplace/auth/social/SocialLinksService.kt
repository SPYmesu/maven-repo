package su.spyme.marketplace.auth.social

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.database.NowExpression
import java.time.Instant

/** Exposed mapping for V028.social_links. */
object BaseSocialLinksTable : Table("social_links") {
    val id: Column<Long> = long("id").autoIncrement()
    val userId: Column<Long> = long("user_id")
    val provider: Column<String> = varchar("provider", 32)
    val externalId: Column<String> = varchar("external_id", 255)
    val displayName: Column<String?> = varchar("display_name", 255).nullable()
    val linkedAt: Column<Instant> = timestamp("linked_at").defaultExpression(NowExpression)
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * An external identity attached to a marketplace user.
 *
 * @property provider `tg`, `vk`, or any other provider code a host uses.
 * @property externalId the provider's user id (Telegram user id, VK user id, ...).
 */
data class SocialLink(
    val id: Long,
    val userId: Long,
    val provider: String,
    val externalId: String,
    val displayName: String?,
    val linkedAt: Instant,
) {
    companion object {
        fun fromRow(row: ResultRow) = SocialLink(
            id = row[BaseSocialLinksTable.id],
            userId = row[BaseSocialLinksTable.userId],
            provider = row[BaseSocialLinksTable.provider],
            externalId = row[BaseSocialLinksTable.externalId],
            displayName = row[BaseSocialLinksTable.displayName],
            linkedAt = row[BaseSocialLinksTable.linkedAt],
        )
    }
}

/**
 * CRUD over `social_links`. The unique indexes of V028 make an external account
 * belong to at most one user and a user hold at most one identity per provider;
 * violations surface as the SQL unique violation (SQLState 23505).
 */
open class SocialLinksService(protected val mainDb: Database) {

    /** The user that owns the external account, if any. */
    open fun findByExternal(provider: String, externalId: String): SocialLink? = transaction(mainDb) {
        BaseSocialLinksTable.selectAll()
            .where { (BaseSocialLinksTable.provider eq provider) and (BaseSocialLinksTable.externalId eq externalId) }
            .firstOrNull()?.let(SocialLink::fromRow)
    }

    open fun listForUser(userId: Long): List<SocialLink> = transaction(mainDb) {
        BaseSocialLinksTable.selectAll()
            .where { BaseSocialLinksTable.userId eq userId }
            .orderBy(BaseSocialLinksTable.id to SortOrder.ASC)
            .map(SocialLink::fromRow)
    }

    open fun findForUser(userId: Long, provider: String): SocialLink? = transaction(mainDb) {
        BaseSocialLinksTable.selectAll()
            .where { (BaseSocialLinksTable.userId eq userId) and (BaseSocialLinksTable.provider eq provider) }
            .firstOrNull()?.let(SocialLink::fromRow)
    }

    /** Attaches the account to [userId]; fails with a unique violation if either side is taken. */
    open fun link(userId: Long, provider: String, externalId: String, displayName: String?): SocialLink =
        transaction(mainDb) {
            val id = BaseSocialLinksTable.insert {
                it[BaseSocialLinksTable.userId] = userId
                it[BaseSocialLinksTable.provider] = provider
                it[BaseSocialLinksTable.externalId] = externalId
                it[BaseSocialLinksTable.displayName] = displayName
            }[BaseSocialLinksTable.id]
            BaseSocialLinksTable.selectAll().where { BaseSocialLinksTable.id eq id }.first().let(SocialLink::fromRow)
        }

    /** Refreshes the cached display name of an existing link. */
    open fun updateDisplayName(linkId: Long, displayName: String?) {
        transaction(mainDb) {
            BaseSocialLinksTable.update({ BaseSocialLinksTable.id eq linkId }) {
                it[BaseSocialLinksTable.displayName] = displayName
            }
        }
    }

    /** Detaches [provider]; true if a link existed. */
    open fun unlink(userId: Long, provider: String): Boolean = transaction(mainDb) {
        BaseSocialLinksTable.deleteWhere {
            (BaseSocialLinksTable.userId eq userId) and (BaseSocialLinksTable.provider eq provider)
        } > 0
    }
}
