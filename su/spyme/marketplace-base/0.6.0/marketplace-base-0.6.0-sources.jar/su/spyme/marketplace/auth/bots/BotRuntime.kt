package su.spyme.marketplace.auth.bots

import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.ratelimit.CaffeineRateLimitStore
import su.spyme.marketplace.core.ratelimit.RateLimitStore
import su.spyme.marketplace.notifications.NotificationChannel
import su.spyme.marketplace.notifications.NotificationChannelRegistry

/**
 * Owns the configured transports and the router in front of them. A host builds
 * one, calls [start] after bootstrap and [stop] on shutdown, and registers
 * [notificationChannels] with its [NotificationChannelRegistry]:
 *
 * ```kotlin
 * val bots = BotRuntime(botAuth, hostHandlers = listOf(OrdersCommand()))
 * bots.registerNotificationChannels(channelRegistry)
 * bots.start()
 * ```
 *
 * Platforms missing from [BotConfig] are skipped, so a deployment with no
 * tokens runs without any bot.
 */
class BotRuntime(
    private val auth: BotAuthService,
    hostHandlers: List<BotCommandHandler> = emptyList(),
    messages: BotMessages = BotMessages(),
    rateLimits: RateLimitStore = CaffeineRateLimitStore(),
    telegramApiBase: String = "https://api.telegram.org",
    vkApiBase: String = "https://api.vk.com/method",
    /** Site base URL used for links in bot notifications; null = no links. */
    private val publicUrl: String? = null,
) {
    private val log = LoggerFactory.getLogger(BotRuntime::class.java)
    private val router = BotRouter(auth, hostHandlers, messages, rateLimits)

    /** Telegram transport, null when not configured. */
    val telegram: TelegramBotAdapter? = auth.config.telegram?.let {
        TelegramBotAdapter(it.botToken, router::handle, telegramApiBase)
    }

    /** VK transport, null when not configured. */
    val vk: VkBotAdapter? = auth.config.vk?.let {
        VkBotAdapter(it.groupId, it.groupToken, router::handle, vkApiBase)
    }

    /** Starts every configured transport. */
    fun start() {
        if (telegram == null && vk == null) log.info("no bot configured - bot transports skipped")
        telegram?.start()
        vk?.start()
    }

    fun stop() {
        telegram?.stop()
        vk?.stop()
    }

    /** One outbound channel per configured transport (`tg`, `vk`). */
    fun notificationChannels(): List<NotificationChannel> =
        listOfNotNull(telegram, vk).map { BotNotificationChannel(it, publicUrl) }

    fun registerNotificationChannels(registry: NotificationChannelRegistry) {
        notificationChannels().forEach(registry::register)
    }
}
