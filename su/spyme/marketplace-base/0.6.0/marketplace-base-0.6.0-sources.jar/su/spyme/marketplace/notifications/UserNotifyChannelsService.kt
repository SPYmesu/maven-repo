package su.spyme.marketplace.notifications

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.upsert
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.core.database.stringArray
import java.time.Instant

/** Exposed mapping for V045.user_notify_channels. */
object BaseUserNotifyChannelsTable : Table("user_notify_channels") {
    val userId: Column<Long> = long("user_id")
    val channels: Column<List<String>> = stringArray("channels", 16)
    val updatedAt: Column<Instant> = timestamp("updated_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(userId)
}

/**
 * Which channels a user wants notifications on, in priority order. Codes are
 * the storefront's: [SITE], `tg`, `vk`, `email` (the bot codes equal
 * [ChannelCodes.TELEGRAM] / [ChannelCodes.VK]). Producers read [get] and map
 * [SITE] to [ChannelCodes.IN_APP] when they enqueue.
 */
open class UserNotifyChannelsService(protected val mainDb: Database) {

    /** The user's channels; `[site]` when they never chose. */
    open fun get(userId: Long): List<String> = transaction(mainDb) {
        BaseUserNotifyChannelsTable.selectAll()
            .where { BaseUserNotifyChannelsTable.userId eq userId }
            .firstOrNull()?.get(BaseUserNotifyChannelsTable.channels)
    } ?: listOf(SITE)

    /** Replaces the list (duplicates dropped, order kept) and returns what was stored. */
    open fun set(userId: Long, channels: List<String>): List<String> {
        val clean = channels.distinct()
        transaction(mainDb) {
            BaseUserNotifyChannelsTable.upsert {
                it[BaseUserNotifyChannelsTable.userId] = userId
                it[BaseUserNotifyChannelsTable.channels] = clean
                it[BaseUserNotifyChannelsTable.updatedAt] = Instant.now()
            }
        }
        return clean
    }

    /** Appends [channel] when absent (a platform was just linked). */
    open fun ensure(userId: Long, channel: String) {
        val current = get(userId)
        if (channel !in current) set(userId, current + channel)
    }

    /** Drops [channel]; never leaves the list empty (falls back to [SITE]). */
    open fun remove(userId: Long, channel: String) {
        set(userId, get(userId).filter { it != channel }.ifEmpty { listOf(SITE) })
    }

    companion object {
        /** The in-app feed on the site; always allowed. */
        const val SITE = "site"
    }
}
