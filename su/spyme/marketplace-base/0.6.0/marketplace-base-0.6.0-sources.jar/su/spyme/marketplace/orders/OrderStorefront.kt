package su.spyme.marketplace.orders

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp
import org.jetbrains.exposed.sql.json.jsonb
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.Database
import su.spyme.marketplace.core.database.NowExpression
import su.spyme.marketplace.orders.state.OrderTransitionEvent
import su.spyme.marketplace.orders.state.OrderTransitionListener
import java.time.Instant

/** Exposed mapping for V044.order_checkout_details (what the buyer entered at checkout). */
object BaseOrderCheckoutDetailsTable : Table("order_checkout_details") {
    val orderId: Column<Long> = long("order_id")
    val deliveryMethodCode: Column<String> = varchar("delivery_method_code", 32)
    val deliveryMethodTitle: Column<String> = text("delivery_method_title")
    val contact: Column<JsonElement> = jsonb("contact", Json, JsonElement.serializer())
    val comment: Column<String?> = text("comment").nullable()
    val createdAt: Column<Instant> = timestamp("created_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(orderId)
}

/** Exposed mapping for V044.order_status_history. */
object BaseOrderStatusHistoryTable : Table("order_status_history") {
    val id: Column<Long> = long("id").autoIncrement()
    val orderId: Column<Long> = long("order_id")
    val fromStatus: Column<String> = varchar("from_status", 32)
    val toStatus: Column<String> = varchar("to_status", 32)
    val actor: Column<String> = varchar("actor", 32)
    val actorUserId: Column<Long?> = long("actor_user_id").nullable()
    val reason: Column<String?> = text("reason").nullable()
    val occurredAt: Column<Instant> = timestamp("occurred_at").defaultExpression(NowExpression)

    override val primaryKey = PrimaryKey(id)
}

/**
 * Appends every committed transition to `order_status_history`, which feeds the
 * `history` timeline of the storefront order. Registered by
 * [su.spyme.marketplace.web.storefrontRoutes] when the routes are mounted.
 */
class OrderStatusHistoryListener(private val mainDb: Database) : OrderTransitionListener {
    override suspend fun onTransition(event: OrderTransitionEvent) {
        transaction(mainDb) {
            BaseOrderStatusHistoryTable.insert {
                it[orderId] = event.orderId
                it[fromStatus] = event.from.name
                it[toStatus] = event.to.name
                it[actor] = event.actor.name
                it[actorUserId] = event.actorUserId
                it[reason] = event.reason
                it[occurredAt] = event.occurredAt
            }
        }
    }
}
