package su.spyme.marketplace.refunds

import kotlinx.serialization.json.JsonElement
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.SqlExpressionBuilder.inList
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.payments.PaymentsServiceBase
import su.spyme.marketplace.payments.BasePaymentsTable
import java.time.Instant

/** One line on a refund request — quantity to refund + monetary amount. */
data class NewRefundLine(
    val orderItemId: Long,
    val quantity: Int,
    val amount: Money,
)

/**
 * Owns the refund lifecycle and the implicit payment-side bookkeeping
 * (flips a payment to REFUNDED once the matching refunds total covers
 * its full amount).
 *
 * Order-level PARTIALLY_REFUNDED / REFUNDED are *display* states the
 * OrdersService derives — never written here.
 */
open class RefundsServiceBase(
    protected val mainDb: Database,
    protected val payments: PaymentsServiceBase,
) {

    /**
     * Files a new refund request. Lines are optional — pass `null` or
     * an empty list to refund the whole order.
     *
     * @param paymentId Targets a specific payment row (the one that
     *        will be debited at COMPLETE time). May be null for store
     *        credit / pre-payment cancellations.
     */
    open fun requestRefund(
        orderId: Long,
        type: RefundType,
        money: Money,
        reasonCode: String,
        requestedBy: Long,
        paymentId: Long? = null,
        reasonText: String? = null,
        lines: List<NewRefundLine>? = null,
    ): Refund {
        require(money.amount >= 0) { "refund amount must be non-negative" }
        if (lines != null) {
            require(lines.all { it.quantity > 0 }) { "every refund line needs quantity > 0" }
            require(lines.all { it.amount.currency == money.currency }) {
                "refund line currency must match the refund currency"
            }
        }

        return transaction(mainDb) {
            val newId = BaseRefundsTable.insert {
                it[BaseRefundsTable.orderId] = orderId
                it[BaseRefundsTable.paymentId] = paymentId
                it[BaseRefundsTable.type] = type.sqlValue
                it[BaseRefundsTable.amount] = money.amount
                it[BaseRefundsTable.currency] = money.currency
                it[BaseRefundsTable.reasonCode] = reasonCode
                it[BaseRefundsTable.reasonText] = reasonText
                it[BaseRefundsTable.requestedBy] = requestedBy
            }[BaseRefundsTable.id]

            lines.orEmpty().forEach { line ->
                BaseRefundItemsTable.insert {
                    it[BaseRefundItemsTable.refundId] = newId
                    it[BaseRefundItemsTable.orderItemId] = line.orderItemId
                    it[BaseRefundItemsTable.quantity] = line.quantity
                    it[BaseRefundItemsTable.amount] = line.amount.amount
                }
            }
            loadById(newId)!!
        }
    }

    open fun approve(refundId: Long, approvedBy: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            requireOpen(refundId, "approve")
            BaseRefundsTable.update({ BaseRefundsTable.id eq refundId }) {
                it[BaseRefundsTable.status] = RefundStatus.APPROVED.name
                it[BaseRefundsTable.approvedBy] = approvedBy
                it[BaseRefundsTable.approvedAt] = now
            }
        }
    }

    /** Required before COMPLETE for type=RETURN; no-op for type=REFUND. */
    open fun markGoodsReceived(refundId: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            requireOpen(refundId, "mark goods received on")
            BaseRefundsTable.update({ BaseRefundsTable.id eq refundId }) {
                it[BaseRefundsTable.status] = RefundStatus.GOODS_RECEIVED.name
                it[BaseRefundsTable.goodsReceivedAt] = now
            }
        }
    }

    /**
     * Closes the refund. Allowed from APPROVED (type=REFUND) or GOODS_RECEIVED
     * (required for type=RETURN); anything else throws [IllegalStateException]
     * and changes nothing. The currency must match the payment's. If the
     * cumulative completed-refund amount for the linked payment now covers the full payment amount, the
     * payment row is flipped to REFUNDED (per the architecture plan).
     */
    open fun complete(
        refundId: Long,
        refundProviderId: String? = null,
        gatewayMetadata: JsonElement? = null,
        now: Instant = Instant.now(),
    ): Refund = transaction(mainDb) {
        val refund = loadById(refundId) ?: error("refund $refundId not found")

        // Serialize completes against one payment: lock its row, then re-read the
        // refund and the completed total under the lock. Without it two refunds
        // that each fit the payment both pass the cap check on a stale sum.
        refund.paymentId?.let { lockPayment(it) }
        val current = loadById(refundId)!!
        val allowedFrom = when (current.type) {
            RefundType.RETURN -> setOf(RefundStatus.GOODS_RECEIVED)
            RefundType.REFUND -> setOf(RefundStatus.APPROVED, RefundStatus.GOODS_RECEIVED)
        }
        check(current.status in allowedFrom) {
            "refund $refundId is ${current.status}, cannot complete (needs one of $allowedFrom)"
        }

        // Money-integrity guard: the cumulative COMPLETED refunds against a
        // payment must never exceed what was captured. Without this, filing
        // several refunds each ≤ the order total and completing them all
        // drives the refunded sum above the payment amount (direct loss).
        refund.paymentId?.let { paymentId ->
            payments.findById(paymentId)?.let { payment ->
                require(refund.money.currency == payment.money.currency) {
                    "refund currency ${refund.money.currency} differs from payment currency ${payment.money.currency}"
                }
                val alreadyCompleted = totalCompletedAgainstPayment(paymentId)
                require(alreadyCompleted + refund.money.amount <= payment.money.amount) {
                    "refund would exceed payment: already=$alreadyCompleted + this=${refund.money.amount} " +
                        "> captured=${payment.money.amount}"
                }
            }
        }

        val moved = BaseRefundsTable.update({
            (BaseRefundsTable.id eq refundId) and
                (BaseRefundsTable.status inList allowedFrom.map { it.name })
        }) {
            it[BaseRefundsTable.status] = RefundStatus.COMPLETED.name
            it[BaseRefundsTable.completedAt] = now
            it[BaseRefundsTable.refundProviderId] = refundProviderId
            if (gatewayMetadata != null) it[BaseRefundsTable.gatewayMetadata] = gatewayMetadata
        }
        check(moved == 1) { "refund $refundId changed concurrently" }

        // Side-effect: full refund flips the payment to REFUNDED.
        refund.paymentId?.let { paymentId ->
            val payment = payments.findById(paymentId) ?: return@let
            if (totalCompletedAgainstPayment(paymentId) >= payment.money.amount) {
                payments.markRefunded(paymentId, now)
            }
        }

        loadById(refundId)!!
    }

    open fun reject(refundId: Long, approvedBy: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            requireOpen(refundId, "reject")
            BaseRefundsTable.update({ BaseRefundsTable.id eq refundId }) {
                it[BaseRefundsTable.status] = RefundStatus.REJECTED.name
                it[BaseRefundsTable.approvedBy] = approvedBy
                it[BaseRefundsTable.rejectedAt] = now
            }
        }
    }

    open fun findById(refundId: Long): Refund? = transaction(mainDb) {
        loadById(refundId)
    }

    open fun listForOrder(orderId: Long): List<Refund> = transaction(mainDb) {
        BaseRefundsTable.selectAll()
            .where { BaseRefundsTable.orderId eq orderId }
            .orderBy(BaseRefundsTable.requestedAt to SortOrder.ASC)
            .map(Refund::fromRow)
    }

    open fun listLinesFor(refundId: Long): List<RefundItem> = transaction(mainDb) {
        BaseRefundItemsTable.selectAll()
            .where { BaseRefundItemsTable.refundId eq refundId }
            .map(RefundItem::fromRow)
    }

    /** Sum of COMPLETED refund amounts for an order — drives the display status. */
    open fun totalCompletedForOrder(orderId: Long): Long = transaction(mainDb) {
        BaseRefundsTable.selectAll()
            .where {
                (BaseRefundsTable.orderId eq orderId) and
                    (BaseRefundsTable.status eq RefundStatus.COMPLETED.name)
            }
            .sumOf { it[BaseRefundsTable.amount] }
    }

    /** Row lock on the payment, held until the surrounding transaction ends. */
    private fun lockPayment(paymentId: Long) {
        BasePaymentsTable.selectAll().where { BasePaymentsTable.id eq paymentId }.forUpdate().toList()
    }

    /** COMPLETED and REJECTED are terminal; any other status may still move. */
    private fun requireOpen(refundId: Long, action: String) {
        val status = BaseRefundsTable.selectAll().where { BaseRefundsTable.id eq refundId }
            .forUpdate().firstOrNull()?.get(BaseRefundsTable.status)?.let(RefundStatus::parse)
        check(status != RefundStatus.COMPLETED && status != RefundStatus.REJECTED) {
            "cannot $action refund $refundId: already $status"
        }
    }

    private fun totalCompletedAgainstPayment(paymentId: Long): Long = transaction(mainDb) {
        BaseRefundsTable.selectAll()
            .where {
                (BaseRefundsTable.paymentId eq paymentId) and
                    (BaseRefundsTable.status eq RefundStatus.COMPLETED.name)
            }
            .sumOf { it[BaseRefundsTable.amount] }
    }

    private fun loadById(id: Long): Refund? = BaseRefundsTable.selectAll()
        .where { BaseRefundsTable.id eq id }
        .firstOrNull()
        ?.let(Refund::fromRow)
}
