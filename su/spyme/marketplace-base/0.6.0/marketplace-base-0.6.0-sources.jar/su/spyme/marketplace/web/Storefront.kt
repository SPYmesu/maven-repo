package su.spyme.marketplace.web

import io.ktor.server.routing.Route
import su.spyme.marketplace.inventory.InventoryOrderListener
import su.spyme.marketplace.orders.OrderStatusHistoryListener

/**
 * The single entry point for hosts: mounts the whole storefront contract of
 * `docs/storefront-api.md` marked "base" (cart, orders, reviews, me, admin
 * orders, bot login) on this route.
 *
 * ```kotlin
 * routing { storefrontRoutes(deps) }
 * ```
 *
 * Also hooks two [su.spyme.marketplace.orders.state.OrderTransitionListener]s
 * into [StorefrontDeps.orderListeners] (once, even if mounted again): the
 * status history behind the order timeline, and - when [StorefrontDeps.stock]
 * is set - the stock reservation upkeep (extend on PAID, fulfil on SHIPPED,
 * release on CANCELLED).
 *
 * The routes answer with their own JSON and need no ContentNegotiation or
 * StatusPages plugin. Each group can also be mounted alone: [cartRoutes],
 * [orderRoutes], [reviewRoutes], [meRoutes], [adminOrderRoutes], [authBotRoutes].
 */
fun Route.storefrontRoutes(deps: StorefrontDeps) {
    registerListeners(deps)
    cartRoutes(deps)
    orderRoutes(deps)
    reviewRoutes(deps)
    meRoutes(deps)
    adminOrderRoutes(deps)
    authBotRoutes(deps)
    adminRoutes(deps)
    categoryRoutes(deps)
}

private fun registerListeners(deps: StorefrontDeps) {
    val listeners = deps.orderListeners
    synchronized(listeners) {
        if (!listeners.contains(HISTORY_LISTENER)) {
            listeners.register(HISTORY_LISTENER, OrderStatusHistoryListener(deps.mainDb))
        }
        val stock = deps.stock
        if (stock != null && !listeners.contains(STOCK_LISTENER)) {
            listeners.register(STOCK_LISTENER, InventoryOrderListener(stock.inventory, stock.paidHold.seconds))
        }
    }
}

private const val HISTORY_LISTENER = "storefront.history"
private const val STOCK_LISTENER = "storefront.stock"
