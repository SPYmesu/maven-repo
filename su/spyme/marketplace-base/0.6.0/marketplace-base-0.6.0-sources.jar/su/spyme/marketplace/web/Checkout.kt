package su.spyme.marketplace.web

import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.LoggerFactory
import su.spyme.marketplace.cart.BaseCartItemsTable
import su.spyme.marketplace.cart.CartItem
import su.spyme.marketplace.cart.CartOwner
import su.spyme.marketplace.orders.BaseOrderCheckoutDetailsTable
import su.spyme.marketplace.orders.NewOrderItem
import su.spyme.marketplace.orders.Order
import su.spyme.marketplace.orders.state.IllegalOrderTransitionException
import su.spyme.marketplace.orders.state.OrderStatus
import su.spyme.marketplace.orders.state.TransitionActor
import su.spyme.marketplace.payments.PaymentStatus

/** What the buyer submits to `POST /api/orders`, validated. */
internal class CheckoutRequest(
    val paymentProvider: String,
    val deliveryMethod: String,
    val contact: JsonObject,
    val address: JsonObject?,
    val comment: String?,
)

internal class PlacedOrder(val order: Order, val redirectUrl: String?)

/** Checkout, cancellation and reorder orchestration shared by the customer and admin routes. */
internal class Checkout(private val deps: StorefrontDeps) {

    private val log = LoggerFactory.getLogger(Checkout::class.java)

    /**
     * Cart -> order -> payment start.
     *
     * Everything up to the payment runs in ONE database transaction: the cart is
     * read `FOR UPDATE` (so a double submit finds it already empty), the order is
     * created, stock is reserved line by line and the order moves to
     * `AWAITING_PAYMENT`. Running out of stock on any line throws and rolls the
     * whole thing back - no half-built orders. The gateway is called afterwards,
     * outside the transaction.
     */
    suspend fun place(userId: Long, request: CheckoutRequest): PlacedOrder {
        val gateway = deps.gateways.getOrNull(request.paymentProvider)
            ?: throw badRequest("UNKNOWN_PAYMENT_PROVIDER", "Unknown payment provider")
        val delivery = deps.deliveryMethods().firstOrNull { it.code == request.deliveryMethod }
            ?: throw badRequest("UNKNOWN_DELIVERY_METHOD", "Unknown delivery method")
        if (delivery.needsAddress) {
            val a = request.address
            if (listOf("city", "street", "house").any { a?.str(it).isNullOrBlank() }) {
                throw badRequest("ADDRESS_REQUIRED", "deliveryAddress.city, street and house are required")
            }
        }
        val locale = deps.users.findById(userId)?.locale ?: "ru"

        val order = transaction(deps.mainDb) {
            val lines = BaseCartItemsTable.selectAll()
                .where { BaseCartItemsTable.userId eq userId }
                .orderBy(BaseCartItemsTable.id)
                .forUpdate()
                .map(CartItem::fromRow)
            if (lines.isEmpty()) throw badRequest("EMPTY_CART", "The cart is empty")

            val resolved = lines.map { line ->
                line to (deps.catalog.find(line.productId, line.variantId)
                    ?: throw conflict("PRODUCT_UNAVAILABLE", "A product in the cart is no longer available"))
            }
            val currency = resolved.first().second.unitPrice.currency
            check(resolved.all { it.second.unitPrice.currency == currency } && delivery.priceFor(lines.sumOf { it.quantity }).currency == currency) {
                "cart and delivery prices must share one currency"
            }
            val kinds = resolved.map { it.second.kind }.toSet()

            val created = deps.orders.createOrder(
                userId = userId,
                productKind = if (kinds.size > 1) "MIXED" else kinds.single().name,
                items = resolved.map { (line, product) ->
                    NewOrderItem(
                        productId = line.productId,
                        variantId = line.variantId,
                        vendorId = product.vendorId,
                        quantity = line.quantity,
                        unitPrice = product.unitPrice,
                        snapshotMeta = buildJsonObject {
                            product.snapshot.forEach { (k, v) -> put(k, v) }
                            put("title", product.title)
                            put("slug", product.slug)
                            put("imageUrl", product.imageUrl)
                        },
                    )
                },
                currency = currency,
                locale = locale,
                shippingAddress = request.address,
                shipping = delivery.priceFor(lines.sumOf { it.quantity }),
            )

            deps.stock?.let { stock ->
                for ((line, _) in resolved) {
                    if (stock.inventory.findStock(stock.warehouseId, line.productId, line.variantId) == null) continue
                    stock.inventory.reserveStock(
                        stock.warehouseId, line.productId, line.variantId, line.quantity,
                        stock.reservationTtl.seconds, orderId = created.id,
                    ) ?: throw conflict(
                        "OUT_OF_STOCK", "Not enough stock",
                        buildJsonObject {
                            put("productId", line.productId)
                            put("available", deps.available(line.productId, line.variantId) ?: 0)
                        },
                    )
                }
            }

            BaseOrderCheckoutDetailsTable.insert {
                it[orderId] = created.id
                it[deliveryMethodCode] = delivery.code
                it[deliveryMethodTitle] = delivery.title
                it[contact] = request.contact
                it[comment] = request.comment
            }
            BaseCartItemsTable.deleteWhere { BaseCartItemsTable.userId eq userId }
            deps.orders.transition(created.id, OrderStatus.AWAITING_PAYMENT, TransitionActor.SYSTEM)
        }

        val redirectUrl = startPayment(order, gateway)
        return PlacedOrder(deps.orders.findById(order.id)!!, redirectUrl)
    }

    /**
     * Creates the payment row and asks the gateway to initiate it. A gateway that
     * answers without a redirect has nothing left for the buyer to do, so the
     * payment is captured at once and the order moves to `PAID`; otherwise the
     * redirect URL goes back to the SPA and the gateway's webhook finishes later.
     * Any gateway failure cancels the order (releasing its stock) and answers 502.
     */
    private suspend fun startPayment(order: Order, gateway: su.spyme.marketplace.payments.PaymentGateway): String? {
        val key = "order-${order.id}-${gateway.name}"
        val payment = deps.payments.createInitiated(order.id, gateway.name, order.total, key)
        try {
            val returnUrl = deps.config.publicUrl.trimEnd('/') + deps.config.orderReturnPath.replace("{id}", order.id.toString())
            val init = gateway.initiate(order.id, order.total, key, returnUrl, mapOf("orderNumber" to order.orderNumber))
            deps.payments.setProviderPaymentId(payment.id, init.providerPaymentId)
            if (init.redirectUrl != null) return init.redirectUrl

            val capture = gateway.capture(init.providerPaymentId)
            if (!capture.captured) throw IllegalStateException(capture.failureReason ?: "capture refused")
            deps.payments.markCaptured(payment.id, capture.gatewayMetadata)
            deps.orders.transition(order.id, OrderStatus.PAID, TransitionActor.PAYMENT_GATEWAY)
            return null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            log.warn("payment for order {} failed: {}", order.id, e.message)
            deps.payments.markFailed(payment.id, e.message ?: e.javaClass.simpleName)
            runCatching { deps.orders.cancel(order.id, "PAYMENT_FAILED", e.message?.take(500), TransitionActor.SYSTEM) }
            throw ApiException(HttpStatusCode.BadGateway, "PAYMENT_FAILED", "Payment could not be started")
        }
    }

    /**
     * Cancels [order] and abandons its unfinished payments. [reason] is a
     * cancellation-reason code, or free text (stored as [freeTextCode] + text).
     * Stock goes back through the order listeners.
     */
    suspend fun cancel(
        order: Order, actor: TransitionActor, actorUserId: Long,
        reason: String?, freeTextCode: String,
    ): Order {
        val (code, text) = resolveReason(reason, freeTextCode)
        val cancelled = try {
            deps.orders.cancel(order.id, code, text, actor, actorUserId)
        } catch (e: IllegalOrderTransitionException) {
            throw conflict("INVALID_TRANSITION", e.why)
        } catch (e: IllegalArgumentException) {
            throw badRequest("BAD_REASON", e.message ?: "bad reason")
        }
        for (p in deps.payments.listForOrder(order.id)) {
            if (p.status != PaymentStatus.INITIATED && p.status != PaymentStatus.AUTHORIZED) continue
            val gateway = deps.gateways.getOrNull(p.provider)
            val providerId = p.providerPaymentId
            if (gateway != null && providerId != null) {
                try {
                    gateway.cancel(providerId)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    log.warn("gateway cancel failed for payment {}: {}", p.id, e.message)
                }
            }
            deps.payments.markCancelled(p.id)
        }
        return cancelled
    }

    /** Puts the order's lines back into the buyer's cart (lines no longer sold are skipped). */
    fun reorder(userId: Long, order: Order) {
        val reason = order.cancellationReasonCode?.let { deps.cancellationReasons.getOrNull(it) }
        if (reason?.blocksReorder == true) throw conflict("REORDER_BLOCKED", "This order cannot be repeated")
        for (item in deps.orders.listItems(order.id)) {
            if (deps.catalog.find(item.productId, item.variantId) == null) continue
            deps.cart.addItem(CartOwner.User(userId), item.productId, item.variantId, item.quantity)
        }
    }

    /** A registered reason code is used as-is; anything else is free text filed under [freeTextCode]. */
    fun resolveReason(input: String?, freeTextCode: String): Pair<String, String?> {
        val text = input?.trim()?.takeIf { it.isNotEmpty() }?.take(500) ?: return freeTextCode to null
        return if (deps.cancellationReasons.isValid(text)) text to null else freeTextCode to text
    }
}
