package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import su.spyme.marketplace.auth.bots.BotAuthService
import su.spyme.marketplace.auth.bots.BotPlatform
import su.spyme.marketplace.auth.bots.CodeLogin
import java.time.Duration

/**
 * Login through the shop's Telegram / VK bot. The SPA already speaks the
 * moonstudio shapes, which these follow (with a few extra fields, see
 * `docs/storefront-api.md`):
 *
 *  - `GET  /api/auth/login-modes`
 *  - `POST /api/auth/code/start` `{platform}` - site-issued code for the user to send to the bot
 *  - `POST /api/auth/code/poll` `{code}` - `PENDING`, or `REDEEMED` + session cookie
 *  - `POST /api/auth/code-login` `{code}` - spends a code the bot handed out, sets the cookie
 *  - `POST /api/auth/logout`
 *
 * Codes are single-use and short-lived; the endpoints are rate-limited per client IP.
 */
fun Route.authBotRoutes(deps: StorefrontDeps) {
    val web = deps.web

    endpoint(HttpMethod.Get, "/api/auth/login-modes") {
        val cfg = deps.botAuth?.config
        val platforms = BotPlatform.entries.filter { cfg?.isEnabled(it) == true }
        respondJson(buildJsonObject {
            for (p in BotPlatform.entries) put(p.code, cfg?.modeOf(p)?.wire ?: "bot_to_user")
            cfg?.telegram?.let { put("tgBotUsername", it.botUsername) }
            cfg?.vk?.let { put("vkGroupScreenName", it.screenName) }
            put("emailEnabled", false)
            put("modes", JsonArray(platforms.map { p ->
                buildJsonObject {
                    put("platform", if (p == BotPlatform.TELEGRAM) "telegram" else p.code)
                    put("botName", cfg?.botName(p))
                    put("botUrl", cfg?.botUrl(p))
                    put("mode", cfg?.modeOf(p)?.wire)
                }
            }))
        })
    }

    endpoint(HttpMethod.Post, "/api/auth/code/start") {
        val bots = bots(deps)
        throttle(deps, "start", 10)
        val platform = platformOf(bots, jsonBody().str("platform"))
        val issued = bots.startWebLogin(platform)
        val url = bots.config.botUrl(platform)
        respondJson(buildJsonObject {
            put("code", issued.code)
            put("token", issued.code)
            put("expiresAt", issued.expiresAt.toJson())
            put("deepLink", if (platform == BotPlatform.TELEGRAM) "$url?start=${issued.code}" else url)
        })
    }

    endpoint(HttpMethod.Post, "/api/auth/code/poll") {
        val bots = bots(deps)
        throttle(deps, "poll", 120)
        val code = jsonBody().let { it.str("code") ?: it.str("token") } ?: throw badRequest("CODE_REQUIRED", "code is required")
        when (val r = bots.pollWebLogin(code)) {
            CodeLogin.Pending -> respondJson(buildJsonObject { put("status", "PENDING") })
            is CodeLogin.Success -> respondJson(signedIn(deps, this, r.userId, "REDEEMED"))
            CodeLogin.Expired -> throw ApiException(HttpStatusCode.Gone, "CODE_EXPIRED", "The code has expired")
            CodeLogin.Invalid -> throw notFound("CODE_INVALID")
        }
    }

    endpoint(HttpMethod.Post, "/api/auth/code-login") {
        val bots = bots(deps)
        throttle(deps, "login", 10)
        val code = jsonBody().str("code")?.trim()?.takeIf { it.isNotEmpty() } ?: throw badRequest("CODE_REQUIRED", "code is required")
        when (val r = bots.redeemLoginCode(code)) {
            is CodeLogin.Success -> respondJson(signedIn(deps, this, r.userId, null))
            CodeLogin.Expired -> throw ApiException(HttpStatusCode.Gone, "CODE_EXPIRED", "The code has expired")
            CodeLogin.Pending, CodeLogin.Invalid -> throw notFound("CODE_INVALID")
        }
    }

    endpoint(HttpMethod.Post, "/api/auth/logout") {
        web.sessions.signOut(this)
        respondJson(okJson())
    }
}

private fun bots(deps: StorefrontDeps): BotAuthService =
    deps.botAuth ?: throw ApiException(HttpStatusCode.ServiceUnavailable, "BOTS_DISABLED", "No bot is configured")

/** Per-IP fixed budget of [perMinute] calls to one auth endpoint; 429 beyond it. */
private fun ApplicationCall.throttle(deps: StorefrontDeps, bucket: String, perMinute: Int) {
    val key = "auth:$bucket:${deps.web.sessions.clientIp(this)}"
    if (!deps.rateLimits.tryAcquire(key, perMinute, Duration.ofMinutes(1)).allowed) {
        throw ApiException(HttpStatusCode.TooManyRequests, "RATE_LIMITED", "Too many attempts, try again later")
    }
}

/** Opens the session and builds the `{userId, username, ...}` answer. */
private fun signedIn(deps: StorefrontDeps, call: ApplicationCall, userId: Long, status: String?): JsonObject {
    deps.web.sessions.signIn(call, userId)
    val user = deps.users.findById(userId)!!
    return buildJsonObject {
        put("ok", true)
        if (status != null) put("status", status)
        put("userId", userId)
        put("username", user.username)
        put("user", buildJsonObject { put("id", user.id); put("username", user.username) })
    }
}
