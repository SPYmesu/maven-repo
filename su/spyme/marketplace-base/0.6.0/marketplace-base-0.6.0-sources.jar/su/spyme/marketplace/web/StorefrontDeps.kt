package su.spyme.marketplace.web

import kotlinx.serialization.json.JsonObject
import org.jetbrains.exposed.sql.Database
import su.spyme.marketplace.audit.AuditServiceBase
import su.spyme.marketplace.auth.bots.BotAuthService
import su.spyme.marketplace.auth.social.SocialLinksService
import su.spyme.marketplace.bookmarks.BookmarksServiceBase
import su.spyme.marketplace.cart.CartServiceBase
import su.spyme.marketplace.catalog.categories.CategoriesServiceBase
import su.spyme.marketplace.catalog.products.ProductKind
import su.spyme.marketplace.core.BaseConfig
import su.spyme.marketplace.core.Money
import su.spyme.marketplace.core.auth.AuthService
import su.spyme.marketplace.core.auth.RoleRegistry
import su.spyme.marketplace.core.ratelimit.CaffeineRateLimitStore
import su.spyme.marketplace.core.ratelimit.RateLimitStore
import su.spyme.marketplace.inventory.InventoryServiceBase
import su.spyme.marketplace.notifications.InAppNotificationsService
import su.spyme.marketplace.notifications.UserNotifyChannelsService
import su.spyme.marketplace.orders.OrdersServiceBase
import su.spyme.marketplace.orders.cancellation.CancellationReasonRegistry
import su.spyme.marketplace.orders.state.OrderTransitionListenerRegistry
import su.spyme.marketplace.payments.PaymentGatewayRegistry
import su.spyme.marketplace.payments.PaymentsServiceBase
import su.spyme.marketplace.refunds.RefundsServiceBase
import su.spyme.marketplace.reviews.ReviewsServiceBase
import su.spyme.marketplace.shipping.ShippingServiceBase
import su.spyme.marketplace.users.UserSessionsService
import su.spyme.marketplace.users.UsersServiceBase
import java.time.Duration

/**
 * One entry of the admin sidebar. `GET /api/admin/sections` returns the ids whose
 * [minRole] the caller holds, so the SPA only shows what its user may open.
 */
data class AdminSection(val id: String, val minRole: String) {
    companion object {
        /** What the base routes serve: orders, users, audit. */
        val DEFAULTS = listOf(
            AdminSection("users", "MANAGER"),
            AdminSection("orders", "MANAGER"),
            AdminSection("audit", "ADMIN"),
        )
    }
}

/**
 * A way to receive the goods, offered at checkout.
 *
 * @property price flat price added to the order total (as `orders.shipping_amount`);
 *           must be in the shop currency. Ignored when [pricePerItem] is set.
 * @property pricePerItem optional per-item price; the cost of an order is then
 *           `pricePerItem * total item quantity` (see [priceFor]).
 * @property eta optional human delivery-time text, e.g. "3-7 days".
 * @property needsAddress whether `deliveryAddress` is mandatory for this method
 *           (false for pickup).
 */
data class DeliveryMethod(
    val code: String,
    val title: String,
    val description: String?,
    val price: Money,
    val needsAddress: Boolean,
    val pricePerItem: Money? = null,
    val eta: String? = null,
) {
    /**
     * Delivery cost for [quantity] items in total: `pricePerItem * quantity` when
     * [pricePerItem] is set, else the flat [price]. Pure, so hosts reuse it for
     * calculators. The cart view and checkout both go through it.
     */
    fun priceFor(quantity: Int): Money = pricePerItem?.times(quantity) ?: price
}

/**
 * What the storefront needs to know about one purchasable thing. The host's
 * catalog decides the title (an auto shop builds it from brand and model), the
 * image and the price, so none of that is hard-wired into the library.
 *
 * @property snapshot extra host fields frozen into `order_item_snapshots` next
 *           to `title`, `slug` and `imageUrl` (brand, SKU, ...); returned
 *           verbatim as `snapshot` on the order item.
 * @property variantLabel human text of the chosen variant, shown in the cart.
 */
data class StorefrontProduct(
    val productId: Long,
    val variantId: Long?,
    val slug: String,
    val title: String,
    val imageUrl: String?,
    val unitPrice: Money,
    val kind: ProductKind,
    val vendorId: Long? = null,
    val variantLabel: String? = null,
    val snapshot: JsonObject = JsonObject(emptyMap()),
)

/** The host's view of its catalog, as far as cart, checkout and reviews need it. */
interface StorefrontCatalog {
    /**
     * The purchasable product (or variant of it), or null when it does not exist
     * or may not be bought (unpublished, archived). Cart lines whose product
     * resolves to null are dropped from the cart view.
     */
    fun find(productId: Long, variantId: Long? = null): StorefrontProduct?

    /** Same as [find] for the product page slug (base product, no variant). */
    fun findBySlug(slug: String): StorefrontProduct?
}

/**
 * Turns on stock control. Products that have a `stock_levels` row in
 * [warehouseId] are tracked: adding to the cart is capped at what is available,
 * checkout reserves the stock atomically (no oversell), cancel releases it and
 * shipping fulfils it. Products without a row are treated as unlimited.
 *
 * @property reservationTtl how long an unpaid order holds stock; the cron sweep
 *           ([InventoryServiceBase.releaseExpiredReservations]) frees it afterwards.
 * @property paidHold how long a paid order keeps its hold while waiting to ship.
 */
data class StockTracking(
    val inventory: InventoryServiceBase,
    val warehouseId: Long,
    val reservationTtl: Duration = Duration.ofMinutes(30),
    val paidHold: Duration = Duration.ofDays(3650),
)

/**
 * Plain settings of the route set.
 *
 * @property publicUrl base URL of the site; payment return URLs are built from it.
 * @property orderReturnPath where a gateway sends the buyer back, `{id}` is the order id.
 * @property adminRole minimum role for the admin routes.
 * @property autoApproveReviews publish reviews immediately instead of waiting
 *           for moderation (hosts without a moderation screen).
 * @property placeholderEmailDomain addresses at this domain (bot-created
 *           accounts) are not shown as the user's email.
 * @property secureCookies force the `Secure` flag; null decides per request from the scheme.
 * @property defaultLocale locale used for category names when the request names none that exist.
 * @property superRole minimum role to change roles, ban/restore users and use the audit log.
 */
data class StorefrontConfig(
    val publicUrl: String,
    val currency: String = "RUB",
    val authCookieName: String = "mp_session",
    val cartCookieName: String = "mp_cart",
    val cartCookieMaxAge: Duration = Duration.ofDays(30),
    val orderReturnPath: String = "/#/orders/{id}",
    val adminRole: String = "MANAGER",
    val autoApproveReviews: Boolean = false,
    val placeholderEmailDomain: String = "bot.invalid",
    val secureCookies: Boolean? = null,
    val defaultLocale: String = "ru",
    val superRole: String = "ADMIN",
)

/**
 * Everything [storefrontRoutes] needs, built once by the host from the services
 * it already constructs for bootstrap. The library never constructs services
 * itself, so a host that subclasses (`OrdersServiceBase`, `CartServiceBase`, ...)
 * keeps its overrides in effect.
 *
 * Host-specific inputs are [catalog], [deliveryMethods] and [stock]; everything
 * else is a library service. [botAuth] may be null when login happens elsewhere
 * (the bot login and link routes then answer 503 / are empty).
 */
class StorefrontDeps(
    val config: StorefrontConfig,
    val authConfig: BaseConfig.Auth,
    val mainDb: Database,
    val users: UsersServiceBase,
    val roles: RoleRegistry,
    val auth: AuthService,
    val sessions: UserSessionsService,
    val cart: CartServiceBase,
    val orders: OrdersServiceBase,
    /** The registry [orders] fires; the route set adds its history/stock listeners to it. */
    val orderListeners: OrderTransitionListenerRegistry,
    val cancellationReasons: CancellationReasonRegistry,
    val payments: PaymentsServiceBase,
    val gateways: PaymentGatewayRegistry,
    val refunds: RefundsServiceBase,
    val shipping: ShippingServiceBase,
    val reviews: ReviewsServiceBase,
    val bookmarks: BookmarksServiceBase,
    val notifications: InAppNotificationsService,
    val notifyChannels: UserNotifyChannelsService,
    val social: SocialLinksService,
    val catalog: StorefrontCatalog,
    /** Called on every cart view and checkout, so prices may change at runtime. */
    val deliveryMethods: () -> List<DeliveryMethod>,
    val botAuth: BotAuthService? = null,
    val stock: StockTracking? = null,
    /** Throttles login-code endpoints per client IP. */
    val rateLimits: RateLimitStore = CaffeineRateLimitStore(),
    /** Audit log used by the admin routes; pass the host's instance when it registers its own undo appliers. */
    val audit: AuditServiceBase = AuditServiceBase(mainDb),
    val categories: CategoriesServiceBase = CategoriesServiceBase(mainDb),
    /** Sections `GET /api/admin/sections` offers; hosts add theirs: `AdminSection.DEFAULTS + AdminSection("inventory", "MANAGER")`. */
    val adminSections: List<AdminSection> = AdminSection.DEFAULTS,
) {
    internal val web: WebContext by lazy { WebContext(this) }
}
