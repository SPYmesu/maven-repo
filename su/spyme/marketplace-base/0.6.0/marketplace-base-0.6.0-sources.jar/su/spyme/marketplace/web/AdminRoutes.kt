package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.exceptions.ExposedSQLException
import su.spyme.marketplace.audit.AlreadyRevertedException
import su.spyme.marketplace.audit.AuditLogEntry
import su.spyme.marketplace.audit.AuditServiceBase
import su.spyme.marketplace.audit.IrreversibleActionException
import su.spyme.marketplace.audit.UndoTooOldException
import su.spyme.marketplace.users.User
import java.time.Instant

/** Entity type the user-management audit entries are filed under. */
const val USER_AUDIT_ENTITY = "USER"

/**
 * Admin sidebar, user management and the audit log - what the SPA's
 * `pages/admin/{index,users,audit}.js` call:
 *
 *  - `GET  /api/admin/sections` - `{allowed: [ids]}`: [StorefrontDeps.adminSections]
 *    whose `minRole` the caller holds (401 guest, 403 below [StorefrontConfig.adminRole]).
 *  - users (list: [StorefrontConfig.adminRole]+; changes: [StorefrontConfig.superRole]):
 *    `GET /api/admin/users?query=&role=&offset=&limit=`, `PATCH /api/admin/users/{id}`
 *    (`role` | `roles`, `displayName`), `DELETE` (soft-delete: bans, ends sessions),
 *    `POST .../restore`, `POST .../bump-jwt`.
 *  - audit ([StorefrontConfig.superRole]): `GET /api/admin/audit`, `GET .../{id}`,
 *    `POST .../{id}/undo`, `POST .../bulk-undo`.
 *
 * Safeguards: nobody can lower their own access or ban themselves; a role change
 * bumps `jwt_version` and ends the user's sessions; every change is audited under
 * [USER_AUDIT_ENTITY] with before/after snapshots, and an undo applier for that
 * entity type is registered on [StorefrontDeps.audit] (once).
 */
fun Route.adminRoutes(deps: StorefrontDeps) {
    val web = deps.web
    registerUserUndo(deps)

    endpoint(HttpMethod.Get, "/api/admin/sections") {
        val user = web.sessions.requireStaff(this)
        val allowed = deps.adminSections.filter { deps.roles.hasAtLeast(user.roles, it.minRole) }.map { it.id }
        respondJson(buildJsonObject { put("allowed", JsonArray(allowed.map { JsonPrimitive(it) })) })
    }

    // ---- users ----

    endpoint(HttpMethod.Get, "/api/admin/users") {
        web.sessions.requireStaff(this)
        val (offset, limit) = page(defaultLimit = 50, maxLimit = 200)
        val (rows, total) = deps.users.search(
            query = request.queryParameters["query"] ?: request.queryParameters["q"],
            role = request.queryParameters["role"],
            offset = offset.toLong(), limit = limit,
        )
        respondJson(pageJson(rows.map { adminUserJson(deps, it) }, total, offset, limit))
    }

    endpoint(HttpMethod.Patch, "/api/admin/users/{id}") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val target = targetUser(deps, this)
        val body = jsonBody()
        val before = userSnapshot(target)

        val newRoles: List<String>? = when {
            body["roles"] != null -> (body["roles"] as? JsonArray)?.map { (it as? JsonPrimitive)?.content.orEmpty() }
                ?: throw badRequest("BAD_ROLE", "roles must be an array of role codes")
            body.str("role") != null -> listOf(body.str("role")!!)
            else -> null
        }
        if (newRoles != null) {
            if (newRoles.isEmpty() || newRoles.any { !deps.roles.isValid(it) }) {
                throw badRequest("BAD_ROLE", "Unknown or empty role set")
            }
            val demotesSelf = target.id == admin.id && !deps.roles.hasAtLeast(newRoles, deps.config.superRole)
            if (demotesSelf) throw conflict("SELF_DEMOTION", "You cannot lower your own access")
        }
        val displayName = if (body.containsKey("displayName")) parseDisplayName(body["displayName"]) else null
        if (newRoles == null && !body.containsKey("displayName")) throw badRequest("NOTHING_TO_UPDATE", "Send role, roles or displayName")

        val rolesChanged = newRoles != null && newRoles.toSet() != target.roles.toSet()
        if (newRoles != null && rolesChanged) deps.users.assignRoles(target.id, newRoles)
        if (body.containsKey("displayName")) deps.users.setDisplayName(target.id, displayName)
        // Roles are re-read per request, but a changed role set must also end existing sessions.
        if (rolesChanged) deps.auth.logoutEverywhere(target.id)

        val updated = deps.users.findById(target.id, includeDeleted = true)!!
        audit(deps, this, admin, if (rolesChanged) "USER_ROLES_CHANGE" else "USER_UPDATE", target.id, before, userSnapshot(updated))
        respondJson(adminUserJson(deps, updated))
    }

    endpoint(HttpMethod.Delete, "/api/admin/users/{id}") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val target = targetUser(deps, this)
        if (target.id == admin.id) throw conflict("SELF_BAN", "You cannot delete your own account")
        val before = userSnapshot(target)
        if (!target.isDeleted) {
            deps.users.softDelete(target.id)
            deps.auth.logoutEverywhere(target.id)
            audit(deps, this, admin, "USER_DELETE", target.id, before, userSnapshot(deps.users.findById(target.id, true)!!))
        }
        respondJson(okJson())
    }

    endpoint(HttpMethod.Post, "/api/admin/users/{id}/restore") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val target = targetUser(deps, this)
        if (target.mergedIntoUserId != null) throw conflict("MERGED", "This account was merged into user ${target.mergedIntoUserId}")
        val before = userSnapshot(target)
        if (target.isDeleted) {
            try {
                deps.users.restoreDeleted(target.id)
            } catch (e: ExposedSQLException) {
                // The username / email was taken by a newer account in the meantime.
                if (e.sqlState == "23505") throw conflict("IDENTITY_TAKEN", "Username or email is used by another account") else throw e
            }
            audit(deps, this, admin, "USER_RESTORE", target.id, before, userSnapshot(deps.users.findById(target.id, true)!!))
        }
        respondJson(okJson())
    }

    endpoint(HttpMethod.Post, "/api/admin/users/{id}/bump-jwt") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val target = targetUser(deps, this)
        deps.auth.logoutEverywhere(target.id)
        // Ending sessions cannot be undone, so the entry is not reversible.
        audit(deps, this, admin, "USER_BUMP_JWT", target.id, null, null, reversible = false)
        respondJson(okJson())
    }

    // ---- audit ----

    endpoint(HttpMethod.Get, "/api/admin/audit") {
        web.sessions.requireRole(this, deps.config.superRole)
        val (offset, limit) = page(defaultLimit = 50, maxLimit = 200)
        val q = request.queryParameters
        val actorIds = q["actor"]?.trim()?.takeIf { it.isNotEmpty() }?.let { raw ->
            raw.toLongOrNull()?.let { listOf(it) } ?: deps.users.search(raw, null, 0, 50).first.map { it.id }
        }
        val (entityType, entityId) = parseEntity(q["entity"])
        val (rows, total) = deps.audit.search(
            actorUserIds = actorIds, entityType = entityType, entityId = entityId,
            action = q["action"]?.trim()?.takeIf { it.isNotEmpty() },
            from = parseInstant(q["from"]), to = parseInstant(q["to"]),
            offset = offset.toLong(), limit = limit,
        )
        respondJson(pageJson(rows.map { auditJson(deps, it, detail = false) }, total, offset, limit))
    }

    endpoint(HttpMethod.Get, "/api/admin/audit/{id}") {
        web.sessions.requireRole(this, deps.config.superRole)
        val entry = parameters["id"]?.toLongOrNull()?.let { deps.audit.findById(it) } ?: throw notFound("AUDIT_NOT_FOUND")
        respondJson(auditJson(deps, entry, detail = true))
    }

    endpoint(HttpMethod.Post, "/api/admin/audit/{id}/undo") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val id = parameters["id"]?.toLongOrNull() ?: throw notFound("AUDIT_NOT_FOUND")
        val undo = try {
            deps.audit.undo(id, actorUserId = admin.id)
        } catch (e: IllegalArgumentException) {
            throw notFound("AUDIT_NOT_FOUND")
        } catch (e: IrreversibleActionException) {
            throw conflict("IRREVERSIBLE", "This action cannot be undone")
        } catch (e: AlreadyRevertedException) {
            throw conflict("ALREADY_REVERTED", "Already undone")
        } catch (e: UndoTooOldException) {
            throw conflict("UNDO_TOO_OLD", "Too old to undo")
        } catch (e: IllegalStateException) {
            // No applier for the entity type, or the entry carries no snapshot.
            throw conflict("UNDO_UNAVAILABLE", e.message ?: "Undo is not available for this entry")
        }
        respondJson(buildJsonObject { put("ok", true); put("undoAuditId", undo.id) })
    }

    endpoint(HttpMethod.Post, "/api/admin/audit/bulk-undo") {
        val admin = web.sessions.requireRole(this, deps.config.superRole)
        val body = jsonBody()
        val actor = body.long("actorUserId") ?: throw badRequest("BAD_ACTOR", "actorUserId is required")
        val from = parseInstant(body.str("fromTimestamp")) ?: throw badRequest("BAD_TIMESTAMP", "fromTimestamp is required (ISO-8601)")
        val report = deps.audit.bulkUndo(actor, from, actorOfUndo = admin.id)
        respondJson(buildJsonObject {
            put("undoneCount", report.succeeded.size)
            put("undone", JsonArray(report.succeeded.map { JsonPrimitive(it) }))
            put("failed", JsonArray(report.failed.map { buildJsonObject { put("auditId", it.auditId); put("reason", it.reason) } }))
        })
    }
}

// ---- helpers ----

private fun targetUser(deps: StorefrontDeps, call: ApplicationCall): User =
    call.parameters["id"]?.toLongOrNull()?.let { deps.users.findById(it, includeDeleted = true) } ?: throw notFound("USER_NOT_FOUND")

private fun highestRole(deps: StorefrontDeps, roles: List<String>): String =
    roles.mapNotNull { deps.roles.getOrNull(it) }.maxByOrNull { it.level }?.code ?: "USER"

private fun adminUserJson(deps: StorefrontDeps, u: User): JsonObject = buildJsonObject {
    put("id", u.id)
    put("email", u.email)
    put("username", u.username)
    put("displayName", u.displayName)
    put("role", highestRole(deps, u.roles))
    put("roles", JsonArray(u.roles.map { JsonPrimitive(it) }))
    put("emailVerified", u.isEmailVerified)
    put("createdAt", u.createdAt.toJson())
    put("lastActiveAt", u.lastActiveAt.toJson())
    put("deletedAt", u.deletedAt.toJson())
}

private fun userSnapshot(u: User): JsonObject = buildJsonObject {
    put("roles", JsonArray(u.roles.map { JsonPrimitive(it) }))
    put("displayName", u.displayName)
    put("deleted", u.isDeleted)
}

private fun audit(
    deps: StorefrontDeps, call: ApplicationCall, admin: User, action: String, userId: Long,
    before: JsonElement?, after: JsonElement?, reversible: Boolean = true,
) {
    deps.audit.log(
        action = action, entityType = USER_AUDIT_ENTITY, entityId = userId,
        actorUserId = admin.id, actorRole = highestRole(deps, admin.roles),
        actorIp = deps.web.sessions.ipLiteral(call),
        actorUserAgent = call.request.headers["User-Agent"]?.take(255),
        snapshotBefore = before, snapshotAfter = after, isReversible = reversible,
    )
}

/** Undo for [USER_AUDIT_ENTITY] entries: puts roles, display name and deleted flag back. */
private fun registerUserUndo(deps: StorefrontDeps) {
    synchronized(deps.audit) {
        if (deps.audit.hasApplier(USER_AUDIT_ENTITY)) return
        deps.audit.registerApplier(USER_AUDIT_ENTITY) { id, before ->
            val snap = before as? JsonObject ?: error("user snapshot must be an object")
            val current = deps.users.findById(id, includeDeleted = true) ?: error("user $id no longer exists")
            val roles = (snap["roles"] as? JsonArray)?.map { (it as? JsonPrimitive)?.content.orEmpty() }
            var sessionsEnded = false
            if (roles != null && roles.toSet() != current.roles.toSet()) {
                deps.users.assignRoles(id, roles)
                sessionsEnded = true
            }
            if (snap.containsKey("displayName")) deps.users.setDisplayName(id, snap.str("displayName"))
            when ((snap["deleted"] as? JsonPrimitive)?.content) {
                "true" -> if (!current.isDeleted) { deps.users.softDelete(id); sessionsEnded = true }
                "false" -> if (current.isDeleted) deps.users.restoreDeleted(id)
            }
            if (sessionsEnded) deps.auth.logoutEverywhere(id)
            emptyMap()
        }
    }
}

/** `Type`, `Type#id` or a bare numeric id. */
private fun parseEntity(raw: String?): Pair<String?, Long?> {
    val s = raw?.trim()?.takeIf { it.isNotEmpty() } ?: return null to null
    s.toLongOrNull()?.let { return null to it }
    val type = s.substringBefore('#').takeIf { it.isNotBlank() }
    return type to s.substringAfter('#', "").toLongOrNull()
}

private fun parseInstant(raw: String?): Instant? =
    raw?.trim()?.takeIf { it.isNotEmpty() }?.let {
        runCatching { Instant.parse(it) }.getOrNull() ?: throw badRequest("BAD_TIMESTAMP", "Expected an ISO-8601 instant: $it")
    }

private fun auditJson(deps: StorefrontDeps, e: AuditLogEntry, detail: Boolean): JsonObject = buildJsonObject {
    put("id", e.id)
    put("createdAt", e.createdAt.toJson())
    put("actorUserId", e.actorUserId)
    put("actorUserEmail", e.actorUserId?.let { deps.users.findById(it, includeDeleted = true)?.email })
    put("actorRole", e.actorRole)
    put("action", e.action)
    put("entityType", e.entityType)
    put("entityId", e.entityId)
    put("irreversible", !e.isReversible)
    put("revertedAt", e.revertedAt.toJson())
    put("maxUndoAgeDays", deps.audit.maxUndoAgeDays)
    if (detail) {
        put("actorIp", e.actorIp)
        put("parentAuditId", e.parentAuditId)
        put("revertedAuditId", e.revertedAuditId)
        put("snapshotBefore", e.entitySnapshotBefore ?: JsonNull)
        put("snapshotAfter", e.entitySnapshotAfter ?: JsonNull)
    }
}
