package su.spyme.marketplace.gdpr

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.VarCharColumnType
import org.jetbrains.exposed.sql.statements.StatementType
import org.jetbrains.exposed.sql.transactions.transaction

/**
 * Built-in scrubber for everything a user can authenticate with: password
 * hash, TOTP secret and recovery codes, social links, OAuth tokens, WebAuthn
 * credentials and challenges, sessions and one-time codes. Deleting the
 * `users` row's PII alone ([UserRowScrubber]) leaves these behind, and the
 * soft-deleted user would still be able to sign in with them.
 *
 * API keys scoped to the user are revoked rather than deleted (the audit
 * trail of what the key did stays intact; the key itself no longer verifies).
 *
 * The archive snapshot holds row counts and the identifiers of the social
 * accounts that were linked; secrets (hashes, TOTP seeds, tokens) are never
 * written to it.
 *
 * Register it **before** [UserRowScrubber]: one-time codes addressed to the
 * user's email or phone are matched through the users row, which the user
 * scrubber anonymizes.
 */
class AuthDataScrubber : DeletionScrubber {
    override val name = "auth"

    override fun scrub(userId: Long, mainDb: Database): JsonObject = transaction(mainDb) {
        val social = exec(
            "SELECT provider, external_id, display_name FROM social_links WHERE user_id = $userId ORDER BY id",
            explicitStatementType = StatementType.SELECT,
        ) { rs ->
            buildList {
                while (rs.next()) {
                    add(buildJsonObject {
                        put("provider", JsonPrimitive(rs.getString(1)))
                        put("external_id", JsonPrimitive(rs.getString(2)))
                        put("display_name", JsonPrimitive(rs.getString(3)))
                    })
                }
            }
        }.orEmpty()

        val counts = linkedMapOf<String, Long>()
        for (table in DELETE_BY_USER_ID) {
            counts[table] = countDeleted("DELETE FROM $table WHERE user_id = $userId RETURNING 1")
        }

        val contacts = exec(
            "SELECT email, phone FROM users WHERE id = $userId",
            explicitStatementType = StatementType.SELECT,
        ) { rs -> if (rs.next()) listOfNotNull(rs.getString(1), rs.getString(2)) else emptyList() }.orEmpty()
        val otpSql = buildString {
            append("DELETE FROM otp_codes WHERE user_id = $userId")
            repeat(contacts.size) { append(" OR lower(recipient) = lower(?)") }
            append(" RETURNING 1")
        }
        counts["otp_codes"] = countDeleted(otpSql, contacts.map { VarCharColumnType() to it })

        counts["api_keys_revoked"] = countDeleted(
            "UPDATE api_keys SET revoked_at = NOW() " +
                "WHERE scope_user_id = $userId AND revoked_at IS NULL RETURNING 1",
        )

        buildJsonObject {
            put("social_links", JsonArray(social))
            put("deleted_rows", buildJsonObject { counts.forEach { (k, v) -> put(k, JsonPrimitive(v)) } })
        }
    }

    private fun org.jetbrains.exposed.sql.Transaction.countDeleted(
        dml: String,
        args: List<Pair<VarCharColumnType, String>> = emptyList(),
    ): Long = exec(
        "WITH affected AS ($dml) SELECT count(*) FROM affected",
        args,
        StatementType.SELECT,
    ) { rs -> if (rs.next()) rs.getLong(1) else 0L } ?: 0L

    private companion object {
        val DELETE_BY_USER_ID = listOf(
            "password_credentials",
            "totp_recovery_codes",
            "totp_secrets",
            "social_links",
            "oauth_tokens",
            "webauthn_credentials",
            "webauthn_challenges",
            "user_sessions",
        )
    }
}
