package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import su.spyme.marketplace.cart.CartOwner
import su.spyme.marketplace.core.Money

/** Available quantity of a tracked product, null when stock is not tracked for it. */
internal fun StorefrontDeps.available(productId: Long, variantId: Long?): Int? =
    stock?.let { it.inventory.findStock(it.warehouseId, productId, variantId)?.available }

internal fun StorefrontDeps.paymentProvidersJson() = JsonArray(
    gateways.all().map { g -> buildJsonObject { put("code", g.name); put("title", g.title) } },
)

/** [quantity] = total items in the cart; `price` is the cost for that cart. */
internal fun DeliveryMethod.toJson(quantity: Int) = buildJsonObject {
    put("code", code)
    put("title", title)
    put("description", description)
    put("eta", eta)
    put("price", priceFor(quantity).toJson())
    pricePerItem?.let { put("pricePerItem", it.toJson()) }
    put("needsAddress", needsAddress)
}

/** `GET /api/cart` body for [owner] (null = guest without a cart yet). Lines whose product vanished are dropped. */
internal fun StorefrontDeps.cartJson(owner: CartOwner?): JsonObject {
    val items = mutableListOf<JsonObject>()
    var total = Money(0, config.currency)
    var count = 0
    for (line in owner?.let { cart.list(it) }.orEmpty().sortedBy { it.id }) {
        val product = catalog.find(line.productId, line.variantId)
        if (product == null) {
            cart.removeItem(owner!!, line.id)
            continue
        }
        val lineTotal = product.unitPrice * line.quantity
        total = if (items.isEmpty()) lineTotal else total + lineTotal
        count += line.quantity
        items += buildJsonObject {
            put("id", line.id)
            put("productId", line.productId)
            put("variantId", line.variantId)
            put("slug", product.slug)
            put("title", product.title)
            put("imageUrl", product.imageUrl)
            put("quantity", line.quantity)
            put("unitPrice", product.unitPrice.toJson())
            put("lineTotal", lineTotal.toJson())
            put("variant", product.variantLabel)
            put("available", available(line.productId, line.variantId)?.let { JsonPrimitive(it) } ?: JsonNull)
        }
    }
    return buildJsonObject {
        put("items", JsonArray(items))
        put("count", count)
        put("total", total.toJson())
        put("paymentProviders", paymentProvidersJson())
        put("deliveryMethods", JsonArray(deliveryMethods().map { it.toJson(count) }))
    }
}

/**
 * Cart endpoints. Guests are tracked by the HttpOnly `mp_cart` cookie (started
 * on the first add); signed-in users use their own cart. `POST /api/cart/merge`
 * folds the guest cart into the user's right after login.
 */
fun Route.cartRoutes(deps: StorefrontDeps) {
    val web = deps.web

    endpoint(HttpMethod.Get, "/api/cart") {
        respondJson(deps.cartJson(web.sessions.cartOwner(this)))
    }

    endpoint(HttpMethod.Post, "/api/cart/items") {
        val body = jsonBody()
        val quantity = body.int("quantity") ?: 1
        if (quantity !in 1..MAX_QUANTITY) throw badRequest("BAD_QUANTITY", "quantity must be 1..$MAX_QUANTITY")
        val variantId = body.long("variantId")
        val product = (body.long("productId")?.let { deps.catalog.find(it, variantId) }
            ?: body.str("slug")?.let { slug ->
                deps.catalog.findBySlug(slug)?.let { base ->
                    if (variantId == null) base else deps.catalog.find(base.productId, variantId)
                }
            }) ?: throw notFound("PRODUCT_NOT_FOUND")

        val owner = web.sessions.cartOwnerOrStart(this)
        val inCart = deps.cart.list(owner)
            .firstOrNull { it.productId == product.productId && it.variantId == product.variantId }?.quantity ?: 0
        requireStock(deps, product.productId, product.variantId, inCart + quantity)
        deps.cart.addItem(owner, product.productId, product.variantId, quantity)
        respondJson(deps.cartJson(owner))
    }

    endpoint(HttpMethod.Patch, "/api/cart/items/{id}") {
        val owner = web.sessions.cartOwner(this)
        val line = ownLine(deps, owner, this)
        val quantity = jsonBody().int("quantity") ?: throw badRequest("BAD_QUANTITY", "quantity is required")
        if (quantity > MAX_QUANTITY) throw badRequest("BAD_QUANTITY", "quantity must be at most $MAX_QUANTITY")
        if (quantity > 0) requireStock(deps, line.productId, line.variantId, quantity)
        deps.cart.updateQuantity(owner!!, line.id, quantity)
        respondJson(deps.cartJson(owner))
    }

    endpoint(HttpMethod.Delete, "/api/cart/items/{id}") {
        val owner = web.sessions.cartOwner(this)
        val line = ownLine(deps, owner, this)
        deps.cart.removeItem(owner!!, line.id)
        respondJson(deps.cartJson(owner))
    }

    endpoint(HttpMethod.Post, "/api/cart/clear") {
        val owner = web.sessions.cartOwner(this)
        owner?.let { deps.cart.clear(it) }
        respondJson(deps.cartJson(owner))
    }

    endpoint(HttpMethod.Post, "/api/cart/merge") {
        val user = web.sessions.requireUser(this)
        web.sessions.guestToken(this)?.let {
            deps.cart.mergeGuestIntoUser(it, user.id)
            web.sessions.clearGuestToken(this)
        }
        respondJson(deps.cartJson(CartOwner.User(user.id)))
    }
}

private const val MAX_QUANTITY = 999

/** The cart line `{id}` of [owner]; 404 when it is missing or someone else's. */
private fun ownLine(deps: StorefrontDeps, owner: CartOwner?, call: ApplicationCall) =
    call.parameters["id"]?.toLongOrNull()
        ?.let { id -> owner?.let { deps.cart.list(it) }?.firstOrNull { it.id == id } }
        ?: throw notFound("CART_ITEM_NOT_FOUND")

private fun requireStock(deps: StorefrontDeps, productId: Long, variantId: Long?, wanted: Int) {
    val available = deps.available(productId, variantId) ?: return
    if (wanted > available) {
        throw conflict(
            "OUT_OF_STOCK", "Only $available left",
            buildJsonObject { put("available", available) },
        )
    }
}
