package su.spyme.marketplace.web

import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.request.receiveText
import io.ktor.server.response.respondText
import io.ktor.server.routing.Route
import io.ktor.server.routing.route
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.Money
import java.time.Instant

private val log = LoggerFactory.getLogger("su.spyme.marketplace.web")

internal val json = Json { ignoreUnknownKeys = true }

/**
 * A request failure with a stable machine-readable [code]; rendered as
 * `{"error": code, "message": ...}` plus any [extra] fields. Thrown from route
 * code, mapped by [endpoint].
 */
internal class ApiException(
    val status: HttpStatusCode,
    val code: String,
    message: String = code,
    val extra: JsonObject = JsonObject(emptyMap()),
) : RuntimeException(message)

internal fun badRequest(code: String, message: String = code) = ApiException(HttpStatusCode.BadRequest, code, message)
internal fun notFound(code: String = "NOT_FOUND") = ApiException(HttpStatusCode.NotFound, code)
internal fun conflict(code: String, message: String = code, extra: JsonObject = JsonObject(emptyMap())) =
    ApiException(HttpStatusCode.Conflict, code, message, extra)

/**
 * Registers [handler] for [method] [path]. The handler may throw [ApiException]
 * (rendered as its status) or anything else (logged, answered with a bare 500),
 * so routes never depend on the host having installed StatusPages.
 */
internal fun Route.endpoint(method: HttpMethod, path: String, handler: suspend ApplicationCall.() -> Unit) {
    route(path, method) {
        handle {
            try {
                call.handler()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                call.respondJson(e.status, buildJsonObject {
                    put("error", e.code)
                    put("message", e.message ?: e.code)
                    e.extra.forEach { (k, v) -> put(k, v) }
                })
            } catch (e: Exception) {
                log.error("{} {} failed", call.request.local.method.value, call.request.local.uri, e)
                call.respondJson(HttpStatusCode.InternalServerError, buildJsonObject {
                    put("error", "INTERNAL")
                    put("message", "Internal error")
                })
            }
        }
    }
}

internal suspend fun ApplicationCall.respondJson(status: HttpStatusCode, body: JsonElement) {
    respondText(json.encodeToString(JsonElement.serializer(), body), ContentType.Application.Json, status)
}

internal suspend fun ApplicationCall.respondJson(body: JsonElement) = respondJson(HttpStatusCode.OK, body)

/** The JSON object body; an empty body is `{}`, anything else that is not an object is a 400. */
internal suspend fun ApplicationCall.jsonBody(): JsonObject {
    val text = receiveText()
    if (text.isBlank()) return JsonObject(emptyMap())
    return runCatching { json.parseToJsonElement(text) as? JsonObject }.getOrNull()
        ?: throw badRequest("BAD_JSON", "Request body must be a JSON object")
}

// ---- tiny JSON accessors ---------------------------------------------------

internal fun JsonObject.str(name: String): String? = (this[name] as? JsonPrimitive)?.contentOrNull
internal fun JsonObject.long(name: String): Long? = str(name)?.toLongOrNull()
internal fun JsonObject.int(name: String): Int? = str(name)?.toIntOrNull()
internal fun JsonObject.obj(name: String): JsonObject? = this[name] as? JsonObject

internal fun Money.toJson(): JsonObject = buildJsonObject {
    put("amount", amount)
    put("currency", currency)
}

internal fun Instant?.toJson(): JsonElement = if (this == null) JsonNull else JsonPrimitive(toString())

internal fun String?.toJson(): JsonElement = if (this == null) JsonNull else JsonPrimitive(this)

/** `offset` / `limit` query parameters with sane bounds. */
internal fun ApplicationCall.page(defaultLimit: Int = 20, maxLimit: Int = 100): Pair<Int, Int> {
    val offset = request.queryParameters["offset"]?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val limit = request.queryParameters["limit"]?.toIntOrNull()?.coerceIn(1, maxLimit) ?: defaultLimit
    return offset to limit
}

internal fun pageJson(items: List<JsonElement>, total: Long, offset: Int, limit: Int): JsonObject = buildJsonObject {
    put("items", kotlinx.serialization.json.JsonArray(items))
    put("total", total)
    put("offset", offset)
    put("limit", limit)
}

internal fun okJson(): JsonObject = buildJsonObject { put("ok", true) }

/**
 * Notification payload that makes a status notification link to the SPA order
 * page (`#/orders/{id}`). Producers pass it to `NotifierService.enqueue(payload = ...)`;
 * `/api/me/notifications` turns it into `actionUrl` / `actionLabel`, and
 * [su.spyme.marketplace.auth.bots.BotNotificationChannel] appends an absolute
 * link when it knows the public URL.
 */
fun orderNotificationPayload(orderId: Long, label: String = "Открыть заказ"): JsonObject = buildJsonObject {
    put("orderId", orderId)
    put("actionUrl", "#/orders/$orderId")
    put("actionLabel", label)
}
