package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.exceptions.ExposedSQLException
import su.spyme.marketplace.auth.bots.BotAuthService
import su.spyme.marketplace.auth.bots.BotPlatform
import su.spyme.marketplace.auth.bots.UnlinkResult
import su.spyme.marketplace.notifications.Notification
import su.spyme.marketplace.notifications.UserNotifyChannelsService
import su.spyme.marketplace.users.User
import java.util.UUID

/**
 * The signed-in user's own data: profile, in-app notifications, bookmarks,
 * sessions, linked messengers and notification channels. `GET /api/me` answers
 * `{"guest": true}` (200) for visitors so the SPA can probe it freely; every
 * other endpoint is 401 without a session.
 */
fun Route.meRoutes(deps: StorefrontDeps) {
    val web = deps.web

    // ---- profile ----

    endpoint(HttpMethod.Get, "/api/me") {
        val user = web.sessions.user(this)
        respondJson(if (user == null) buildJsonObject { put("guest", true) } else meJson(deps, user))
    }

    endpoint(HttpMethod.Patch, "/api/me") {
        val user = web.sessions.requireUser(this)
        val body = jsonBody()
        val language = body.str("language")
        val username = body.str("username")
        val displayName = if (body.containsKey("displayName")) parseDisplayName(body["displayName"]) else null
        if (language != null && !LANGUAGE.matches(language)) throw badRequest("BAD_LANGUAGE", "language must look like 'ru' or 'en-GB'")
        if (username != null && !USERNAME.matches(username)) throw badRequest("BAD_USERNAME", "username must be 3-16 letters, digits or _")
        try {
            deps.users.updateProfile(user.id, username = username, locale = language)
        } catch (e: ExposedSQLException) {
            if (e.sqlState == "23505") throw conflict("USERNAME_TAKEN", "Username is taken") else throw e
        }
        if (body.containsKey("displayName")) deps.users.setDisplayName(user.id, displayName)
        respondJson(JsonObject(meJson(deps, deps.users.findById(user.id)!!) + ("ok" to JsonPrimitive(true))))
    }

    // ---- in-app notifications ----

    endpoint(HttpMethod.Get, "/api/me/notifications") {
        val user = web.sessions.requireUser(this)
        val (offset, limit) = page(defaultLimit = 20, maxLimit = 50)
        val unread = request.queryParameters["unread"] == "1" || request.queryParameters["onlyUnread"] == "true"
        val (rows, total) = deps.notifications.list(user.id, unread, offset.toLong(), limit)
        respondJson(pageJson(rows.map(::notificationJson), total, offset, limit))
    }

    endpoint(HttpMethod.Get, "/api/me/notifications/unread-count") {
        val user = web.sessions.requireUser(this)
        respondJson(buildJsonObject { put("count", deps.notifications.unreadCount(user.id)) })
    }

    endpoint(HttpMethod.Post, "/api/me/notifications/read-all") {
        val user = web.sessions.requireUser(this)
        deps.notifications.markAllRead(user.id)
        respondJson(okJson())
    }

    endpoint(HttpMethod.Post, "/api/me/notifications/{id}/read") {
        val user = web.sessions.requireUser(this)
        val id = parameters["id"]?.toLongOrNull()
        if (id == null || !deps.notifications.markRead(user.id, id)) throw notFound("NOTIFICATION_NOT_FOUND")
        respondJson(okJson())
    }

    // ---- bookmarks ----

    endpoint(HttpMethod.Get, "/api/me/bookmarks") {
        val user = web.sessions.requireUser(this)
        val items = deps.bookmarks.listForUser(user.id).mapNotNull { b ->
            deps.catalog.find(b.productId)?.let { p ->
                buildJsonObject {
                    put("productId", p.productId)
                    put("slug", p.slug)
                    put("title", p.title)
                    put("imageUrl", p.imageUrl)
                    put("price", p.unitPrice.toJson())
                    put("createdAt", b.createdAt.toJson())
                }
            }
        }
        respondJson(buildJsonObject { put("items", JsonArray(items)); put("total", items.size) })
    }

    endpoint(HttpMethod.Post, "/api/me/bookmarks") {
        val user = web.sessions.requireUser(this)
        val product = jsonBody().str("slug")?.let { deps.catalog.findBySlug(it) } ?: throw notFound("PRODUCT_NOT_FOUND")
        deps.bookmarks.add(user.id, product.productId)
        respondJson(buildJsonObject { put("ok", true); put("productId", product.productId); put("bookmarked", true) })
    }

    endpoint(HttpMethod.Delete, "/api/me/bookmarks/{productId}") {
        val user = web.sessions.requireUser(this)
        val productId = parameters["productId"]?.toLongOrNull() ?: throw notFound("PRODUCT_NOT_FOUND")
        deps.bookmarks.remove(user.id, productId)
        respondJson(okJson())
    }

    // ---- sessions ----

    endpoint(HttpMethod.Get, "/api/me/sessions") {
        val auth = web.sessions.current(this) ?: throw web.unauthorized()
        val items = deps.sessions.listActiveByUser(auth.user.id).sortedByDescending { it.lastActiveAt }.map { s ->
            buildJsonObject {
                put("id", s.id.toString())
                put("userAgent", s.userAgent)
                put("ip", s.ip)
                put("createdAt", s.createdAt.toJson())
                put("lastSeenAt", s.lastActiveAt.toJson())
                put("current", s.id == auth.session.id)
            }
        }
        respondJson(buildJsonObject { put("items", JsonArray(items)); put("total", items.size) })
    }

    endpoint(HttpMethod.Delete, "/api/me/sessions/{id}") {
        val user = web.sessions.requireUser(this)
        val id = runCatching { UUID.fromString(parameters["id"]) }.getOrNull()
        val session = id?.let { deps.sessions.findById(it) }?.takeIf { it.userId == user.id } ?: throw notFound("SESSION_NOT_FOUND")
        deps.sessions.revoke(session.id)
        respondJson(okJson())
    }

    // ---- linked messengers ----

    endpoint(HttpMethod.Get, "/api/me/links") {
        val user = web.sessions.requireUser(this)
        respondJson(buildJsonObject { put("links", linksJson(deps, user.id)) })
    }

    endpoint(HttpMethod.Post, "/api/me/link/start") {
        val user = web.sessions.requireUser(this)
        val bots = deps.botAuth ?: throw ApiException(io.ktor.http.HttpStatusCode.ServiceUnavailable, "BOTS_DISABLED", "No bot is configured")
        val platform = platformOf(bots, jsonBody().str("platform"))
        val issued = bots.startLink(user.id, platform) ?: throw conflict("ALREADY_LINKED", "This messenger is already linked")
        val url = bots.config.botUrl(platform)
        respondJson(buildJsonObject {
            put("code", issued.code)
            put("expiresAt", issued.expiresAt.toJson())
            // Telegram carries the code in the /start payload; VK has no payload, the user pastes it.
            put("deeplink", if (platform == BotPlatform.TELEGRAM) "$url?start=${issued.code}" else url)
        })
    }

    endpoint(HttpMethod.Delete, "/api/me/link/{platform}") {
        val user = web.sessions.requireUser(this)
        val bots = deps.botAuth ?: throw ApiException(io.ktor.http.HttpStatusCode.ServiceUnavailable, "BOTS_DISABLED", "No bot is configured")
        when (bots.unlink(user.id, platformOf(bots, parameters["platform"]))) {
            UnlinkResult.UNLINKED -> respondJson(okJson())
            UnlinkResult.NOT_LINKED -> throw notFound("NOT_LINKED")
            UnlinkResult.LAST_LOGIN_METHOD -> throw conflict("LAST_LOGIN_METHOD", "This is your only way to sign in")
        }
    }

    // ---- notification channels ----

    endpoint(HttpMethod.Get, "/api/me/notify-channels") {
        val user = web.sessions.requireUser(this)
        respondJson(buildJsonObject { put("channels", strings(deps.notifyChannels.get(user.id))) })
    }

    endpoint(HttpMethod.Put, "/api/me/notify-channels") {
        val user = web.sessions.requireUser(this)
        val requested = (jsonBody()["channels"] as? JsonArray)
            ?.map { (it as? JsonPrimitive)?.content ?: throw badRequest("BAD_CHANNELS", "channels must be strings") }
            ?.distinct().orEmpty()
        if (requested.isEmpty()) throw badRequest("BAD_CHANNELS", "Pick at least one channel")
        val linked = deps.social.listForUser(user.id).map { it.provider }.toSet()
        for (c in requested) {
            when (c) {
                UserNotifyChannelsService.SITE -> Unit
                "email" -> if (!user.isEmailVerified) throw badRequest("EMAIL_NOT_VERIFIED", "Email is not verified")
                "tg", "vk" -> if (c !in linked) throw badRequest("NOT_LINKED", "$c is not linked")
                else -> throw badRequest("BAD_CHANNELS", "Unknown channel '$c'")
            }
        }
        respondJson(buildJsonObject { put("ok", true); put("channels", strings(deps.notifyChannels.set(user.id, requested))) })
    }
}

/** Trimmed 1-100 chars without control characters; empty or JSON null clears the name (returns null). */
internal fun parseDisplayName(value: kotlinx.serialization.json.JsonElement?): String? {
    if (value is JsonNull) return null
    val raw = (value as? JsonPrimitive)?.takeIf { it.isString }?.content
        ?: throw badRequest("BAD_DISPLAY_NAME", "displayName must be a string")
    val name = raw.trim()
    if (name.isEmpty()) return null
    if (name.length > 100 || name.any { it.isISOControl() }) {
        throw badRequest("BAD_DISPLAY_NAME", "displayName must be 1-100 characters without control characters")
    }
    return name
}

private val LANGUAGE = Regex("^[a-z]{2}(-[A-Za-z]{2})?$")
private val USERNAME = Regex("^[A-Za-z0-9_]{3,16}$")

private fun strings(list: List<String>) = JsonArray(list.map { JsonPrimitive(it) })

internal fun platformOf(bots: BotAuthService, raw: String?): BotPlatform =
    BotPlatform.parse(raw)?.takeIf { bots.config.isEnabled(it) } ?: throw badRequest("BAD_PLATFORM", "platform must be an enabled bot: tg | vk")

private fun linksJson(deps: StorefrontDeps, userId: Long) = JsonArray(
    deps.social.listForUser(userId).map { l ->
        buildJsonObject { put("platform", l.provider); put("displayName", l.displayName); put("linkedAt", l.linkedAt.toJson()) }
    },
)

private fun notificationJson(n: Notification): JsonObject = buildJsonObject {
    val payload = n.payload as? JsonObject
    put("id", n.id)
    put("kind", n.kind)
    put("title", n.subject)
    put("body", n.body)
    put("isRead", n.readAt != null)
    put("readAt", n.readAt.toJson())
    put("createdAt", n.createdAt.toJson())
    // Producers that only know the order id (orderNotificationPayload) still get the order-page link.
    val orderLink = payload?.long("orderId")?.let { orderNotificationPayload(it) }
    put("actionUrl", payload?.str("actionUrl") ?: orderLink?.str("actionUrl"))
    put("actionLabel", payload?.str("actionLabel") ?: orderLink?.str("actionLabel"))
}

private fun meJson(deps: StorefrontDeps, user: User): JsonObject {
    // Highest-level role wins; unknown codes (removed module) are ignored.
    val role = user.roles.mapNotNull { deps.roles.getOrNull(it) }.maxByOrNull { it.level }?.code ?: "USER"
    val hidden = user.email.endsWith("@" + deps.config.placeholderEmailDomain, ignoreCase = true)
    return buildJsonObject {
        put("id", user.id)
        put("username", user.username)
        put("displayName", user.displayName)
        put("email", if (hidden) null else user.email)
        put("emailVerified", user.isEmailVerified)
        put("role", role)
        put("roles", strings(user.roles))
        put("language", user.locale)
        put("notifyChannels", strings(deps.notifyChannels.get(user.id)))
        put("createdAt", user.createdAt.toJson())
        put("links", linksJson(deps, user.id))
    }
}

internal fun WebContext.unauthorized() =
    ApiException(io.ktor.http.HttpStatusCode.Unauthorized, "UNAUTHORIZED", "Sign in required")
