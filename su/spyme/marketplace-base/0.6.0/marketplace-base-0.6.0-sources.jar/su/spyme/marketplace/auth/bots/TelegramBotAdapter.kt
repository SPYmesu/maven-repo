package su.spyme.marketplace.auth.bots

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.jsonPrimitive
import org.slf4j.LoggerFactory
import java.time.Duration

/**
 * Telegram Bot API over long polling (`getUpdates`). No host types: the token
 * comes in through the constructor and every update is handed to [onEvent].
 *
 * Call [start] once and [stop] on shutdown. A second poller on the same token
 * (e.g. a dev copy of the app) makes Telegram answer 409; the loop logs it and
 * keeps retrying.
 *
 * @param apiBase overridable for tests.
 */
class TelegramBotAdapter(
    private val token: String,
    private val onEvent: suspend (BotEvent) -> Unit,
    private val apiBase: String = "https://api.telegram.org",
) : BotTransport {

    override val platform: BotPlatform = BotPlatform.TELEGRAM

    private val log = LoggerFactory.getLogger(TelegramBotAdapter::class.java)
    private val http = BotHttp()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null

    /** Starts the poll loop; a second call is a no-op. */
    @Synchronized
    fun start() {
        if (pollJob != null) return
        pollJob = scope.launch { pollLoop() }
        log.info("Telegram bot adapter started (long poll)")
    }

    fun stop() {
        scope.cancel()
        pollJob = null
    }

    override suspend fun sendMessage(chatId: String, text: String) = send(chatId, text, html = false)

    override suspend fun sendCode(chatId: String, template: String, code: String) {
        // Escape template and code so & < > cannot break the markup; the code
        // itself goes into <code> for tap-to-copy.
        val html = escapeHtml(template).replace("{code}", "<code>${escapeHtml(code)}</code>")
        send(chatId, html, html = true)
    }

    private suspend fun send(chatId: String, text: String, html: Boolean) {
        val params = buildMap<String, Any> {
            put("chat_id", chatId)
            put("text", text)
            put("disable_web_page_preview", true)
            if (html) put("parse_mode", "HTML")
        }
        val reply = parseJsonObject(http.postForm("$apiBase/bot$token/sendMessage", params, REQUEST_TIMEOUT))
        if (reply == null || reply["ok"].str() != "true") {
            throw BotSendException(reply?.get("description").str() ?: "telegram error code=${reply?.get("error_code").str()}")
        }
    }

    private suspend fun pollLoop() {
        var offset = 0L
        while (scope.isActive) {
            try {
                val body = http.get(
                    "$apiBase/bot$token/getUpdates",
                    mapOf("timeout" to 25, "offset" to offset, "allowed_updates" to """["message","callback_query"]"""),
                    POLL_TIMEOUT,
                )
                val reply = parseJsonObject(body)
                if (reply == null || reply["ok"].str() != "true") {
                    log.warn("Telegram getUpdates refused: {}", body.take(120).replace('\n', ' '))
                    delay(RETRY_DELAY_MS)
                    continue
                }
                for (update in reply["result"].arr().orEmpty()) {
                    val u = update.obj() ?: continue
                    u["update_id"]?.jsonPrimitive?.longOrNull?.let { offset = maxOf(offset, it + 1) }
                    try {
                        dispatch(u)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        log.error("Telegram update handling failed", e)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.error("Telegram poll error: {}: {}", e.javaClass.simpleName, e.message)
                delay(RETRY_DELAY_MS)
            }
        }
    }

    private suspend fun dispatch(update: JsonObject) {
        update["message"].obj()?.let { msg ->
            val text = msg["text"].str()?.trim() ?: return@let
            val from = msg["from"].obj() ?: return@let
            onEvent(
                BotEvent.Message(
                    transport = this, platformUserId = from["id"].str() ?: return@let,
                    chatId = msg["chat"].obj()?.get("id").str() ?: return@let,
                    fromUsername = from["username"].str(), fromDisplayName = displayName(from), text = text,
                    fromFirstName = from["first_name"].str()?.trim()?.takeIf { it.isNotEmpty() },
                ),
            )
            return
        }
        update["callback_query"].obj()?.let { cb ->
            val from = cb["from"].obj() ?: return@let
            val userId = from["id"].str() ?: return@let
            onEvent(
                BotEvent.Callback(
                    transport = this, platformUserId = userId,
                    chatId = cb["message"].obj()?.get("chat").obj()?.get("id").str() ?: userId,
                    fromUsername = from["username"].str(), fromDisplayName = displayName(from),
                    data = cb["data"].str().orEmpty(),
                    fromFirstName = from["first_name"].str()?.trim()?.takeIf { it.isNotEmpty() },
                ),
            )
        }
    }

    private fun displayName(from: JsonObject): String? =
        listOfNotNull(from["first_name"].str(), from["last_name"].str()).joinToString(" ").ifBlank { null }

    private companion object {
        val POLL_TIMEOUT: Duration = Duration.ofSeconds(40)
        val REQUEST_TIMEOUT: Duration = Duration.ofSeconds(30)
        const val RETRY_DELAY_MS = 5_000L

        fun escapeHtml(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    }
}
