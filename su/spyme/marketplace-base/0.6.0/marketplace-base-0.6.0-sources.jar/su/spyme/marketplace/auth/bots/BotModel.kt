package su.spyme.marketplace.auth.bots

import su.spyme.marketplace.auth.otp.OtpChannel

/**
 * Messenger a shop bot lives on.
 *
 * @property code value stored in `social_links.provider`, used as the `platform`
 *           in the HTTP API and as the notification channel code
 *           ([su.spyme.marketplace.notifications.ChannelCodes]).
 * @property otpChannel `otp_codes.channel` for codes issued through this bot.
 */
enum class BotPlatform(val code: String, val otpChannel: OtpChannel) {
    TELEGRAM("tg", OtpChannel.TG_BOT),
    VK("vk", OtpChannel.VK_BOT);

    companion object {
        /** Accepts the short code (`tg`, `vk`) or the long name (`telegram`), any case. */
        fun parse(value: String?): BotPlatform? = when (value?.trim()?.lowercase()) {
            "tg", "telegram" -> TELEGRAM
            "vk" -> VK
            else -> null
        }
    }
}

/**
 * How the SPA should present login for a platform. The server accepts both
 * flows regardless; this only decides what `GET /api/auth/login-modes` advertises.
 */
enum class LoginMode(val wire: String) {
    /** The bot hands the user a code (`/login`) which they type on the site. */
    BOT_TO_USER("bot_to_user"),

    /** The site hands the user a code which they send to the bot; the site polls. */
    USER_TO_BOT("user_to_bot"),
}

/**
 * Bot settings. A platform whose section is null is not offered at all.
 *
 * @property autoRegister whether `/start` in the bot creates an account for an
 *           unknown messenger user (otherwise they must link from the site first).
 * @property placeholderEmailDomain accounts created by the bot get the synthetic
 *           address `<platform>-<id>@<domain>` because `users.email` is mandatory;
 *           [su.spyme.marketplace.web.StorefrontConfig] hides such addresses.
 */
data class BotConfig(
    val telegram: Telegram? = null,
    val vk: Vk? = null,
    val loginModes: Map<BotPlatform, LoginMode> = emptyMap(),
    val loginCodeTtlMinutes: Long = 5,
    val linkCodeTtlMinutes: Long = 10,
    val autoRegister: Boolean = true,
    val placeholderEmailDomain: String = "bot.invalid",
) {
    /** @property botUsername bot handle without `@`, used for `https://t.me/<handle>` links. */
    data class Telegram(val botToken: String, val botUsername: String)

    /** @property screenName community short name, used for `https://vk.me/<name>` links. */
    data class Vk(val groupId: Long, val groupToken: String, val screenName: String)

    fun isEnabled(platform: BotPlatform): Boolean = when (platform) {
        BotPlatform.TELEGRAM -> telegram != null
        BotPlatform.VK -> vk != null
    }

    fun modeOf(platform: BotPlatform): LoginMode = loginModes[platform] ?: LoginMode.BOT_TO_USER

    /** Public bot link (no payload) or null when the platform is off. */
    fun botUrl(platform: BotPlatform): String? = when (platform) {
        BotPlatform.TELEGRAM -> telegram?.let { "https://t.me/${it.botUsername}" }
        BotPlatform.VK -> vk?.let { "https://vk.me/${it.screenName}" }
    }

    fun botName(platform: BotPlatform): String? = when (platform) {
        BotPlatform.TELEGRAM -> telegram?.botUsername
        BotPlatform.VK -> vk?.screenName
    }
}

/** Outbound half of a bot: what replies and notifications are sent through. */
interface BotTransport {
    val platform: BotPlatform

    /**
     * Sends plain text to [chatId] (for private chats equal to the platform user id).
     * @throws BotSendException when the platform refuses; transport errors propagate as-is.
     */
    suspend fun sendMessage(chatId: String, text: String)

    /**
     * Sends [template] with the `{code}` placeholder replaced by [code]. Telegram
     * renders the code as a tap-to-copy span; platforms without markup substitute plain text.
     */
    suspend fun sendCode(chatId: String, template: String, code: String) =
        sendMessage(chatId, template.replace("{code}", code))
}

/** The platform API answered but refused (blocked bot, no permission, bad chat). */
class BotSendException(message: String) : RuntimeException(message)

/**
 * Normalised inbound update, identical for every platform so command handlers
 * are written once.
 *
 * @property platformUserId the sender's id on the platform (what `social_links.external_id` holds).
 * @property chatId where replies go.
 */
sealed class BotEvent(
    val transport: BotTransport,
    val platformUserId: String,
    val chatId: String,
    val fromUsername: String?,
    val fromDisplayName: String?,
    /** The sender's first name alone (what becomes `users.display_name`); null if the platform gave none. */
    val fromFirstName: String?,
) {
    val platform: BotPlatform get() = transport.platform

    suspend fun reply(text: String) = transport.sendMessage(chatId, text)

    /** See [BotTransport.sendCode]. */
    suspend fun replyCode(template: String, code: String) = transport.sendCode(chatId, template, code)

    /** A text message. */
    class Message(
        transport: BotTransport, platformUserId: String, chatId: String,
        fromUsername: String?, fromDisplayName: String?,
        val text: String,
        fromFirstName: String? = null,
    ) : BotEvent(transport, platformUserId, chatId, fromUsername, fromDisplayName, fromFirstName)

    /** An inline-button press (Telegram only). */
    class Callback(
        transport: BotTransport, platformUserId: String, chatId: String,
        fromUsername: String?, fromDisplayName: String?,
        val data: String,
        fromFirstName: String? = null,
    ) : BotEvent(transport, platformUserId, chatId, fromUsername, fromDisplayName, fromFirstName)
}

/**
 * Hook for host-specific bot commands (`/orders`, `/stats`, ...). Handlers run
 * before the built-in ones (`/start`, `/login`, `/help`, login/link codes), in
 * list order; the first to return true consumes the event, so a handler can also
 * override a built-in. Exceptions are caught by the router and answered with
 * [BotMessages.error].
 */
fun interface BotCommandHandler {
    /** @return true if the event was handled and must not reach later handlers. */
    suspend fun handle(event: BotEvent, bot: BotAuthService): Boolean
}

/**
 * User-facing texts of the built-in commands. The defaults are Russian (the shop
 * audience); [EN] is the English set. Copy and override what you need.
 */
data class BotMessages(
    val welcomeNew: String = "Добро пожаловать! Аккаунт {username} создан.",
    val welcomeBack: String = "Здравствуйте, {username}! Команды: /help",
    val notLinked: String = "Этот аккаунт не привязан к магазину. Откройте сайт и привяжите мессенджер в профиле либо отправьте сюда код привязки.",
    val loginCode: String = "Ваш код для входа: {code}\nДействителен {minutes} мин.",
    val loginConfirmed: String = "Код принят. Возвращайтесь на сайт - вы вошли как {username}.",
    val linked: String = "Аккаунт привязан как {username}. Возвращайтесь на сайт.",
    val merged: String = "Аккаунты объединены. Возвращайтесь на сайт — вы вошли как {username}.",
    val invalidCode: String = "Код неверный или уже использован.",
    val expiredCode: String = "Код истёк. Запросите новый.",
    val alreadyLinked: String = "Этот мессенджер уже привязан к аккаунту.",
    val accountTaken: String = "Этот аккаунт мессенджера привязан к другому аккаунту магазина.",
    val help: String = "Команды:\n/start - регистрация или приветствие\n/login - получить код для входа на сайт\n/help - эта справка",
    val error: String = "Что-то пошло не так. Попробуйте позже.",
) {
    companion object {
        /** Russian texts; the same as the default [BotMessages]. */
        val RU = BotMessages()

        /** English texts. */
        val EN = BotMessages(
            welcomeNew = "Welcome! Your account {username} has been created.",
            welcomeBack = "Hello, {username}! Commands: /help",
            notLinked = "This account is not linked to the shop. Open the site and link it in your profile, or send the link code here.",
            loginCode = "Your login code: {code}\nValid for {minutes} minutes.",
            loginConfirmed = "Code accepted. Go back to the site - you are signed in as {username}.",
            linked = "Account linked as {username}. Go back to the site.",
            merged = "Accounts merged. Go back to the site - you are signed in as {username}.",
            invalidCode = "The code is invalid or already used.",
            expiredCode = "The code has expired. Request a new one.",
            alreadyLinked = "This messenger is already linked to the account.",
            accountTaken = "This messenger account is linked to another shop account.",
            help = "Commands:\n/start - register or greet\n/login - get a code to sign in on the site\n/help - this text",
            error = "Something went wrong. Try again later.",
        )
    }
}
