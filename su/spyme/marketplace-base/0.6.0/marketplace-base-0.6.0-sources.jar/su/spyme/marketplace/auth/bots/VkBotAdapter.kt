package su.spyme.marketplace.auth.bots

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import org.slf4j.LoggerFactory
import java.time.Duration
import java.util.concurrent.ThreadLocalRandom

/**
 * VK community bot over the Long Poll API:
 *
 *  1. `groups.getLongPollServer` -> server / key / ts
 *  2. `GET {server}?act=a_check&key=..&ts=..&wait=25`
 *  3. `message_new` updates -> [BotEvent.Message] -> [onEvent]
 *  4. `messages.send` for outgoing text
 *
 * Two behaviours are deliberate and must be kept:
 *  - `a_check` is a **GET**. lp.vk.com's nginx answers a body-less POST with
 *    `411 Length Required` (HTML, not JSON).
 *  - A reply that is not JSON, or carries neither `ts` nor `failed`, never
 *    advances the loop: the server/key are re-fetched after a pause. Without
 *    this guard the loop spins at CPU speed on an HTML error page.
 *
 * @param apiBase overridable for tests.
 */
class VkBotAdapter(
    private val groupId: Long,
    private val groupToken: String,
    private val onEvent: suspend (BotEvent) -> Unit,
    private val apiBase: String = "https://api.vk.com/method",
) : BotTransport {

    override val platform: BotPlatform = BotPlatform.VK

    private val log = LoggerFactory.getLogger(VkBotAdapter::class.java)
    private val http = BotHttp()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null

    /** Starts the poll loop; a second call is a no-op. */
    @Synchronized
    fun start() {
        if (pollJob != null) return
        pollJob = scope.launch {
            try {
                pollLoop()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.error("VK poll loop crashed", e)
            }
        }
        log.info("VK bot adapter started (Long Poll, groupId={})", groupId)
    }

    fun stop() {
        scope.cancel()
        pollJob = null
    }

    override suspend fun sendMessage(chatId: String, text: String) {
        val userId = chatId.toLongOrNull() ?: return
        val reply = api(
            "messages.send",
            mapOf(
                "user_id" to userId,
                // random_id is VK's de-duplication key: reusing one drops the message.
                "random_id" to ThreadLocalRandom.current().nextInt(),
                "message" to text,
            ),
        )
        reply?.get("error").obj()?.let { throw BotSendException(it["error_msg"].str() ?: "vk error ${it["error_code"].str()}") }
    }

    private suspend fun api(method: String, params: Map<String, Any>): JsonObject? =
        parseJsonObject(
            http.postQuery("$apiBase/$method", params + mapOf("access_token" to groupToken, "v" to API_VERSION), API_TIMEOUT),
        )

    private data class LongPoll(val server: String, val key: String, val ts: String)

    private suspend fun fetchServer(): LongPoll? = try {
        val response = api("groups.getLongPollServer", mapOf("group_id" to groupId))?.get("response").obj()
        val server = response?.get("server").str()
        val key = response?.get("key").str()
        val ts = response?.get("ts").str()
        if (server == null || key == null || ts == null) null else LongPoll(server, key, ts)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        log.error("groups.getLongPollServer failed: {}", e.message)
        null
    }

    private suspend fun pollLoop() {
        var poll = fetchServer() ?: run {
            log.error("groups.getLongPollServer returned an error - VK adapter will not start")
            return
        }
        while (scope.isActive) {
            try {
                val body = http.get(
                    poll.server,
                    mapOf("act" to "a_check", "key" to poll.key, "ts" to poll.ts, "wait" to "25"),
                    POLL_TIMEOUT,
                )
                val reply = parseJsonObject(body)

                // A valid long-poll reply always has `ts` or `failed`.
                if (reply == null || (reply["ts"] == null && reply["failed"] == null)) {
                    log.warn("VK long poll: unexpected reply ({}) - refreshing server", body.take(80).replace("\n", " "))
                    val refreshed = fetchServer()
                    if (refreshed == null) {
                        delay(10_000)
                    } else {
                        poll = refreshed
                        delay(3_000)
                    }
                    continue
                }

                when (reply["failed"].str()?.toIntOrNull()) {
                    1 -> { // history lost: keep the key, take the new ts
                        poll = poll.copy(ts = reply["ts"].str() ?: poll.ts)
                        continue
                    }
                    2, 3 -> { // key expired / data lost: start over
                        log.warn("VK long poll failed={} - refreshing server/key", reply["failed"].str())
                        val refreshed = fetchServer()
                        if (refreshed == null) delay(10_000) else poll = refreshed
                        continue
                    }
                }

                poll = poll.copy(ts = reply["ts"].str() ?: poll.ts)
                for (update in reply["updates"].arr().orEmpty()) {
                    try {
                        dispatch(update.obj() ?: continue)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        log.error("VK update handling failed", e)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.error("VK poll error: {}: {}", e.javaClass.simpleName, e.message)
                delay(5_000)
            }
        }
    }

    private suspend fun dispatch(update: JsonObject) {
        if (update["type"].str() != "message_new") return
        val message = update["object"].obj()?.get("message").obj() ?: return
        val peerId = message["peer_id"].str() ?: return
        val text = message["text"].str()?.trim().orEmpty()
        if (text.isEmpty()) return
        val fromId = message["from_id"].str() ?: peerId
        val info = fetchUserInfo(fromId)
        onEvent(BotEvent.Message(this, fromId, peerId, info.username, info.displayName, text, info.firstName))
    }

    /**
     * `users.get` for the sender (message_new carries only the id). `idNNN`
     * screen names are dropped, like a Telegram user without @username.
     */
    private data class VkUserInfo(val username: String?, val displayName: String?, val firstName: String?)

    private suspend fun fetchUserInfo(userId: String): VkUserInfo = try {
        val user = api("users.get", mapOf("user_ids" to userId, "fields" to "screen_name"))
            ?.get("response").arr()?.firstOrNull().obj()
        val name = listOfNotNull(user?.get("first_name").str(), user?.get("last_name").str())
            .filter { it.isNotBlank() }.joinToString(" ").ifBlank { null }
        val screen = user?.get("screen_name").str()?.takeUnless { it.matches(Regex("^id\\d+$")) }
        VkUserInfo(screen, name, user?.get("first_name").str()?.trim()?.takeIf { it.isNotEmpty() })
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        log.warn("VK users.get failed for {}: {}", userId, e.message)
        VkUserInfo(null, null, null)
    }

    private companion object {
        const val API_VERSION = "5.199"
        val API_TIMEOUT: Duration = Duration.ofSeconds(60)
        val POLL_TIMEOUT: Duration = Duration.ofSeconds(60)
    }
}
