package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import su.spyme.marketplace.catalog.categories.Category

/**
 * `GET /api/categories` (public): the active categories as
 * `{categories: [{id, slug, name, parentId, sortOrder}]}`, listed depth-first
 * (parents before their children, siblings by `sortOrder` then slug) so the
 * `parentId` links rebuild the tree. `name` is the title in the request locale:
 * `?lang=`, then the `Accept-Language` tags in order (a region tag falls back to
 * its bare language), then [StorefrontConfig.defaultLocale], then any translation,
 * and finally the slug.
 */
fun Route.categoryRoutes(deps: StorefrontDeps) {
    endpoint(HttpMethod.Get, "/api/categories") {
        val titles = deps.categories.listAllTranslations().groupBy { it.categoryId }
        val wanted = localeCandidates(this) + deps.config.defaultLocale
        fun nameOf(c: Category): String {
            val byLocale = titles[c.id].orEmpty().associateBy { it.locale.lowercase() }
            return wanted.firstNotNullOfOrNull { byLocale[it] }?.title
                ?: byLocale.values.firstOrNull()?.title
                ?: c.slug
        }

        val byParent = deps.categories.listAll().groupBy { it.parentId }
            .mapValues { (_, list) -> list.sortedWith(compareBy({ it.sortOrder }, { it.slug })) }
        val ordered = ArrayList<Category>()
        fun walk(parent: Long?) {
            for (c in byParent[parent].orEmpty()) {
                ordered += c
                walk(c.id)
            }
        }
        walk(null)

        respondJson(buildJsonObject {
            put("categories", JsonArray(ordered.map { c ->
                buildJsonObject {
                    put("id", c.id)
                    put("slug", c.slug)
                    put("name", nameOf(c))
                    put("parentId", c.parentId)
                    put("sortOrder", c.sortOrder)
                }
            }))
        })
    }
}

/** Lower-cased locale tags in preference order, each followed by its bare language. */
private fun localeCandidates(call: ApplicationCall): List<String> {
    val explicit = call.request.queryParameters["lang"]?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
    val header = call.request.headers["Accept-Language"].orEmpty().split(',')
        .map { it.trim() }
        .filter { it.isNotEmpty() && !it.contains("q=0,") && !it.endsWith("q=0") }
        .map { it.substringBefore(';').trim().lowercase().replace('_', '-') }
    return (listOfNotNull(explicit) + header)
        .flatMap { listOf(it, it.substringBefore('-')) }
        .filter { it.isNotEmpty() && it != "*" }
        .distinct()
}
