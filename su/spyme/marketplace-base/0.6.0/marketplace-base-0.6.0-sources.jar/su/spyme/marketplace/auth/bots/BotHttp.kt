package su.spyme.marketplace.auth.bots

import kotlinx.coroutines.future.await
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration

/**
 * Minimal HTTP client for the messenger APIs, on the JDK's own
 * [java.net.http.HttpClient]. (Ktor CIO on Windows fails long-poll requests to
 * lp.vk.com with "Connection refused: getsockopt"; the JDK client does not.)
 * Calls are cancellable: cancelling the coroutine cancels the request.
 */
internal class BotHttp {
    private val client: HttpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build()

    /** GET with [params] in the query string. */
    suspend fun get(url: String, params: Map<String, Any>, timeout: Duration): String =
        send(HttpRequest.newBuilder(URI.create(withQuery(url, params))).timeout(timeout).GET().build())

    /** POST with [params] in the query string and no body (the way api.vk.com methods are called). */
    suspend fun postQuery(url: String, params: Map<String, Any>, timeout: Duration): String =
        send(
            HttpRequest.newBuilder(URI.create(withQuery(url, params))).timeout(timeout)
                .POST(HttpRequest.BodyPublishers.noBody()).build(),
        )

    /** POST with [params] as an `application/x-www-form-urlencoded` body. */
    suspend fun postForm(url: String, params: Map<String, Any>, timeout: Duration): String =
        send(
            HttpRequest.newBuilder(URI.create(url)).timeout(timeout)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(encode(params))).build(),
        )

    private suspend fun send(request: HttpRequest): String =
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).await().body()

    private fun withQuery(url: String, params: Map<String, Any>): String =
        url + (if (url.contains("?")) "&" else "?") + encode(params)

    private fun encode(params: Map<String, Any>): String = params.entries.joinToString("&") { (k, v) ->
        "${URLEncoder.encode(k, Charsets.UTF_8)}=${URLEncoder.encode(v.toString(), Charsets.UTF_8)}"
    }
}

/** Parses [body] as a JSON object; null for anything else (HTML error pages, empty body, arrays). */
internal fun parseJsonObject(body: String): JsonObject? =
    runCatching { Json.parseToJsonElement(body) as? JsonObject }.getOrNull()

internal fun JsonElement?.str(): String? = (this as? JsonPrimitive)?.contentOrNull
internal fun JsonElement?.obj(): JsonObject? = this as? JsonObject
internal fun JsonElement?.arr(): JsonArray? = this as? JsonArray
