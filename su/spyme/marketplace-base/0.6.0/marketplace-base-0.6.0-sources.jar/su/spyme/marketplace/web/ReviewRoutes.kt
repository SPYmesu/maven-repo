package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import su.spyme.marketplace.reviews.Review
import su.spyme.marketplace.reviews.ReviewStatus

/**
 * Product reviews. `GET` lists approved, public reviews with their replies;
 * `POST` files the caller's review (re-submitting edits it and sends it back to
 * moderation, unless [StorefrontConfig.autoApproveReviews]).
 */
fun Route.reviewRoutes(deps: StorefrontDeps) {
    val web = deps.web

    endpoint(HttpMethod.Get, "/api/products/{slug}/reviews") {
        val product = productBySlug(deps, this)
        val (offset, limit) = page()
        val all = deps.reviews.listForProduct(product.productId, onlyApproved = true)
        val avg = if (all.isEmpty()) JsonNull else JsonPrimitive(all.sumOf { it.rating.toInt() }.toDouble() / all.size)
        respondJson(buildJsonObject {
            put("items", JsonArray(all.drop(offset).take(limit).map { reviewJson(deps, it) }))
            put("total", all.size)
            put("ratingAvg", avg)
            put("ratingCount", all.size)
            put("offset", offset)
            put("limit", limit)
        })
    }

    endpoint(HttpMethod.Post, "/api/products/{slug}/reviews") {
        val user = web.sessions.requireUser(this)
        val product = productBySlug(deps, this)
        val body = jsonBody()
        val rating = body.int("rating")?.takeIf { it in 1..5 } ?: throw badRequest("BAD_RATING", "rating must be 1..5")
        val text = body.str("body")?.trim().orEmpty()
        if (text.isEmpty() || text.length > 5000) throw badRequest("BAD_BODY", "body must be 1..5000 characters")

        var review = deps.reviews.submit(user.id, product.productId, rating, text, locale = user.locale)
        if (deps.config.autoApproveReviews) review = deps.reviews.moderate(review.id, ReviewStatus.APPROVED)
        respondJson(HttpStatusCode.Created, reviewJson(deps, review).let { base ->
            kotlinx.serialization.json.JsonObject(base + ("status" to JsonPrimitive(review.status.name)))
        })
    }
}

private fun productBySlug(deps: StorefrontDeps, call: ApplicationCall) =
    call.parameters["slug"]?.let { deps.catalog.findBySlug(it) } ?: throw notFound("PRODUCT_NOT_FOUND")

private fun reviewJson(deps: StorefrontDeps, r: Review) = buildJsonObject {
    put("id", r.id)
    put("author", authorJson(deps, r.userId))
    put("rating", r.rating.toInt())
    put("body", r.body)
    put("createdAt", r.createdAt.toJson())
    put("replies", JsonArray(deps.reviews.listReplies(r.id).map { reply ->
        buildJsonObject {
            put("id", reply.id)
            put("author", authorJson(deps, reply.userId))
            put("body", reply.body)
            put("isOfficial", reply.isOfficial)
            put("createdAt", reply.createdAt.toJson())
        }
    }))
}

private fun authorJson(deps: StorefrontDeps, userId: Long) = buildJsonObject {
    put("id", userId)
    put("name", deps.users.findById(userId, includeDeleted = true)?.username)
}
