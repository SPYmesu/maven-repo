package su.spyme.marketplace.notifications

import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import java.time.Instant

/**
 * Read side of the `in-app` channel: the notification feed a user sees on the
 * site, plus read markers (V043). The rows are produced by
 * [NotifierService.enqueue] like for any other channel; for `in-app` the row
 * itself is the delivery, which is what [InAppNotificationChannel] reports.
 */
open class InAppNotificationsService(protected val mainDb: Database) {

    /** One page of [userId]'s feed, newest first, plus the unfiltered total. */
    open fun list(userId: Long, onlyUnread: Boolean, offset: Long, limit: Int): Pair<List<Notification>, Long> =
        transaction(mainDb) {
            val total = BaseNotificationsTable.selectAll().where { feed(userId, onlyUnread) }.count()
            val rows = BaseNotificationsTable.selectAll()
                .where { feed(userId, onlyUnread) }
                .orderBy(BaseNotificationsTable.id to SortOrder.DESC)
                .limit(limit).offset(offset)
                .map(Notification::fromRow)
            rows to total
        }

    open fun unreadCount(userId: Long): Long = transaction(mainDb) {
        BaseNotificationsTable.selectAll().where { feed(userId, onlyUnread = true) }.count()
    }

    /** Marks one notification read; false when it is not [userId]'s (no cross-user writes). */
    open fun markRead(userId: Long, id: Long, now: Instant = Instant.now()): Boolean = transaction(mainDb) {
        BaseNotificationsTable.update({
            (BaseNotificationsTable.id eq id) and feed(userId, onlyUnread = true)
        }) { it[BaseNotificationsTable.readAt] = now } > 0 ||
            BaseNotificationsTable.selectAll()
                .where { (BaseNotificationsTable.id eq id) and feed(userId, onlyUnread = false) }
                .any()
    }

    /** Marks everything read; returns how many rows changed. */
    open fun markAllRead(userId: Long, now: Instant = Instant.now()): Int = transaction(mainDb) {
        BaseNotificationsTable.update({ feed(userId, onlyUnread = true) }) {
            it[BaseNotificationsTable.readAt] = now
        }
    }

    private fun feed(userId: Long, onlyUnread: Boolean): Op<Boolean> {
        val own = (BaseNotificationsTable.userId eq userId) and
            (BaseNotificationsTable.channel eq ChannelCodes.IN_APP)
        return if (onlyUnread) own and Op.build { BaseNotificationsTable.readAt.isNull() } else own
    }
}

/**
 * `in-app` delivery: the notification row is already what the user reads, so
 * dispatch just acknowledges it. Register it next to the real transports so the
 * [NotifierService] worker settles these rows instead of failing them as
 * "no channel registered".
 */
object InAppNotificationChannel : NotificationChannel {
    override val code: String = ChannelCodes.IN_APP

    override suspend fun send(message: NotificationChannel.OutboundMessage): NotificationChannel.Result =
        NotificationChannel.Result.Sent
}
