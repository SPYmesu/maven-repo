package su.spyme.marketplace.auth.bots

import kotlinx.coroutines.CancellationException
import org.slf4j.LoggerFactory
import su.spyme.marketplace.notifications.NotificationChannel

/**
 * [NotificationChannel] that delivers through a bot transport. One class serves
 * both platforms: the channel code is the platform code (`tg` / `vk`, equal to
 * [su.spyme.marketplace.notifications.ChannelCodes]), and `notifications.recipient`
 * is the user's id on that platform (`social_links.external_id`).
 *
 * Permission errors (user blocked the bot, community messages denied) are
 * reported as non-retryable so the [su.spyme.marketplace.notifications.NotifierService]
 * stops after the first attempt; everything else is retried.
 */
class BotNotificationChannel(
    private val transport: BotTransport,
    /** Site base URL; when set, notifications that carry an `actionUrl` get an absolute link appended. */
    private val publicUrl: String? = null,
) : NotificationChannel {

    override val code: String = transport.platform.code

    private val log = LoggerFactory.getLogger(BotNotificationChannel::class.java)

    override suspend fun send(message: NotificationChannel.OutboundMessage): NotificationChannel.Result =
        try {
            val link = (message.payload as? kotlinx.serialization.json.JsonObject)
                ?.get("actionUrl")?.let { (it as? kotlinx.serialization.json.JsonPrimitive)?.content }
                ?.takeIf { publicUrl != null }
                ?.let { "\n\n" + publicUrl!!.trimEnd('/') + "/" + it.trimStart('/') }
                .orEmpty()
            val text = message.subject?.takeIf { it.isNotBlank() }?.let { "$it\n\n${message.body}" } ?: message.body
            transport.sendMessage(message.recipient, text + link)
            NotificationChannel.Result.Sent
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val reason = e.message?.take(400) ?: e.javaClass.simpleName
            val retryable = !isPermissionError(reason)
            log.debug("{} send failed (notification {}, retryable={}): {}", code, message.notificationId, retryable, reason)
            NotificationChannel.Result.Failed(reason, retryable = retryable)
        }

    private fun isPermissionError(reason: String): Boolean {
        val m = reason.lowercase()
        return PERMISSION_MARKERS.any(m::contains)
    }

    private companion object {
        val PERMISSION_MARKERS = listOf(
            // Telegram
            "forbidden", "blocked", "deactivated", "kicked", "not allowed", "deleted account",
            // VK
            "deny_send", "without permission", "blacklist", "user has blocked",
        )
    }
}
