package su.spyme.marketplace.auth.bots

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.exceptions.ExposedSQLException
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.auth.otp.BaseOtpCodesTable
import su.spyme.marketplace.auth.otp.OtpCode
import su.spyme.marketplace.auth.otp.OtpPurpose
import su.spyme.marketplace.auth.otp.OtpRedeemResult
import su.spyme.marketplace.auth.otp.OtpService
import su.spyme.marketplace.auth.otp.OtpStatus
import su.spyme.marketplace.auth.social.SocialLink
import su.spyme.marketplace.auth.social.SocialLinksService
import su.spyme.marketplace.notifications.UserNotifyChannelsService
import su.spyme.marketplace.users.AccountMergeService
import su.spyme.marketplace.users.MergeRefusedException
import su.spyme.marketplace.users.UsersServiceBase
import java.security.SecureRandom
import java.time.Duration
import java.time.Instant

/** A freshly issued one-time code and when it stops working. */
data class IssuedCode(val code: String, val expiresAt: Instant)

/** Outcome of the site-side half of code login ([BotAuthService.redeemLoginCode], [BotAuthService.pollWebLogin]). */
sealed class CodeLogin {
    /** The code is good and now spent; sign [userId] in. */
    data class Success(val userId: Long) : CodeLogin()

    /** `user_to_bot` only: the bot has not confirmed the code yet. */
    data object Pending : CodeLogin()

    /** Unknown, wrong kind, already used, or the account is gone. */
    data object Invalid : CodeLogin()

    data object Expired : CodeLogin()
}

/** Outcome of `/login` in the bot. */
sealed class LoginCodeIssue {
    data class Issued(val code: IssuedCode) : LoginCodeIssue()
    data object NotLinked : LoginCodeIssue()
}

/** Outcome of the bot receiving a site-issued login code (`user_to_bot`). */
sealed class WebLoginConfirm {
    /** [username] is the greeting name (display name, else username). */
    data class Confirmed(val username: String) : WebLoginConfirm()
    data object InvalidCode : WebLoginConfirm()
    data object ExpiredCode : WebLoginConfirm()
    data object NotLinked : WebLoginConfirm()
}

/** Outcome of the bot receiving a link code issued by [BotAuthService.startLink]. */
sealed class LinkResult {
    /** The messenger account belonged to another shop account, which was merged into the code's owner; [username] is the greeting name. */
    data class Merged(val userId: Long, val username: String) : LinkResult()

    /** [username] is the greeting name (display name, else username). */
    data class Linked(val userId: Long, val username: String) : LinkResult()
    data object InvalidCode : LinkResult()
    data object ExpiredCode : LinkResult()

    /** The user already has an identity on this platform. */
    data object AlreadyLinked : LinkResult()

    /** The messenger account belongs to a different shop account. */
    data object AccountTaken : LinkResult()
}

enum class UnlinkResult { UNLINKED, NOT_LINKED, LAST_LOGIN_METHOD }

/**
 * Login and account linking through messenger bots, on top of [OtpService]
 * (`otp_codes`, V024) and `social_links` (V028).
 *
 * Two login flows share the `LOGIN` purpose and are told apart by the code's
 * `payload.mode`:
 *
 *  - **bot_to_user** - the bot issues `AC-XXXXXX` to a linked messenger user
 *    ([issueLoginCode]); the user types it on the site ([redeemLoginCode]).
 *  - **user_to_bot** - the site issues the code ([startWebLogin]); the user sends
 *    it to the bot ([confirmWebLogin] binds their account to the row, status stays
 *    `PENDING`); the site polls ([pollWebLogin]) and spends it.
 *
 * Linking from the profile: the site issues `LK-XXXXXX` ([startLink]) and the
 * user sends it to the bot ([redeemLinkCode]).
 *
 * Every code is single-use (the final spend is [OtpService.redeem]'s conditional
 * `PENDING -> REDEEMED` flip, so concurrent attempts yield exactly one winner)
 * and expires after [BotConfig.loginCodeTtlMinutes] / [BotConfig.linkCodeTtlMinutes].
 * Guessing is a rate-limit concern of the HTTP layer; the code space is
 * 30^6, about 7e8.
 *
 * `otp_codes.recipient` is `<platform>:<external id>`, or `<platform>:*` while
 * the messenger account is not known yet.
 */
open class BotAuthService(
    protected val mainDb: Database,
    protected val users: UsersServiceBase,
    protected val otp: OtpService,
    protected val social: SocialLinksService,
    protected val notifyChannels: UserNotifyChannelsService,
    val config: BotConfig,
    /** When set, a link code sent from a messenger account that belongs to another live user merges that user into the code's owner. */
    val accountMerge: AccountMergeService? = null,
) {

    // ---- site side -------------------------------------------------------

    /** `user_to_bot`: issues a code for the visitor to send to the bot. */
    open fun startWebLogin(platform: BotPlatform): IssuedCode =
        issue(LOGIN_PREFIX, platform, OtpPurpose.LOGIN, recipient(platform, null), config.loginCodeTtlMinutes, null, LoginMode.USER_TO_BOT)

    /** `bot_to_user`: spends a code the bot handed out. */
    open fun redeemLoginCode(rawCode: String): CodeLogin {
        val row = find(rawCode, OtpPurpose.LOGIN, LoginMode.BOT_TO_USER) ?: return CodeLogin.Invalid
        val userId = row.userId ?: return CodeLogin.Invalid
        return spend(row, userId)
    }

    /** `user_to_bot`: [CodeLogin.Pending] until the bot confirms, then spends the code. */
    open fun pollWebLogin(rawCode: String): CodeLogin {
        val row = find(rawCode, OtpPurpose.LOGIN, LoginMode.USER_TO_BOT) ?: return CodeLogin.Invalid
        if (row.status != OtpStatus.PENDING) return CodeLogin.Invalid
        if (row.isExpired(Instant.now())) return CodeLogin.Expired
        val userId = row.userId ?: return CodeLogin.Pending
        return spend(row, userId)
    }

    /** Issues a link code for the signed-in [userId]; null when the platform is already linked. */
    open fun startLink(userId: Long, platform: BotPlatform): IssuedCode? {
        if (social.findForUser(userId, platform.code) != null) return null
        return issue(LINK_PREFIX, platform, OtpPurpose.LINK_SOCIAL, recipient(platform, null), config.linkCodeTtlMinutes, userId, null)
    }

    /**
     * Detaches [platform]. The last identity cannot be removed from an account
     * without a verified email: it would lock the owner out.
     */
    open fun unlink(userId: Long, platform: BotPlatform): UnlinkResult {
        val links = social.listForUser(userId)
        if (links.none { it.provider == platform.code }) return UnlinkResult.NOT_LINKED
        if (links.size <= 1 && users.findById(userId)?.isEmailVerified != true) return UnlinkResult.LAST_LOGIN_METHOD
        social.unlink(userId, platform.code)
        notifyChannels.remove(userId, platform.code)
        return UnlinkResult.UNLINKED
    }

    // ---- bot side --------------------------------------------------------

    /** `/login`: issues a `bot_to_user` code for the linked messenger user. */
    open fun issueLoginCode(platform: BotPlatform, platformUserId: String): LoginCodeIssue {
        val userId = social.findByExternal(platform.code, platformUserId)?.userId ?: return LoginCodeIssue.NotLinked
        if (users.findById(userId) == null) return LoginCodeIssue.NotLinked
        val code = issue(
            LOGIN_PREFIX, platform, OtpPurpose.LOGIN, recipient(platform, platformUserId),
            config.loginCodeTtlMinutes, userId, LoginMode.BOT_TO_USER,
        )
        return LoginCodeIssue.Issued(code)
    }

    /**
     * The bot received a code the site issued with [startWebLogin]: binds the
     * sender's account (registering it when [BotConfig.autoRegister]) to the code.
     * Only the first sender wins; a different sender gets [WebLoginConfirm.InvalidCode].
     * Idempotent for that first sender: a repeated delivery of the same code (deep link
     * plus a manual resend) answers [WebLoginConfirm.Confirmed] again, also after the
     * site's poll already spent the code.
     */
    open fun confirmWebLogin(rawCode: String, event: BotEvent): WebLoginConfirm {
        val platform = event.platform
        val row = find(rawCode, OtpPurpose.LOGIN, LoginMode.USER_TO_BOT)
            ?.takeIf { it.channel == platform.otpChannel }
            ?: return WebLoginConfirm.InvalidCode
        val sender = recipient(platform, event.platformUserId)
        if (row.userId != null) {
            val mine = row.recipient == sender &&
                (row.status == OtpStatus.REDEEMED || (row.status == OtpStatus.PENDING && !row.isExpired(Instant.now())))
            if (!mine) return WebLoginConfirm.InvalidCode
            fillDisplayName(row.userId!!, event)
            return WebLoginConfirm.Confirmed(greetingName(row.userId!!))
        }
        if (row.status != OtpStatus.PENDING) return WebLoginConfirm.InvalidCode
        if (row.isExpired(Instant.now())) return WebLoginConfirm.ExpiredCode
        val userId = findOrRegister(event) ?: return WebLoginConfirm.NotLinked
        val bound = transaction(mainDb) {
            BaseOtpCodesTable.update({
                (BaseOtpCodesTable.code eq row.code) and
                    (BaseOtpCodesTable.status eq OtpStatus.PENDING.name) and
                    BaseOtpCodesTable.userId.isNull()
            }) {
                it[BaseOtpCodesTable.userId] = userId
                it[BaseOtpCodesTable.recipient] = recipient(platform, event.platformUserId)
            }
        }
        if (bound != 1) return WebLoginConfirm.InvalidCode
        fillDisplayName(userId, event)
        return WebLoginConfirm.Confirmed(greetingName(userId))
    }

    /** The bot received a link code ([startLink]): attaches the sender's account to the code's owner. */
    open fun redeemLinkCode(rawCode: String, event: BotEvent): LinkResult {
        val platform = event.platform
        val row = find(rawCode, OtpPurpose.LINK_SOCIAL, null)
            ?.takeIf { it.channel == platform.otpChannel && it.status == OtpStatus.PENDING }
            ?: return LinkResult.InvalidCode
        val ownerId = row.userId ?: return LinkResult.InvalidCode
        if (row.isExpired(Instant.now())) return LinkResult.ExpiredCode

        val existing = social.findByExternal(platform.code, event.platformUserId)
        if (existing != null && existing.userId == ownerId) return LinkResult.AlreadyLinked
        if (social.findForUser(ownerId, platform.code) != null) return LinkResult.AlreadyLinked
        if (existing != null) {
            // The messenger account already belongs to another shop account: merge it into the owner when allowed.
            val merger = accountMerge
            if (merger == null || users.findById(existing.userId) == null) return LinkResult.AccountTaken
            return mergeInto(row, ownerId, existing.userId, event, merger)
        }

        // Spend the code and create the link atomically: a lost race on either
        // (code or account) rolls both back.
        try {
            val spent = transaction(mainDb) {
                if (otp.redeem(row.code, OtpPurpose.LINK_SOCIAL, row.recipient) !is OtpRedeemResult.Redeemed) {
                    false
                } else {
                    social.link(ownerId, platform.code, event.platformUserId, event.fromDisplayName ?: event.fromUsername)
                    true
                }
            }
            if (!spent) return LinkResult.InvalidCode
        } catch (e: ExposedSQLException) {
            if (e.sqlState != UNIQUE_VIOLATION) throw e
            return LinkResult.AccountTaken
        }
        notifyChannels.ensure(ownerId, platform.code)
        fillDisplayName(ownerId, event)
        return LinkResult.Linked(ownerId, greetingName(ownerId))
    }

    /** The shop user behind the messenger account, registering one on first contact when allowed. */
    open fun findOrRegister(event: BotEvent): Long? {
        val platform = event.platform
        social.findByExternal(platform.code, event.platformUserId)?.let { link ->
            return link.userId.takeIf { users.findById(it) != null }
        }
        if (!config.autoRegister) return null
        return register(event)
    }

    /**
     * Spends the link code and merges [fromUserId] into [ownerId] atomically: a merge that
     * throws (e.g. a host contributor) rolls the code back too, so it can be retried.
     */
    private fun mergeInto(row: OtpCode, ownerId: Long, fromUserId: Long, event: BotEvent, merger: AccountMergeService): LinkResult {
        try {
            val done = transaction(mainDb) {
                if (otp.redeem(row.code, OtpPurpose.LINK_SOCIAL, row.recipient) !is OtpRedeemResult.Redeemed) {
                    false
                } else {
                    merger.merge(fromUserId, ownerId)
                    true
                }
            }
            if (!done) return LinkResult.InvalidCode
        } catch (e: MergeRefusedException) {
            return LinkResult.AccountTaken
        }
        fillDisplayName(ownerId, event)
        notifyChannels.ensure(ownerId, event.platform.code)
        return LinkResult.Merged(ownerId, greetingName(ownerId))
    }

    /** Display name of a user ("" when gone) for bot replies. */
    open fun usernameOf(userId: Long): String = users.findById(userId)?.username.orEmpty()

    /** What the bot calls the user in greetings: display name, else username ("" when the user is gone). */
    open fun greetingName(userId: Long): String = users.findById(userId)?.shownName.orEmpty()

    /**
     * Fills `users.display_name` from the sender's first name when it is still empty.
     * An existing value is never overwritten - the user may have edited it.
     */
    open fun fillDisplayName(userId: Long, event: BotEvent) {
        val first = event.fromFirstName?.trim()?.take(100)?.takeIf { it.isNotEmpty() } ?: return
        users.setDisplayNameIfAbsent(userId, first)
    }

    /** Whether the messenger account is already linked to a live user. */
    open fun findUserId(platform: BotPlatform, platformUserId: String): Long? =
        social.findByExternal(platform.code, platformUserId)?.userId?.takeIf { users.findById(it) != null }

    // ---- internals -------------------------------------------------------

    /** Creates user + link + default notification channels; null if another request linked the account first. */
    private fun register(event: BotEvent): Long? {
        val platform = event.platform
        repeat(MAX_REGISTER_ATTEMPTS) { attempt ->
            try {
                return transaction(mainDb) {
                    val user = users.createUser(
                        username = pickUsername(event, attempt),
                        email = "${platform.code}-${event.platformUserId}@${config.placeholderEmailDomain}",
                    )
                    social.link(user.id, platform.code, event.platformUserId, event.fromDisplayName ?: event.fromUsername)
                    notifyChannels.set(user.id, listOf(UserNotifyChannelsService.SITE, platform.code))
                    fillDisplayName(user.id, event)
                    user.id
                }
            } catch (e: ExposedSQLException) {
                if (e.sqlState != UNIQUE_VIOLATION) throw e
                // Either the account was linked concurrently (done) or the username is taken (retry).
                social.findByExternal(platform.code, event.platformUserId)?.let { return it.userId }
            }
        }
        return null
    }

    private fun pickUsername(event: BotEvent, attempt: Int): String {
        val seed = (event.fromUsername ?: event.fromDisplayName).orEmpty()
            .replace(Regex("[^A-Za-z0-9_]"), "_").trim('_')
        val base = if (seed.length >= 3) seed.take(USERNAME_MAX - 5) else "${event.platform.code}_${event.platformUserId}".take(USERNAME_MAX - 5)
        val candidate = if (attempt == 0) base else "${base}_${RANDOM.nextInt(1000, 10000)}"
        // Fast path for the common clash; the unique index decides under races.
        return if (attempt == 0 && users.findByUsername(candidate) != null) "${base}_${RANDOM.nextInt(1000, 10000)}" else candidate
    }

    /** Spends [row] (conditional flip) and maps the verdict. */
    private fun spend(row: OtpCode, userId: Long): CodeLogin {
        if (users.findById(userId) == null) return CodeLogin.Invalid
        return when (otp.redeem(row.code, row.purpose)) {
            is OtpRedeemResult.Redeemed -> CodeLogin.Success(userId)
            OtpRedeemResult.Expired -> CodeLogin.Expired
            else -> CodeLogin.Invalid
        }
    }

    /** Row for [rawCode] if it has the right [purpose] and (when given) [mode]; expiry is the caller's call. */
    private fun find(rawCode: String, purpose: OtpPurpose, mode: LoginMode?): OtpCode? {
        val row = otp.findByCode(rawCode.trim().uppercase())?.takeIf { it.purpose == purpose } ?: return null
        if (mode != null && modeOf(row) != mode) return null
        return row
    }

    private fun modeOf(row: OtpCode): LoginMode? {
        val wire = (row.payload as? JsonObject)?.get("mode").str()
        return LoginMode.entries.firstOrNull { it.wire == wire }
    }

    private fun recipient(platform: BotPlatform, platformUserId: String?) = "${platform.code}:${platformUserId ?: "*"}"

    /**
     * Inserts a fresh code. `otp_codes.code` is the primary key and spent rows
     * linger for the retention period, so a collision regenerates the code.
     * Must run outside a transaction: a failed INSERT would poison it.
     */
    private fun issue(
        prefix: String, platform: BotPlatform, purpose: OtpPurpose, recipient: String,
        ttlMinutes: Long, userId: Long?, mode: LoginMode?,
    ): IssuedCode {
        val payload = mode?.let { m -> buildJsonObject { put("mode", m.wire) } }
        var attempt = 1
        while (true) {
            try {
                val row = otp.issue(
                    code = newCode(prefix), channel = platform.otpChannel, purpose = purpose,
                    recipient = recipient, ttl = Duration.ofMinutes(ttlMinutes), userId = userId, payload = payload,
                )
                return IssuedCode(row.code, row.expiresAt)
            } catch (e: ExposedSQLException) {
                if (e.sqlState != UNIQUE_VIOLATION || attempt++ >= MAX_ISSUE_ATTEMPTS) throw e
            }
        }
    }

    companion object {
        const val LOGIN_PREFIX = "AC"
        const val LINK_PREFIX = "LK"

        /** Matches a login/link code as typed by a user (case-insensitive). */
        val CODE_PATTERN = Regex("^(AC|LK)-[A-Z0-9]{4,12}$", RegexOption.IGNORE_CASE)

        private const val UNIQUE_VIOLATION = "23505"
        private const val MAX_ISSUE_ATTEMPTS = 3
        private const val MAX_REGISTER_ATTEMPTS = 4
        private const val USERNAME_MAX = 16
        private val RANDOM = SecureRandom()

        // No 0/O/1/I - codes are read off a screen and typed.
        private val ALPHABET = ('A'..'Z').filter { it !in "OI" } + ('2'..'9')

        private fun newCode(prefix: String): String =
            "$prefix-" + String(CharArray(6) { ALPHABET[RANDOM.nextInt(ALPHABET.size)] })
    }
}
