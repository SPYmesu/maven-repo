package su.spyme.marketplace.users

import com.github.benmanes.caffeine.cache.Cache
import com.github.benmanes.caffeine.cache.Caffeine
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.Op
import org.jetbrains.exposed.sql.QueryBuilder
import org.jetbrains.exposed.sql.SortOrder
import org.jetbrains.exposed.sql.VarCharColumnType
import org.jetbrains.exposed.sql.or
import org.jetbrains.exposed.sql.SqlExpressionBuilder
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.like
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.core.auth.RoleRegistry
import java.time.Duration
import java.time.Instant

open class UsersServiceBase(
    protected val mainDb: Database,
    protected val roleRegistry: RoleRegistry,
    cacheTtlSeconds: Long = 60,
) {

    private val byIdCache: Cache<Long, User> = Caffeine.newBuilder()
        .expireAfterWrite(Duration.ofSeconds(cacheTtlSeconds))
        .maximumSize(10_000)
        .build()

    open fun createUser(
        username: String,
        email: String,
        roles: List<String> = listOf(RoleRegistry.USER.code),
        locale: String = "ru",
        timezone: String? = null,
        phone: String? = null,
    ): User {
        require(username.isNotBlank()) { "username must not be blank" }
        require(email.isNotBlank()) { "email must not be blank" }
        validateRoles(roles)

        return transaction(mainDb) {
            val newId = BaseUsersTable.insert {
                it[BaseUsersTable.username] = username
                it[BaseUsersTable.email] = email
                it[BaseUsersTable.roles] = roles
                it[BaseUsersTable.locale] = locale
                it[BaseUsersTable.timezone] = timezone
                it[BaseUsersTable.phone] = phone
            }[BaseUsersTable.id]
            loadById(newId, includeDeleted = false) ?: error("Inserted user $newId not found in tx")
        }
    }

    open fun findById(id: Long, includeDeleted: Boolean = false): User? {
        byIdCache.getIfPresent(id)?.let { cached ->
            if (includeDeleted || !cached.isDeleted) return cached
        }
        val loaded = transaction(mainDb) { loadById(id, includeDeleted) }
        if (loaded != null) byIdCache.put(id, loaded)
        return loaded
    }

    open fun findByEmail(email: String, includeDeleted: Boolean = false): User? =
        transaction(mainDb) {
            BaseUsersTable.selectAll()
                .where {
                    if (includeDeleted) BaseUsersTable.email eq email
                    else (BaseUsersTable.email eq email) and BaseUsersTable.deletedAt.isNull()
                }
                .firstOrNull()
                ?.let(User::fromRow)
        }

    open fun findByUsername(username: String, includeDeleted: Boolean = false): User? =
        transaction(mainDb) {
            BaseUsersTable.selectAll()
                .where {
                    if (includeDeleted) BaseUsersTable.username eq username
                    else (BaseUsersTable.username eq username) and BaseUsersTable.deletedAt.isNull()
                }
                .firstOrNull()
                ?.let(User::fromRow)
        }

    /**
     * Admin listing, newest first, soft-deleted users included. [query] matches
     * username or email as a substring (case-insensitive) or the exact id;
     * [role] keeps users holding that role code. Returns the page and the total.
     */
    open fun search(query: String? = null, role: String? = null, offset: Long = 0, limit: Int = 50): Pair<List<User>, Long> =
        transaction(mainDb) {
            val q = query?.trim()?.takeIf { it.isNotEmpty() }
            val filter: Op<Boolean> = listOfNotNull(
                q?.let { raw ->
                    val like = "%" + raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
                    val byText = (BaseUsersTable.username like like) or (BaseUsersTable.email like like)
                    raw.toLongOrNull()?.let { byText or (BaseUsersTable.id eq it) } ?: byText
                },
                role?.takeIf { it.isNotBlank() }?.let(::holdsRole),
            ).fold(Op.TRUE as Op<Boolean>) { acc, op -> acc and op }
            val total = BaseUsersTable.selectAll().where { filter }.count()
            val page = BaseUsersTable.selectAll().where { filter }
                .orderBy(BaseUsersTable.id to SortOrder.DESC)
                .limit(limit).offset(offset)
                .map(User::fromRow)
            page to total
        }

    /** `'ROLE' = ANY(users.roles)` */
    private fun holdsRole(role: String): Op<Boolean> = object : Op<Boolean>() {
        override fun toQueryBuilder(queryBuilder: QueryBuilder) {
            queryBuilder.registerArgument(VarCharColumnType(), role)
            queryBuilder.append(" = ANY(")
            queryBuilder.append(BaseUsersTable.roles)
            queryBuilder.append(")")
        }
    }

    open fun assignRoles(id: Long, roles: List<String>) {
        validateRoles(roles)
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.roles] = roles
            }
        }
        byIdCache.invalidate(id)
    }

    /**
     * Self-service profile edit: changes [username] and/or [locale] when non-null.
     * A username already taken by an active user surfaces as the SQL unique
     * violation (`users_username_active_idx`), SQLState 23505.
     */
    open fun updateProfile(id: Long, username: String? = null, locale: String? = null) {
        if (username == null && locale == null) return
        require(username == null || username.isNotBlank()) { "username must not be blank" }
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                if (username != null) it[BaseUsersTable.username] = username
                if (locale != null) it[BaseUsersTable.locale] = locale
            }
        }
        byIdCache.invalidate(id)
    }

    /** Sets the display name; null clears it (the UI then falls back to the username). */
    open fun setDisplayName(id: Long, displayName: String?) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) { it[BaseUsersTable.displayName] = displayName }
        }
        byIdCache.invalidate(id)
    }

    /** Fills the display name only when it is still empty (never overwrites an edited one). */
    open fun setDisplayNameIfAbsent(id: Long, displayName: String): Boolean {
        val changed = transaction(mainDb) {
            BaseUsersTable.update({ (BaseUsersTable.id eq id) and BaseUsersTable.displayName.isNull() }) {
                it[BaseUsersTable.displayName] = displayName
            }
        } > 0
        if (changed) byIdCache.invalidate(id)
        return changed
    }

    /**
     * Marks [fromId] as folded into [intoId]: soft-deletes it and bumps its jwt_version.
     * Runs in the caller's transaction when there is one (account merge); the caches are
     * dropped here and again by the merge service after it commits.
     */
    open fun markMerged(fromId: Long, intoId: Long, now: Instant = Instant.now()) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq fromId }) {
                it[BaseUsersTable.deletedAt] = now
                it[BaseUsersTable.mergedIntoUserId] = intoId
                with(SqlExpressionBuilder) { it[BaseUsersTable.jwtVersion] = BaseUsersTable.jwtVersion + 1 }
            }
        }
        invalidateCache(fromId)
    }

    /** Drops the cached copy of [id] (after changes made outside this service's own methods). */
    open fun invalidateCache(id: Long) = byIdCache.invalidate(id)

    open fun markEmailVerified(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.emailVerifiedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    open fun markPhoneVerified(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.phoneVerifiedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    open fun updateLastActiveAt(id: Long, at: Instant = Instant.now()) {
        // last_active_at is cheap and stale reads cost nothing — bypass cache invalidation.
        transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                it[BaseUsersTable.lastActiveAt] = at
            }
        }
    }

    /**
     * Increments [BaseUsersTable.jwtVersion] atomically — every JWT
     * minted before this point becomes invalid (per В1 bulk-revoke).
     * Returns the new version.
     */
    open fun bumpJwtVersion(id: Long): Int {
        val newVersion = transaction(mainDb) {
            BaseUsersTable.update({ BaseUsersTable.id eq id }) {
                with(SqlExpressionBuilder) {
                    it[BaseUsersTable.jwtVersion] = BaseUsersTable.jwtVersion + 1
                }
            }
            BaseUsersTable.selectAll()
                .where { BaseUsersTable.id eq id }
                .first()[BaseUsersTable.jwtVersion]
        }
        byIdCache.invalidate(id)
        return newVersion
    }

    open fun softDelete(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({
                (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNull()
            }) {
                it[BaseUsersTable.deletedAt] = Instant.now()
            }
        }
        byIdCache.invalidate(id)
    }

    /**
     * Lifts soft-delete. Fails silently if the row's email/username is
     * now claimed by an active user — partial unique indexes will
     * reject the row's resurrection at the SQL layer; caller resolves. A merged-away user is never restored.
     */
    open fun restoreDeleted(id: Long) {
        transaction(mainDb) {
            BaseUsersTable.update({
                (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNotNull() and
                    BaseUsersTable.mergedIntoUserId.isNull()
            }) {
                it[BaseUsersTable.deletedAt] = null
            }
        }
        byIdCache.invalidate(id)
    }

    private fun loadById(id: Long, includeDeleted: Boolean): User? =
        BaseUsersTable.selectAll()
            .where {
                if (includeDeleted) BaseUsersTable.id eq id
                else (BaseUsersTable.id eq id) and BaseUsersTable.deletedAt.isNull()
            }
            .firstOrNull()
            ?.let(User::fromRow)

    private fun validateRoles(roles: List<String>) {
        val unknown = roles.filterNot(roleRegistry::isValid)
        require(unknown.isEmpty()) { "Unknown role(s): $unknown" }
    }
}
