package su.spyme.marketplace.inventory

import su.spyme.marketplace.orders.state.OrderStatus
import su.spyme.marketplace.orders.state.OrderTransitionEvent
import su.spyme.marketplace.orders.state.OrderTransitionListener

/**
 * Keeps stock reservations in step with the order lifecycle (the storefront
 * reserves at checkout):
 *
 *  - `PAID` - the hold is extended by [paidHoldSeconds] so the expiry sweep does
 *    not release stock that is already sold and waiting to ship;
 *  - `SHIPPED` - the hold is fulfilled (`on_hand` and `reserved` drop);
 *  - `CANCELLED` - the hold is released.
 *
 * All three are idempotent, as listeners must be. Registered by
 * [su.spyme.marketplace.web.storefrontRoutes] when the host enabled stock tracking.
 */
class InventoryOrderListener(
    private val inventory: InventoryServiceBase,
    private val paidHoldSeconds: Long,
) : OrderTransitionListener {
    override suspend fun onTransition(event: OrderTransitionEvent) {
        when (event.to) {
            OrderStatus.PAID -> inventory.extendOrderReservations(event.orderId, paidHoldSeconds, event.occurredAt)
            OrderStatus.SHIPPED -> inventory.fulfillOrderReservations(event.orderId, event.occurredAt)
            OrderStatus.CANCELLED -> inventory.releaseOrderReservations(event.orderId, event.occurredAt)
            else -> Unit
        }
    }
}
