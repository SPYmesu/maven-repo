package su.spyme.marketplace.payments

import su.spyme.marketplace.core.Money
import java.util.UUID

/**
 * Gateway that takes no real money: [initiate] answers without a redirect and
 * [capture] always succeeds, so a checkout through it ends with the order
 * already `PAID` (the storefront captures right away when the gateway returns
 * no `redirectUrl`).
 *
 * Meant for demos, staging and integration tests. It is never registered
 * implicitly: a host adds it to the [PaymentGatewayRegistry] only when its own
 * configuration says so, e.g.
 *
 * ```kotlin
 * if (config.testPaymentsEnabled) gateways.register(TestPaymentGateway(title = "Bank card"))
 * ```
 *
 * @property title label shown in the checkout provider list.
 */
class TestPaymentGateway(override val title: String = "Test payment") : PaymentGateway {

    override val name: String = CODE

    override suspend fun initiate(
        orderId: Long,
        amount: Money,
        idempotencyKey: String,
        returnUrl: String,
        metadata: Map<String, String>,
    ): PaymentGateway.InitiateResult =
        // Deterministic per idempotency key, like a real provider's payment id.
        PaymentGateway.InitiateResult(
            providerPaymentId = "test_" + UUID.nameUUIDFromBytes(idempotencyKey.toByteArray()),
            redirectUrl = null,
            gatewayMetadata = null,
        )

    override suspend fun capture(providerPaymentId: String): PaymentGateway.CaptureResult =
        PaymentGateway.CaptureResult(captured = true, gatewayMetadata = null)

    override suspend fun cancel(providerPaymentId: String): Boolean = true

    override suspend fun refund(
        providerPaymentId: String,
        amount: Money,
        idempotencyKey: String,
    ): PaymentGateway.RefundResult =
        PaymentGateway.RefundResult(
            refundProviderId = "test_refund_" + UUID.nameUUIDFromBytes(idempotencyKey.toByteArray()),
            gatewayMetadata = null,
        )

    /** Nothing calls back asynchronously: every operation completes inline. */
    override suspend fun parseWebhook(headers: Map<String, String>, body: String): PaymentGateway.WebhookEvent? = null

    companion object {
        /** `payments.provider` value and the `paymentProvider` the SPA sends. */
        const val CODE = "test"
    }
}
