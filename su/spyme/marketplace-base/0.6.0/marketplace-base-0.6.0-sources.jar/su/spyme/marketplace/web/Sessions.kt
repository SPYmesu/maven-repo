package su.spyme.marketplace.web

import io.ktor.http.Cookie
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.plugins.origin
import io.ktor.server.request.header
import su.spyme.marketplace.cart.CartOwner
import su.spyme.marketplace.core.auth.AuthService
import su.spyme.marketplace.users.User
import java.util.UUID

/** Cookie-based identity: who is calling, sign-in/out, the guest cart token. */
internal class Sessions(private val deps: StorefrontDeps) {

    private val config get() = deps.config

    /** The verified login behind the request (cookie, or `Authorization: Bearer`), or null for a guest. */
    fun current(call: ApplicationCall): AuthService.VerifiedAuth? {
        val token = call.request.cookies[config.authCookieName]
            ?: call.request.header("Authorization")?.removePrefix("Bearer ")?.takeIf { it.isNotBlank() }
            ?: return null
        // Any verification failure (bad signature, expired, revoked, user gone) is simply "not signed in".
        return runCatching { deps.auth.verifyAccessToken(token) }.getOrNull()
    }

    fun user(call: ApplicationCall): User? = current(call)?.user

    fun requireUser(call: ApplicationCall): User =
        user(call) ?: throw ApiException(HttpStatusCode.Unauthorized, "UNAUTHORIZED", "Sign in required")

    /** Signed in with at least [StorefrontConfig.adminRole]. */
    /** Signed in with at least [role] (401 guest, 403 below). */
    fun requireRole(call: ApplicationCall, role: String): User {
        val user = requireUser(call)
        if (!deps.roles.hasAtLeast(user.roles, role)) {
            throw ApiException(HttpStatusCode.Forbidden, "FORBIDDEN", "Not allowed")
        }
        return user
    }

    fun requireStaff(call: ApplicationCall): User {
        val user = requireUser(call)
        if (!deps.roles.hasAtLeast(user.roles, config.adminRole)) {
            throw ApiException(HttpStatusCode.Forbidden, "FORBIDDEN", "Not allowed")
        }
        return user
    }

    /** Opens a session for [userId] and sets the auth cookie. */
    fun signIn(call: ApplicationCall, userId: Long) {
        val result = deps.auth.login(
            userId = userId,
            deviceLabel = null,
            ip = ipLiteral(call),
            userAgent = call.request.header("User-Agent")?.take(255),
        )
        setCookie(call, config.authCookieName, result.accessToken, deps.authConfig.jwtAccessTtl.inWholeSeconds)
    }

    /** Revokes the current session (if any) and clears the auth cookie. */
    fun signOut(call: ApplicationCall) {
        current(call)?.let { deps.auth.logout(it.session.id) }
        clearCookie(call, config.authCookieName)
    }

    fun clientIp(call: ApplicationCall): String = call.request.origin.remoteAddress

    /** The client address if it is an IP literal (fits INET columns), else null. */
    fun ipLiteral(call: ApplicationCall): String? = clientIp(call).takeIf { IP_LITERAL.matches(it) }

    /** Cart of the caller: the user's, else the guest's, else null (no cookie yet). */
    fun cartOwner(call: ApplicationCall): CartOwner? =
        user(call)?.let { CartOwner.User(it.id) } ?: guestToken(call)?.let { CartOwner.Guest(it) }

    /** Like [cartOwner] but starts a guest cart (sets the cookie) when there is none. */
    fun cartOwnerOrStart(call: ApplicationCall): CartOwner {
        cartOwner(call)?.let { return it }
        val token = UUID.randomUUID().toString().replace("-", "")
        setCookie(call, config.cartCookieName, token, config.cartCookieMaxAge.seconds)
        return CartOwner.Guest(token)
    }

    /** The `mp_cart` token if it has the shape we issue; anything else is ignored. */
    fun guestToken(call: ApplicationCall): String? =
        call.request.cookies[config.cartCookieName]?.takeIf { TOKEN.matches(it) }

    fun clearGuestToken(call: ApplicationCall) = clearCookie(call, config.cartCookieName)

    private fun setCookie(call: ApplicationCall, name: String, value: String, maxAgeSeconds: Long) {
        call.response.cookies.append(
            Cookie(
                name = name, value = value, maxAge = maxAgeSeconds.toInt(), path = "/",
                httpOnly = true, secure = secure(call), extensions = mapOf("SameSite" to "Lax"),
            ),
        )
    }

    private fun clearCookie(call: ApplicationCall, name: String) = setCookie(call, name, "", 0)

    private fun secure(call: ApplicationCall) = config.secureCookies ?: (call.request.origin.scheme == "https")

    private companion object {
        /** `user_sessions.ip` is an INET column: store only IP literals, never a host name. */
        val IP_LITERAL = Regex("^(?=.*[.:])[0-9A-Fa-f:.]+$")
        val TOKEN = Regex("^[A-Za-z0-9_-]{16,64}$")
    }
}
