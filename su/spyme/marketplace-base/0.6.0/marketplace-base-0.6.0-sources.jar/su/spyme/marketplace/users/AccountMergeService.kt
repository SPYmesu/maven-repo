package su.spyme.marketplace.users

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.inList
import org.jetbrains.exposed.sql.Transaction
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.TransactionManager
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import su.spyme.marketplace.audit.AuditServiceBase
import su.spyme.marketplace.cart.BaseCartItemsTable
import su.spyme.marketplace.cart.CartItem
import su.spyme.marketplace.notifications.UserNotifyChannelsService
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Host hook of an account merge: move the host's own user-owned rows (purchases,
 * licences, `users_<host>_extras`, ...) from [fromUserId] to [intoUserId].
 *
 * Runs inside the merge transaction, after the base tables were moved: use [tx] (or
 * any Exposed statement - they join it). Throwing aborts and rolls back the whole
 * merge, base tables included. Must tolerate rows that exist on both sides (the
 * survivor's data wins).
 */
fun interface AccountMergeContributor {
    fun merge(tx: Transaction, fromUserId: Long, intoUserId: Long)
}

/** The merge cannot run: a side is missing, deleted, already merged, or both are the same. */
class MergeRefusedException(message: String) : RuntimeException(message)

/**
 * Outcome of [AccountMergeService.merge].
 *
 * @property emailTaken the survivor had a placeholder email and took the merged
 *           account's verified one.
 */
data class MergeReport(val fromUserId: Long, val intoUserId: Long, val emailTaken: Boolean)

/**
 * Folds user B ([merge] `fromUserId`) into user A (`intoUserId`) in ONE transaction.
 *
 * A keeps: username, display name (B's fills a gap), roles - never escalated from B,
 * locale, notification settings (B's channels are appended) and email (unless it is
 * a placeholder at [placeholderEmailDomain] and B has a verified real one: B's is taken).
 *
 * Moved from B to A: orders (checkout details, history, payments, refunds and shipments
 * hang off the order), cart lines (same product/variant are summed, capped at the
 * available stock for lines the survivor already had - see [stockCap]), bookmarks
 * (union), reviews (a product both reviewed keeps A's), review replies, in-app and other
 * notifications, social links (A's win a clash on the same provider), OAuth tokens,
 * referral rewards (rewards between A and B are dropped), subscriptions, downloads,
 * shipping addresses, promocode redemptions, passkeys, API keys, webhook
 * subscriptions and uploads. A's password and TOTP win; B's are dropped when A has
 * its own. B's pending one-time codes and WebAuthn challenges are deleted.
 * Left on B (history, harmless once B is gone): audit entries, `settings.updated_by`,
 * refund actors, vendor memberships, GDPR requests.
 *
 * B ends soft-deleted with `merged_into_user_id = A`, a bumped jwt_version and no
 * sessions, so it never resolves for login, OTP or bot lookups again. An audit entry
 * `user.merge` (not reversible) records both ids. Host tables are moved by
 * [AccountMergeContributor]s registered with [addContributor].
 *
 * @property stockCap available quantity of a product/variant, or null when stock is
 *           not tracked; used to cap merged cart lines.
 */
open class AccountMergeService(
    protected val mainDb: Database,
    protected val users: UsersServiceBase,
    protected val sessions: UserSessionsService,
    protected val notifyChannels: UserNotifyChannelsService,
    protected val audit: AuditServiceBase,
    private val placeholderEmailDomain: String = "bot.invalid",
    private val stockCap: (productId: Long, variantId: Long?) -> Int? = { _, _ -> null },
    contributors: List<AccountMergeContributor> = emptyList(),
) {
    private val contributors = CopyOnWriteArrayList(contributors)

    /** Registers a host hook; it runs for every later merge. */
    fun addContributor(contributor: AccountMergeContributor) {
        contributors += contributor
    }

    /** @throws MergeRefusedException when the merge is not allowed; any other failure rolls everything back. */
    open fun merge(fromUserId: Long, intoUserId: Long): MergeReport {
        if (fromUserId == intoUserId) throw MergeRefusedException("cannot merge an account into itself")
        val report = transaction(mainDb) {
            val tx = TransactionManager.current()
            // Lock both rows, lowest id first, so two crossing merges cannot deadlock.
            val rows = BaseUsersTable.selectAll()
                .where { BaseUsersTable.id inList listOf(fromUserId, intoUserId) }
                .orderBy(BaseUsersTable.id)
                .forUpdate()
                .map(User::fromRow)
                .associateBy { it.id }
            val from = rows[fromUserId] ?: throw MergeRefusedException("user $fromUserId not found")
            val into = rows[intoUserId] ?: throw MergeRefusedException("user $intoUserId not found")
            if (from.isDeleted || from.mergedIntoUserId != null) throw MergeRefusedException("user $fromUserId is gone")
            if (into.isDeleted || into.mergedIntoUserId != null) throw MergeRefusedException("user $intoUserId is gone")

            moveOrders(tx, fromUserId, intoUserId)
            mergeCarts(fromUserId, intoUserId)
            moveBookmarks(tx, fromUserId, intoUserId)
            moveReviews(tx, fromUserId, intoUserId)
            moveNotifications(tx, fromUserId, intoUserId)
            moveSocialLinks(tx, fromUserId, intoUserId)
            mergeNotifyChannels(tx, fromUserId, intoUserId)
            moveReferrals(tx, fromUserId, intoUserId)
            moveCredentials(tx, fromUserId, intoUserId)
            moveOtherOwnedRows(tx, fromUserId, intoUserId)

            users.markMerged(fromUserId, intoUserId)
            sessions.revokeAllByUser(fromUserId)

            // Identity: the survivor's wins, except a placeholder email and an empty display name.
            val takeEmail = into.email.endsWith("@$placeholderEmailDomain", ignoreCase = true) &&
                from.isEmailVerified && !from.email.endsWith("@$placeholderEmailDomain", ignoreCase = true)
            if (takeEmail || (into.displayName == null && from.displayName != null)) {
                BaseUsersTable.update({ BaseUsersTable.id eq intoUserId }) {
                    if (takeEmail) {
                        it[BaseUsersTable.email] = from.email
                        it[BaseUsersTable.emailVerifiedAt] = from.emailVerifiedAt
                    }
                    if (into.displayName == null && from.displayName != null) it[BaseUsersTable.displayName] = from.displayName
                }
            }

            contributors.forEach { it.merge(tx, fromUserId, intoUserId) }

            audit.log(
                action = "user.merge", entityType = "USER", entityId = intoUserId,
                actorUserId = intoUserId,
                snapshotBefore = buildJsonObject { put("fromUserId", fromUserId); put("roles", strings(from.roles)) },
                snapshotAfter = buildJsonObject {
                    put("fromUserId", fromUserId); put("intoUserId", intoUserId); put("emailTaken", takeEmail)
                },
                isReversible = false,
            )
            MergeReport(fromUserId, intoUserId, takeEmail)
        }
        users.invalidateCache(fromUserId)
        users.invalidateCache(intoUserId)
        return report
    }

    // ---- per-area moves (all run in the merge transaction) ----

    private fun moveOrders(tx: Transaction, from: Long, into: Long) {
        tx.exec("UPDATE orders SET user_id = $into WHERE user_id = $from")
        tx.exec("UPDATE orders SET cancelled_by = $into WHERE cancelled_by = $from")
    }

    private fun mergeCarts(from: Long, into: Long) {
        val mine = BaseCartItemsTable.selectAll().where { BaseCartItemsTable.userId eq into }
            .map(CartItem::fromRow).associateBy { it.productId to it.variantId }
        for (line in BaseCartItemsTable.selectAll().where { BaseCartItemsTable.userId eq from }.map(CartItem::fromRow)) {
            val existing = mine[line.productId to line.variantId]
            if (existing == null) {
                BaseCartItemsTable.update({ BaseCartItemsTable.id eq line.id }) { it[BaseCartItemsTable.userId] = into }
            } else {
                var sum = existing.quantity + line.quantity
                // Never push the survivor's own line below what they already had.
                stockCap(line.productId, line.variantId)?.let { sum = minOf(sum, maxOf(it, existing.quantity)) }
                BaseCartItemsTable.update({ BaseCartItemsTable.id eq existing.id }) { it[BaseCartItemsTable.quantity] = sum }
                BaseCartItemsTable.deleteWhere { BaseCartItemsTable.id eq line.id }
            }
        }
    }

    private fun moveBookmarks(tx: Transaction, from: Long, into: Long) {
        tx.exec("INSERT INTO bookmarks (user_id, product_id) SELECT $into, product_id FROM bookmarks WHERE user_id = $from ON CONFLICT DO NOTHING")
        tx.exec("DELETE FROM bookmarks WHERE user_id = $from")
    }

    private fun moveReviews(tx: Transaction, from: Long, into: Long) {
        // One review per (user, product): where A already reviewed, A's stays and B's goes (replies cascade).
        tx.exec("DELETE FROM reviews WHERE user_id = $from AND product_id IN (SELECT product_id FROM reviews WHERE user_id = $into)")
        tx.exec("UPDATE reviews SET user_id = $into WHERE user_id = $from")
        tx.exec("UPDATE review_replies SET user_id = $into WHERE user_id = $from")
    }

    private fun moveNotifications(tx: Transaction, from: Long, into: Long) {
        tx.exec("UPDATE notifications SET recipient = '$into' WHERE user_id = $from AND channel = 'in-app'")
        tx.exec("UPDATE notifications SET user_id = $into WHERE user_id = $from")
    }

    private fun moveSocialLinks(tx: Transaction, from: Long, into: Long) {
        tx.exec("DELETE FROM social_links WHERE user_id = $from AND provider IN (SELECT provider FROM social_links WHERE user_id = $into)")
        tx.exec("UPDATE social_links SET user_id = $into WHERE user_id = $from")
        tx.exec("UPDATE oauth_tokens SET user_id = $into WHERE user_id = $from")
    }

    private fun mergeNotifyChannels(tx: Transaction, from: Long, into: Long) {
        val theirs = notifyChannels.get(from)
        val mine = notifyChannels.get(into)
        notifyChannels.set(into, mine + theirs.filter { it !in mine })
        tx.exec("DELETE FROM user_notify_channels WHERE user_id = $from")
    }

    private fun moveReferrals(tx: Transaction, from: Long, into: Long) {
        // A reward between the two merged accounts would become a self-referral.
        tx.exec(
            "DELETE FROM referral_rewards WHERE (referrer_user_id = $from AND referred_user_id = $into) " +
                "OR (referrer_user_id = $into AND referred_user_id = $from)",
        )
        tx.exec("UPDATE referral_rewards SET referrer_user_id = $into WHERE referrer_user_id = $from")
        tx.exec("UPDATE referral_rewards SET referred_user_id = $into WHERE referred_user_id = $from")
    }

    private fun moveCredentials(tx: Transaction, from: Long, into: Long) {
        // The survivor's password / TOTP win; B's are taken over only when A has none.
        tx.exec("UPDATE password_credentials SET user_id = $into WHERE user_id = $from AND NOT EXISTS (SELECT 1 FROM password_credentials WHERE user_id = $into)")
        tx.exec("DELETE FROM password_credentials WHERE user_id = $from")
        val takesTotp = !exists(tx, "SELECT 1 FROM totp_secrets WHERE user_id = $into")
        if (takesTotp) {
            tx.exec("UPDATE totp_secrets SET user_id = $into WHERE user_id = $from")
            tx.exec("UPDATE totp_recovery_codes SET user_id = $into WHERE user_id = $from")
        }
        tx.exec("DELETE FROM totp_recovery_codes WHERE user_id = $from")
        tx.exec("DELETE FROM totp_secrets WHERE user_id = $from")
        tx.exec("UPDATE webauthn_credentials SET user_id = $into WHERE user_id = $from")
        tx.exec("DELETE FROM webauthn_challenges WHERE user_id = $from")
        // A code B was issued (login, link, 2FA step) must not work any more.
        tx.exec("DELETE FROM otp_codes WHERE user_id = $from")
    }

    private fun moveOtherOwnedRows(tx: Transaction, from: Long, into: Long) {
        tx.exec("UPDATE subscriptions SET user_id = $into WHERE user_id = $from")
        tx.exec("UPDATE downloads SET user_id = $into WHERE user_id = $from")
        // Moved addresses must not become a second default.
        tx.exec("UPDATE shipping_addresses SET user_id = $into, is_default = FALSE WHERE user_id = $from")
        tx.exec("UPDATE promocode_redemptions SET user_id = $into WHERE user_id = $from")
        tx.exec("UPDATE api_keys SET scope_user_id = $into WHERE scope_user_id = $from")
        tx.exec("UPDATE webhook_subscriptions SET owner_user_id = $into WHERE owner_user_id = $from")
        tx.exec("UPDATE uploads SET uploaded_by_user_id = $into WHERE uploaded_by_user_id = $from")
    }

    private fun exists(tx: Transaction, select: String): Boolean =
        tx.exec("SELECT EXISTS ($select)") { rs -> rs.next() && rs.getBoolean(1) } ?: false

    private fun strings(list: List<String>) = JsonArray(list.map { JsonPrimitive(it) })
}
