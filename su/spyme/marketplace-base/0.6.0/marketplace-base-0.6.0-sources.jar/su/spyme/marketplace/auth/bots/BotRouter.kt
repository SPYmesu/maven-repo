package su.spyme.marketplace.auth.bots

import kotlinx.coroutines.CancellationException
import org.slf4j.LoggerFactory
import su.spyme.marketplace.core.ratelimit.CaffeineRateLimitStore
import su.spyme.marketplace.core.ratelimit.RateLimitStore
import java.time.Duration

/**
 * Dispatches inbound bot events: host [handlers] first (in order), then the
 * built-in commands:
 *
 *  - `/start [arg]` - `arg` may be a login/link code (Telegram deep link
 *    `?start=<code>`); otherwise greets a known user or registers a new one.
 *  - `/login` - issues a code to type on the site.
 *  - `/help`, `/menu`.
 *  - a bare `AC-XXXXXX` / `LK-XXXXXX` message - the same as `/start <code>`.
 *
 * Unknown commands are ignored silently (anti-spam). Each messenger user gets
 * [RATE_PERMITS] events per minute; the rest are dropped.
 */
class BotRouter(
    private val auth: BotAuthService,
    private val handlers: List<BotCommandHandler> = emptyList(),
    private val messages: BotMessages = BotMessages(),
    private val rateLimits: RateLimitStore = CaffeineRateLimitStore(),
) {
    private val log = LoggerFactory.getLogger(BotRouter::class.java)

    /** Entry point wired into the transport adapters as `onEvent`. */
    suspend fun handle(event: BotEvent) {
        val key = "bot:${event.platform.code}:${event.platformUserId}"
        if (!rateLimits.tryAcquire(key, RATE_PERMITS, Duration.ofMinutes(1)).allowed) return
        try {
            // Any contact backfills a missing display name (cheap: one cached user read).
            auth.findUserId(event.platform, event.platformUserId)?.let { auth.fillDisplayName(it, event) }
            if (handlers.any { it.handle(event, auth) }) return
            if (event is BotEvent.Message) builtIn(event)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            log.error("bot command failed", e)
            runCatching { event.reply(messages.error) }
        }
    }

    private suspend fun builtIn(event: BotEvent.Message) {
        val text = event.text
        if (BotAuthService.CODE_PATTERN.matches(text)) return acceptCode(event, text)
        if (!text.startsWith("/")) return
        val parts = text.split(Regex("\\s+"))
        // Telegram appends @BotName to commands in group chats.
        val command = parts[0].substringBefore("@").lowercase()
        when (command) {
            "/start" -> {
                val arg = parts.getOrNull(1)
                if (arg != null && BotAuthService.CODE_PATTERN.matches(arg)) acceptCode(event, arg) else start(event)
            }
            "/login" -> login(event)
            "/help", "/menu" -> event.reply(messages.help)
        }
    }

    private suspend fun start(event: BotEvent.Message) {
        val known = auth.findUserId(event.platform, event.platformUserId)
        val userId = known ?: auth.findOrRegister(event)
        if (userId == null) {
            event.reply(messages.notLinked)
            return
        }
        val username = auth.greetingName(userId)
        event.reply((if (known != null) messages.welcomeBack else messages.welcomeNew).replace("{username}", username))
    }

    private suspend fun login(event: BotEvent.Message) {
        when (val issued = auth.issueLoginCode(event.platform, event.platformUserId)) {
            is LoginCodeIssue.Issued -> event.replyCode(
                messages.loginCode.replace("{minutes}", auth.config.loginCodeTtlMinutes.toString()),
                issued.code.code,
            )
            LoginCodeIssue.NotLinked -> event.reply(messages.notLinked)
        }
    }

    /** `AC-` codes confirm a site login, `LK-` codes link the account. */
    private suspend fun acceptCode(event: BotEvent.Message, code: String) {
        if (code.startsWith(BotAuthService.LINK_PREFIX, ignoreCase = true)) {
            event.reply(
                when (val r = auth.redeemLinkCode(code, event)) {
                    is LinkResult.Linked -> messages.linked.replace("{username}", r.username)
                    is LinkResult.Merged -> messages.merged.replace("{username}", r.username)
                    LinkResult.InvalidCode -> messages.invalidCode
                    LinkResult.ExpiredCode -> messages.expiredCode
                    LinkResult.AlreadyLinked -> messages.alreadyLinked
                    LinkResult.AccountTaken -> messages.accountTaken
                },
            )
        } else {
            event.reply(
                when (val r = auth.confirmWebLogin(code, event)) {
                    is WebLoginConfirm.Confirmed -> messages.loginConfirmed.replace("{username}", r.username)
                    WebLoginConfirm.InvalidCode -> messages.invalidCode
                    WebLoginConfirm.ExpiredCode -> messages.expiredCode
                    WebLoginConfirm.NotLinked -> messages.notLinked
                },
            )
        }
    }

    private companion object {
        const val RATE_PERMITS = 10
    }
}
