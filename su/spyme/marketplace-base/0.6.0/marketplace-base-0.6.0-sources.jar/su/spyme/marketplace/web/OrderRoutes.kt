package su.spyme.marketplace.web

import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.routing.Route
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import su.spyme.marketplace.cart.CartOwner
import su.spyme.marketplace.orders.Order
import su.spyme.marketplace.orders.state.TransitionActor

/** Bundles the per-deps helpers the route files share. */
internal class WebContext(deps: StorefrontDeps) {
    val sessions = Sessions(deps)
    val views = OrderViews(deps)
    val checkout = Checkout(deps)
}

/**
 * Buyer-side order endpoints: place from the cart, list, detail, cancel,
 * reorder. Another user's order is a plain 404 (never 403) so ids cannot be probed.
 */
fun Route.orderRoutes(deps: StorefrontDeps) {
    val web = deps.web

    endpoint(HttpMethod.Post, "/api/orders") {
        val user = web.sessions.requireUser(this)
        val placed = web.checkout.place(user.id, parseCheckout(jsonBody()))
        val body = web.views.json(placed.order)
        respondJson(HttpStatusCode.Created, JsonObject(body + ("redirectUrl" to (placed.redirectUrl.toJson()))))
    }

    endpoint(HttpMethod.Get, "/api/orders") {
        val user = web.sessions.requireUser(this)
        val (offset, limit) = page()
        val all = deps.orders.listForUser(user.id)
        respondJson(pageJson(all.drop(offset).take(limit).map { web.views.json(it) }, all.size.toLong(), offset, limit))
    }

    endpoint(HttpMethod.Get, "/api/orders/{id}") {
        respondJson(web.views.json(ownOrder(deps, this)))
    }

    endpoint(HttpMethod.Post, "/api/orders/{id}/cancel") {
        val order = ownOrder(deps, this)
        val reason = jsonBody().str("reason")
        val cancelled = web.checkout.cancel(order, TransitionActor.USER, order.userId, reason, "USER_REQUESTED")
        respondJson(web.views.json(cancelled))
    }

    endpoint(HttpMethod.Post, "/api/orders/{id}/reorder") {
        val order = ownOrder(deps, this)
        web.checkout.reorder(order.userId, order)
        respondJson(deps.cartJson(CartOwner.User(order.userId)))
    }
}

private fun ownOrder(deps: StorefrontDeps, call: ApplicationCall): Order {
    val user = deps.web.sessions.requireUser(call)
    return call.parameters["id"]?.toLongOrNull()
        ?.let { deps.orders.findById(it) }
        ?.takeIf { it.userId == user.id }
        ?: throw notFound("ORDER_NOT_FOUND")
}

private fun parseCheckout(body: JsonObject): CheckoutRequest {
    val contact = body.obj("contact") ?: throw badRequest("CONTACT_REQUIRED", "contact is required")
    val name = contact.str("name")?.trim().orEmpty()
    val phone = contact.str("phone")?.trim().orEmpty()
    if (name.isEmpty() || phone.isEmpty()) throw badRequest("CONTACT_REQUIRED", "contact.name and contact.phone are required")
    if (name.length > 200 || phone.length > 40) throw badRequest("CONTACT_INVALID", "contact is too long")

    val address = body.obj("deliveryAddress")
    val comment = body.str("comment")?.trim()?.takeIf { it.isNotEmpty() }
    if ((comment?.length ?: 0) > 1000) throw badRequest("COMMENT_TOO_LONG", "comment is too long")

    return CheckoutRequest(
        paymentProvider = body.str("paymentProvider") ?: throw badRequest("PAYMENT_PROVIDER_REQUIRED", "paymentProvider is required"),
        deliveryMethod = body.str("deliveryMethod") ?: throw badRequest("DELIVERY_METHOD_REQUIRED", "deliveryMethod is required"),
        contact = buildJsonObject { put("name", name); put("phone", phone) },
        address = address,
        comment = comment,
    )
}
