package su.spyme.marketplace.web

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.SqlExpressionBuilder.inList
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import su.spyme.marketplace.orders.BaseOrderCheckoutDetailsTable
import su.spyme.marketplace.orders.BaseOrderItemSnapshotsTable
import su.spyme.marketplace.orders.BaseOrderStatusHistoryTable
import su.spyme.marketplace.orders.Order
import su.spyme.marketplace.orders.state.OrderStatus
import su.spyme.marketplace.orders.state.TransitionActor
import su.spyme.marketplace.users.User

/** Builds the `Order` JSON of the storefront contract from the order tables. */
internal class OrderViews(private val deps: StorefrontDeps) {

    /**
     * @param customer when given, adds `customer: {id, name}` (admin lists).
     * @param actor whose point of view `allowedTransitions` is computed from: the
     *        statuses the order's state machine lets this actor move it to right now.
     */
    fun json(order: Order, customer: User? = null, actor: TransitionActor = TransitionActor.USER): JsonObject {
        val machine = deps.orders.stateMachineFor(order)
        val items = deps.orders.listItems(order.id)
        val snapshots = transaction(deps.mainDb) {
            BaseOrderItemSnapshotsTable.selectAll()
                .where { BaseOrderItemSnapshotsTable.orderItemId inList items.map { it.id } }
                .associate { it[BaseOrderItemSnapshotsTable.orderItemId] to it[BaseOrderItemSnapshotsTable.snapshotMeta] }
        }
        val details = transaction(deps.mainDb) {
            BaseOrderCheckoutDetailsTable.selectAll().where { BaseOrderCheckoutDetailsTable.orderId eq order.id }.firstOrNull()
        }
        val history = transaction(deps.mainDb) {
            BaseOrderStatusHistoryTable.selectAll()
                .where { BaseOrderStatusHistoryTable.orderId eq order.id }
                .orderBy(BaseOrderStatusHistoryTable.id)
                .toList()
        }
        val payment = deps.payments.listForOrder(order.id).lastOrNull()
        val reason = order.cancellationReasonCode?.let { deps.cancellationReasons.getOrNull(it) }

        return buildJsonObject {
            put("id", order.id)
            put("number", order.orderNumber)
            put("createdAt", order.placedAt.toJson())
            put("status", order.status.name)
            put("displayStatus", deps.orders.deriveDisplayStatus(order).name)
            put("items", JsonArray(items.map { item ->
                val snap = snapshots[item.id] as? JsonObject
                buildJsonObject {
                    put("id", item.id)
                    put("productId", item.productId)
                    put("variantId", item.variantId)
                    put("slug", snap?.str("slug"))
                    put("title", snap?.str("title"))
                    put("imageUrl", snap?.str("imageUrl"))
                    put("quantity", item.quantity)
                    put("unitPrice", item.unitPrice.toJson())
                    put("lineTotal", item.lineTotal.toJson())
                    put("snapshot", snap ?: JsonNull)
                }
            }))
            put("subtotal", order.subtotal.toJson())
            put("deliveryPrice", order.shipping.toJson())
            put("total", order.total.toJson())
            put("deliveryMethod", details?.let {
                buildJsonObject {
                    put("code", it[BaseOrderCheckoutDetailsTable.deliveryMethodCode])
                    put("title", it[BaseOrderCheckoutDetailsTable.deliveryMethodTitle])
                }
            } ?: JsonNull)
            put("deliveryAddress", order.shippingAddress ?: JsonNull)
            put("contact", details?.get(BaseOrderCheckoutDetailsTable.contact) ?: JsonNull)
            put("comment", details?.get(BaseOrderCheckoutDetailsTable.comment))
            put("payment", payment?.let {
                buildJsonObject {
                    put("provider", it.provider)
                    put("title", deps.gateways.getOrNull(it.provider)?.title ?: it.provider)
                    put("status", it.status.name)
                }
            } ?: JsonNull)
            put("shipments", JsonArray(deps.shipping.listShipmentsForOrder(order.id).map { s ->
                buildJsonObject {
                    put("status", s.status.name)
                    put("trackingNumber", s.trackingNumber)
                    put("carrier", s.carrierId?.let { deps.shipping.loadCarrierById(it)?.name })
                }
            }))
            put("refunds", JsonArray(deps.refunds.listForOrder(order.id).map { r ->
                buildJsonObject {
                    put("id", r.id)
                    put("amount", r.money.toJson())
                    put("status", r.status.name)
                    put("createdAt", r.createdAt.toJson())
                }
            }))
            put("history", JsonArray(
                listOf<JsonElement>(buildJsonObject {
                    put("status", OrderStatus.NEW.name)
                    put("at", order.placedAt.toJson())
                    put("actor", TransitionActor.USER.name)
                }) + history.map { h ->
                    buildJsonObject {
                        put("status", h[BaseOrderStatusHistoryTable.toStatus])
                        put("at", h[BaseOrderStatusHistoryTable.occurredAt].toJson())
                        put("actor", h[BaseOrderStatusHistoryTable.actor])
                    }
                },
            ))
            put("allowedTransitions", JsonArray(
                machine.nextStates(order.status).filter { machine.canTransition(order.status, it, actor) }
                    .sortedBy { it.ordinal }.map { JsonPrimitive(it.name) },
            ))
            put("canCancel", canCancel(order))
            put("canReorder", reason?.blocksReorder != true)
            if (customer != null) {
                put("customer", buildJsonObject { put("id", customer.id); put("name", customer.username) })
            }
        }
    }

    /** Whether the buyer themself may cancel now (the order's machine allows `USER` the edge). */
    fun canCancel(order: Order): Boolean =
        !order.status.isTerminal &&
            deps.orders.stateMachineFor(order).canTransition(order.status, OrderStatus.CANCELLED, TransitionActor.USER)
}
