-- V046 — users.display_name: the name shown to people (first name from the
-- messenger, editable by the user). `username` stays the unique login handle.

ALTER TABLE users ADD COLUMN display_name VARCHAR(100) NULL;

-- One-off backfill: the first word of the messenger label stored on the user's
-- earliest social link ("Anton Krayushkin" -> "Anton"). Handles ("@nick") are skipped.
UPDATE users u
SET display_name = left(split_part(btrim(s.display_name), ' ', 1), 100)
FROM (
    SELECT DISTINCT ON (user_id) user_id, display_name
    FROM social_links
    WHERE btrim(coalesce(display_name, '')) <> '' AND btrim(display_name) NOT LIKE '@%'
    ORDER BY user_id, id
) s
WHERE s.user_id = u.id AND u.display_name IS NULL;
