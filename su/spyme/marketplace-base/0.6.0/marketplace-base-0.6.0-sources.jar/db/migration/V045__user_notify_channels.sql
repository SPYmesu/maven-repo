-- V045 — per-user notification channel preferences.
--
-- Codes the storefront uses: site, tg, vk, email. Order is the user's
-- priority order. A user without a row defaults to {site}.

CREATE TABLE user_notify_channels (
    user_id     BIGINT        PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    channels    VARCHAR(16)[] NOT NULL DEFAULT ARRAY['site']::VARCHAR(16)[],
    updated_at  TIMESTAMP     NOT NULL DEFAULT NOW()
);
