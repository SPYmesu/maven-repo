-- V043 — read marker for in-app notifications.
--
-- The storefront lists a user's `in-app` notifications and lets them mark
-- them read. Other channels never look at the column.

ALTER TABLE notifications ADD COLUMN read_at TIMESTAMP NULL;

-- "Unread badge" lookup.
CREATE INDEX notifications_user_unread_idx
    ON notifications (user_id)
    WHERE channel = 'in-app' AND read_at IS NULL;
