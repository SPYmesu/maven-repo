-- V047 — account merge: a user folded into another keeps its row (soft-deleted)
-- and points at the survivor. Merged users never resolve for login, OTP or bot lookups.

ALTER TABLE users ADD COLUMN merged_into_user_id BIGINT NULL REFERENCES users(id) ON DELETE SET NULL;

CREATE INDEX users_merged_into_idx ON users (merged_into_user_id) WHERE merged_into_user_id IS NOT NULL;
