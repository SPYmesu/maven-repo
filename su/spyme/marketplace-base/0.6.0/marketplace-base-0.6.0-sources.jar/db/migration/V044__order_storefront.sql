-- V044 — storefront side-tables for orders.
--
-- order_checkout_details — what the buyer entered at checkout that `orders`
--   has no column for: chosen delivery method, contact and a free comment.
--   (The delivery address itself lives in `orders.shipping_address`.)
-- order_status_history   — one row per status transition, written by the
--   storefront's OrderTransitionListener; backs the order timeline.

CREATE TABLE order_checkout_details (
    order_id              BIGINT       PRIMARY KEY REFERENCES orders(id) ON DELETE CASCADE,
    delivery_method_code  VARCHAR(32)  NOT NULL,
    delivery_method_title TEXT         NOT NULL,
    contact               JSONB        NOT NULL,
    comment               TEXT         NULL,
    created_at            TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE order_status_history (
    id             BIGSERIAL    PRIMARY KEY,
    order_id       BIGINT       NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    from_status    VARCHAR(32)  NOT NULL,
    to_status      VARCHAR(32)  NOT NULL,
    actor          VARCHAR(32)  NOT NULL,
    actor_user_id  BIGINT       NULL,
    reason         TEXT         NULL,
    occurred_at    TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX order_status_history_order_idx ON order_status_history (order_id, id);
