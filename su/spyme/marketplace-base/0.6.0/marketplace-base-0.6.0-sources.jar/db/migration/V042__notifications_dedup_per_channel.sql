-- V042 — notification dedup is per (dedup_key, channel).
--
-- V016 made dedup_key unique on its own, so an event fanned out to several
-- channels kept only the first row and silently lost the others. The new
-- index is strictly weaker (every row set valid under the old one is valid
-- under the new one), so it applies safely to existing data.

DROP INDEX IF EXISTS notifications_dedup_idx;

CREATE UNIQUE INDEX notifications_dedup_idx
    ON notifications (dedup_key, channel)
    WHERE dedup_key IS NOT NULL;
